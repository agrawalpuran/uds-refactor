import mongoose, { Schema, Document } from 'mongoose'

export interface IProductFeedback extends Document {
  orderId: string // Order ID reference
  productId: string // Product/Uniform ID
  uniformId?: string // String ID reference to Uniform (6-digit numeric string)
  employeeId: string // String ID reference to Employee (6-digit numeric string)
  employeeIdNum: string // Numeric employee ID for correlation
  companyId: string // String ID reference to Company (6-digit numeric string)
  companyIdNum: number // Numeric company ID for correlation
  vendorId?: string // String ID reference to Vendor (6-digit numeric string)
  rating: number // Rating from 1 to 5
  comment?: string // Optional feedback comment
  viewedBy?: string[] // Array of admin emails who have viewed this feedback
  viewedAt?: Date // Timestamp when feedback was first viewed by any admin
  createdAt?: Date
  updatedAt?: Date
}

const ProductFeedbackSchema = new Schema<IProductFeedback>(
  {
    orderId: {
      type: String,
      required: true,
      index: true,
    },
    productId: {
      type: String,
      required: true,
      // Index created via compound index below - don't use index: true here
    },
    uniformId: {
      type: String,
      required: false,
      validate: {
        validator: function(v: string) {
          return !v || /^\d{6}$/.test(v)
        },
        message: 'Uniform ID must be a 6-digit numeric string (e.g., "200001")'
      }
    },
    employeeId: {
      type: String,
      required: true,
      validate: {
        validator: function(v: string) {
          return /^\d{6}$/.test(v)
        },
        message: 'Employee ID must be a 6-digit numeric string (e.g., "300001")'
      }
    },
    employeeIdNum: {
      type: String,
      required: true,
      index: true,
    },
    companyId: {
      type: String,
      required: true,
      validate: {
        validator: function(v: string) {
          return /^\d{6}$/.test(v)
        },
        message: 'Company ID must be a 6-digit numeric string (e.g., "100001")'
      }
    },
    companyIdNum: {
      type: Number,
      required: true,
      index: true,
    },
    vendorId: {
      type: String,
      required: false,
      validate: {
        validator: function(v: string) {
          return !v || /^\d{6}$/.test(v)
        },
        message: 'Vendor ID must be a 6-digit numeric string (e.g., "100001")'
      }
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
      validate: {
        validator: Number.isInteger,
        message: 'Rating must be an integer between 1 and 5',
      },
    },
    comment: {
      type: String,
      maxlength: 2000,
    },
    viewedBy: {
      type: [String],
      default: [],
      index: true,
    },
    viewedAt: {
      type: Date,
      index: true,
    },
  },
  {
    timestamps: true,
  }
)

// Compound indexes for efficient queries
ProductFeedbackSchema.index({ employeeId: 1, companyId: 1 })
// Unique constraint: one feedback per product per order per employee
ProductFeedbackSchema.index({ orderId: 1, productId: 1, employeeId: 1 }, { unique: true })
ProductFeedbackSchema.index({ productId: 1, vendorId: 1 })
ProductFeedbackSchema.index({ companyId: 1, createdAt: -1 })

const ProductFeedback = mongoose.models.ProductFeedback || mongoose.model<IProductFeedback>('ProductFeedback', ProductFeedbackSchema)

export default ProductFeedback

