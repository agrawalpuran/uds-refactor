import mongoose, { Schema, Document } from 'mongoose'

export interface IPurchaseOrder extends Document {
  id: string // Unique identifier (numeric/string)
  companyId: mongoose.Types.ObjectId // FK to Company
  vendorId: string // Vendor numeric ID (6-digit string, e.g., "100001")
  client_po_number: string // Client/customer generated PO number (NOT unique - can repeat)
  po_date: Date // Date PO was created
  po_status: 'CREATED' | 'SENT_TO_VENDOR' | 'ACKNOWLEDGED' | 'IN_FULFILMENT' | 'COMPLETED' | 'CANCELLED' // PO status
  created_by_user_id: mongoose.Types.ObjectId // User who created the PO (ref: Employee)
  createdAt?: Date
  updatedAt?: Date
}

const PurchaseOrderSchema = new Schema<IPurchaseOrder>(
  {
    id: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    companyId: {
      type: Schema.Types.ObjectId,
      ref: 'Company',
      required: true,
      index: true,
    },
    vendorId: {
      type: String,
      required: true,
      index: true,
      validate: {
        validator: function(v: string) {
          // Must be exactly 6 digits
          return /^\d{6}$/.test(v)
        },
        message: 'Vendor ID must be a 6-digit numeric string (e.g., "100001")'
      }
    },
    client_po_number: {
      type: String,
      required: true,
      trim: true,
      maxlength: 50,
      // NOT unique - PO numbers can repeat (business requirement)
      index: true, // Non-unique index for querying, but NOT unique constraint
    },
    po_date: {
      type: Date,
      required: true,
      default: Date.now,
    },
    po_status: {
      type: String,
      enum: ['CREATED', 'SENT_TO_VENDOR', 'ACKNOWLEDGED', 'IN_FULFILMENT', 'COMPLETED', 'CANCELLED'],
      default: 'CREATED',
      required: true,
      index: true,
    },
    created_by_user_id: {
      type: Schema.Types.ObjectId,
      ref: 'Employee',
      required: true,
      index: true,
    },
  },
  {
    timestamps: true,
  }
)

// Compound indexes
// NOTE: Removed unique constraint on (companyId, client_po_number) - PO numbers can repeat per business requirement
PurchaseOrderSchema.index({ companyId: 1, client_po_number: 1 }) // Non-unique index for querying PO numbers by company
PurchaseOrderSchema.index({ companyId: 1, po_status: 1 }) // Compound index for PO status queries by company
PurchaseOrderSchema.index({ vendorId: 1, po_status: 1 }) // Compound index for PO status queries by vendor
PurchaseOrderSchema.index({ po_date: -1 }) // Index for date-based queries

const PurchaseOrder = mongoose.models.PurchaseOrder || mongoose.model<IPurchaseOrder>('PurchaseOrder', PurchaseOrderSchema)

export default PurchaseOrder

