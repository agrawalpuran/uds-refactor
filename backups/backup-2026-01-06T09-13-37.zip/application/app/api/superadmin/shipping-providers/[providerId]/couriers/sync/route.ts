import { NextResponse } from 'next/server'
import { getShipmentServiceProviderById, getProviderWithAuth } from '@/lib/db/shipping-config-access'
import { getProviderInstance } from '@/lib/providers/ProviderFactory'
import '@/lib/models/ShipmentServiceProvider'

/**
 * GET /api/superadmin/shipping-providers/[providerId]/couriers/sync
 * Fetch available couriers from the provider API and return normalized list
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ providerId: string }> | { providerId: string } }
) {
  try {
    // Handle both Promise and direct params (Next.js 15 compatibility)
    const resolvedParams = params instanceof Promise ? await params : params
    const { providerId } = resolvedParams

    if (!providerId) {
      return NextResponse.json(
        { error: 'providerId is required' },
        { status: 400 }
      )
    }

    // Get provider by providerId first to get providerRefId
    const provider = await getShipmentServiceProviderById(providerId, true) // Include auth for internal use
    if (!provider) {
      return NextResponse.json(
        { error: 'Provider not found' },
        { status: 404 }
      )
    }

    if (!provider.providerRefId) {
      return NextResponse.json(
        { error: 'Provider Ref ID not found. Please ensure provider has been migrated.' },
        { status: 400 }
      )
    }

    if (!provider.authConfig) {
      return NextResponse.json(
        { error: 'Provider authentication not configured' },
        { status: 400 }
      )
    }

    // Get provider with decrypted authConfig
    const providerWithAuth = await getProviderWithAuth(provider.providerRefId)
    if (!providerWithAuth || !providerWithAuth.authConfig) {
      return NextResponse.json(
        { error: 'Provider authentication not configured' },
        { status: 400 }
      )
    }

    // Get provider instance using stored authConfig
    const providerInstance = await getProviderInstance(provider.providerCode)

    // Check if provider supports courier listing
    if (!providerInstance.getSupportedCouriers) {
      return NextResponse.json(
        { 
          error: 'Courier listing not supported by this provider',
          supported: false,
        },
        { status: 400 }
      )
    }

    // Fetch couriers from provider
    const result = await providerInstance.getSupportedCouriers()

    if (!result.success || !result.couriers) {
      return NextResponse.json(
        {
          error: result.error || 'Failed to fetch couriers',
          supported: true,
        },
        { status: 500 }
      )
    }

    // Normalize couriers to UDS format
    const normalizedCouriers = result.couriers.map((courier) => ({
      courierCode: courier.courierCode,
      courierName: courier.courierName,
      serviceTypes: courier.serviceTypes || [],
      isActive: courier.isActive ?? true, // Default to active for new couriers
      source: 'API_SYNC' as const,
      lastSyncedAt: new Date(),
    }))

    return NextResponse.json({
      success: true,
      couriers: normalizedCouriers,
      count: normalizedCouriers.length,
      providerCode: provider.providerCode,
      providerName: provider.providerName,
    })
  } catch (error: any) {
    console.error('API Error in /api/superadmin/shipping-providers/[providerId]/couriers/sync GET:', error)
    return NextResponse.json(
      {
        error: error.message || 'Unknown error occurred',
        type: 'api_error',
      },
      { status: 500 }
    )
  }
}

