/**
 * MongoDB Data Access Layer
 * This file contains all database query functions
 */

import connectDB from './mongodb'
import mongoose from 'mongoose'
// Import Branch first to ensure it's registered before Employee uses it
import Branch from '../models/Branch'
import Uniform, { IUniform } from '../models/Uniform'
import Vendor, { IVendor } from '../models/Vendor'
import Company, { ICompany } from '../models/Company'
import Employee, { IEmployee } from '../models/Employee'
import Order, { IOrder } from '../models/Order'
import CompanyAdmin from '../models/CompanyAdmin'
import Location from '../models/Location'
import LocationAdmin from '../models/LocationAdmin'
import { ProductCompany, ProductVendor } from '../models/Relationship'
// VendorCompany relationships are now derived from ProductCompany + ProductVendor
// No need to import VendorCompany model
import DesignationProductEligibility from '../models/DesignationProductEligibility'
import DesignationSubcategoryEligibility from '../models/DesignationSubcategoryEligibility'
import Subcategory from '../models/Subcategory'
import ProductSubcategoryMapping from '../models/ProductSubcategoryMapping'
import VendorInventory from '../models/VendorInventory'
import ProductFeedback from '../models/ProductFeedback'
import ReturnRequest from '../models/ReturnRequest'
import ProductSizeChart from '../models/ProductSizeChart'
// Ensure Category model is registered (required by Subcategory)
import Category from '../models/Category'
import ProductCategory from '../models/ProductCategory'
// Indent workflow models
import IndentHeader from '../models/IndentHeader'
import VendorIndent from '../models/VendorIndent'
import OrderSuborder from '../models/OrderSuborder'
import GoodsReceiptNote from '../models/GoodsReceiptNote'
import VendorInvoice from '../models/VendorInvoice'
import Payment from '../models/Payment'
import PurchaseOrder from '../models/PurchaseOrder'
import POOrder from '../models/POOrder'
import GRN from '../models/GRN'
import Invoice from '../models/Invoice'
import SystemShippingConfig from '../models/SystemShippingConfig'
import ShipmentServiceProvider from '../models/ShipmentServiceProvider'
import CompanyShippingProvider from '../models/CompanyShippingProvider'
import { getCurrentCycleDates, isDateInCurrentCycle } from '../utils/eligibility-cycles'
import {
  getCategoriesByCompany,
  getCategoryByIdOrName,
  getProductCategoryId,
  getProductCategoryName,
  normalizeCategoryName,
  ensureSystemCategories
} from './category-helpers'

// Ensure Branch model is registered
if (!mongoose.models.Branch) {
  require('../models/Branch')
}

// Ensure Category model is registered (required by Subcategory and other models)
if (!mongoose.models.Category) {
  require('../models/Category')
}

/**
 * Helper function to get Company by ID (handles both ObjectId and string ID)
 * This is the single source of truth for company lookups
 */
async function getCompanyByIdSafe(companyId: any): Promise<any> {
  if (!companyId) {
    return null
  }
  
  // If it's already a string ID (6 digits), use it directly
  if (typeof companyId === 'string' && /^\d{6}$/.test(companyId)) {
    return await Company.findOne({ id: companyId })
  }
  
  // All company IDs are string IDs - no ObjectId conversion needed
  
  // Fallback: try as string ID
  if (typeof companyId === 'string') {
    return await Company.findOne({ id: companyId })
  }
  
  return null
}

/**
 * Helper function to convert companyId from ObjectId to numeric ID
 * This is the single source of truth for companyId conversion
 */
async function convertCompanyIdToNumericId(companyIdObjectId: any): Promise<string | null> {
  if (!companyIdObjectId) {
    console.warn(`[convertCompanyIdToNumericId] ⚠️ Input is null or undefined`)
    return null
  }
  
  const db = mongoose.connection.db
  if (!db) {
    console.error(`[convertCompanyIdToNumericId] ❌ Database connection not available`)
    return null
  }
  
  try {
    // Convert to string if it's an ObjectId
    const companyIdStr = companyIdObjectId.toString()
    
    // Check if it's already a numeric ID (6 digits)
    if (/^\d{6}$/.test(companyIdStr)) {
      return companyIdStr
    }
    
    // For non-numeric IDs, look up the company by string ID
    console.log(`[convertCompanyIdToNumericId] 🔍 Looking up company with ID: ${companyIdStr}`)
    const companyDoc = await db.collection('companies').findOne({
      id: companyIdStr
    })
    
    if (!companyDoc) {
      console.error(`[convertCompanyIdToNumericId] ❌ Company not found for ID: ${companyIdStr}`)
      console.error(`   This means the employee's companyId doesn't match any company in the database`)
      console.error(`   💡 Fix: Check if company exists or employee companyId needs to be updated`)
      return null
    }
    
    if (!companyDoc.id) {
      console.error(`[convertCompanyIdToNumericId] ❌ Company found but missing 'id' field!`)
      console.error(`   Company name: ${companyDoc.name || 'N/A'}`)
      console.error(`   💡 Fix: Run scripts/fix-company-ids.js to add missing id fields`)
      return null
    }
    
    console.log(`[convertCompanyIdToNumericId] ✅ Successfully found company ID: ${companyDoc.id}`)
    return String(companyDoc.id)
  } catch (error: any) {
    console.error(`[convertCompanyIdToNumericId] ❌ Error converting companyId:`, error.message)
    console.error(`   Input: ${companyIdObjectId}`)
    console.error(`   Input type: ${typeof companyIdObjectId}`)
    if (error.stack) {
      console.error(`   Stack:`, error.stack)
    }
    return null
  }
}

// Helper to convert MongoDB document to plain object
function toPlainObject(doc: any): any {
  if (!doc) return null
  if (Array.isArray(doc)) {
    return doc.map((d) => toPlainObject(d))
  }
  const obj = doc.toObject ? doc.toObject() : doc
  // Ensure id field exists - use string ID field as primary identifier
  // Remove internal _id field (MongoDB ObjectId) from output
  if (obj._id && !obj.id) {
    // Fallback: Only set id from _id if id doesn't already exist
    obj.id = String(obj._id)
  }
  delete obj._id
  // Convert ObjectIds in arrays to strings
  if (obj.companyIds && Array.isArray(obj.companyIds)) {
    obj.companyIds = obj.companyIds.map((id: any) => {
      if (id && typeof id === 'object' && id.id) {
        return id.id // If populated, use the id field
      }
      return id.toString()
    })
  }
  // vendorId removed from Uniform model - use ProductVendor collection instead
  // branchId and branchName removed - use locationId instead
  // Handle companyId - if it's null, don't process it (will be fixed in getEmployeeByEmail)
  // If it exists, convert it properly
  if (obj.companyId !== null && obj.companyId !== undefined) {
    // Handle populated companyId (object with id and name) or ObjectId
    if (obj.companyId && typeof obj.companyId === 'object') {
      if (obj.companyId.id) {
        // Populated object - use the id field (this is the company's string 'id' field like 'COMP-INDIGO')
        obj.companyId = obj.companyId.id
      } else if (obj.companyId._id) {
        // Populated object with _id but no id field - this shouldn't happen if populate worked correctly
        // Keep as _id string for now, will be converted in getEmployeeByEmail
        obj.companyId = obj.companyId._id.toString()
      } else if (obj.companyId.toString) {
        // ObjectId - convert to string, will be converted to company string ID in getEmployeeByEmail
        obj.companyId = obj.companyId.toString()
      }
    } else if (typeof obj.companyId === 'string') {
      // Already a string - check if it's an ObjectId string (24 hex chars) or company string ID
      // If it's an ObjectId string, it will be converted in getEmployeeByEmail
      // If it's already a company string ID (like 'COMP-INDIGO'), keep it
      obj.companyId = obj.companyId
    }
  }
  // Note: If companyId is null, we leave it as null - getEmployeeByEmail will fix it from raw document
  if (obj.employeeId) {
    if (obj.employeeId && typeof obj.employeeId === 'object' && obj.employeeId.id) {
      obj.employeeId = obj.employeeId.id
    } else {
      obj.employeeId = obj.employeeId.toString()
    }
  }
  if (obj.items && Array.isArray(obj.items)) {
    obj.items = obj.items.map((item: any) => ({
      ...item,
      uniformId: item.uniformId?.toString() || (item.uniformId?.id || item.uniformId),
      productId: item.productId || item.uniformId?.id || item.uniformId?.toString(), // Ensure productId is included
      // Ensure price and quantity are preserved as numbers
      price: typeof item.price === 'number' ? item.price : parseFloat(item.price) || 0,
      quantity: typeof item.quantity === 'number' ? item.quantity : parseInt(item.quantity) || 0,
    }))
  }
  // Ensure numeric IDs are included in order objects
  if (obj.employeeIdNum !== undefined) {
    obj.employeeIdNum = obj.employeeIdNum
  }
  if (obj.companyIdNum !== undefined) {
    obj.companyIdNum = typeof obj.companyIdNum === 'number' ? obj.companyIdNum : Number(obj.companyIdNum) || obj.companyIdNum
  }
  // Handle vendorId population - ensure vendorName is available
  if (obj.vendorId) {
    if (typeof obj.vendorId === 'object' && obj.vendorId !== null) {
      // Populated vendorId - preserve the object but also ensure vendorName is set
      if (obj.vendorId.name && !obj.vendorName) {
        obj.vendorName = obj.vendorId.name
      }
      // Keep vendorId as object for frontend access
    } else if (typeof obj.vendorId === 'string') {
      // vendorId is an ObjectId string - vendorName should be set during order creation
      // If not, we can't get it here without a lookup
    }
  }
  // Ensure total is preserved as a number
  if (obj.total !== undefined) {
    obj.total = typeof obj.total === 'number' ? obj.total : parseFloat(obj.total) || 0
  }
  // Explicitly preserve attribute fields (they should be preserved by default, but ensure they're included)
  // Attributes are optional fields, so preserve them if they exist
  if ('attribute1_name' in obj) obj.attribute1_name = obj.attribute1_name
  if ('attribute1_value' in obj) obj.attribute1_value = obj.attribute1_value
  if ('attribute2_name' in obj) obj.attribute2_name = obj.attribute2_name
  if ('attribute2_value' in obj) obj.attribute2_value = obj.attribute2_value
  if ('attribute3_name' in obj) obj.attribute3_name = obj.attribute3_name
  if ('attribute3_value' in obj) obj.attribute3_value = obj.attribute3_value
  // Explicitly preserve company settings boolean fields (ensure they're always included, even if false)
  // For company objects, always include these fields with defaults if missing
  if (obj.id && typeof obj.id === 'string' && /^\d{6}$/.test(obj.id)) {
    // This is a company object (has 6-digit numeric ID)
    // Always include boolean settings fields, defaulting to false if not present
    // BUT: Only default if the field truly doesn't exist (use 'in' operator, not !== undefined)
    // This is critical because a field can be explicitly set to false, which is different from undefined
    if (!('showPrices' in obj)) obj.showPrices = false
    if (!('allowPersonalPayments' in obj)) obj.allowPersonalPayments = false
    if (!('allowPersonalAddressDelivery' in obj)) obj.allowPersonalAddressDelivery = false
    // CRITICAL: Only default enableEmployeeOrder if it doesn't exist in the object
    // If it exists (even as false), preserve the actual value
    if (!('enableEmployeeOrder' in obj)) {
      obj.enableEmployeeOrder = false
    } else {
      // Field exists - ensure it's a boolean
      obj.enableEmployeeOrder = Boolean(obj.enableEmployeeOrder)
    }
  } else {
    // For other objects, preserve if they exist
    if ('showPrices' in obj) obj.showPrices = obj.showPrices
    if ('allowPersonalPayments' in obj) obj.allowPersonalPayments = obj.allowPersonalPayments
    if ('allowPersonalAddressDelivery' in obj) obj.allowPersonalAddressDelivery = obj.allowPersonalAddressDelivery
    if ('enableEmployeeOrder' in obj) obj.enableEmployeeOrder = Boolean(obj.enableEmployeeOrder)
  }
  return obj
}

// ========== UNIFORM/PRODUCT FUNCTIONS ==========

export async function getProductsByCompany(companyId: string | number): Promise<any[]> {
  await connectDB()
  
  if (!companyId && companyId !== 0) {
    console.warn('getProductsByCompany: companyId is empty or undefined')
    return []
  }
  
  // Convert companyId to number if it's a string representation of a number
  let numericCompanyId: number | null = null
  if (typeof companyId === 'string') {
    // Try to parse as number
    const parsed = Number(companyId)
    if (!isNaN(parsed) && isFinite(parsed)) {
      numericCompanyId = parsed
    }
  } else if (typeof companyId === 'number') {
    numericCompanyId = companyId
  }
  
  // Find company by numeric ID first (since company.id is now numeric)
  let company = null
  if (numericCompanyId !== null) {
    company = await Company.findOne({ id: numericCompanyId })
    if (company) {
      console.log(`getProductsByCompany: Found company by numeric ID: ${numericCompanyId} (${company.name})`)
    }
  }
  
  // If still not found, try as string ID (for backward compatibility)
  if (!company && typeof companyId === 'string') {
    company = await Company.findOne({ id: companyId })
    if (company) {
      console.log(`getProductsByCompany: Found company by string ID: ${companyId} (${company.name})`)
      numericCompanyId = company.id
    }
  }
  
  if (!company) {
    console.warn(`getProductsByCompany: Company not found for companyId: ${companyId} (type: ${typeof companyId})`)
    // List available companies for debugging
    const allCompanies = await Company.find({}, 'id name').limit(5).lean()
    console.warn(`getProductsByCompany: Available companies:`, allCompanies.map((c: any) => `${c.id} (${c.name})`))
    return []
  }

  // Only get products directly linked via ProductCompany relationship
  // Query using string ID (not ObjectId)
  const db = mongoose.connection.db
  if (!db) {
    console.warn('getProductsByCompany: Database connection not available')
    return []
  }
  
  const companyIdStr = company.id || ''
  // Query directly using string ID
  const productCompanyLinks = await db.collection('productcompanies').find({
    companyId: companyIdStr
  }).toArray()
  
  console.log(`getProductsByCompany: Found ${productCompanyLinks.length} ProductCompany relationships for company ${companyId} (${company.name || 'Unknown'})`)
  
  if (productCompanyLinks.length === 0) {
    console.warn(`getProductsByCompany: No ProductCompany relationships found for company ${companyId} (${company.name || 'Unknown'})`)
    console.warn(`  - This means products are not linked to this company via ProductCompany relationships`)
    return []
  }
  
  // Get product ObjectIds from the relationships (as strings for comparison)
  const productIdStrs = productCompanyLinks
    .map((link: any) => {
      if (!link.productId) return null
      return link.productId.toString ? link.productId.toString() : String(link.productId)
    })
    .filter((id: any) => id !== null && id !== undefined)
  
  if (productIdStrs.length === 0) {
    console.log(`No valid product IDs found in relationships for company ${companyId}`)
    return []
  }
  
  console.log(`getProductsByCompany: Looking for ${productIdStrs.length} products with IDs: ${productIdStrs.slice(0, 3).join(', ')}...`)

  // Fetch all products and filter by string comparison (most reliable)
  const allProducts = await db.collection('uniforms').find({}).toArray()
  const matchingProducts = allProducts.filter((p: any) => {
    const productIdStr = p.id || String(p._id || '')
    return productIdStrs.includes(productIdStr)
  })
  
  console.log(`getProductsByCompany: Found ${matchingProducts.length} products using string comparison`)
  
  if (matchingProducts.length === 0) {
    console.log(`getProductsByCompany: No products found. Sample product ids: ${matchingProducts.slice(0, 3).map((p: any) => p.id || p._id).join(', ')}`)
    return []
  }
  
  // Extract string IDs from matching products
  const productIds = matchingProducts.map((p: any) => p.id || String(p._id)).filter((id: string) => /^\d{6}$/.test(id))
  console.log(`getProductsByCompany: Querying ${productIds.length} products by id`)
  
  // Fetch products using string ID field
  const products = await Uniform.find({
    id: { $in: productIds },
  }).lean()
  
  // Manually populate vendorId since populate doesn't work with string IDs
  if (products.length > 0) {
    const vendorIds = [...new Set(products.map((p: any) => p.vendorId).filter(Boolean))]
    const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
    const vendorMap = new Map(vendors.map((v: any) => [v.id, v]))
    
    products.forEach((product: any) => {
      if (product.vendorId && vendorMap.has(product.vendorId)) {
        product.vendorId = vendorMap.get(product.vendorId)
      }
    })
  }

  console.log(`getProductsByCompany(${companyId}): Mongoose query returned ${products.length} products`)
  
  // If Mongoose query returns 0, use raw collection data as fallback
  let productsToUse = products
  if (!products || products.length === 0) {
    console.warn(`getProductsByCompany: Mongoose query returned 0 products, using raw collection data as fallback`)
    // Use the raw products we found earlier
    // First, get all vendors for population
    const allVendors = await db.collection('vendors').find({}).toArray()
    const vendorMap = new Map()
    allVendors.forEach((v: any) => {
      const vendorId = v.id || ''
      if (vendorId) vendorMap.set(vendorId, { id: vendorId, name: v.name })
    })
    
    // Use the raw products we found earlier - preserve ALL fields including attributes
    productsToUse = matchingProducts.map((p: any) => {
      const product: any = { 
        ...p,
        // Explicitly preserve attribute fields
        attribute1_name: p.attribute1_name,
        attribute1_value: p.attribute1_value,
        attribute2_name: p.attribute2_name,
        attribute2_value: p.attribute2_value,
        attribute3_name: p.attribute3_name,
        attribute3_value: p.attribute3_value,
      }
      // Use string id field - no ObjectId conversion needed
      // Ensure product has an id field
      if (!product.id && product._id) {
        product.id = String(product._id)
      }
      // vendorId removed from Uniform model - use ProductVendor collection instead
      return product
    })
  }
  
  // Filter products to only include those that have vendors linked for fulfillment
  // A product must have:
  // 1. A ProductVendor relationship (vendor supplies the product)
  // If product is linked to company and has vendors, it can be fulfilled
  
  if (productsToUse.length === 0) {
    return []
  }
  
  // Get all ProductVendor links for all products at once (using raw MongoDB)
  // Use the productIdStrs we already have from the ProductCompany relationships
  const allProductVendorLinks = await db.collection('productvendors').find({}).toArray()
  
  const productVendorLinks = allProductVendorLinks.filter((link: any) => {
    if (!link.productId) return false
    const linkProductIdStr = link.productId.toString ? link.productId.toString() : String(link.productId)
    return productIdStrs.includes(linkProductIdStr)
  })
  
  // Populate vendor details manually
  const allVendors = await db.collection('vendors').find({}).toArray()
  const vendorMap = new Map()
  allVendors.forEach((v: any) => {
    const vendorId = v.id || ''
    if (vendorId) vendorMap.set(vendorId, { id: vendorId, name: v.name })
  })
  
  // Enhance links with vendor details
  const enhancedProductVendorLinks = productVendorLinks.map((link: any) => {
    const vendorIdStr = link.vendorId?.id || String(link.vendorId || '')
    const vendor = vendorMap.get(vendorIdStr)
    return {
      productId: link.productId,
      vendorId: vendor ? { id: vendor.id, name: vendor.name } : null
    }
  })
  
  // Create a map of product ID -> set of vendor IDs that supply it
  const productVendorMap = new Map<string, Set<string>>()
  for (const pvLink of enhancedProductVendorLinks) {
    const productId = pvLink.productId?.id || String(pvLink.productId || '')
    const vendorId = pvLink.vendorId?.id || String(pvLink.vendorId || '')
    
    if (productId && vendorId && /^\d{6}$/.test(productId) && /^\d{6}$/.test(vendorId)) {
      if (!productVendorMap.has(productId)) {
        productVendorMap.set(productId, new Set())
      }
      productVendorMap.get(productId)!.add(vendorId)
    }
  }
  
  // Filter products: only include those that have at least one vendor that supplies the product
  // Check if there are ANY vendors in the system at all (not just for these products)
  const hasAnyVendorsInSystem = allVendors.length > 0
  
  const productsWithVendors = productsToUse.filter((product: any) => {
    const productIdStr = product.id || ''
    const vendorsForProduct = productVendorMap.get(productIdStr)
    
    // If no vendors exist in the system at all, show all products (for initial setup)
    if (!hasAnyVendorsInSystem) {
      console.log(`getProductsByCompany: No vendors in system, showing product ${product.id} (${product.name}) without vendor requirement`)
      return true
    }
    
    // If vendors exist in system, products MUST have vendors to be shown
    if (!vendorsForProduct || vendorsForProduct.size === 0) {
      console.log(`getProductsByCompany: Product ${product.id} (${product.name}) has no vendors linked - skipping (vendors exist in system)`)
      return false
    }
    
    // Product is linked to company and has vendors - it can be fulfilled
    return true
  })
  
  console.log(`getProductsByCompany(${companyId}): Filtered to ${productsWithVendors.length} products${hasAnyVendorsInSystem ? ' with vendors for fulfillment' : ' (no vendors in system, showing all)'}`)
  
  // Enhance products with all vendors that can fulfill them
  const enhancedProducts = productsWithVendors.map((product: any) => {
    const productIdStr = product.id || ''
    const vendorsForProduct = productVendorMap.get(productIdStr) || new Set()
    
    // Get all vendors that supply this product
    const availableVendors: any[] = []
    for (const vendorIdStr of vendorsForProduct) {
      // Find vendor details from enhancedProductVendorLinks
      const pvLink = enhancedProductVendorLinks.find((link: any) => {
        const linkProductId = link.productId?.id || String(link.productId || '')
        const linkVendorId = link.vendorId?.id || String(link.vendorId || '')
        return linkProductId === productIdStr && linkVendorId === vendorIdStr
      })
      if (pvLink && pvLink.vendorId) {
        availableVendors.push({
          id: pvLink.vendorId.id || String(pvLink.vendorId || ''),
          name: pvLink.vendorId.name || 'Unknown Vendor'
        })
      }
    }
    
    // Convert to plain object and add vendors array
    const plainProduct = toPlainObject(product)
    plainProduct.vendors = availableVendors
    // vendorId removed - use vendors array from ProductVendor collection instead
    // Explicitly preserve attribute fields (ensure they're included in response)
    if ((product as any).attribute1_name !== undefined) plainProduct.attribute1_name = (product as any).attribute1_name
    if ((product as any).attribute1_value !== undefined) plainProduct.attribute1_value = (product as any).attribute1_value
    if ((product as any).attribute2_name !== undefined) plainProduct.attribute2_name = (product as any).attribute2_name
    if ((product as any).attribute2_value !== undefined) plainProduct.attribute2_value = (product as any).attribute2_value
    if ((product as any).attribute3_name !== undefined) plainProduct.attribute3_name = (product as any).attribute3_name
    if ((product as any).attribute3_value !== undefined) plainProduct.attribute3_value = (product as any).attribute3_value
    
    return plainProduct
  })
  
  return enhancedProducts
}

// Get all products linked to a company (without vendor fulfillment filter)
// This is useful for category extraction and other purposes where we need all linked products
export async function getAllProductsByCompany(companyId: string | number): Promise<any[]> {
  await connectDB()
  
  if (!companyId && companyId !== 0) {
    console.warn('getAllProductsByCompany: companyId is empty or undefined')
    return []
  }
  
  // Convert companyId to number if it's a string representation of a number
  let numericCompanyId: number | null = null
  if (typeof companyId === 'string') {
    // Try to parse as number
    const parsed = Number(companyId)
    if (!isNaN(parsed) && isFinite(parsed)) {
      numericCompanyId = parsed
    }
  } else if (typeof companyId === 'number') {
    numericCompanyId = companyId
  }
  
  // Find company by numeric ID first (since company.id is now numeric)
  let company = null
  if (numericCompanyId !== null) {
    company = await Company.findOne({ id: numericCompanyId })
    if (company) {
      console.log(`getAllProductsByCompany: Found company by numeric ID: ${numericCompanyId} (${company.name})`)
    }
  }
  
  // If still not found, try as string ID (for backward compatibility)
  if (!company && typeof companyId === 'string') {
    company = await Company.findOne({ id: companyId })
    if (company) {
      console.log(`getAllProductsByCompany: Found company by string ID: ${companyId} (${company.name})`)
      numericCompanyId = company.id
    }
  }
  
  if (!company) {
    console.warn(`getAllProductsByCompany: Company not found for companyId: ${companyId} (type: ${typeof companyId})`)
    // List available companies for debugging
    const allCompanies = await Company.find({}, 'id name').limit(5).lean()
    console.warn(`getAllProductsByCompany: Available companies:`, allCompanies.map((c: any) => `${c.id} (${c.name})`))
    return []
  }

  // Get all products directly linked via ProductCompany relationship
  // Query using string ID (not ObjectId)
  const db = mongoose.connection.db
  if (!db) {
    console.warn('getAllProductsByCompany: Database connection not available')
    return []
  }
  
  const companyIdStr = company.id || ''
  // Query directly using string ID
  const productCompanyLinks = await db.collection('productcompanies').find({
    companyId: companyIdStr
  }).toArray()
  
  console.log(`getAllProductsByCompany: Found ${productCompanyLinks.length} ProductCompany relationships for company ${companyId} (${company.name || 'Unknown'})`)
  
  if (productCompanyLinks.length === 0) {
    console.log(`getAllProductsByCompany: No products directly linked to company ${companyId}`)
    return []
  }
  
  // Get product ObjectIds from the relationships (as strings for comparison)
  const productIdStrs = productCompanyLinks
    .map((link: any) => {
      if (!link.productId) return null
      return link.productId.toString ? link.productId.toString() : String(link.productId)
    })
    .filter((id: any) => id !== null && id !== undefined)
  
  if (productIdStrs.length === 0) {
    console.log(`getAllProductsByCompany: No valid product IDs found in relationships for company ${companyId}`)
    return []
  }
  
  console.log(`getAllProductsByCompany: Looking for ${productIdStrs.length} products with IDs: ${productIdStrs.slice(0, 3).join(', ')}...`)

  // Fetch all products and filter by string comparison (most reliable)
  const allProducts = await db.collection('uniforms').find({}).toArray()
  const matchingProducts = allProducts.filter((p: any) => {
    const productIdStr = p.id || String(p._id || '')
    return productIdStrs.includes(productIdStr)
  })
  
  console.log(`getAllProductsByCompany: Found ${matchingProducts.length} products using string comparison`)
  
  if (matchingProducts.length === 0) {
    console.log(`getAllProductsByCompany: No products found. Sample product ids: ${matchingProducts.slice(0, 3).map((p: any) => p.id || p._id).join(', ')}`)
    return []
  }
  
  // Extract string IDs from matching products
  const productIds = matchingProducts.map((p: any) => p.id || String(p._id)).filter((id: string) => /^\d{6}$/.test(id))
  console.log(`getAllProductsByCompany: Querying ${productIds.length} products by id`)
  
  // Fetch products using string ID field
  const products = await Uniform.find({
    id: { $in: productIds },
  }).lean()
  
  // Manually populate vendorId since populate doesn't work with string IDs
  if (products.length > 0) {
    const vendorIds = [...new Set(products.map((p: any) => p.vendorId).filter(Boolean))]
    const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
    const vendorMap = new Map(vendors.map((v: any) => [v.id, v]))
    
    products.forEach((product: any) => {
      if (product.vendorId && vendorMap.has(product.vendorId)) {
        product.vendorId = vendorMap.get(product.vendorId)
      }
    })
  }

  console.log(`getAllProductsByCompany(${companyId}): Mongoose query returned ${products.length} products (all, without vendor filter)`)
  
  // If Mongoose query returns 0, use raw collection data as fallback
  let productsToUse = products
  if (!products || products.length === 0) {
    console.warn(`getAllProductsByCompany: Mongoose query returned 0 products, using raw collection data as fallback`)
    // Use the raw products we found earlier
    // First, get all vendors for population
    const allVendors = await db.collection('vendors').find({}).toArray()
    const vendorMap = new Map()
    allVendors.forEach((v: any) => {
      const vendorId = v.id || ''
      if (vendorId) vendorMap.set(vendorId, { id: vendorId, name: v.name })
    })
    
    // Use the raw products we found earlier - preserve ALL fields including attributes
    productsToUse = matchingProducts.map((p: any) => {
      const product: any = { 
        ...p,
        // Explicitly preserve attribute fields
        attribute1_name: p.attribute1_name,
        attribute1_value: p.attribute1_value,
        attribute2_name: p.attribute2_name,
        attribute2_value: p.attribute2_value,
        attribute3_name: p.attribute3_name,
        attribute3_value: p.attribute3_value,
      }
      // Use string id field - no ObjectId conversion needed
      // Ensure product has an id field
      if (!product.id && product._id) {
        product.id = String(product._id)
      }
      // vendorId removed from Uniform model - use ProductVendor collection instead
      return product
    })
  }
  
  // Convert to plain objects and ensure attributes are preserved
  return productsToUse.map((p: any) => {
    const plain = toPlainObject(p)
    // Explicitly preserve attribute fields
    if (p.attribute1_name !== undefined) plain.attribute1_name = p.attribute1_name
    if (p.attribute1_value !== undefined) plain.attribute1_value = p.attribute1_value
    if (p.attribute2_name !== undefined) plain.attribute2_name = p.attribute2_name
    if (p.attribute2_value !== undefined) plain.attribute2_value = p.attribute2_value
    if (p.attribute3_name !== undefined) plain.attribute3_name = p.attribute3_name
    if (p.attribute3_value !== undefined) plain.attribute3_value = p.attribute3_value
    return plain
  })
}

/**
 * CRITICAL: Vendor Product Fetch - STRICT ProductVendor Relationship Enforcement
 * 
 * SINGLE SOURCE OF TRUTH: ProductVendor relationships (created by Super Admin)
 * 
 * This function:
 * 1. Uses centralized vendor resolution (single source of truth)
 * 2. ONLY uses ProductVendor relationships - NO FALLBACKS
 * 3. Returns empty array if no ProductVendor relationships exist
 * 4. Ensures vendors see ONLY products explicitly assigned to them
 * 5. Includes comprehensive logging for debugging
 * 
 * NO FALLBACKS TO:
 * - Inventory records (vendors may have inventory for products not assigned)
 * - Orders (vendors may have fulfilled orders for products not assigned)
 * 
 * This ensures strict access control and data integrity.
 */
export async function getProductsByVendor(vendorId: string): Promise<any[]> {
  await connectDB()
  
  // 🔍 LOG: Service boundary - COMPREHENSIVE DEBUGGING
  console.log(`\n╔════════════════════════════════════════════════════════════╗`)
  console.log(`║  [getProductsByVendor] START - COMPREHENSIVE DEBUGGING     ║`)
  console.log(`╚════════════════════════════════════════════════════════════╝`)
  console.log(`[getProductsByVendor] Input vendorId: "${vendorId}" (type: ${typeof vendorId})`)
  console.log(`[getProductsByVendor] vendorId length: ${vendorId?.length || 0}`)
  console.log(`[getProductsByVendor] vendorId trimmed: "${vendorId?.trim() || ''}"`)
  
  // STEP 1: Get vendor document directly from database
  // We use the vendor's string ID field for all lookups
  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  const vendor = await db.collection('vendors').findOne({ id: vendorId })
  if (!vendor) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }
  
  // Use vendor's string ID field
  const vendorIdStr = vendor.id || ''
  if (!vendorIdStr) {
    throw new Error(`Vendor missing id field: ${vendorId}`)
  }
  
  console.log(`[getProductsByVendor] Vendor id: ${vendorIdStr}`)
  
  const vendorName = vendor.name || 'Unknown Vendor'
  
  console.log(`[getProductsByVendor] ✅ Vendor found: ${vendorName} (${vendorIdStr})`)

  // STEP 2: Query ProductVendor relationships using vendor's string ID
  console.log(`[getProductsByVendor] Querying ProductVendor relationships for vendor: ${vendorName} (${vendorIdStr})`)
  
  // CRITICAL FIX: Query ProductVendor using string vendorId ONLY
  // ProductVendor schema stores vendorId as STRING (6-digit numeric), not ObjectId
  // Do NOT use ObjectId fallback - ProductVendor always uses string IDs
  let productVendorLinks = await db.collection('productvendors').find({ 
    vendorId: vendorIdStr 
  }).toArray()
  
  // CRITICAL: No ObjectId fallback - ProductVendor always uses string IDs per schema definition

  console.log(`[getProductsByVendor] ✅ ProductVendor relationships found: ${productVendorLinks.length}`)
  
  // DEBUG: If no results, log diagnostic info
  if (productVendorLinks.length === 0) {
    console.log(`[getProductsByVendor] ⚠️ No ProductVendor relationships found. Checking database contents...`)
    const allProductVendorLinks = await db.collection('productvendors').find({}).toArray()
    console.log(`[getProductsByVendor] Total ProductVendor links in database: ${allProductVendorLinks.length}`)
    
    if (allProductVendorLinks.length > 0) {
      console.log(`[getProductsByVendor] Sample ProductVendor link vendorId formats (first 3):`)
      allProductVendorLinks.slice(0, 3).forEach((link: any, idx: number) => {
        const linkVendorId = link.vendorId
        const linkVendorIdStr = String(linkVendorId || '')
        console.log(`[getProductsByVendor]   Link ${idx}:`, {
          vendorId: linkVendorId,
          vendorIdType: typeof linkVendorId,
          vendorIdString: linkVendorIdStr,
          ourVendorId: vendorIdStr,
          matches: linkVendorIdStr === vendorIdStr
        })
      })
    }
  }
  
  console.log(`[getProductsByVendor] Total ProductVendor relationships found: ${productVendorLinks.length}`)

  // CRITICAL FIX: ProductVendor stores productId as STRING (6-digit numeric), not ObjectId
  // Extract product IDs as STRING IDs, not ObjectIds
  let productStringIds: string[] = []

  if (productVendorLinks.length > 0) {
    // Primary method: Extract product IDs from ProductVendor relationships as STRINGS
    console.log(`[getProductsByVendor] Using ProductVendor relationships (primary method)`)
    
    // Log all links for debugging
    console.log(`[getProductsByVendor] ProductVendor links details:`, productVendorLinks.map((link: any, idx: number) => ({
      index: idx,
      productId: link.productId,
      productIdType: typeof link.productId,
      productIdConstructor: link.productId?.constructor?.name,
      vendorId: link.vendorId,
      vendorIdType: typeof link.vendorId,
      vendorIdConstructor: link.vendorId?.constructor?.name
    })))
    
    productStringIds = productVendorLinks
      .map((link: any, index: number) => {
        const productId = link.productId
        if (!productId) {
          console.warn(`[getProductsByVendor] ⚠️ Link ${index} has no productId`)
          return null
        }
        
        // CRITICAL FIX: ProductVendor stores productId as STRING (6-digit numeric), not ObjectId
        // Extract as string ID directly
        const productIdStr = typeof productId === 'string' ? productId : String(productId || '')
        
        // Validate it's a 6-digit numeric string
        if (/^\d{6}$/.test(productIdStr)) {
          return productIdStr
        }
        
        console.warn(`[getProductsByVendor] ⚠️ Link ${index} has invalid productId format:`, {
          productId,
          productIdStr,
          type: typeof productId,
          constructor: productId?.constructor?.name,
          isValid: /^\d{6}$/.test(productIdStr)
        })
        return null
      })
      .filter((id: any) => id !== null) as string[]
      
    console.log(`[getProductsByVendor] Extracted ${productStringIds.length} product STRING IDs from ProductVendor relationships`)
    if (productStringIds.length > 0) {
      console.log(`[getProductsByVendor] Product STRING IDs extracted:`, productStringIds)
    }
  } else {
    // CRITICAL: NO FALLBACKS - ProductVendor relationships are the SINGLE SOURCE OF TRUTH
    // If no ProductVendor relationships exist, vendor has NO assigned products
    // Do NOT fall back to inventory or orders - this would show unassigned products
    console.log(`[getProductsByVendor] ⚠️ No ProductVendor relationships found for vendor ${vendorName} (${vendorId})`)
    console.log(`[getProductsByVendor] ⚠️ This vendor has NO products assigned via ProductVendor relationships`)
    console.log(`[getProductsByVendor] ⚠️ Returning empty array - vendor must have products assigned by Super Admin`)
    console.log(`[getProductsByVendor] ⚠️ NOT using fallback to inventory/orders (would violate access control)`)
    
    // Log diagnostic info but DO NOT use it for fallback
    const inventoryCount = await VendorInventory.countDocuments({ vendorId: vendorIdStr })
    const orderCount = await Order.countDocuments({ vendorId: vendorIdStr })
    console.log(`[getProductsByVendor] Diagnostic (for reference only, NOT used):`, {
      inventoryRecords: inventoryCount,
      ordersWithVendor: orderCount,
      note: 'These are NOT used as fallback - ProductVendor relationships are required'
    })
    
    // Return empty array - vendor has no assigned products
    return []
  }

  // STEP 3: Validate we have products
  if (productStringIds.length === 0) {
    console.error(`[getProductsByVendor] ❌ CRITICAL: No products found for vendor ${vendorName} (${vendorIdStr})`)
    console.error(`[getProductsByVendor] Diagnostic info:`)
    console.error(`  - ProductVendor relationships: ${productVendorLinks.length}`)
    console.error(`  - Inventory records: ${await VendorInventory.countDocuments({ vendorId: vendorIdStr })}`)
    console.error(`  - Orders with vendor: ${await Order.countDocuments({ vendorId: vendorIdStr })}`)
    console.error(`[getProductsByVendor] This vendor has no products linked via any method.`)
    return []
  }

  console.log(`[getProductsByVendor] ✅ Proceeding with ${productStringIds.length} product STRING IDs`)

  // STEP 4: Fetch products from database using STRING IDs
  // CRITICAL FIX: Query Uniform using string 'id' field, not '_id' ObjectId
  // ProductVendor stores productId as STRING (6-digit numeric), so query by string id field
  console.log(`[getProductsByVendor] Querying uniforms collection for ${productStringIds.length} products`)
  console.log(`[getProductsByVendor] Product STRING IDs to query:`, productStringIds)
  
  let products = await Uniform.find({
    id: { $in: productStringIds }, // CRITICAL: Use string 'id' field, not '_id' ObjectId
  })
    .lean()

  console.log(`[getProductsByVendor] Products query result: ${products.length} products found by string id`)
  
  // CRITICAL SECURITY CHECK: Ensure query didn't return more products than expected
  if (products.length > productStringIds.length) {
    console.error(`[getProductsByVendor] ❌❌❌ CRITICAL SECURITY VIOLATION: Query returned ${products.length} products but only ${productStringIds.length} ProductVendor relationships exist!`)
    console.error(`[getProductsByVendor] This should NEVER happen - the query should only return products in productStringIds array!`)
    console.error(`[getProductsByVendor] Products returned:`, products.map((p: any) => `${p.name} (${p.id})`))
    console.error(`[getProductsByVendor] Expected productStringIds:`, productStringIds)
    console.error(`[getProductsByVendor] ❌ Filtering to ONLY products that match productStringIds...`)
    
    // CRITICAL: Filter to ONLY products that match productStringIds
    const productIdSet = new Set(productStringIds)
    const filteredProducts = products.filter((p: any) => {
      const pIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
      return productIdSet.has(pIdStr)
    })
    
    console.error(`[getProductsByVendor] After filtering: ${filteredProducts.length} products (removed ${products.length - filteredProducts.length} invalid products)`)
    products = filteredProducts
    
    // If still too many, this is a critical MongoDB/Mongoose bug
    if (products.length > productStringIds.length) {
      console.error(`[getProductsByVendor] ❌❌❌ STILL TOO MANY AFTER FILTERING! This indicates a critical bug in MongoDB query!`)
      console.error(`[getProductsByVendor] Limiting to first ${productStringIds.length} products as emergency safeguard`)
      products = products.slice(0, productStringIds.length)
    }
  }
  
  // 🔍 DIAGNOSTIC: If query returned 0, try individual queries
  if (products.length === 0 && productStringIds.length > 0) {
    console.log(`[getProductsByVendor] 🔍 DIAGNOSTIC: Query returned 0. Trying individual queries by string id...`)
    for (const productIdStr of productStringIds) {
      try {
        const individualProduct = await Uniform.findOne({ id: productIdStr }).lean()
        if (individualProduct) {
          console.log(`[getProductsByVendor] ✅ Individual query by id(${productIdStr}) found product: ${individualProduct.id} (${individualProduct.name})`)
        } else {
          console.log(`[getProductsByVendor] ❌ Individual query by id(${productIdStr}) returned null`)
        }
      } catch (err: any) {
        console.error(`[getProductsByVendor] ❌ Error in individual query by id(${productIdStr}):`, err.message)
      }
    }
  }
  
  // FALLBACK: If no products found by string id, try to find products that exist in database
  if (products.length === 0) {
    console.warn(`[getProductsByVendor] ⚠️ No products found by string id. Checking if products exist in database...`)
    
    // Get all products to see what's available
    const allProducts = await Uniform.find({}).select('id name').limit(10).lean()
    console.log(`[getProductsByVendor] Sample products in database:`, allProducts.map((p: any) => ({
      id: p.id,
      name: p.name
    })))
    
    // Try to find products by matching string IDs
    const matchingProducts = allProducts.filter((p: any) => {
      const pIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
      return productStringIds.includes(pIdStr)
    })
    
    if (matchingProducts.length > 0) {
      console.log(`[getProductsByVendor] Found ${matchingProducts.length} products by string comparison`)
      
      // 🔍 DIAGNOSTIC: Log the matching products
      console.log(`[getProductsByVendor] 🔍 DIAGNOSTIC: Matching products details:`)
      matchingProducts.forEach((p: any, idx: number) => {
        console.log(`[getProductsByVendor]   matchingProducts[${idx}]:`, {
          id: p.id,
          name: p.name
        })
      })
      
      // Extract string IDs from matching products
      const matchingProductIds = matchingProducts.map((p: any) => {
        return p.id || ''
      }).filter((id: string) => id.length > 0)
      
      console.log(`[getProductsByVendor] Fetching full product data for ${matchingProductIds.length} products`)
      console.log(`[getProductsByVendor] 🔍 DIAGNOSTIC: Product IDs to query:`, matchingProductIds)
      
      // Query by string 'id' field
      console.log(`[getProductsByVendor] Products found by string comparison. Fetching full product data by string id...`)
      
      const numericIds = matchingProductIds
      console.log(`[getProductsByVendor] 🔍 DIAGNOSTIC: Numeric IDs to query:`, numericIds)
      
      if (numericIds.length > 0) {
        // CRITICAL SECURITY: Ensure numericIds count matches productStringIds count
        // If numericIds has more items than productStringIds, we have a data inconsistency
        if (numericIds.length > productStringIds.length) {
          console.error(`[getProductsByVendor] ❌ CRITICAL SECURITY VIOLATION: numericIds (${numericIds.length}) exceeds productStringIds (${productStringIds.length})!`)
          console.error(`[getProductsByVendor] This indicates a bug in the fallback logic - limiting to productStringIds count`)
          numericIds.splice(productStringIds.length) // Limit to productStringIds count
        }
        
        // Query by string 'id' field (this is the reliable field)
        // CRITICAL: Only query for the exact numericIds we extracted from matchingProducts
        products = await Uniform.find({
          id: { $in: numericIds }
        }).lean()
        
        console.log(`[getProductsByVendor] Query by string id result: ${products.length} products found`)
        
        // CRITICAL SECURITY: If query returned more products than expected, this is a violation
        if (products.length > productStringIds.length) {
          console.error(`[getProductsByVendor] ❌ CRITICAL SECURITY VIOLATION: Query returned ${products.length} products but only ${productStringIds.length} ProductVendor relationships exist!`)
          console.error(`[getProductsByVendor] This indicates the query is returning products not assigned to this vendor!`)
          console.error(`[getProductsByVendor] Products returned:`, products.map((p: any) => `${p.name} (${p.id})`))
          console.error(`[getProductsByVendor] Expected productStringIds:`, productStringIds)
        }
        
        // CRITICAL: Verify products match productStringIds
        if (products.length > 0) {
          console.log(`[getProductsByVendor] 🔍 Verifying products match productStringIds from ProductVendor links...`)
          const productIdSet = new Set(productStringIds)
          const verifiedProducts = products.filter((p: any) => {
            const pIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
            const matches = productIdSet.has(pIdStr)
            if (!matches) {
              console.error(`[getProductsByVendor] ❌ SECURITY: Product ${p.id} (${p.name}) doesn't match any productId from ProductVendor links - REMOVING`)
            }
            return matches
          })
          
          if (verifiedProducts.length < products.length) {
            console.error(`[getProductsByVendor] ❌ SECURITY VIOLATION: Removed ${products.length - verifiedProducts.length} products with mismatched id`)
            products = verifiedProducts
          }
          
          // CRITICAL: Final check - ensure we don't return more products than ProductVendor relationships
          if (products.length > productStringIds.length) {
            console.error(`[getProductsByVendor] ❌ CRITICAL: After verification, still have ${products.length} products but only ${productStringIds.length} ProductVendor relationships!`)
            console.error(`[getProductsByVendor] Limiting to first ${productStringIds.length} products that match productStringIds`)
            const limitedProducts = products.slice(0, productStringIds.length).filter((p: any) => {
              const pIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
              return productStringIds.includes(pIdStr)
            })
            console.error(`[getProductsByVendor] After limiting: ${limitedProducts.length} products`)
            products = limitedProducts
          }
        }
        
        if (products.length === 0) {
          // Fallback: Query individually
          console.log(`[getProductsByVendor] ⚠️ Query by $in failed, trying individual queries...`)
          const directProducts: any[] = []
          for (const numericId of numericIds) {
            try {
              const directProduct = await Uniform.findOne({ id: numericId }).lean()
              if (directProduct) {
                // Verify id matches productStringIds
                const pIdStr = typeof directProduct.id === 'string' ? directProduct.id : String(directProduct.id || '')
                if (productStringIds.includes(pIdStr)) {
                  directProducts.push(directProduct)
                  console.log(`[getProductsByVendor] ✅ Found product by string id: ${numericId}`)
                } else {
                  console.warn(`[getProductsByVendor] ⚠️ Product ${numericId} found but doesn't match ProductVendor links`)
                }
              } else {
                console.log(`[getProductsByVendor] ❌ Product not found by string id: ${numericId}`)
              }
            } catch (err: any) {
              console.error(`[getProductsByVendor] ❌ Error querying product ${numericId}:`, err.message)
            }
          }
          if (directProducts.length > 0) {
            products = directProducts
            console.log(`[getProductsByVendor] ✅ Using ${directProducts.length} products from individual queries`)
          }
        }
      }
      
      if (products.length === 0) {
        console.error(`[getProductsByVendor] ❌ All query methods failed. Products exist but cannot be retrieved.`)
      }
    } else {
      // CRITICAL: Product IDs from ProductVendor do not match any products in database
      // This indicates orphaned ProductVendor relationships (product was deleted but relationship remains)
      // DO NOT fall back to inventory - this would show unassigned products
      console.error(`[getProductsByVendor] ❌ CRITICAL: Product IDs from ProductVendor do not match any products in database`)
      console.error(`[getProductsByVendor] This indicates data inconsistency - ProductVendor relationships may be orphaned`)
      console.error(`[getProductsByVendor] NOT using fallback to inventory (would violate access control)`)
      console.error(`[getProductsByVendor] Returning empty array - orphaned relationships should be cleaned up by Super Admin`)
      
      // Return empty array - orphaned relationships should not show products
      return []
    }
  }
  
  // CRITICAL SECURITY CHECK: Ensure products count never exceeds productStringIds count
  // This is the FINAL safeguard before proceeding to inventory attachment
  if (products.length > productStringIds.length) {
    console.error(`\n[getProductsByVendor] ❌❌❌ CRITICAL SECURITY VIOLATION BEFORE INVENTORY ATTACHMENT ❌❌❌`)
    console.error(`[getProductsByVendor] Found ${products.length} products but only ${productStringIds.length} ProductVendor relationships!`)
    console.error(`[getProductsByVendor] Products found:`, products.map((p: any) => `${p.name} (${p.id})`))
    console.error(`[getProductsByVendor] Expected productStringIds:`, productStringIds)
    console.error(`[getProductsByVendor] ❌ BLOCKING - Filtering to ONLY products that match ProductVendor relationships...`)
    
    // CRITICAL: Filter to ONLY products that match productStringIds
    const productIdSet = new Set(productStringIds)
    const filteredProducts = products.filter((p: any) => {
      const pIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
      const isValid = productIdSet.has(pIdStr)
      if (!isValid) {
        console.error(`[getProductsByVendor] ❌ Removing product ${p.name} (${p.id}) - id ${pIdStr} not in ProductVendor relationships`)
      }
      return isValid
    })
    
    console.error(`[getProductsByVendor] After filtering: ${filteredProducts.length} products (removed ${products.length - filteredProducts.length} invalid products)`)
    products = filteredProducts
    
    // If still too many, this is a critical bug - limit to productStringIds.length
    if (products.length > productStringIds.length) {
      console.error(`[getProductsByVendor] ❌❌❌ STILL TOO MANY PRODUCTS AFTER FILTERING! This is a critical bug!`)
      console.error(`[getProductsByVendor] Limiting to first ${productStringIds.length} products`)
      products = products.slice(0, productStringIds.length)
    }
  }
  
  if (products.length === 0) {
    console.error(`[getProductsByVendor] ❌ CRITICAL: No products found after all fallback attempts`)
    return []
  }
  
  if (products.length < productStringIds.length) {
    const foundProductIds = new Set(products.map((p: any) => {
      const pIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
      return pIdStr
    }))
    const missingProductIds = productStringIds.filter(id => !foundProductIds.has(id))
    console.warn(`[getProductsByVendor] ⚠️ Some product IDs not found: expected ${productStringIds.length}, found ${products.length}`)
    console.warn(`[getProductsByVendor] Missing product IDs:`, missingProductIds)
    
    // CRITICAL: If we have ProductVendor links but products aren't found, this indicates a data inconsistency
    // Try to find these products by querying the Uniform collection directly
    if (missingProductIds.length > 0 && productVendorLinks.length > 0) {
      console.log(`[getProductsByVendor] 🔍 Attempting to find missing products by direct query...`)
      for (const missingIdStr of missingProductIds) {
        // Try querying by string id
        try {
          const foundProduct = await Uniform.findOne({ id: missingIdStr }).lean()
          if (foundProduct) {
            console.log(`[getProductsByVendor] ✅ Found missing product by string id: ${foundProduct.id} (${foundProduct.name}, SKU: ${foundProduct.sku})`)
            products.push(foundProduct)
            continue
          }
        } catch (err: any) {
          console.log(`[getProductsByVendor] Query by string id failed for ${missingIdStr}:`, err.message)
        }
      }
    }
  }
  
  console.log(`[getProductsByVendor] ✅ Successfully found ${products.length} products`)

  // CRITICAL SECURITY: Get inventory data ONLY for products in productStringIds (from ProductVendor relationships)
  // This ensures we never return inventory for unassigned products
  // If productStringIds is empty, this query will return nothing (correct behavior)
  if (productStringIds.length === 0) {
    console.log(`[getProductsByVendor] ⚠️ No product IDs to query inventory for - skipping inventory query`)
  }
  
  // VendorInventory uses string IDs for vendorId and productId
  const inventoryRecords = await VendorInventory.find({
    vendorId: vendorIdStr,
    productId: { $in: productStringIds },
  })
    .lean()
  
  console.log(`[getProductsByVendor] ✅ Found ${inventoryRecords.length} inventory record(s) for ${productStringIds.length} assigned product(s)`)
  
  // CRITICAL VALIDATION: Verify all inventory records are for products in productStringIds
  const validProductIdStrs = new Set(productStringIds)
  const invalidInventory = inventoryRecords.filter((inv: any) => {
    const invProductIdStr = String(inv.productId || '')
    return !validProductIdStrs.has(invProductIdStr)
  })
  
  if (invalidInventory.length > 0) {
    console.error(`[getProductsByVendor] ❌ CRITICAL SECURITY VIOLATION: Found ${invalidInventory.length} inventory record(s) for products NOT in ProductVendor relationships!`)
    console.error(`[getProductsByVendor] These inventory records will be IGNORED to prevent data leakage`)
    invalidInventory.forEach((inv: any) => {
      console.error(`[getProductsByVendor]   - Inventory ID: ${inv.id}, Product ID: ${inv.productId || 'N/A'}`)
    })
  }
  
  // Filter out invalid inventory records
  const validInventoryRecords = inventoryRecords.filter((inv: any) => {
    const invProductIdStr = String(inv.productId || '')
    return validProductIdStrs.has(invProductIdStr)
  })
  
  if (validInventoryRecords.length < inventoryRecords.length) {
    console.error(`[getProductsByVendor] ❌ Removed ${inventoryRecords.length - validInventoryRecords.length} invalid inventory record(s)`)
  }

  // Create a map of productId (string) -> inventory (using ONLY valid inventory records)
  const inventoryMap = new Map()
  validInventoryRecords.forEach((inv: any) => {
    const invProductIdStr = String(inv.productId || '')
    // Convert Map to object if needed
    const sizeInventory = inv.sizeInventory instanceof Map
      ? Object.fromEntries(inv.sizeInventory)
      : inv.sizeInventory || {}
    
    inventoryMap.set(invProductIdStr, {
      sizeInventory,
      totalStock: inv.totalStock || 0,
    })
  })

  // Attach inventory data to products
  let productsWithInventory = products.map((product: any) => {
    // Use string id field
    const productIdStr = product.id || ''
    
    const inventory = inventoryMap.get(productIdStr) || {
      sizeInventory: {},
      totalStock: 0,
    }

    const plainProduct = toPlainObject(product)
    // Explicitly preserve attribute fields
    if (product.attribute1_name !== undefined) plainProduct.attribute1_name = product.attribute1_name
    if (product.attribute1_value !== undefined) plainProduct.attribute1_value = product.attribute1_value
    if (product.attribute2_name !== undefined) plainProduct.attribute2_name = product.attribute2_name
    if (product.attribute2_value !== undefined) plainProduct.attribute2_value = product.attribute2_value
    if (product.attribute3_name !== undefined) plainProduct.attribute3_name = product.attribute3_name
    if (product.attribute3_value !== undefined) plainProduct.attribute3_value = product.attribute3_value

    // Use string id field
    return {
      ...plainProduct,
      id: product.id || productIdStr, // Use string id
      inventory: inventory.sizeInventory,
      totalStock: inventory.totalStock,
      // For backward compatibility, set stock to totalStock
      stock: inventory.totalStock,
    }
  })

  // STEP 5: CRITICAL VALIDATION - Ensure all returned products are from ProductVendor relationships
  // This is a security check to prevent returning products not assigned to this vendor
  if (productsWithInventory.length > 0 && productVendorLinks.length > 0) {
    console.log(`[getProductsByVendor] 🔍 STEP 5: Validating ${productsWithInventory.length} products against ${productVendorLinks.length} ProductVendor links`)
    
    // Build Set of valid product IDs from ProductVendor links
    // CRITICAL: Use the SAME productStringIds we extracted earlier
    // This ensures we're comparing the exact same string IDs that were used to query products
    const validProductIds = new Set<string>(productStringIds)
    
    console.log(`[getProductsByVendor] 🔍 Valid product IDs Set size: ${validProductIds.size}`)
    console.log(`[getProductsByVendor] 🔍 Valid product IDs:`, Array.from(validProductIds).slice(0, 5))
    console.log(`[getProductsByVendor] 🔍 Products to validate:`, productsWithInventory.map((p: any) => ({
      id: p.id,
      name: p.name,
      _id: p._id?.toString() || String(p._id || '')
    })).slice(0, 3))
    
    // Filter products to only those in validProductIds
    const filteredProducts = productsWithInventory.filter((p: any) => {
      // CRITICAL: Use string id field for comparison (ProductVendor stores productId as string)
      const productIdStr = typeof p.id === 'string' ? p.id : String(p.id || '')
      const isValid = validProductIds.has(productIdStr)
      
      if (!isValid) {
        console.error(`[getProductsByVendor] ❌ SECURITY: Product ${p.id} (${p.name}) is NOT in ProductVendor relationships - REMOVING`)
        console.error(`[getProductsByVendor]   Product id: ${productIdStr}`)
        console.error(`[getProductsByVendor]   Valid IDs include: ${Array.from(validProductIds).slice(0, 3).join(', ')}`)
      } else {
        console.log(`[getProductsByVendor] ✅ Product ${p.id} (${p.name}) is VALID - keeping`)
      }
      
      return isValid
    })
    
    if (filteredProducts.length < productsWithInventory.length) {
      console.error(`[getProductsByVendor] ❌ SECURITY VIOLATION: Removed ${productsWithInventory.length - filteredProducts.length} products not in ProductVendor relationships`)
      console.error(`[getProductsByVendor] Only returning ${filteredProducts.length} products that are explicitly assigned to vendor`)
    } else {
      console.log(`[getProductsByVendor] ✅ All ${filteredProducts.length} products validated successfully`)
    }
    
    productsWithInventory = filteredProducts
  } else if (productsWithInventory.length > 0 && productVendorLinks.length === 0) {
    // CRITICAL: If we have products but no ProductVendor links, this is a security violation
    console.error(`[getProductsByVendor] ❌ CRITICAL SECURITY VIOLATION: Have ${productsWithInventory.length} products but NO ProductVendor links`)
    console.error(`[getProductsByVendor] This should not happen - returning empty array`)
    productsWithInventory = []
  }
  
  // STEP 6: CRITICAL FINAL VALIDATION - Ensure product count matches ProductVendor relationships
  // This is a security check to prevent returning more products than assigned
  if (productsWithInventory.length > productVendorLinks.length) {
    console.error(`\n[getProductsByVendor] ❌❌❌ CRITICAL SECURITY VIOLATION DETECTED ❌❌❌`)
    console.error(`[getProductsByVendor] Returning ${productsWithInventory.length} products but only ${productVendorLinks.length} ProductVendor relationships exist!`)
    console.error(`[getProductsByVendor] This indicates products are being returned that are NOT assigned to this vendor!`)
    console.error(`[getProductsByVendor] Products being returned:`)
    productsWithInventory.forEach((p: any, idx: number) => {
      console.error(`[getProductsByVendor]   ${idx + 1}. ${p.name} (SKU: ${p.sku}, ID: ${p.id})`)
    })
    console.error(`[getProductsByVendor] ProductVendor relationships:`)
    productVendorLinks.forEach((link: any, idx: number) => {
      const linkProductIdStr = typeof link.productId === 'string' ? link.productId : String(link.productId || 'N/A')
      console.error(`[getProductsByVendor]   ${idx + 1}. ProductId: ${linkProductIdStr}`)
    })
    console.error(`[getProductsByVendor] ❌ BLOCKING RETURN - Returning EMPTY ARRAY to prevent data leakage!`)
    console.error(`[getProductsByVendor] This is a critical security violation - products are being returned that violate vendor-product isolation!`)
    
    // CRITICAL: Return empty array instead of violating products
    // This ensures vendors NEVER see products not assigned to them, even if there's a bug in the query logic
    return []
  }
  
  // STEP 7: Final validation and logging
  console.log(`\n╔════════════════════════════════════════════════════════════╗`)
  console.log(`║  [getProductsByVendor] FINAL RESULT                        ║`)
  console.log(`╚════════════════════════════════════════════════════════════╝`)
  console.log(`[getProductsByVendor] Vendor: ${vendorName} (${vendorId})`)
  console.log(`[getProductsByVendor] ProductVendor relationships found: ${productVendorLinks.length}`)
  console.log(`[getProductsByVendor] Product STRING IDs extracted: ${productStringIds.length}`)
  console.log(`[getProductsByVendor] Products returned: ${productsWithInventory.length}`)
  
  // CRITICAL: Verify count matches
  if (productsWithInventory.length === productVendorLinks.length) {
    console.log(`[getProductsByVendor] ✅ Product count matches ProductVendor relationships (${productsWithInventory.length} = ${productVendorLinks.length})`)
  } else if (productsWithInventory.length < productVendorLinks.length) {
    console.warn(`[getProductsByVendor] ⚠️  Product count (${productsWithInventory.length}) is less than ProductVendor relationships (${productVendorLinks.length})`)
    console.warn(`[getProductsByVendor] This may indicate orphaned ProductVendor relationships (products deleted but relationships remain)`)
  } else {
    console.error(`[getProductsByVendor] ❌ CRITICAL: Product count (${productsWithInventory.length}) exceeds ProductVendor relationships (${productVendorLinks.length})`)
    console.error(`[getProductsByVendor] This should have been caught by the validation above!`)
  }
  
  console.log(`[getProductsByVendor] ✅ All products validated against ProductVendor relationships`)
  
  if (productsWithInventory.length > 0) {
    console.log(`[getProductsByVendor] ✅ SUCCESS - Products found:`)
    productsWithInventory.forEach((p: any, idx: number) => {
      console.log(`[getProductsByVendor]   ${idx + 1}. ${p.name} (SKU: ${p.sku}, ID: ${p.id})`)
    })
  } else if (productVendorLinks.length === 0) {
    console.log(`[getProductsByVendor] ✅ Correctly returning empty array - vendor has no ProductVendor relationships`)
    console.log(`[getProductsByVendor] ⚠️  Vendor ${vendorName} needs products assigned via Super Admin → Product to Vendor`)
  } else {
    console.error(`[getProductsByVendor] ❌ CRITICAL: Returning empty array despite having ${productStringIds.length} product STRING IDs`)
    console.error(`[getProductsByVendor] This indicates a data inconsistency. Products exist but cannot be returned.`)
    console.error(`[getProductsByVendor] Diagnostic:`)
    console.error(`  - ProductVendor links: ${productVendorLinks.length}`)
    console.error(`  - Product STRING IDs extracted: ${productStringIds.length}`)
    console.error(`  - Products found: ${productsWithInventory.length}`)
  }
  
  console.log(`[getProductsByVendor] END\n`)

  return productsWithInventory
}

export async function getAllProducts(): Promise<any[]> {
  await connectDB()
  
  const products = await Uniform.find()
    .populate('vendorId', 'id name')
    .lean()

  // Convert to plain objects and ensure attributes are preserved
  return products.map((p: any) => {
    const plain = toPlainObject(p)
    // Explicitly preserve attribute fields
    if (p.attribute1_name !== undefined) plain.attribute1_name = p.attribute1_name
    if (p.attribute1_value !== undefined) plain.attribute1_value = p.attribute1_value
    if (p.attribute2_name !== undefined) plain.attribute2_name = p.attribute2_name
    if (p.attribute2_value !== undefined) plain.attribute2_value = p.attribute2_value
    if (p.attribute3_name !== undefined) plain.attribute3_name = p.attribute3_name
    if (p.attribute3_value !== undefined) plain.attribute3_value = p.attribute3_value
    return plain
  })
}

export async function createProduct(productData: {
  name: string
  category: 'shirt' | 'pant' | 'shoe' | 'jacket' | 'accessory'
  gender: 'male' | 'female' | 'unisex'
  sizes: string[]
  price: number
  image: string
  sku: string
  vendorId?: string
  stock?: number
  // Optional SKU attributes
  attribute1_name?: string
  attribute1_value?: string | number
  attribute2_name?: string
  attribute2_value?: string | number
  attribute3_name?: string
  attribute3_value?: string | number
}): Promise<any> {
  await connectDB()
  
  // Generate unique 6-digit numeric product ID (starting from 200001)
  const existingProducts = await Uniform.find({})
    .sort({ id: -1 })
    .limit(1)
    .lean()
  
  let nextProductId = 200001 // Start from 200001
  if (existingProducts.length > 0) {
    const lastId = existingProducts[0].id
    if (/^\d{6}$/.test(String(lastId))) {
      const lastIdNum = parseInt(String(lastId), 10)
      if (lastIdNum >= 200001 && lastIdNum < 300000) {
        nextProductId = lastIdNum + 1
      }
    }
  }
  
  let productId = String(nextProductId).padStart(6, '0')
  
  // Check if this ID already exists (safety check)
    const existingProduct = await Uniform.findOne({ id: productId })
  if (existingProduct) {
    // Find next available ID
    for (let i = nextProductId + 1; i < 300000; i++) {
      const testId = String(i).padStart(6, '0')
      const exists = await Uniform.findOne({ id: testId })
      if (!exists) {
        productId = testId
        break
      }
    }
  }
  
  // Check if SKU already exists
  const existingBySku = await Uniform.findOne({ sku: productData.sku })
  if (existingBySku) {
    throw new Error(`Product with SKU already exists: ${productData.sku}`)
  }
  
  // Handle vendor if provided (optional - can be linked later via relationships)
  // vendorId removed from Uniform model - use ProductVendor collection to link products to vendors
  
  const productDataToCreate: any = {
    id: productId,
    name: productData.name,
    category: productData.category,
    gender: productData.gender,
    sizes: productData.sizes || [],
    price: productData.price,
    image: productData.image || '',
    sku: productData.sku,
    companyIds: [],
  }
  
  // Add optional attributes (only include if name is provided - name is required for attribute to be valid)
  // This ensures attributes are saved to the database when provided
  if (productData.attribute1_name !== undefined && productData.attribute1_name !== null && String(productData.attribute1_name).trim() !== '') {
    productDataToCreate.attribute1_name = String(productData.attribute1_name).trim()
    if (productData.attribute1_value !== undefined && productData.attribute1_value !== null && String(productData.attribute1_value).trim() !== '') {
      productDataToCreate.attribute1_value = productData.attribute1_value
    } else {
      // Even if value is empty, save the name (value can be added later)
      productDataToCreate.attribute1_value = null
    }
  }
  if (productData.attribute2_name !== undefined && productData.attribute2_name !== null && String(productData.attribute2_name).trim() !== '') {
    productDataToCreate.attribute2_name = String(productData.attribute2_name).trim()
    if (productData.attribute2_value !== undefined && productData.attribute2_value !== null && String(productData.attribute2_value).trim() !== '') {
      productDataToCreate.attribute2_value = productData.attribute2_value
    } else {
      productDataToCreate.attribute2_value = null
    }
  }
  if (productData.attribute3_name !== undefined && productData.attribute3_name !== null && String(productData.attribute3_name).trim() !== '') {
    productDataToCreate.attribute3_name = String(productData.attribute3_name).trim()
    if (productData.attribute3_value !== undefined && productData.attribute3_value !== null && String(productData.attribute3_value).trim() !== '') {
      productDataToCreate.attribute3_value = productData.attribute3_value
    } else {
      productDataToCreate.attribute3_value = null
    }
  }
  
  // ============================================================
  // FORENSIC DIAGNOSTIC: STEP 3 - INSPECT ACTUAL PAYLOAD
  // ============================================================
  console.log('\n╔════════════════════════════════════════════════════════════╗')
  console.log('║  FORENSIC: PRODUCT PAYLOAD INSPECTION                     ║')
  console.log('╚════════════════════════════════════════════════════════════╝')
  console.log('[FORENSIC] Product data to create:')
  console.log(JSON.stringify(productDataToCreate, null, 2))
  console.log('\n[FORENSIC] Field-by-field type analysis:')
  Object.keys(productDataToCreate).forEach(key => {
    const value = productDataToCreate[key]
    const type = typeof value
    const isArray = Array.isArray(value)
    console.log(`  ${key}: ${isArray ? 'Array' : type} = ${isArray ? `[${value.length} items]` : JSON.stringify(value)}`)
  })
  
  // ============================================================
  // FORENSIC DIAGNOSTIC: STEP 4 - SCHEMA VS PAYLOAD COMPARISON
  // ============================================================
  console.log('\n[FORENSIC] Schema requirements vs Payload:')
  const schemaChecks = {
    'id': {
      required: true,
      type: 'string',
      validation: '6 digits',
      provided: productDataToCreate.id,
      typeMatch: typeof productDataToCreate.id === 'string',
      validationMatch: /^\d{6}$/.test(String(productDataToCreate.id || '')),
    },
    'name': {
      required: true,
      type: 'string',
      provided: productDataToCreate.name,
      typeMatch: typeof productDataToCreate.name === 'string',
      notEmpty: productDataToCreate.name && String(productDataToCreate.name).trim().length > 0,
    },
    'category': {
      required: true,
      type: 'string',
      enum: ['shirt', 'pant', 'shoe', 'jacket', 'accessory'],
      provided: productDataToCreate.category,
      typeMatch: typeof productDataToCreate.category === 'string',
      enumMatch: ['shirt', 'pant', 'shoe', 'jacket', 'accessory'].includes(productDataToCreate.category),
    },
    'gender': {
      required: true,
      type: 'string',
      enum: ['male', 'female', 'unisex'],
      provided: productDataToCreate.gender,
      typeMatch: typeof productDataToCreate.gender === 'string',
      enumMatch: ['male', 'female', 'unisex'].includes(productDataToCreate.gender),
    },
    'sizes': {
      required: true,
      type: 'array',
      provided: productDataToCreate.sizes,
      isArray: Array.isArray(productDataToCreate.sizes),
      notEmpty: Array.isArray(productDataToCreate.sizes) && productDataToCreate.sizes.length > 0,
    },
    'price': {
      required: true,
      type: 'number',
      provided: productDataToCreate.price,
      typeMatch: typeof productDataToCreate.price === 'number',
      isFinite: typeof productDataToCreate.price === 'number' && isFinite(productDataToCreate.price),
    },
    'image': {
      required: true,
      type: 'string',
      provided: productDataToCreate.image,
      typeMatch: typeof productDataToCreate.image === 'string',
      notEmpty: productDataToCreate.image && String(productDataToCreate.image).trim().length > 0,
    },
    'sku': {
      required: true,
      type: 'string',
      provided: productDataToCreate.sku,
      typeMatch: typeof productDataToCreate.sku === 'string',
      notEmpty: productDataToCreate.sku && String(productDataToCreate.sku).trim().length > 0,
    },
    'companyIds': {
      required: false,
      type: 'array',
      default: [],
      provided: productDataToCreate.companyIds,
      isArray: Array.isArray(productDataToCreate.companyIds),
    },
  }
  
  Object.keys(schemaChecks).forEach(field => {
    const check = schemaChecks[field as keyof typeof schemaChecks]
    const status = check.required 
      ? (check.typeMatch && (check.enumMatch !== undefined ? check.enumMatch : true) && (check.notEmpty !== undefined ? check.notEmpty : true) && (check.validationMatch !== undefined ? check.validationMatch : true) && (check.isFinite !== undefined ? check.isFinite : true))
      : 'N/A (optional)'
    console.log(`  ${field}:`)
    console.log(`    Required: ${check.required}`)
    console.log(`    Expected Type: ${check.type}`)
    if (check.enum) console.log(`    Enum: ${JSON.stringify(check.enum)}`)
    if (check.validation) console.log(`    Validation: ${check.validation}`)
    console.log(`    Provided: ${JSON.stringify(check.provided)}`)
    console.log(`    Type Match: ${check.typeMatch !== undefined ? check.typeMatch : 'N/A'}`)
    if (check.enumMatch !== undefined) console.log(`    Enum Match: ${check.enumMatch}`)
    if (check.validationMatch !== undefined) console.log(`    Validation Match: ${check.validationMatch}`)
    if (check.notEmpty !== undefined) console.log(`    Not Empty: ${check.notEmpty}`)
    if (check.isFinite !== undefined) console.log(`    Is Finite: ${check.isFinite}`)
    console.log(`    ✅ Status: ${status === true ? 'PASS' : status === false ? '❌ FAIL' : status}`)
  })
  
  // ============================================================
  // FORENSIC DIAGNOSTIC: STEP 6 - FORCE ERROR SURFACING
  // ============================================================
  console.log('\n[FORENSIC] Attempting Uniform.create()...')
  let newProduct
  try {
    newProduct = await Uniform.create(productDataToCreate)
    console.log('[FORENSIC] ✅ Uniform.create() succeeded')
    console.log('[FORENSIC] Created product object:')
    console.log(JSON.stringify(newProduct.toObject(), null, 2))
  } catch (err: any) {
    console.error('\n╔════════════════════════════════════════════════════════════╗')
    console.error('║  ❌ UNIFORM SAVE FAILED - VALIDATION ERROR                ║')
    console.error('╚════════════════════════════════════════════════════════════╝')
    console.error(`[FORENSIC] Error Name: ${err.name}`)
    console.error(`[FORENSIC] Error Message: ${err.message}`)
    console.error(`[FORENSIC] Error Code: ${err.code || 'N/A'}`)
    if (err.errors) {
      console.error('[FORENSIC] Validation Errors:')
      Object.keys(err.errors).forEach(key => {
        const error = err.errors[key]
        console.error(`  ${key}:`)
        console.error(`    Kind: ${error.kind}`)
        console.error(`    Path: ${error.path}`)
        console.error(`    Value: ${JSON.stringify(error.value)}`)
        console.error(`    Message: ${error.message}`)
      })
    }
    if (err.keyPattern) {
      console.error('[FORENSIC] Duplicate Key Pattern:')
      console.error(JSON.stringify(err.keyPattern, null, 2))
    }
    if (err.keyValue) {
      console.error('[FORENSIC] Duplicate Key Value:')
      console.error(JSON.stringify(err.keyValue, null, 2))
    }
    console.error('[FORENSIC] Full Error Stack:')
    console.error(err.stack)
    throw err
  }
  
  // Fetch the created product with populated fields using the string ID (more reliable)
  const created = await Uniform.findOne({ id: productId })
    .populate('vendorId', 'id name')
    .lean()
  
  if (!created) {
    // Fallback: try to use the created product directly
    await newProduct.populate('vendorId', 'id name')
    return toPlainObject(newProduct)
  }
  
  return toPlainObject(created)
}

export async function updateProduct(
  productId: string,
  updateData: {
    name?: string
    category?: 'shirt' | 'pant' | 'shoe' | 'jacket' | 'accessory'
    gender?: 'male' | 'female' | 'unisex'
    sizes?: string[]
    price?: number
    image?: string
    sku?: string
    vendorId?: string
    stock?: number
    // Optional SKU attributes
    attribute1_name?: string
    attribute1_value?: string | number
    attribute2_name?: string
    attribute2_value?: string | number
    attribute3_name?: string
    attribute3_value?: string | number
  }
): Promise<any> {
  await connectDB()
  
  // First, verify the product exists and get its current SKU for validation
  let product: any = await Uniform.findOne({ id: productId }).lean()
  
  // All product IDs are string IDs - no ObjectId fallback needed
  
  if (!product) {
    throw new Error(`Product not found: ${productId}`)
  }
  
  // Handle SKU update (check for duplicates) - must check before update
  if (updateData.sku !== undefined && updateData.sku !== (product as any).sku) {
    const existingBySku = await Uniform.findOne({ sku: updateData.sku }).lean()
    if (existingBySku && (existingBySku as any).id !== productId) {
      throw new Error(`Product with SKU already exists: ${updateData.sku}`)
    }
  }
  
  // Build update object - only include fields that are defined
  const updateObject: any = {}
  if (updateData.name !== undefined) updateObject.name = updateData.name
  if (updateData.category !== undefined) updateObject.category = updateData.category
  if (updateData.gender !== undefined) updateObject.gender = updateData.gender
  if (updateData.sizes !== undefined) updateObject.sizes = updateData.sizes
  if (updateData.price !== undefined) updateObject.price = updateData.price
  if (updateData.image !== undefined) updateObject.image = updateData.image
  if (updateData.sku !== undefined) updateObject.sku = updateData.sku
  
  console.log('[updateProduct] Update data received:', JSON.stringify(updateData, null, 2))
  
  // Update optional attributes (only save if name is provided - name is required for attribute to be valid)
  // IMPORTANT: Check for both undefined and empty string, as form data may send empty strings
  if (updateData.attribute1_name !== undefined) {
    const attr1Name = updateData.attribute1_name ? String(updateData.attribute1_name).trim() : ''
    if (attr1Name !== '') {
      // Name is provided - save it
      updateObject.attribute1_name = attr1Name
      // Save value if provided, otherwise don't include it (preserve existing or leave empty)
      if (updateData.attribute1_value !== undefined && updateData.attribute1_value !== null && String(updateData.attribute1_value).trim() !== '') {
        updateObject.attribute1_value = updateData.attribute1_value
      }
      // Note: If value is empty, we don't set it to null - we just don't update it
    } else {
      // Name is empty - clear the entire attribute
      updateObject.attribute1_name = null
      updateObject.attribute1_value = null
    }
  } else if (updateData.attribute1_value !== undefined) {
    // Only value is being updated (name not provided, preserve existing name)
    if (updateData.attribute1_value !== null && String(updateData.attribute1_value).trim() !== '') {
      updateObject.attribute1_value = updateData.attribute1_value
    } else {
      // Value is being cleared
      updateObject.attribute1_value = null
    }
  }
  
  if (updateData.attribute2_name !== undefined) {
    const attr2Name = updateData.attribute2_name ? String(updateData.attribute2_name).trim() : ''
    if (attr2Name !== '') {
      updateObject.attribute2_name = attr2Name
      if (updateData.attribute2_value !== undefined && updateData.attribute2_value !== null && String(updateData.attribute2_value).trim() !== '') {
        updateObject.attribute2_value = updateData.attribute2_value
      }
    } else {
      updateObject.attribute2_name = null
      updateObject.attribute2_value = null
    }
  } else if (updateData.attribute2_value !== undefined) {
    if (updateData.attribute2_value !== null && String(updateData.attribute2_value).trim() !== '') {
      updateObject.attribute2_value = updateData.attribute2_value
    } else {
      updateObject.attribute2_value = null
    }
  }
  
  if (updateData.attribute3_name !== undefined) {
    const attr3Name = updateData.attribute3_name ? String(updateData.attribute3_name).trim() : ''
    if (attr3Name !== '') {
      updateObject.attribute3_name = attr3Name
      if (updateData.attribute3_value !== undefined && updateData.attribute3_value !== null && String(updateData.attribute3_value).trim() !== '') {
        updateObject.attribute3_value = updateData.attribute3_value
      }
    } else {
      updateObject.attribute3_name = null
      updateObject.attribute3_value = null
    }
  } else if (updateData.attribute3_value !== undefined) {
    if (updateData.attribute3_value !== null && String(updateData.attribute3_value).trim() !== '') {
      updateObject.attribute3_value = updateData.attribute3_value
    } else {
      updateObject.attribute3_value = null
    }
  }
  
  // Build the update query - use $set for all fields
  // Only use $unset to remove fields when name is explicitly cleared
  const updateQuery: any = { $set: {} }
  const unsetFields: any = {}
  
  // Process attributes specially: if name is being cleared, unset both name and value
  // Otherwise, set the name and value (value can be null if not provided)
  const attributeNames = ['attribute1', 'attribute2', 'attribute3']
  attributeNames.forEach(attrPrefix => {
    const nameKey = `${attrPrefix}_name`
    const valueKey = `${attrPrefix}_value`
    
    if (nameKey in updateObject) {
      if (updateObject[nameKey] === null) {
        // Name is being cleared - unset both name and value
        unsetFields[nameKey] = ''
        unsetFields[valueKey] = ''
      } else {
        // Name is being set - include it in $set
        updateQuery.$set[nameKey] = updateObject[nameKey]
        // If value is also being updated, include it (even if null)
        if (valueKey in updateObject) {
          if (updateObject[valueKey] === null) {
            // Value is being cleared but name exists - unset only the value
            unsetFields[valueKey] = ''
          } else {
            updateQuery.$set[valueKey] = updateObject[valueKey]
          }
        }
      }
    } else if (valueKey in updateObject) {
      // Only value is being updated (name not provided)
      if (updateObject[valueKey] === null) {
        unsetFields[valueKey] = ''
      } else {
        updateQuery.$set[valueKey] = updateObject[valueKey]
      }
    }
  })
  
  // Process non-attribute fields
  Object.keys(updateObject).forEach(key => {
    if (!key.startsWith('attribute')) {
      if (updateObject[key] === null) {
        unsetFields[key] = ''
      } else {
        updateQuery.$set[key] = updateObject[key]
      }
    }
  })
  
  if (Object.keys(unsetFields).length > 0) {
    updateQuery.$unset = unsetFields
  }
  
  // Use findOneAndUpdate to update directly in database (avoids save() issues)
  // Try by id field first
  let updated = await Uniform.findOneAndUpdate(
    { id: productId },
    updateQuery,
    { new: true, runValidators: true }
  ).lean()
  
  // All product IDs are string IDs - no ObjectId fallback needed
  if (!updated) {
    // Try as string ID
    const productIdStr = String(productId)
    if (/^\d{6}$/.test(productIdStr)) {
      updated = await Uniform.findOneAndUpdate(
        { id: productIdStr },
      updateQuery,
      { new: true, runValidators: true }
    ).lean()
    }
  }
  
  if (!updated) {
    throw new Error(`Product not found for update: ${productId}`)
  }
  
  return toPlainObject(updated)
}

export async function deleteProduct(productId: string): Promise<void> {
  await connectDB()
  
  const product = await Uniform.findOne({ id: productId })
  if (!product) {
    throw new Error(`Product not found: ${productId}`)
  }
  
  // Delete product-company relationships
  await ProductCompany.deleteMany({ productId: product.id })
  
  // Delete product-vendor relationships
  await ProductVendor.deleteMany({ productId: product.id })
  
  // Delete the product
  await Uniform.deleteOne({ id: product.id })
}

export async function getProductById(productId: string): Promise<any | null> {
  await connectDB()
  
  if (!productId) {
    console.warn('[getProductById] No productId provided.')
    return null
  }
  
  // Find by string ID field
  const product = await Uniform.findOne({ id: productId }).lean()
  
  if (product && product.vendorId) {
    // Manually fetch vendor since populate doesn't work with string IDs
    const vendor = await Vendor.findOne({ id: product.vendorId }).select('id name').lean()
    if (vendor) {
      (product as any).vendorId = vendor
    }
  }
  
  if (!product) {
    console.warn(`[getProductById] No product found for ID: ${productId}`)
    return null
  }
  
  const plain = toPlainObject(product)
  // Explicitly preserve attribute fields
  const productAny = product as any
  if (productAny.attribute1_name !== undefined) plain.attribute1_name = productAny.attribute1_name
  if (productAny.attribute1_value !== undefined) plain.attribute1_value = productAny.attribute1_value
  if (productAny.attribute2_name !== undefined) plain.attribute2_name = productAny.attribute2_name
  if (productAny.attribute2_value !== undefined) plain.attribute2_value = productAny.attribute2_value
  if (productAny.attribute3_name !== undefined) plain.attribute3_name = productAny.attribute3_name
  if (productAny.attribute3_value !== undefined) plain.attribute3_value = productAny.attribute3_value
  
  return plain
}

// ========== VENDOR FUNCTIONS ==========

export async function getAllVendors(): Promise<any[]> {
  await connectDB()
  
  const vendors = await Vendor.find().lean()
  return vendors.map((v: any) => toPlainObject(v))
}

export async function getVendorById(vendorId: string): Promise<any | null> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId }).lean()
  return vendor ? toPlainObject(vendor) : null
}

export async function getVendorByEmail(email: string): Promise<any | null> {
  await connectDB()
  
  console.log(`[getVendorByEmail] ========================================`)
  console.log(`[getVendorByEmail] 🚀 LOOKING UP VENDOR BY EMAIL`)
  console.log(`[getVendorByEmail] Input email: "${email}"`)
  console.log(`[getVendorByEmail] Input type: ${typeof email}`)
  
  if (!email) {
    console.log(`[getVendorByEmail] ❌ Email is empty, returning null`)
    return null
  }
  
  const normalizedEmail = email.trim().toLowerCase()
  console.log(`[getVendorByEmail] Normalized email: "${normalizedEmail}"`)
  
  // Try case-insensitive search using regex
  console.log(`[getVendorByEmail] 🔍 Attempting regex search...`)
  let vendor = await Vendor.findOne({ 
    email: { $regex: new RegExp(`^${normalizedEmail.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }
  }).lean()
  
  if (vendor) {
    console.log(`[getVendorByEmail] ✅ Found vendor via regex: ${vendor.name} (id: ${vendor.id}, _id: ${vendor._id?.toString()})`)
    console.log(`[getVendorByEmail] Vendor email in DB: "${vendor.email}"`)
  } else {
    console.log(`[getVendorByEmail] ⚠️ Regex search returned no results, trying manual comparison...`)
    
    // If not found, try fetching all and comparing (fallback)
    const allVendors = await Vendor.find({}).lean()
    console.log(`[getVendorByEmail] Fetched ${allVendors.length} vendor(s) for manual comparison`)
    
    for (const v of allVendors) {
      const vEmailNormalized = v.email ? v.email.trim().toLowerCase() : ''
      console.log(`[getVendorByEmail]   Comparing: "${vEmailNormalized}" with "${normalizedEmail}"`)
      if (vEmailNormalized === normalizedEmail) {
        vendor = v
        console.log(`[getVendorByEmail] ✅ Found vendor via manual comparison: ${vendor.name} (id: ${vendor.id}, _id: ${vendor._id?.toString()})`)
        break
      }
    }
    
    if (!vendor) {
      console.log(`[getVendorByEmail] ❌ Vendor not found for email: "${email}"`)
      console.log(`[getVendorByEmail] Available vendor emails:`, allVendors.map((v: any) => v.email || 'N/A'))
    }
  }
  
  const result = vendor ? toPlainObject(vendor) : null
  if (result) {
    console.log(`[getVendorByEmail] ✅ Returning vendor: ${result.name} (id: ${result.id})`)
  } else {
    console.log(`[getVendorByEmail] ❌ Returning null (vendor not found)`)
  }
  console.log(`[getVendorByEmail] ========================================`)
  
  return result
}

export async function createVendor(vendorData: {
  name: string
  email: string
  phone: string
  logo: string
  website: string
  primaryColor: string
  secondaryColor: string
  accentColor: string
  theme?: 'light' | 'dark' | 'custom'
}): Promise<any> {
  await connectDB()
  
  // Check if email already exists
  const existingByEmail = await Vendor.findOne({ email: vendorData.email })
  if (existingByEmail) {
    throw new Error(`Vendor with email already exists: ${vendorData.email}`)
  }
  
  // Generate next 6-digit numeric vendor ID
  // Find the highest existing vendor ID
  const existingVendors = await Vendor.find({})
    .sort({ id: -1 })
    .limit(1)
    .lean()
  
  let nextVendorId = 100001 // Start from 100001
  if (existingVendors.length > 0) {
    const lastId = existingVendors[0].id
    // Extract numeric part if it's already numeric
    if (/^\d{6}$/.test(lastId)) {
      const lastIdNum = parseInt(lastId, 10)
      nextVendorId = lastIdNum + 1
    } else {
      // If old format exists, start from 100001
      nextVendorId = 100001
    }
  }
  
  // Ensure it's 6 digits
  let vendorId = String(nextVendorId).padStart(6, '0')
  
  // Check if this ID already exists (shouldn't happen, but safety check)
  const existingById = await Vendor.findOne({ id: vendorId })
  if (existingById) {
    // Find next available ID
    let foundId = false
    for (let i = nextVendorId + 1; i < 999999; i++) {
      const testId = String(i).padStart(6, '0')
      const exists = await Vendor.findOne({ id: testId })
      if (!exists) {
        vendorId = testId
        foundId = true
        break
      }
    }
    if (!foundId) {
      throw new Error('Unable to generate unique vendor ID')
    }
  }
  
  const vendorDataToCreate: any = {
    id: vendorId,
    name: vendorData.name,
    email: vendorData.email,
    phone: vendorData.phone,
    logo: vendorData.logo,
    website: vendorData.website,
    primaryColor: vendorData.primaryColor,
    secondaryColor: vendorData.secondaryColor,
    accentColor: vendorData.accentColor,
    theme: vendorData.theme || 'light',
  }
  
  const newVendor = await Vendor.create(vendorDataToCreate)
  return toPlainObject(newVendor)
}

export async function updateVendor(vendorId: string, vendorData: {
  name?: string
  email?: string
  phone?: string
  logo?: string
  website?: string
  primaryColor?: string
  secondaryColor?: string
  accentColor?: string
  theme?: 'light' | 'dark' | 'custom'
}): Promise<any> {
  await connectDB()
  
  console.log(`[updateVendor] Starting update for vendorId: ${vendorId}`)
  console.log(`[updateVendor] Update data:`, vendorData)
  
  // Find vendor by id field (not _id)
  let vendor = await Vendor.findOne({ id: vendorId })
  
  // Fallback: try finding by _id if vendorId looks like an ObjectId
  // All vendor IDs are string IDs - no ObjectId fallback needed
  if (!vendor) {
    console.log(`[updateVendor] Vendor not found by id field`)
    vendor = null
    if (vendor) {
      console.log(`[updateVendor] Found vendor by _id, using vendor.id: ${vendor.id}`)
    }
  }
  
  if (!vendor) {
    // List available vendors for debugging
    const allVendors = await Vendor.find({}, 'id name').limit(5).lean()
    const availableIds = allVendors.map((v: any) => v.id).join(', ')
    console.error(`[updateVendor] Vendor not found. Available vendor IDs: ${availableIds || 'none'}`)
    throw new Error(`Vendor not found with id: ${vendorId}`)
  }
  
  console.log(`[updateVendor] Vendor found:`, {
    id: vendor.id,
    name: vendor.name
  })
  
  // If email is being updated, check if it conflicts with another vendor
  if (vendorData.email && vendorData.email !== vendor.email) {
    const existingByEmail = await Vendor.findOne({ email: vendorData.email })
    if (existingByEmail && existingByEmail.id !== vendorId) {
      throw new Error(`Vendor with email already exists: ${vendorData.email}`)
    }
  }
  
  // Build update object with only provided fields
  const updateData: any = {}
  if (vendorData.name !== undefined) updateData.name = vendorData.name
  if (vendorData.email !== undefined) updateData.email = vendorData.email
  if (vendorData.phone !== undefined) updateData.phone = vendorData.phone
  if (vendorData.logo !== undefined) updateData.logo = vendorData.logo
  if (vendorData.website !== undefined) updateData.website = vendorData.website
  if (vendorData.primaryColor !== undefined) updateData.primaryColor = vendorData.primaryColor
  if (vendorData.secondaryColor !== undefined) updateData.secondaryColor = vendorData.secondaryColor
  if (vendorData.accentColor !== undefined) updateData.accentColor = vendorData.accentColor
  if (vendorData.theme !== undefined) updateData.theme = vendorData.theme
  
  console.log(`[updateVendor] Update data to apply:`, updateData)
  console.log(`[updateVendor] Query filter: { id: ${vendorId} }`)
  
  // Use findOneAndUpdate with id field
  let updatedVendor
  try {
    updatedVendor = await Vendor.findOneAndUpdate(
      { id: vendorId },
      { $set: updateData },
      { new: true, runValidators: true }
    )
    
    console.log(`[updateVendor] findOneAndUpdate result:`, updatedVendor ? 'Success' : 'Null')
  } catch (updateError: any) {
    console.error(`[updateVendor] Error during findOneAndUpdate:`, {
      error: updateError.message,
      stack: updateError.stack,
      vendorId
    })
    throw new Error(`Failed to update vendor: ${updateError.message}`)
  }
  
  if (!updatedVendor) {
    // Try alternative approach: update the document directly
    console.log(`[updateVendor] findOneAndUpdate returned null, trying direct update`)
    try {
      // Update fields directly on the vendor document
      Object.assign(vendor, updateData)
      await vendor.save()
      updatedVendor = vendor
      console.log(`[updateVendor] Direct save successful`)
    } catch (saveError: any) {
      console.error(`[updateVendor] Direct save also failed:`, {
        error: saveError.message,
        stack: saveError.stack
      })
      throw new Error(`Failed to update vendor with id: ${vendorId}. Error: ${saveError.message}`)
    }
  }
  
  console.log(`[updateVendor] ✅ Update successful for vendor ${vendorId}`)
  return toPlainObject(updatedVendor)
}

// ========== COMPANY FUNCTIONS ==========

export async function createCompany(companyData: {
  name: string
  logo: string
  website: string
  primaryColor: string
  secondaryColor?: string
  showPrices?: boolean
  allowPersonalPayments?: boolean
}): Promise<any> {
  await connectDB()
  
  // Check if company name already exists
  const existingByName = await Company.findOne({ name: companyData.name })
  if (existingByName) {
    throw new Error(`Company with name already exists: ${companyData.name}`)
  }
  
  // Generate next 6-digit numeric company ID (starting from 100001)
  const existingCompanies = await Company.find({})
    .sort({ id: -1 })
    .limit(1)
    .lean()
  
  let nextCompanyId = 100001 // Start from 100001
  if (existingCompanies.length > 0) {
    const lastId = existingCompanies[0].id
    if (/^\d{6}$/.test(String(lastId))) {
      const lastIdNum = parseInt(String(lastId), 10)
      if (lastIdNum >= 100001 && lastIdNum < 200000) {
        nextCompanyId = lastIdNum + 1
      }
    }
  }
  
  let companyId = String(nextCompanyId).padStart(6, '0')
  
  // Check if this ID already exists (safety check)
  const existingById = await Company.findOne({ id: companyId })
  if (existingById) {
    // Find next available ID
    for (let i = nextCompanyId + 1; i < 200000; i++) {
      const testId = String(i).padStart(6, '0')
      const exists = await Company.findOne({ id: testId })
      if (!exists) {
        companyId = testId
        break
      }
    }
  }
  
  const companyDataToCreate: any = {
    id: companyId,
    name: companyData.name,
    logo: companyData.logo,
    website: companyData.website,
    primaryColor: companyData.primaryColor,
    secondaryColor: companyData.secondaryColor || '#f76b1c',
    showPrices: companyData.showPrices || false,
    allowPersonalPayments: companyData.allowPersonalPayments || false,
  }
  
  const newCompany = await Company.create(companyDataToCreate)
  return toPlainObject(newCompany)
}

export async function getAllCompanies(): Promise<any[]> {
  await connectDB()
  
  const companies = await Company.find()
    .populate('adminId', 'id employeeId firstName lastName email')
    .lean()
  
  // Convert to plain objects but preserve _id for ObjectId matching
  return companies.map((c: any) => {
    const plain = toPlainObject(c)
    // Preserve _id for ObjectId matching (needed for companyId conversion)
    if (c._id) {
      plain._id = c._id.toString()
    }
    return plain
  })
}

// ========== LOCATION FUNCTIONS ==========

/**
 * Create a new Location
 * @param locationData Location data including companyId and adminId (required)
 * @returns Created location object
 */
export async function createLocation(locationData: {
  name: string
  companyId: string // Company ID (6-digit numeric string)
  adminId?: string // Employee ID (6-digit numeric string) - Location Admin (optional)
  address_line_1: string
  address_line_2?: string
  address_line_3?: string
  city: string
  state: string
  pincode: string
  country?: string
  phone?: string
  email?: string
  status?: 'active' | 'inactive'
}): Promise<any> {
  await connectDB()
  
  // Find company by ID
  const company = await Company.findOne({ id: locationData.companyId })
  if (!company) {
    throw new Error(`Company not found: ${locationData.companyId}`)
  }
  
  // Find employee (Location Admin) by employeeId if provided
  let adminEmployee = null
  if (locationData.adminId) {
    adminEmployee = await Employee.findOne({ employeeId: locationData.adminId })
    if (!adminEmployee) {
      throw new Error(`Employee not found for Location Admin: ${locationData.adminId}`)
    }
    
    // Verify employee belongs to the same company
    // CRITICAL FIX: adminEmployee.companyId is a STRING ID, not ObjectId
    const employeeCompanyId = typeof adminEmployee.companyId === 'object' && adminEmployee.companyId?.id
      ? adminEmployee.companyId.id
      : (await Company.findOne({ id: String(adminEmployee.companyId) }))?.id
    
    if (employeeCompanyId !== locationData.companyId) {
      throw new Error(`Employee ${locationData.adminId} does not belong to company ${locationData.companyId}`)
    }
  }
  
  // Check if location name already exists for this company
  const existingLocation = await Location.findOne({ 
    companyId: company.id, // Use string ID, not ObjectId
    name: locationData.name.trim() 
  })
  if (existingLocation) {
    throw new Error(`Location with name "${locationData.name}" already exists for this company`)
  }
  
  // Generate next 6-digit numeric location ID (starting from 400001)
  const existingLocations = await Location.find({})
    .sort({ id: -1 })
    .limit(1)
    .lean()
  
  let nextLocationId = 400001 // Start from 400001
  if (existingLocations.length > 0) {
    const lastId = existingLocations[0].id
    if (/^\d{6}$/.test(String(lastId))) {
      const lastIdNum = parseInt(String(lastId), 10)
      if (lastIdNum >= 400001 && lastIdNum < 500000) {
        nextLocationId = lastIdNum + 1
      }
    }
  }
  
  let locationId = String(nextLocationId).padStart(6, '0')
  
  // Check if this ID already exists (safety check)
  const existingById = await Location.findOne({ id: locationId })
  if (existingById) {
    // Find next available ID
    for (let i = nextLocationId + 1; i < 500000; i++) {
      const testId = String(i).padStart(6, '0')
      const exists = await Location.findOne({ id: testId })
      if (!exists) {
        locationId = testId
        break
      }
    }
  }
  
  // Create location with structured address fields
  const locationDataToCreate: any = {
    id: locationId,
    name: locationData.name.trim(),
    companyId: company.id, // Use string ID, not ObjectId
    address_line_1: locationData.address_line_1.trim(),
    address_line_2: locationData.address_line_2?.trim(),
    address_line_3: locationData.address_line_3?.trim(),
    city: locationData.city.trim(),
    state: locationData.state.trim(),
    pincode: locationData.pincode.trim(),
    country: locationData.country?.trim() || 'India',
    status: locationData.status || 'active',
  }
  
  // Add adminId if provided - use string ID, not ObjectId
  if (adminEmployee) {
    locationDataToCreate.adminId = adminEmployee.id || adminEmployee.employeeId
  }
  
  // Add optional fields
  if (locationData.phone) locationDataToCreate.phone = locationData.phone.trim()
  if (locationData.email) locationDataToCreate.email = locationData.email.trim()
  
  const newLocation = await Location.create(locationDataToCreate)
  
  // Create LocationAdmin relationship if admin exists
  if (adminEmployee) {
    // Use employee.id (6-digit numeric string) instead of ObjectId
    const employeeIdString = adminEmployee.id || adminEmployee.employeeId
    if (!employeeIdString) {
      console.warn(`[createLocation] Admin employee has no id or employeeId field`)
    } else {
      await LocationAdmin.findOneAndUpdate(
        { locationId: newLocation.id, employeeId: employeeIdString },
        { locationId: newLocation.id, employeeId: employeeIdString },
        { upsert: true }
      )
    }
  }
  
  // Fetch and return with manually populated admin info
  const location = await Location.findOne({ id: newLocation.id })
    .lean()
  
  if (!location) {
    throw new Error(`Location not found after creation: ${newLocation.id}`)
  }
  
  const locationObj = toPlainObject(location)
  
  // Manually fetch company info
  if (locationObj.companyId && typeof locationObj.companyId === 'string') {
    const companyInfo = await Company.findOne({ id: locationObj.companyId })
      .select('id name')
      .lean()
    if (companyInfo) {
      locationObj.companyId = toPlainObject(companyInfo)
    }
  }
  
  // Manually fetch admin info using string ID
  if (locationObj.adminId && typeof locationObj.adminId === 'string') {
    const admin = await Employee.findOne({ 
      $or: [
        { id: locationObj.adminId },
        { employeeId: locationObj.adminId }
      ]
    }).select('id employeeId firstName lastName email designation').lean()
    
    if (admin) {
      // CRITICAL: Decrypt sensitive fields since we used .lean() which bypasses Mongoose hooks
      const { decrypt } = require('../utils/encryption')
      const decryptedAdmin: any = { ...admin }
      const sensitiveFields = ['firstName', 'lastName', 'email', 'designation']
      
      for (const field of sensitiveFields) {
        if (decryptedAdmin[field] && typeof decryptedAdmin[field] === 'string' && decryptedAdmin[field].includes(':')) {
          try {
            decryptedAdmin[field] = decrypt(decryptedAdmin[field])
          } catch (error) {
            // If decryption fails, keep original value
            console.warn(`[getLocationById] Failed to decrypt admin ${field}:`, error)
          }
        }
      }
      
      locationObj.adminId = toPlainObject(decryptedAdmin)
    } else {
      locationObj.adminId = null
    }
  } else if (!locationObj.adminId) {
    locationObj.adminId = null
  }
  
  return locationObj
}

/**
 * Get all locations for a company
 * @param companyId Company ID (6-digit numeric string)
 * @returns Array of locations
 */
export async function getLocationsByCompany(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    return []
  }
  
  // CRITICAL FIX: Location.companyId is stored as STRING ID, not ObjectId
  const locations = await Location.find({ companyId: company.id })
    .sort({ name: 1 })
    .lean()
  
  // Manually fetch admin info for each location using string IDs
  const locationsWithAdmin = await Promise.all(locations.map(async (location: any) => {
    const locationObj = toPlainObject(location)
    
    // Manually fetch company info
    if (locationObj.companyId && typeof locationObj.companyId === 'string') {
      const companyInfo = await Company.findOne({ id: locationObj.companyId })
        .select('id name')
        .lean()
      if (companyInfo) {
        locationObj.companyId = toPlainObject(companyInfo)
      }
    }
    
    // Manually fetch admin info using string ID
    if (locationObj.adminId && typeof locationObj.adminId === 'string') {
      const admin = await Employee.findOne({ 
        $or: [
          { id: locationObj.adminId },
          { employeeId: locationObj.adminId }
        ]
      }).select('id employeeId firstName lastName email designation').lean()
      
      if (admin) {
        // CRITICAL: Decrypt sensitive fields since we used .lean() which bypasses Mongoose hooks
        const { decrypt } = require('../utils/encryption')
        const decryptedAdmin: any = { ...admin }
        const sensitiveFields = ['firstName', 'lastName', 'email', 'designation']
        
        for (const field of sensitiveFields) {
          if (decryptedAdmin[field] && typeof decryptedAdmin[field] === 'string' && decryptedAdmin[field].includes(':')) {
            try {
              decryptedAdmin[field] = decrypt(decryptedAdmin[field])
            } catch (error) {
              // If decryption fails, keep original value
              console.warn(`[getLocationsByCompany] Failed to decrypt admin ${field}:`, error)
            }
          }
        }
        
        locationObj.adminId = toPlainObject(decryptedAdmin)
      } else {
        locationObj.adminId = null
      }
    } else if (!locationObj.adminId) {
      locationObj.adminId = null
    }
    
    return locationObj
  }))
  
  return locationsWithAdmin
}

/**
 * Get location by ID
 * @param locationId Location ID (6-digit numeric string)
 * @returns Location object or null
 */
export async function getLocationById(locationId: string): Promise<any | null> {
  await connectDB()
  
  const location = await Location.findOne({ id: locationId })
    .lean()
  
  if (!location) {
    return null
  }
  
  const locationObj = toPlainObject(location)
  
  // Manually fetch company info
  if (locationObj.companyId && typeof locationObj.companyId === 'string') {
    const companyInfo = await Company.findOne({ id: locationObj.companyId })
      .select('id name')
      .lean()
    if (companyInfo) {
      locationObj.companyId = toPlainObject(companyInfo)
    }
  }
  
  // Manually fetch admin info using string ID
  if (locationObj.adminId && typeof locationObj.adminId === 'string') {
    const admin = await Employee.findOne({ 
      $or: [
        { id: locationObj.adminId },
        { employeeId: locationObj.adminId }
      ]
    }).select('id employeeId firstName lastName email designation').lean()
    
    if (admin) {
      // CRITICAL: Decrypt sensitive fields since we used .lean() which bypasses Mongoose hooks
      const { decrypt } = require('../utils/encryption')
      const decryptedAdmin: any = { ...admin }
      const sensitiveFields = ['firstName', 'lastName', 'email', 'designation']
      
      for (const field of sensitiveFields) {
        if (decryptedAdmin[field] && typeof decryptedAdmin[field] === 'string' && decryptedAdmin[field].includes(':')) {
          try {
            decryptedAdmin[field] = decrypt(decryptedAdmin[field])
          } catch (error) {
            // If decryption fails, keep original value
            console.warn(`[updateLocation] Failed to decrypt admin ${field}:`, error)
          }
        }
      }
      
      locationObj.adminId = toPlainObject(decryptedAdmin)
    } else {
      locationObj.adminId = null
    }
  } else if (!locationObj.adminId) {
    locationObj.adminId = null
  }
  
  return locationObj
}

/**
 * Update location
 * @param locationId Location ID
 * @param updateData Fields to update
 * @returns Updated location
 */
export async function updateLocation(
  locationId: string,
  updateData: {
    name?: string
    adminId?: string // New Location Admin employee ID
    address_line_1?: string
    address_line_2?: string
    address_line_3?: string
    city?: string
    state?: string
    pincode?: string
    country?: string
    phone?: string
    email?: string
    status?: 'active' | 'inactive'
  }
): Promise<any> {
  await connectDB()
  
  const location = await Location.findOne({ id: locationId })
  if (!location) {
    throw new Error(`Location not found: ${locationId}`)
  }
  
    // If updating admin (including removal)
    if (updateData.adminId !== undefined) {
      if (updateData.adminId) {
        // Assign new admin - populate companyId to ensure we can compare
        const newAdmin = await Employee.findOne({ employeeId: updateData.adminId })
          .populate('companyId', 'id name')
        if (!newAdmin) {
          throw new Error(`Employee not found: ${updateData.adminId}`)
        }
        
        // Verify employee belongs to same company as location
        // Extract location's company ID
        // CRITICAL FIX: Location.companyId is stored as STRING ID, not ObjectId - use findOne with id field
        let locationCompanyId: string | null = null
        if (location.companyId) {
          // location.companyId is a STRING ID (like "100004"), not ObjectId
          if (typeof location.companyId === 'string' && /^\d{6}$/.test(location.companyId)) {
            // It's already a string ID - use it directly
            locationCompanyId = location.companyId
          } else {
            // Fallback: try to find company by id field
            const locationCompany = await Company.findOne({ id: String(location.companyId) }).select('id').lean()
            if (locationCompany && locationCompany.id) {
              locationCompanyId = locationCompany.id
            }
          }
        }
        
        if (!locationCompanyId) {
          throw new Error(`Location ${locationId} has no associated company`)
        }
        
        // Extract employee's company ID
        // Note: newAdmin.companyId is populated, so it should be an object with id property
        let employeeCompanyId: string | null = null
        if (newAdmin.companyId) {
          if (typeof newAdmin.companyId === 'object') {
            // Populated: { id: '100004', name: '...' } (using string id field)
            if (newAdmin.companyId.id) {
              employeeCompanyId = newAdmin.companyId.id
          } else {
            // Populated but id field missing - try to fetch by id field (string ID)
            // CRITICAL FIX: Company.companyId is stored as STRING ID, not ObjectId
            const employeeCompany = await Company.findOne({ id: String(newAdmin.companyId._id || newAdmin.companyId) }).select('id').lean()
            employeeCompanyId = employeeCompany?.id || null
          }
        } else if (typeof newAdmin.companyId === 'string') {
          // Not populated: Could be string ID (6-digit) or ObjectId string (24 hex)
          // CRITICAL FIX: Check if it's a string ID first, then fallback to ObjectId
          if (/^\d{6}$/.test(newAdmin.companyId)) {
            // It's a string ID - use it directly
            employeeCompanyId = newAdmin.companyId
          } else if (newAdmin.companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(newAdmin.companyId)) {
            // It's an ObjectId string - find company by _id and get its id
            const employeeCompany = await Company.findById(newAdmin.companyId).select('id').lean()
            employeeCompanyId = employeeCompany?.id || null
          } else {
            // Try as string ID anyway
            const employeeCompany = await Company.findOne({ id: newAdmin.companyId }).select('id').lean()
            employeeCompanyId = employeeCompany?.id || null
          }
        }
        }
        
        if (!employeeCompanyId) {
          throw new Error(`Employee ${updateData.adminId} has no associated company`)
        }
        
        console.log(`[updateLocation] Company ID comparison: locationCompanyId=${locationCompanyId}, employeeCompanyId=${employeeCompanyId}`)
        
        if (!locationCompanyId || !employeeCompanyId || employeeCompanyId !== locationCompanyId) {
          throw new Error(`Employee ${updateData.adminId} does not belong to location's company. Location company: ${locationCompanyId}, Employee company: ${employeeCompanyId}`)
        }
        
        // Update adminId - use string ID, not ObjectId
        const employeeIdString = newAdmin.id || newAdmin.employeeId
        if (!employeeIdString) {
          throw new Error(`Admin employee has no id or employeeId field`)
        }
        location.adminId = employeeIdString
        
        // Update LocationAdmin relationship (remove old, add new)
        // Use string IDs for both locationId and employeeId
        await LocationAdmin.findOneAndDelete({ locationId: location.id })
        await LocationAdmin.create({
          locationId: location.id, // Use string ID, not ObjectId
          employeeId: employeeIdString
        })
      } else {
        // Remove admin (adminId is null/undefined/empty string)
        // Set to null explicitly so Mongoose will update the field
        location.adminId = null as any
        // Remove LocationAdmin relationship (safe - won't error if record doesn't exist)
        try {
          const deleted = await LocationAdmin.findOneAndDelete({ locationId: location.id })
          if (!deleted) {
            // LocationAdmin record might not exist, which is fine
            console.log('LocationAdmin record not found for deletion (this is OK):', location.id)
          }
        } catch (error: any) {
          // Log but don't fail - LocationAdmin deletion is not critical
          console.error('Error deleting LocationAdmin record (non-critical):', error.message)
        }
      }
    }
  
  // Update other fields
  if (updateData.name !== undefined) location.name = updateData.name.trim()
  if (updateData.address_line_1 !== undefined) location.address_line_1 = updateData.address_line_1.trim()
  if (updateData.address_line_2 !== undefined) location.address_line_2 = updateData.address_line_2?.trim()
  if (updateData.address_line_3 !== undefined) location.address_line_3 = updateData.address_line_3?.trim()
  if (updateData.city !== undefined) location.city = updateData.city.trim()
  if (updateData.state !== undefined) location.state = updateData.state.trim()
  if (updateData.pincode !== undefined) location.pincode = updateData.pincode.trim()
  if (updateData.country !== undefined) location.country = updateData.country.trim()
  if (updateData.phone !== undefined) location.phone = updateData.phone?.trim()
  if (updateData.email !== undefined) location.email = updateData.email?.trim()
  if (updateData.status !== undefined) location.status = updateData.status
  
  await location.save()
  
  // Fetch and return with manually populated admin info
  const updatedLocation = await Location.findOne({ id: location.id })
    .lean()
  
  if (!updatedLocation) {
    throw new Error(`Location not found after update: ${locationId}`)
  }
  
  const locationObj = toPlainObject(updatedLocation)
  
  // Manually fetch company info
  if (locationObj.companyId && typeof locationObj.companyId === 'string') {
    const companyInfo = await Company.findOne({ id: locationObj.companyId })
      .select('id name')
      .lean()
    if (companyInfo) {
      locationObj.companyId = toPlainObject(companyInfo)
    }
  }
  
  // Manually fetch admin info using string ID
  if (locationObj.adminId && typeof locationObj.adminId === 'string') {
    const admin = await Employee.findOne({ 
      $or: [
        { id: locationObj.adminId },
        { employeeId: locationObj.adminId }
      ]
    }).select('id employeeId firstName lastName email designation').lean()
    
    if (admin) {
      // CRITICAL: Decrypt sensitive fields since we used .lean() which bypasses Mongoose hooks
      const { decrypt } = require('../utils/encryption')
      const decryptedAdmin: any = { ...admin }
      const sensitiveFields = ['firstName', 'lastName', 'email', 'designation']
      
      for (const field of sensitiveFields) {
        if (decryptedAdmin[field] && typeof decryptedAdmin[field] === 'string' && decryptedAdmin[field].includes(':')) {
          try {
            decryptedAdmin[field] = decrypt(decryptedAdmin[field])
          } catch (error) {
            // If decryption fails, keep original value
            console.warn(`[updateLocation] Failed to decrypt admin ${field}:`, error)
          }
        }
      }
      
      locationObj.adminId = toPlainObject(decryptedAdmin)
    } else {
      locationObj.adminId = null
    }
  } else if (!locationObj.adminId) {
    locationObj.adminId = null
  }
  
  return locationObj
}

/**
 * Delete location
 * @param locationId Location ID
 * @returns Success status
 */
export async function deleteLocation(locationId: string): Promise<void> {
  await connectDB()
  
  const location = await Location.findOne({ id: locationId })
  if (!location) {
    throw new Error(`Location not found: ${locationId}`)
  }
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Check if any employees are assigned to this location using string ID
  const employeesWithLocation = await Employee.countDocuments({ locationId: location.id })
  if (employeesWithLocation > 0) {
    throw new Error(`Cannot delete location: ${employeesWithLocation} employee(s) are assigned to this location`)
  }
  
  // Delete LocationAdmin relationships - use string ID, not ObjectId
  await LocationAdmin.deleteMany({ locationId: location.id })
  
  // Delete location using string ID
  await Location.deleteOne({ id: location.id })
}

/**
 * Get all locations (for Super Admin)
 * @returns Array of all locations
 */
export async function getAllLocations(): Promise<any[]> {
  await connectDB()
  
  const locations = await Location.find({})
    .sort({ companyId: 1, name: 1 })
    .lean()
  
  // Manually fetch admin info for each location using string IDs
  const locationsWithAdmin = await Promise.all(locations.map(async (location: any) => {
    const locationObj = toPlainObject(location)
    
    // Manually fetch company info
    if (locationObj.companyId && typeof locationObj.companyId === 'string') {
      const companyInfo = await Company.findOne({ id: locationObj.companyId })
        .select('id name')
        .lean()
      if (companyInfo) {
        locationObj.companyId = toPlainObject(companyInfo)
      }
    }
    
    // Manually fetch admin info using string ID
    if (locationObj.adminId && typeof locationObj.adminId === 'string') {
      const admin = await Employee.findOne({ 
        $or: [
          { id: locationObj.adminId },
          { employeeId: locationObj.adminId }
        ]
      }).select('id employeeId firstName lastName email designation').lean()
      
      if (admin) {
        // CRITICAL: Decrypt sensitive fields since we used .lean() which bypasses Mongoose hooks
        const { decrypt } = require('../utils/encryption')
        const decryptedAdmin: any = { ...admin }
        const sensitiveFields = ['firstName', 'lastName', 'email', 'designation']
        
        for (const field of sensitiveFields) {
          if (decryptedAdmin[field] && typeof decryptedAdmin[field] === 'string' && decryptedAdmin[field].includes(':')) {
            try {
              decryptedAdmin[field] = decrypt(decryptedAdmin[field])
            } catch (error) {
              // If decryption fails, keep original value
              console.warn(`[getLocationsByCompany] Failed to decrypt admin ${field}:`, error)
            }
          }
        }
        
        locationObj.adminId = toPlainObject(decryptedAdmin)
      } else {
        locationObj.adminId = null
      }
    } else if (!locationObj.adminId) {
      locationObj.adminId = null
    }
    
    return locationObj
  }))
  
  return locationsWithAdmin
}

export async function getCompanyById(companyId: string | number): Promise<any | null> {
  await connectDB()
  
  // Convert companyId to number if it's a string representation of a number
  let numericCompanyId: number | null = null
  if (typeof companyId === 'string') {
    const parsed = Number(companyId)
    if (!isNaN(parsed) && isFinite(parsed)) {
      numericCompanyId = parsed
    }
  } else if (typeof companyId === 'number') {
    numericCompanyId = companyId
  }
  
  // Find company by numeric ID first (since company.id is now numeric)
  // Explicitly select all fields including enableEmployeeOrder, allowLocationAdminViewFeedback, allowEligibilityConsumptionReset, and workflow fields
  let company = null
  if (numericCompanyId !== null) {
    company = await Company.findOne({ id: numericCompanyId })
      .select('id name logo website primaryColor secondaryColor showPrices allowPersonalPayments allowPersonalAddressDelivery enableEmployeeOrder allowLocationAdminViewFeedback allowEligibilityConsumptionReset enable_pr_po_workflow enable_site_admin_pr_approval require_company_admin_po_approval allow_multi_pr_po enable_site_admin_approval require_company_admin_approval adminId createdAt updatedAt')
      .populate('adminId', 'id employeeId firstName lastName email')
      .lean()
  }
  
  // If not found by numeric ID, try as string ID (for backward compatibility)
  if (!company && typeof companyId === 'string') {
    company = await Company.findOne({ id: companyId })
      .select('id name logo website primaryColor secondaryColor showPrices allowPersonalPayments allowPersonalAddressDelivery enableEmployeeOrder allowLocationAdminViewFeedback allowEligibilityConsumptionReset enable_pr_po_workflow enable_site_admin_pr_approval require_company_admin_po_approval allow_multi_pr_po enable_site_admin_approval require_company_admin_approval adminId createdAt updatedAt')
      .populate('adminId', 'id employeeId firstName lastName email')
      .lean()
  }
  
  return company ? toPlainObject(company) : null
}

export async function updateCompanySettings(
  companyId: string,
  settings: { 
    showPrices?: boolean
    allowPersonalPayments?: boolean
    enableEmployeeOrder?: boolean
    allowLocationAdminViewFeedback?: boolean
    allowEligibilityConsumptionReset?: boolean
    logo?: string
    primaryColor?: string
    secondaryColor?: string
    name?: string
    // PR → PO Workflow Configuration
    enable_pr_po_workflow?: boolean
    enable_site_admin_pr_approval?: boolean
    require_company_admin_po_approval?: boolean
    allow_multi_pr_po?: boolean
    // Shipping Configuration
    shipmentRequestMode?: 'MANUAL' | 'AUTOMATIC'
  }
): Promise<any> {
  await connectDB()
  
  // Try to find company by numeric ID (string or number)
  let company = null
  const numericId = typeof companyId === 'string' ? Number(companyId) : companyId
  if (!isNaN(numericId) && isFinite(numericId)) {
    company = await Company.findOne({ id: String(numericId) })
  }
  
  // If not found, try as string ID
  if (!company) {
    company = await Company.findOne({ id: companyId })
  }
  
  if (!company) {
    console.error(`[updateCompanySettings] Company not found for ID: ${companyId} (type: ${typeof companyId})`)
    throw new Error(`Company not found: ${companyId}`)
  }
  
  if (settings.showPrices !== undefined) {
    company.showPrices = settings.showPrices
  }
  
  if (settings.allowPersonalPayments !== undefined) {
    company.allowPersonalPayments = settings.allowPersonalPayments
  }
  
  if (settings.enableEmployeeOrder !== undefined) {
    // Explicitly set the field to ensure it's saved to database (even if false)
    console.log(`[updateCompanySettings] Setting enableEmployeeOrder to: ${settings.enableEmployeeOrder} (type: ${typeof settings.enableEmployeeOrder})`)
    const boolValue = Boolean(settings.enableEmployeeOrder) // Ensure it's a boolean
    company.enableEmployeeOrder = boolValue
    // Mark the field as modified to ensure Mongoose saves it
    company.markModified('enableEmployeeOrder')
    // Also explicitly set it using set() to ensure it's tracked
    company.set('enableEmployeeOrder', boolValue)
    console.log(`[updateCompanySettings] After setting - company.enableEmployeeOrder=${company.enableEmployeeOrder}, type=${typeof company.enableEmployeeOrder}`)
  } else {
    console.log(`[updateCompanySettings] enableEmployeeOrder is undefined in settings`)
  }
  
  if (settings.allowLocationAdminViewFeedback !== undefined) {
    const boolValue = Boolean(settings.allowLocationAdminViewFeedback)
    company.allowLocationAdminViewFeedback = boolValue
    company.markModified('allowLocationAdminViewFeedback')
    company.set('allowLocationAdminViewFeedback', boolValue)
  }
  
  if (settings.allowEligibilityConsumptionReset !== undefined) {
    const boolValue = Boolean(settings.allowEligibilityConsumptionReset)
    company.allowEligibilityConsumptionReset = boolValue
    company.markModified('allowEligibilityConsumptionReset')
    company.set('allowEligibilityConsumptionReset', boolValue)
  }
  
  if (settings.logo !== undefined) {
    company.logo = settings.logo
  }
  
  if (settings.primaryColor !== undefined) {
    company.primaryColor = settings.primaryColor
  }
  
  if (settings.secondaryColor !== undefined) {
    company.secondaryColor = settings.secondaryColor
  }
  
  if (settings.name !== undefined) {
    company.name = settings.name
  }
  
  // PR → PO Workflow Configuration
  if (settings.enable_pr_po_workflow !== undefined) {
    const boolValue = Boolean(settings.enable_pr_po_workflow)
    company.enable_pr_po_workflow = boolValue
    company.markModified('enable_pr_po_workflow')
    company.set('enable_pr_po_workflow', boolValue)
  }
  
  if (settings.enable_site_admin_pr_approval !== undefined) {
    const boolValue = Boolean(settings.enable_site_admin_pr_approval)
    company.enable_site_admin_pr_approval = boolValue
    company.markModified('enable_site_admin_pr_approval')
    company.set('enable_site_admin_pr_approval', boolValue)
    // Sync to deprecated field for backward compatibility
    company.enable_site_admin_approval = boolValue
  }
  
  if (settings.require_company_admin_po_approval !== undefined) {
    const boolValue = Boolean(settings.require_company_admin_po_approval)
    company.require_company_admin_po_approval = boolValue
    company.markModified('require_company_admin_po_approval')
    company.set('require_company_admin_po_approval', boolValue)
    // Sync to deprecated field for backward compatibility
    company.require_company_admin_approval = boolValue
  }
  
  if (settings.allow_multi_pr_po !== undefined) {
    const boolValue = Boolean(settings.allow_multi_pr_po)
    company.allow_multi_pr_po = boolValue
    company.markModified('allow_multi_pr_po')
    company.set('allow_multi_pr_po', boolValue)
  }
  
  // Shipping Configuration
  if (settings.shipmentRequestMode !== undefined) {
    if (settings.shipmentRequestMode !== 'MANUAL' && settings.shipmentRequestMode !== 'AUTOMATIC') {
      throw new Error('shipmentRequestMode must be either MANUAL or AUTOMATIC')
    }
    company.shipmentRequestMode = settings.shipmentRequestMode
    company.markModified('shipmentRequestMode')
    company.set('shipmentRequestMode', settings.shipmentRequestMode)
  }
  
  // Log before save
  console.log(`[updateCompanySettings] Before save - company.enableEmployeeOrder=${company.enableEmployeeOrder}, type=${typeof company.enableEmployeeOrder}`)
  console.log(`[updateCompanySettings] Company document _id: ${company._id}, id: ${company.id}`)
  
  // Save the company - explicitly save to ensure enableEmployeeOrder is persisted
  // Use updateOne with raw MongoDB if save fails (fallback)
  try {
  await company.save({ validateBeforeSave: true })
  } catch (saveError: any) {
    console.error(`[updateCompanySettings] Error saving company document:`, saveError)
    // Fallback: Use raw MongoDB updateOne
    const db = mongoose.connection.db
    if (db) {
      const queryId = !isNaN(numericId) && isFinite(numericId) ? String(numericId) : companyId
      const updateResult = await db.collection('companies').updateOne(
        { id: queryId },
        { 
          $set: {
            ...(settings.showPrices !== undefined && { showPrices: settings.showPrices }),
            ...(settings.allowPersonalPayments !== undefined && { allowPersonalPayments: settings.allowPersonalPayments }),
            ...(settings.enableEmployeeOrder !== undefined && { enableEmployeeOrder: settings.enableEmployeeOrder }),
            ...(settings.allowLocationAdminViewFeedback !== undefined && { allowLocationAdminViewFeedback: settings.allowLocationAdminViewFeedback }),
            ...(settings.allowEligibilityConsumptionReset !== undefined && { allowEligibilityConsumptionReset: settings.allowEligibilityConsumptionReset }),
            ...(settings.logo !== undefined && { logo: settings.logo }),
            ...(settings.primaryColor !== undefined && { primaryColor: settings.primaryColor }),
            ...(settings.secondaryColor !== undefined && { secondaryColor: settings.secondaryColor }),
            ...(settings.name !== undefined && { name: settings.name }),
            ...(settings.enable_pr_po_workflow !== undefined && { enable_pr_po_workflow: settings.enable_pr_po_workflow }),
            ...(settings.enable_site_admin_pr_approval !== undefined && { 
              enable_site_admin_pr_approval: settings.enable_site_admin_pr_approval,
              enable_site_admin_approval: settings.enable_site_admin_pr_approval // Sync deprecated field
            }),
            ...(settings.require_company_admin_po_approval !== undefined && { 
              require_company_admin_po_approval: settings.require_company_admin_po_approval,
              require_company_admin_approval: settings.require_company_admin_po_approval // Sync deprecated field
            }),
            ...(settings.allow_multi_pr_po !== undefined && { allow_multi_pr_po: settings.allow_multi_pr_po }),
          }
        }
      )
      if (updateResult.matchedCount === 0) {
        throw new Error(`Company not found for update: ${companyId}`)
      }
      console.log(`[updateCompanySettings] Updated company using raw MongoDB updateOne`)
    } else {
      throw saveError
    }
  }
  
  // Verify the save by checking the database directly using raw MongoDB query
  const db = mongoose.connection.db
  let rawDbValue: boolean | null = null
  if (db) {
    // Use the same ID format we used to find the company
    const queryId = !isNaN(numericId) && isFinite(numericId) ? String(numericId) : companyId
    const rawCompany = await db.collection('companies').findOne({ id: queryId })
    rawDbValue = rawCompany?.enableEmployeeOrder !== undefined ? Boolean(rawCompany.enableEmployeeOrder) : null
    console.log(`[updateCompanySettings] Raw DB value after save - enableEmployeeOrder=${rawDbValue}, type=${typeof rawDbValue}, exists=${rawCompany?.enableEmployeeOrder !== undefined}`)
  }
  
  console.log(`[updateCompanySettings] After save - company.enableEmployeeOrder=${company.enableEmployeeOrder}`)
  
  // Fetch the updated company using Mongoose document (not lean) to ensure all fields are included
  // Then convert to plain object
  // Use the same ID format we used to find the company
  let updatedDoc = null
  const queryId = !isNaN(numericId) && isFinite(numericId) ? String(numericId) : companyId
  updatedDoc = await Company.findOne({ id: queryId })
    .select('id name logo website primaryColor secondaryColor showPrices allowPersonalPayments allowPersonalAddressDelivery enableEmployeeOrder allowLocationAdminViewFeedback allowEligibilityConsumptionReset enable_pr_po_workflow enable_site_admin_pr_approval require_company_admin_po_approval allow_multi_pr_po adminId createdAt updatedAt')
  
  // If not found, try with original companyId
  if (!updatedDoc) {
    updatedDoc = await Company.findOne({ id: companyId })
      .select('id name logo website primaryColor secondaryColor showPrices allowPersonalPayments allowPersonalAddressDelivery enableEmployeeOrder allowLocationAdminViewFeedback allowEligibilityConsumptionReset enable_pr_po_workflow enable_site_admin_pr_approval require_company_admin_po_approval allow_multi_pr_po adminId createdAt updatedAt')
  }
  
  if (!updatedDoc) {
    // Fallback: try to use the saved company directly (convert to plain object)
    const savedPlain = company.toObject ? company.toObject() : company
    console.log(`[updateCompanySettings] Using saved company directly, enableEmployeeOrder=${savedPlain.enableEmployeeOrder}`)
    return toPlainObject(savedPlain)
  }
  
  // Convert Mongoose document to plain object - this ensures enableEmployeeOrder is included
  const updated = updatedDoc.toObject ? updatedDoc.toObject() : updatedDoc
  
  // CRITICAL FIX: Override with raw database value if available (raw DB is source of truth)
  // This ensures we use the actual database value, not Mongoose's interpretation
  if (rawDbValue !== null && rawDbValue !== undefined) {
    updated.enableEmployeeOrder = Boolean(rawDbValue)
    console.log(`[updateCompanySettings] Overriding Mongoose value with raw DB value: enableEmployeeOrder=${rawDbValue}`)
  }
  
  // Log the value to verify it's being read correctly
  console.log(`[updateCompanySettings] Final company ${companyId}, enableEmployeeOrder=${updated.enableEmployeeOrder}, type=${typeof updated.enableEmployeeOrder}`)
  console.log(`[updateCompanySettings] Updated object keys:`, Object.keys(updated))
  console.log(`[updateCompanySettings] Updated object enableEmployeeOrder property:`, 'enableEmployeeOrder' in updated)
  
  // Double-check by querying raw MongoDB (reuse existing db variable)
  if (db) {
    const rawCheck = await db.collection('companies').findOne({ id: companyId })
    console.log(`[updateCompanySettings] Final raw DB check - enableEmployeeOrder=${rawCheck?.enableEmployeeOrder}, type=${typeof rawCheck?.enableEmployeeOrder}`)
  }
  
  const plainObj = toPlainObject(updated)
  console.log(`[updateCompanySettings] After toPlainObject - enableEmployeeOrder=${plainObj.enableEmployeeOrder}, type=${typeof plainObj.enableEmployeeOrder}`)
  
  return plainObj
}

// ========== BRANCH FUNCTIONS ==========

export async function getAllBranches(): Promise<any[]> {
  await connectDB()
  
  const branches = await Branch.find()
    .populate('companyId', 'id name')
    .populate('adminId', 'id employeeId firstName lastName email designation')
    .lean()
  return branches.map((b: any) => toPlainObject(b))
}

export async function getBranchById(branchId: string): Promise<any | null> {
  await connectDB()
  
  const branch = await Branch.findOne({ id: branchId })
    .populate('companyId', 'id name')
    .populate('adminId', 'id employeeId firstName lastName email designation')
    .lean()
  return branch ? toPlainObject(branch) : null
}

export async function getBranchesByCompany(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return []

  // CRITICAL FIX: Branch.companyId is stored as STRING ID, not ObjectId
  const branches = await Branch.find({ companyId: company.id })
    .populate('companyId', 'id name')
    .populate('adminId', 'id employeeId firstName lastName email designation')
    .lean()

  return branches.map((b: any) => toPlainObject(b))
}

export async function getEmployeesByBranch(branchId: string): Promise<any[]> {
  await connectDB()
  
  const branch = await Branch.findOne({ id: branchId })
  if (!branch) return []

  const employees = await Employee.find({ branchId: branch._id })
    .populate('companyId', 'id name')
    .populate({
      path: 'branchId',
      select: 'id name address_line_1 city state pincode',
      strictPopulate: false
    })
    .lean()

  return employees.map((e: any) => toPlainObject(e))
}

/**
 * Create a new branch
 * @param branchData Branch data including structured address fields
 * @returns Created branch
 */
export async function createBranch(branchData: {
  name: string
  companyId: string // Company ID (6-digit numeric string)
  adminId?: string // Employee ID (6-digit numeric string) - Branch Admin (optional)
  address_line_1: string
  address_line_2?: string
  address_line_3?: string
  city: string
  state: string
  pincode: string
  country?: string
  phone?: string
  email?: string
  status?: 'active' | 'inactive'
}): Promise<any> {
  await connectDB()
  
  // Find company by ID
  const company = await Company.findOne({ id: branchData.companyId })
  if (!company) {
    throw new Error(`Company not found: ${branchData.companyId}`)
  }
  
  // Find employee (Branch Admin) by employeeId if provided
  let adminEmployee = null
  if (branchData.adminId) {
    adminEmployee = await Employee.findOne({ employeeId: branchData.adminId })
    if (!adminEmployee) {
      throw new Error(`Employee not found for Branch Admin: ${branchData.adminId}`)
    }
    
    // Verify employee belongs to the same company
    // CRITICAL FIX: adminEmployee.companyId is a STRING ID, not ObjectId
    const employeeCompanyId = typeof adminEmployee.companyId === 'object' && adminEmployee.companyId?.id
      ? adminEmployee.companyId.id
      : (await Company.findOne({ id: String(adminEmployee.companyId) }))?.id
    
    if (employeeCompanyId !== branchData.companyId) {
      throw new Error(`Employee ${branchData.adminId} does not belong to company ${branchData.companyId}`)
    }
  }
  
  // Generate next 6-digit numeric branch ID
  const existingBranches = await Branch.find({})
    .sort({ id: -1 })
    .limit(1)
    .lean()
  
  let nextBranchId = 200001 // Start from 200001
  if (existingBranches.length > 0) {
    const lastId = existingBranches[0].id
    if (/^\d{6}$/.test(String(lastId))) {
      const lastIdNum = parseInt(String(lastId), 10)
      if (lastIdNum >= 200001) {
        nextBranchId = lastIdNum + 1
      }
    }
  }
  
  let branchId = String(nextBranchId).padStart(6, '0')
  
  // Check if this ID already exists (safety check)
  const existingById = await Branch.findOne({ id: branchId })
  if (existingById) {
    // Find next available ID
    for (let i = nextBranchId + 1; i < 300000; i++) {
      const testId = String(i).padStart(6, '0')
      const exists = await Branch.findOne({ id: testId })
      if (!exists) {
        branchId = testId
        break
      }
    }
  }
  
  // Create branch with structured address fields
  const branchDataToCreate: any = {
    id: branchId,
    name: branchData.name.trim(),
    companyId: company._id,
    address_line_1: branchData.address_line_1.trim(),
    address_line_2: branchData.address_line_2?.trim(),
    address_line_3: branchData.address_line_3?.trim(),
    city: branchData.city.trim(),
    state: branchData.state.trim(),
    pincode: branchData.pincode.trim(),
    country: branchData.country?.trim() || 'India',
    status: branchData.status || 'active',
  }
  
  // Add optional fields
  if (branchData.phone) branchDataToCreate.phone = branchData.phone.trim()
  if (branchData.email) branchDataToCreate.email = branchData.email.trim()
  
  // Add adminId if provided
  if (adminEmployee) {
    branchDataToCreate.adminId = adminEmployee.id || adminEmployee.employeeId || String(adminEmployee._id || '')
  }
  
  const newBranch = await Branch.create(branchDataToCreate)
  
  // Populate and return - use string id field instead of _id
  const newBranchId = newBranch.id || String(newBranch._id || '')
  const populated = await Branch.findOne({ id: newBranchId })
    .populate('companyId', 'id name')
    .populate('adminId', 'id employeeId firstName lastName email designation')
    .lean()
  
  return toPlainObject(populated)
}

/**
 * Update branch
 * @param branchId Branch ID
 * @param updateData Fields to update
 * @returns Updated branch
 */
export async function updateBranch(
  branchId: string,
  updateData: {
    name?: string
    adminId?: string // New Branch Admin employee ID
    address_line_1?: string
    address_line_2?: string
    address_line_3?: string
    city?: string
    state?: string
    pincode?: string
    country?: string
    phone?: string
    email?: string
    status?: 'active' | 'inactive'
  }
): Promise<any> {
  await connectDB()
  
  const branch = await Branch.findOne({ id: branchId })
  if (!branch) {
    throw new Error(`Branch not found: ${branchId}`)
  }
  
  // Update name if provided
  if (updateData.name !== undefined) {
    branch.name = updateData.name.trim()
  }
  
  // Update address fields if provided
  if (updateData.address_line_1 !== undefined) {
    branch.address_line_1 = updateData.address_line_1.trim()
  }
  if (updateData.address_line_2 !== undefined) {
    branch.address_line_2 = updateData.address_line_2?.trim()
  }
  if (updateData.address_line_3 !== undefined) {
    branch.address_line_3 = updateData.address_line_3?.trim()
  }
  if (updateData.city !== undefined) {
    branch.city = updateData.city.trim()
  }
  if (updateData.state !== undefined) {
    branch.state = updateData.state.trim()
  }
  if (updateData.pincode !== undefined) {
    branch.pincode = updateData.pincode.trim()
  }
  if (updateData.country !== undefined) {
    branch.country = updateData.country.trim()
  }
  
  // Update optional fields
  if (updateData.phone !== undefined) {
    branch.phone = updateData.phone?.trim()
  }
  if (updateData.email !== undefined) {
    branch.email = updateData.email?.trim()
  }
  if (updateData.status !== undefined) {
    branch.status = updateData.status
  }
  
  // Update admin if provided
  if (updateData.adminId !== undefined) {
    if (updateData.adminId) {
      const adminEmployee = await Employee.findOne({ employeeId: updateData.adminId })
      if (!adminEmployee) {
        throw new Error(`Employee not found for Branch Admin: ${updateData.adminId}`)
      }
      
      // Verify employee belongs to the same company
      const employeeCompanyId = typeof adminEmployee.companyId === 'object' && adminEmployee.companyId?.id
        ? adminEmployee.companyId.id
        : (await Company.findById(adminEmployee.companyId))?.id
      
      // CRITICAL FIX: branch.companyId is a STRING ID, not ObjectId
      const branchCompanyId = typeof branch.companyId === 'object' && branch.companyId?.id
        ? branch.companyId.id
        : (await Company.findOne({ id: String(branch.companyId) }))?.id
      
      if (employeeCompanyId !== branchCompanyId) {
        throw new Error(`Employee ${updateData.adminId} does not belong to branch's company`)
      }
      
      branch.adminId = adminEmployee._id
    } else {
      branch.adminId = undefined
    }
  }
  
  await branch.save()
  
  // Populate and return - use string id field instead of _id
  const updatedBranchId = branch.id || String(branch._id || '')
  const updated = await Branch.findOne({ id: updatedBranchId })
    .populate('companyId', 'id name')
    .populate('adminId', 'id employeeId firstName lastName email designation')
    .lean()
  
  return toPlainObject(updated)
}

/**
 * Delete branch
 * @param branchId Branch ID
 * @returns true if deleted
 */
export async function deleteBranch(branchId: string): Promise<boolean> {
  await connectDB()
  
  const branch = await Branch.findOne({ id: branchId })
  if (!branch) {
    throw new Error(`Branch not found: ${branchId}`)
  }
  
  await Branch.deleteOne({ id: branchId })
  return true
}

// ========== COMPANY ADMIN FUNCTIONS (Multiple Admins) ==========

export async function addCompanyAdmin(companyId: string, employeeId: string, canApproveOrders: boolean = false): Promise<void> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }
  
  // Try multiple lookup methods to find the employee
  let employee: any = null
  
  // Method 1: Try by id field (most common)
  employee = await Employee.findOne({ id: employeeId }).populate('companyId')
  
  // Method 2: If not found, try by employeeId field (business ID like "IND-001")
  if (!employee) {
    employee = await Employee.findOne({ employeeId: employeeId }).populate('companyId')
  }
  
  // Method 3: If still not found and employeeId looks like an email, try by email (with encryption handling)
  // NOTE: Removed ObjectId lookup - we only use STRING IDs
  if (!employee && employeeId.includes('@')) {
    const { encrypt, decrypt } = require('../utils/encryption')
    // Normalize email: trim and lowercase for consistent comparison (same as login flow)
    const normalizedEmail = employeeId.trim().toLowerCase()
    
    console.log(`[addCompanyAdmin] Looking up employee by email: ${normalizedEmail}`)
    
    try {
      // Try encrypted email lookup (email should be encrypted in DB)
      const encryptedEmail = encrypt(normalizedEmail)
      employee = await Employee.findOne({ email: encryptedEmail }).populate('companyId')
      if (employee) {
        console.log(`[addCompanyAdmin] ✅ Found employee via encrypted email lookup`)
      }
    } catch (error) {
      console.warn(`[addCompanyAdmin] Encryption failed, trying decryption matching:`, error)
    }
    
    // If not found with encrypted lookup, try decryption matching (handles different encryption formats)
    if (!employee) {
      // CRITICAL FIX: Employee.companyId is stored as STRING ID, not ObjectId
      const allEmployees = await Employee.find({ companyId: company.id }).populate('companyId').lean()
      console.log(`[addCompanyAdmin] Checking ${allEmployees.length} employees via decryption...`)
      for (const emp of allEmployees) {
        if (emp.email && typeof emp.email === 'string') {
          try {
            const decryptedEmail = decrypt(emp.email)
            // Normalize both for comparison (case-insensitive)
            if (decryptedEmail && decryptedEmail.trim().toLowerCase() === normalizedEmail) {
              console.log(`[addCompanyAdmin] ✅ Found employee via decryption: ${decryptedEmail}`)
              const employeeId = emp.id || String(emp._id || '')
              employee = await Employee.findOne({ id: employeeId }).populate('companyId')
              break
            }
          } catch (error) {
            // Skip employees with decryption errors
            continue
          }
        }
      }
    }
  }
  
  if (!employee) {
    throw new Error(`Employee not found: ${employeeId}. Please ensure the employee exists and belongs to the company.`)
  }
  
  // Verify employee belongs to this company
  // First, try to get the raw companyId without population
  let employeeRaw = await Employee.findOne({ 
    $or: [
      { id: employeeId },
      { employeeId: employeeId }
    ]
  }).lean()
  
  if (!employeeRaw) {
    throw new Error(`Employee not found: ${employeeId}`)
  }
  
  // Get the companyId directly from the raw document
  const employeeCompanyIdRaw = employeeRaw.companyId
  
  // Convert both to strings for comparison
  // Handle both cases: employeeCompanyId might be stored as ObjectId or as string ID
  let employeeCompanyIdStr: string | null = null
  if (employeeCompanyIdRaw) {
    if (typeof employeeCompanyIdRaw === 'object' && employeeCompanyIdRaw.toString) {
      // It's an ObjectId - get the actual company ID by looking up the company
      const companyIdStr = String(employeeCompanyIdRaw)
      const employeeCompany = /^\d{6}$/.test(companyIdStr) 
        ? await Company.findOne({ id: companyIdStr }).lean()
        : null
      employeeCompanyIdStr = employeeCompany ? employeeCompany.id : null
    } else {
      // It's already a string ID
      employeeCompanyIdStr = String(employeeCompanyIdRaw)
    }
  }
  
  // Compare using company.id (string) instead of company._id (ObjectId)
  const companyIdStr = company.id
  
  console.log(`[addCompanyAdmin] Debug - Employee: ${employeeId}, Employee companyId: ${employeeCompanyIdStr}, Company id: ${companyIdStr}`)
  
  if (!employeeCompanyIdStr || employeeCompanyIdStr !== companyIdStr) {
    console.error(`[addCompanyAdmin] Company mismatch - Employee companyId: ${employeeCompanyIdStr}, Company id: ${companyIdStr}`)
    // Don't auto-fix - throw error instead to prevent wrong assignments
    const employeeDisplayId = employeeRaw.employeeId || employeeRaw.id || employeeId
    throw new Error(`Employee ${employeeDisplayId} does not belong to company ${companyId} (${company.name}). Employee is associated with a different company. Please select an employee that belongs to ${company.name}.`)
  }
  
  // Create or update company admin record
  // CRITICAL FIX: Use STRING IDs (company.id, employee.id) instead of ObjectId
  // This ensures consistency with the rest of the application's string ID approach
  
  // Get string IDs - use .id field (business string ID), NOT ._id (ObjectId)
  const companyStringId = company.id // String ID like "100004"
  const employeeStringId = employee.id || employee.employeeId // String ID like "300021"
  
  if (!companyStringId || !employeeStringId) {
    throw new Error(`Invalid IDs: companyId=${companyStringId}, employeeId=${employeeStringId}`)
  }
  
  console.log(`[addCompanyAdmin] Using string IDs: companyId=${companyStringId}, employeeId=${employeeStringId}`)
  
  // First, try to delete any existing record for this company+employee combo using STRING IDs
  await CompanyAdmin.deleteMany({
    companyId: companyStringId,
    employeeId: employeeStringId
  })
  
  // Create new record using Mongoose model with STRING IDs
  const adminRecord = await CompanyAdmin.create({
    companyId: companyStringId,    // String ID, NOT ObjectId
    employeeId: employeeStringId,  // String ID, NOT ObjectId
    canApproveOrders: canApproveOrders,
  })
  
  console.log(`[addCompanyAdmin] Created admin record:`, {
    adminId: adminRecord._id,
    companyId: companyStringId,
    employeeId: employeeStringId
  })
  
  // Verify the record was created correctly using STRING IDs
  const verifyRecord = await CompanyAdmin.findOne({
    companyId: companyStringId,
    employeeId: employeeStringId
  }).lean()
  
  if (!verifyRecord) {
    throw new Error(`Admin record was created but cannot be found for company ${companyStringId}, employee ${employeeStringId}`)
  }
  
  console.log(`[addCompanyAdmin] ✅ Verified admin record exists with employeeId: ${verifyRecord.employeeId}`)
  
  console.log(`Successfully added employee ${employeeId} (${employeeStringId}) as admin for company ${companyId} (canApproveOrders: ${canApproveOrders})`)
}

export async function removeCompanyAdmin(companyId: string, employeeId: string): Promise<void> {
  await connectDB()
  
  if (!employeeId) {
    throw new Error('Employee ID is required')
  }
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }
  
  // CRITICAL FIX: Use STRING IDs only, NO ObjectId lookup
  // Find employee by string ID field (id or employeeId)
  let employee: any = null
  
  // Method 1: Try by id field (most common - string ID like "300021")
  employee = await Employee.findOne({ id: employeeId })
  
  // Method 2: If not found, try by employeeId field (business ID like "IND-001")
  if (!employee) {
    employee = await Employee.findOne({ employeeId: employeeId })
  }
  
  if (!employee) {
    throw new Error(`Employee not found: ${employeeId}`)
  }
  
  // Get string IDs - use .id field (business string ID), NOT ._id (ObjectId)
  const companyStringId = company.id
  const employeeStringId = employee.id || employee.employeeId
  
  console.log(`[removeCompanyAdmin] Using string IDs: companyId=${companyStringId}, employeeId=${employeeStringId}`)
  
  // Delete admin record using STRING IDs only
  let result = await CompanyAdmin.findOneAndDelete({
    companyId: companyStringId,
    employeeId: employeeStringId,
  })
  
  // If not found with exact match, try to find by employee's alternative ID
  if (!result && employee.employeeId && employee.employeeId !== employeeStringId) {
    result = await CompanyAdmin.findOneAndDelete({
      companyId: companyStringId,
      employeeId: employee.employeeId,
    })
  }
  
  // If still not found, search all admins for this company and match by string ID
  if (!result) {
    const allAdmins = await CompanyAdmin.find({ companyId: companyStringId }).lean()
    
    for (const adm of allAdmins) {
      const admEmployeeId = String(adm.employeeId || '')
      // Match against any of the employee's string IDs
      if (admEmployeeId === employeeStringId || 
          admEmployeeId === employee.id || 
          admEmployeeId === employee.employeeId ||
          admEmployeeId === employeeId) {
        // Use string id field instead of _id
        const adminId = adm.id || String(adm._id || '')
        result = await CompanyAdmin.deleteOne({ id: adminId })
        if (result && result.deletedCount > 0) {
          console.log(`[removeCompanyAdmin] ✅ Deleted admin record via fallback match`)
          break
        }
      }
    }
  }
  
  if (!result) {
    throw new Error(`Admin relationship not found for employee ${employeeId} (${employeeStringId}) in company ${companyId}`)
  }
  
  console.log(`[removeCompanyAdmin] ✅ Successfully removed admin: company=${companyStringId}, employee=${employeeStringId}`)
}

export async function updateCompanyAdminPrivileges(companyId: string, employeeId: string, canApproveOrders: boolean): Promise<void> {
  await connectDB()
  
  if (!employeeId) {
    throw new Error('Employee ID is required')
  }
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }
  
  // CRITICAL FIX: Use STRING IDs only, NO ObjectId lookup
  // Find employee by string ID field (id or employeeId)
  let employee: any = null
  
  // Method 1: Try by id field (most common - string ID like "300021")
  employee = await Employee.findOne({ id: employeeId })
  
  // Method 2: If not found, try by employeeId field (business ID like "IND-001")
  if (!employee) {
    employee = await Employee.findOne({ employeeId: employeeId })
  }
  
  if (!employee) {
    throw new Error(`Employee not found: ${employeeId}`)
  }
  
  // Get string IDs - use .id field (business string ID), NOT ._id (ObjectId)
  const companyStringId = company.id
  const employeeStringId = employee.id || employee.employeeId
  
  console.log(`[updateCompanyAdminPrivileges] Using string IDs: companyId=${companyStringId}, employeeId=${employeeStringId}`)
  
  // Find admin record using STRING IDs only
  const admin = await CompanyAdmin.findOne({
    companyId: companyStringId,
    employeeId: employeeStringId,
  })
  
  if (!admin) {
    throw new Error(`Employee ${employeeId} (${employeeStringId}) is not an admin of company ${companyId}`)
  }
  
  admin.canApproveOrders = canApproveOrders
  await admin.save()
  
  console.log(`[updateCompanyAdminPrivileges] ✅ Successfully updated admin privileges for ${employeeStringId} in company ${companyStringId}`)
}

export async function getCompanyAdmins(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    console.log(`[getCompanyAdmins] Company ${companyId} not found, returning empty array`)
    return []
  }
  
  // CRITICAL FIX: CompanyAdmin stores employeeId as STRING ID, not ObjectId
  // Do NOT use .populate() as it expects ObjectId - manually fetch employees using string IDs
  const admins = await CompanyAdmin.find({ companyId: company.id }).lean()
  
  console.log(`[getCompanyAdmins] Found ${admins.length} admins for company ${companyId}`)
  if (admins.length > 0) {
    console.log(`[getCompanyAdmins] Admin employeeIds (raw):`, admins.map((a: any) => ({
      employeeId: a.employeeId,
      employeeIdType: typeof a.employeeId
    })))
  }
  
  // Manually fetch employee data using string IDs
  const validAdmins = []
  const { decrypt } = require('../utils/encryption')
  
  for (const admin of admins) {
    if (!admin.employeeId) {
      console.log(`[getCompanyAdmins] Admin has null employeeId, skipping:`, admin._id)
      continue
    }
    
    // CRITICAL: employeeId is stored as STRING ID (e.g., "300021"), not ObjectId
    const employeeIdStr = typeof admin.employeeId === 'string' 
      ? admin.employeeId 
      : String(admin.employeeId)
    
    console.log(`[getCompanyAdmins] Looking up employee by string ID: ${employeeIdStr}`)
    
    // Find employee using string ID field (not _id)
    const employee = await Employee.findOne({ 
      $or: [
        { id: employeeIdStr },
        { employeeId: employeeIdStr }
      ]
    })
      .select('id employeeId firstName lastName email companyName')
      .lean()
    
    if (employee) {
      console.log(`[getCompanyAdmins] ✅ Found employee: ${employee.employeeId || employee.id}`)
      // Attach employee data to admin object
      ;(admin as any).employeeData = {
        _id: employee._id,
        id: employee.id,
        employeeId: employee.employeeId,
        firstName: employee.firstName,
        lastName: employee.lastName,
        email: employee.email,
        companyName: employee.companyName
      }
      validAdmins.push(admin)
    } else {
      console.log(`[getCompanyAdmins] ⚠️ Employee not found for ID: ${employeeIdStr}`)
      // Still include admin record but without employee data
      validAdmins.push(admin)
    }
  }
  
  console.log(`[getCompanyAdmins] Valid admins after filtering: ${validAdmins.length}`)
  
  // Decrypt employee data and format properly
  const formattedAdmins = validAdmins.map((admin: any) => {
    const adminObj: any = {
      employeeId: admin.employeeId, // Keep as string ID
      canApproveOrders: admin.canApproveOrders || false,
      companyId: admin.companyId?.toString() || admin.companyId,
    }
    
    // If employee data was fetched, decrypt and add it
    if (admin.employeeData) {
      const emp = admin.employeeData
      const sensitiveFields = ['email', 'firstName', 'lastName']
      
      adminObj.employee = {
        id: emp.id,
        employeeId: emp.employeeId,
        email: emp.email || '',
        firstName: emp.firstName || '',
        lastName: emp.lastName || '',
        companyName: emp.companyName || ''
      }
      
      // Decrypt sensitive fields
      for (const field of sensitiveFields) {
        if (adminObj.employee[field] && typeof adminObj.employee[field] === 'string' && adminObj.employee[field].includes(':')) {
          try {
            adminObj.employee[field] = decrypt(adminObj.employee[field])
          } catch (error) {
            // Keep original if decryption fails
            console.warn(`Failed to decrypt ${field} for employee ${emp.id}:`, error)
          }
        }
      }
    }
    
    return adminObj
  })
  
  return formattedAdmins
}

export async function isCompanyAdmin(email: string, companyId: string): Promise<boolean> {
  await connectDB()
  
  // Since email is encrypted, we need to find employee by decrypting
  const { encrypt, decrypt } = require('../utils/encryption')
  // Normalize email: trim and lowercase (same as login flow)
  const normalizedEmail = email.trim().toLowerCase()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(normalizedEmail)
  } catch (error) {
    console.warn('[isCompanyAdmin] Encryption failed:', error)
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          // Normalize both for comparison (case-insensitive)
          if (decryptedEmail && decryptedEmail.trim().toLowerCase() === normalizedEmail) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    console.warn('[isCompanyAdmin] Employee not found for email:', normalizedEmail)
    return false
  }
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    console.warn('[isCompanyAdmin] Company not found:', companyId)
    return false
  }
  
  // Use raw MongoDB collection for reliable lookup
  const db = mongoose.connection.db
  if (!db) {
    console.error('[isCompanyAdmin] Database connection not available')
    return false
  }
  
  // Use string IDs for lookup
  const employeeIdStr = employee.id || employee.employeeId || ''
  const companyIdStr = company.id || ''
  
  console.log('[isCompanyAdmin] Looking up admin record:', {
    email: normalizedEmail,
    companyIdString: companyIdStr,
    employeeId: employeeIdStr,
    companyName: company.name
  })
  
  // CRITICAL FIX: CompanyAdmin.companyId is stored as STRING ID, not ObjectId
  // Use company.id (string) instead of companyObjectId for CompanyAdmin queries
  const CompanyAdmin = require('../models/CompanyAdmin').default
  let admin = await CompanyAdmin.findOne({
    companyId: company.id,
    employeeId: employee.id || employee.employeeId
  }).lean()
  
  if (admin) {
    console.log('[isCompanyAdmin] ✅ Found admin via CompanyAdmin model:', {
      adminId: admin._id?.toString(),
      employeeId: admin.employeeId?.toString(),
      companyId: admin.companyId?.toString()
    })
    return true
  }
  
  console.log('[isCompanyAdmin] Not found via CompanyAdmin model, trying raw MongoDB query...')
  
  // CRITICAL FIX: CompanyAdmin.companyId is stored as STRING ID, not ObjectId
  // Use company.id (string) for raw MongoDB query as well
  const adminRecord = await db.collection('companyadmins').findOne({
    companyId: company.id,
    employeeId: employee.id || employee.employeeId
  })
  
  if (adminRecord) {
    console.log('[isCompanyAdmin] ✅ Found admin via raw MongoDB query:', {
      adminId: adminRecord._id?.toString(),
      employeeId: adminRecord.employeeId?.toString(),
      companyId: adminRecord.companyId?.toString()
    })
    return true
  }
  
  // Additional fallback: Get all admins for this company and check employeeId
  // CRITICAL FIX: CompanyAdmin.companyId is stored as STRING ID, not ObjectId
  // Use company.id (string) for query
  const allCompanyAdmins = await db.collection('companyadmins').find({
    companyId: company.id
  }).toArray()
  
  console.log('[isCompanyAdmin] Total admins for company:', allCompanyAdmins.length)
  
  if (allCompanyAdmins.length > 0) {
    console.log('[isCompanyAdmin] Sample admin record:', {
      firstAdmin: {
        employeeId: allCompanyAdmins[0].employeeId?.toString(),
        companyId: allCompanyAdmins[0].companyId?.toString()
      },
      searchingFor: {
        employeeId: employeeIdStr,
        companyId: companyIdStr
      }
    })
  }
  
  console.log('[isCompanyAdmin] Matching by string IDs:', {
    employeeId: employeeIdStr,
    companyId: companyIdStr
  })
  
  // Match by string IDs
  admin = allCompanyAdmins.find((a: any) => {
    if (!a.employeeId || !a.companyId) return false
    
    const aEmployeeIdStr = String(a.employeeId || '')
    const aCompanyIdStr = String(a.companyId || '')
    
    // String ID comparison
    if (aEmployeeIdStr === employeeIdStr && aCompanyIdStr === companyIdStr) {
      console.log('[isCompanyAdmin] ✅ Found admin via string ID comparison:', {
        employeeId: aEmployeeIdStr,
        companyId: aCompanyIdStr
      })
      return true
    }
    
    return false
  })
  
  const isAdmin = !!admin
  console.log('[isCompanyAdmin] Final result:', {
    email: normalizedEmail,
    companyIdString: companyIdStr,
    employeeId: employeeIdStr,
    foundAdmin: !!admin,
    isAdmin,
    allCompanyAdminsCount: allCompanyAdmins.length
  })
  
  if (!isAdmin) {
    // Log all admins for this company to help debug
    console.log('[isCompanyAdmin] Admins for this company:', allCompanyAdmins.map((a: any) => ({
      employeeId: String(a.employeeId || ''),
      matchesEmployee: String(a.employeeId || '') === employeeIdStr,
      companyId: String(a.companyId || '')
    })))
  }
  
  return isAdmin
}

export async function canApproveOrders(email: string, companyId: string): Promise<boolean> {
  await connectDB()
  
  // Since email is encrypted, we need to find employee by decrypting
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = email.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    return false
  }
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    return false
  }
  
  // CRITICAL FIX: CompanyAdmin.companyId and CompanyAdmin.employeeId are STRING IDs (6-digit numeric), not ObjectId
  // Use company.id and employee.id (string IDs) for CompanyAdmin queries
  const employeeIdStr = employee.id || employee.employeeId
  const companyIdStr = company.id
  
  if (!employeeIdStr || !companyIdStr) {
    console.warn('[canApproveOrders] Missing employee or company string ID:', {
      employeeIdStr,
      companyIdStr,
      employeeId: employee.id,
      employeeIdNum: employee.employeeId,
      companyId: company.id
    })
    return false
  }
  
  // Use raw MongoDB collection for reliable lookup (similar to isCompanyAdmin)
  const db = mongoose.connection.db
  if (!db) {
    // Fallback to Mongoose if raw DB not available
    // CRITICAL FIX: Use string IDs, not ObjectIds
    const admin = await CompanyAdmin.findOne({
      companyId: companyIdStr,
      employeeId: employeeIdStr,
    }).lean()
    return admin?.canApproveOrders || false
  }
  
  // Find all admins and match by string comparison
  // CRITICAL FIX: CompanyAdmin stores string IDs, so compare as strings
  const allAdmins = await db.collection('companyadmins').find({}).toArray()
  const admin = allAdmins.find((a: any) => {
    if (!a.employeeId || !a.companyId) return false
    // Compare as strings (both should be 6-digit numeric strings)
    const aEmployeeIdStr = String(a.employeeId)
    const aCompanyIdStr = String(a.companyId)
    return aEmployeeIdStr === employeeIdStr && aCompanyIdStr === companyIdStr
  })
  
  return admin?.canApproveOrders || false
}

// ========== BRANCH ADMIN AUTHORIZATION FUNCTIONS ==========

/**
 * Check if an employee is a Branch Admin for a specific branch
 * @param email Employee email
 * @param branchId Branch ID (string)
 * @returns true if employee is Branch Admin for the branch
 */
export async function isBranchAdmin(email: string, branchId: string): Promise<boolean> {
  await connectDB()
  
  // Find employee by email (handle encryption)
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = email.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    return false
  }
  
  // Find branch
  const Branch = require('../models/Branch').default
  const branch = await Branch.findOne({ id: branchId })
  if (!branch) {
    return false
  }
  
  // Check if employee is the Branch Admin
  const employeeIdStr = (employee._id || employee.id).toString()
  const branchAdminIdStr = branch.adminId?.toString()
  
  return employeeIdStr === branchAdminIdStr
}

/**
 * Get the branch for which an employee is Branch Admin
 * @param email Employee email
 * @returns Branch object if employee is a Branch Admin, null otherwise
 */
export async function getBranchByAdminEmail(email: string): Promise<any | null> {
  await connectDB()
  
  // Find employee by email (handle encryption)
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = email.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    return null
  }
  
  // Find branch where this employee is admin
  const Branch = require('../models/Branch').default
  const branch = await Branch.findOne({ adminId: employee._id })
    .populate('companyId', 'id name')
    .lean()
  
  if (!branch) {
    return null
  }
  
  return toPlainObject(branch)
}

// ========== LOCATION ADMIN AUTHORIZATION FUNCTIONS ==========

/**
 * Check if an employee is a Location Admin for a specific location
 * @param email Employee email
 * @param locationId Location ID (6-digit numeric string)
 * @returns true if employee is Location Admin for the location
 */
export async function isLocationAdmin(email: string, locationId: string): Promise<boolean> {
  await connectDB()
  
  // Find employee by email (handle encryption)
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = email.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    return false
  }
  
  // Find location
  const location = await Location.findOne({ id: locationId })
  if (!location) {
    return false
  }
  
  // CRITICAL FIX: location.adminId is stored as STRING ID (6-digit numeric), not ObjectId
  // Use employee string ID (employee.id or employee.employeeId), not employee._id
  const employeeIdStr = employee.id || employee.employeeId
  if (!employeeIdStr || !/^\d{6}$/.test(String(employeeIdStr))) {
    return false
  }
  
  const locationAdminIdStr = location.adminId ? String(location.adminId) : null
  
  // Compare string IDs
  return employeeIdStr === locationAdminIdStr
}

/**
 * Get the location ID for which an employee is Location Admin
 * @param email Employee email
 * @returns Location ID if employee is a Location Admin, null otherwise
 */
export async function getLocationByAdminEmail(email: string): Promise<any | null> {
  await connectDB()
  
  // Find employee by email (handle encryption)
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = email.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    return null
  }
  
  // Find location where this employee is admin
  // CRITICAL: adminId is stored as STRING ID (6-digit numeric), not ObjectId
  const employeeIdString = employee.id || employee.employeeId
  if (!employeeIdString) {
    return null
  }
  
  // Find location by string adminId
  const location = await Location.findOne({ 
    $or: [
      { adminId: employeeIdString },
      { adminId: String(employeeIdString) }
    ]
  }).lean()
  
  if (!location) {
    return null
  }
  
  const locationObj = toPlainObject(location)
  
  // Manually fetch company info
  if (locationObj.companyId && typeof locationObj.companyId === 'string') {
    const companyInfo = await Company.findOne({ id: locationObj.companyId })
      .select('id name')
      .lean()
    if (companyInfo) {
      locationObj.companyId = toPlainObject(companyInfo)
    }
  }
  
  // Manually fetch admin info using string ID
  if (locationObj.adminId && typeof locationObj.adminId === 'string') {
    const admin = await Employee.findOne({ 
      $or: [
        { id: locationObj.adminId },
        { employeeId: locationObj.adminId }
      ]
    }).select('id employeeId firstName lastName email designation').lean()
    
    if (admin) {
      locationObj.adminId = toPlainObject(admin)
    } else {
      locationObj.adminId = null
    }
  } else if (!locationObj.adminId) {
    locationObj.adminId = null
  }
  
  return locationObj
}

/**
 * Check if an employee is a regular employee (not Company Admin or Location Admin)
 * Used for enableEmployeeOrder enforcement: only regular employees are restricted
 * @param email Employee email
 * @param companyId Company ID (6-digit numeric string)
 * @returns true if employee is a regular employee (not admin)
 */
export async function isRegularEmployee(email: string, companyId: string): Promise<boolean> {
  await connectDB()
  
  // Check if employee is Company Admin
  const isAdmin = await isCompanyAdmin(email, companyId)
  if (isAdmin) {
    return false // Company Admin is not a regular employee
  }
  
  // Check if employee is Location Admin
  const location = await getLocationByAdminEmail(email)
  if (location) {
    return false // Location Admin is not a regular employee
  }
  
  // Check if employee is Branch Admin (if branch functionality exists)
  // Note: Branch functionality may have been replaced by Location, but check for backward compatibility
  try {
    const branch = await getBranchByAdminEmail(email)
    if (branch) {
      return false // Branch Admin is not a regular employee
    }
  } catch (error) {
    // Branch functionality might not exist, ignore
  }
  
  // If not any type of admin, it's a regular employee
  return true
}

/**
 * Verify that an employee belongs to a specific location
 * Used for Location Admin authorization: Location Admin can only manage employees of their location
 * @param employeeId Employee ID (6-digit numeric string)
 * @param locationId Location ID (6-digit numeric string)
 * @returns true if employee belongs to the location
 */
export async function isEmployeeInLocation(employeeId: string, locationId: string): Promise<boolean> {
  await connectDB()
  
  const employee = await Employee.findOne({ employeeId: employeeId })
  if (!employee) {
    return false
  }
  
  const location = await Location.findOne({ id: locationId })
  if (!location) {
    return false
  }
  
  // Check if employee's locationId matches
  if (!employee.locationId) {
    return false // Employee has no location assigned
  }
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Compare employee's locationId (string) with location's id (string)
  const employeeLocationIdStr = employee.locationId ? String(employee.locationId) : null
  const locationIdStr = location.id
  
  return employeeLocationIdStr === locationIdStr
}

/**
 * Get all employees for a specific location
 * @param locationId Location ID (6-digit numeric string or ObjectId)
 * @returns Array of employees
 */
export async function getEmployeesByLocation(locationId: string): Promise<any[]> {
  await connectDB()
  
  // Find location by id (string) - locationId is always a 6-digit string like "400006"
  // Do NOT try to use it as ObjectId (_id) as it will cause cast errors
  const location = await Location.findOne({ id: locationId })
  
  if (!location) {
    console.warn(`[getEmployeesByLocation] Location not found: ${locationId}`)
    return []
  }
  
  console.log(`[getEmployeesByLocation] Found location: ${location.id} (${location._id}), name: ${location.name}`)
  console.log(`[getEmployeesByLocation] Location companyId type: ${typeof location.companyId}, value:`, location.companyId)
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Employees have locationId stored as string ID (location.id), not ObjectId
  const locationIdString = location.id
  
  // Find employees with this locationId using string ID
  let employees = await Employee.find({ locationId: locationIdString })
    .populate('companyId', 'id name')
    .populate('locationId', 'id name')
    .sort({ employeeId: 1 })
    .lean()
  
  console.log(`[getEmployeesByLocation] Found ${employees.length} employees by locationId string ID: ${locationIdString}`)
  
  // Fallback: If no employees found, try alternative approaches
  if (employees.length === 0) {
    // Extract companyId ObjectId properly - handle both populated and non-populated cases
    let companyObjectId = null
    let companyIdStr = ''
    if (location.companyId) {
      if (typeof location.companyId === 'object' && location.companyId.id) {
        // Populated: { id: '100004', name: '...' }
        companyIdStr = location.companyId.id
      } else if (typeof location.companyId === 'string') {
        // String ID
        companyIdStr = location.companyId
      }
    }
    
    if (!companyIdStr) {
      console.error(`[getEmployeesByLocation] Cannot query employees: no valid companyId found`)
      return []
    }
    
    // Get the company to query employees
    const Company = require('../models/Company').default
    const company = await Company.findOne({ id: companyIdStr }).lean()
    if (!company) {
      console.error(`[getEmployeesByLocation] Company not found for ID: ${companyIdStr}`)
      return []
    }
    
    console.log(`[getEmployeesByLocation] Querying employees for company ID: ${companyIdStr}`)
    const allCompanyEmployees = await Employee.find({ 
      companyId: company._id  // Mongoose schema may still use ObjectId reference
    })
      .populate('companyId', 'id name')
      .populate('locationId', 'id name')
      .sort({ employeeId: 1 })
      .lean()
    
    // Filter employees where locationId.id matches location.id
    const matchedByLocationIdString = allCompanyEmployees.filter((emp: any) => {
      if (emp.locationId) {
        const empLocationId = typeof emp.locationId === 'object' 
          ? emp.locationId.id
          : String(emp.locationId || '')
        return empLocationId === location.id
      }
      return false
    })
    
    if (matchedByLocationIdString.length > 0) {
      console.log(`[getEmployeesByLocation] Found ${matchedByLocationIdString.length} employees by locationId string match`)
      employees = matchedByLocationIdString
    }
  }
  
  // Fallback: If no employees found by locationId, try matching by location name (text field)
  // This handles cases where employees might not have locationId set but have location text field
  if (employees.length === 0) {
    const locationName = location.name
    console.log(`[getEmployeesByLocation] Trying fallback: searching by location name "${locationName}"`)
    
    // Extract key location identifiers from location name
    // Examples: "ICICI Bank Chennai Branch" -> ["chennai"]
    //           "Mumbai Office" -> ["mumbai"]
    const locationNameLower = locationName.toLowerCase()
    const locationNameParts = locationNameLower.split(/\s+/)
    
    // Find city/location keywords (exclude common words)
    const excludeWords = ['bank', 'branch', 'office', 'location', 'icici', 'indigo', 'company', 'ltd', 'limited']
    const keyWords = locationNameParts
      .filter((part: string) => part.length > 2 && !excludeWords.includes(part))
      .map((part: string) => part.trim())
    
    // Also try city name from location if available
    if (location.city) {
      keyWords.push(location.city.toLowerCase())
    }
    
    console.log(`[getEmployeesByLocation] Searching for employees with location containing keywords:`, keyWords)
    
    // Get all employees for the same company as the location
    // Extract companyId properly - handle both populated and non-populated cases
    let companyIdForQuery = ''
    if (location.companyId) {
      if (typeof location.companyId === 'object' && location.companyId.id) {
        // Populated: { id: '100004', name: '...' }
        companyIdForQuery = location.companyId.id
      } else if (typeof location.companyId === 'string') {
        // It's a company ID string (like '100004')
        companyIdForQuery = location.companyId
      }
    }
    
    if (!companyIdForQuery) {
      console.warn(`[getEmployeesByLocation] Location has no valid companyId, cannot filter employees. Location companyId:`, location.companyId)
      return []
    }
    
    // Get the company document to find employees
    const Company = require('../models/Company').default
    const company = await Company.findOne({ id: companyIdForQuery }).lean()
    if (!company) {
      console.warn(`[getEmployeesByLocation] Company not found for ID: ${companyIdForQuery}`)
      return []
    }
    
    console.log(`[getEmployeesByLocation] Querying employees for company ID: ${companyIdForQuery}`)
    const allCompanyEmployees = await Employee.find({ companyId: company._id })
      .populate('companyId', 'id name')
      .populate('locationId', 'id name')
      .sort({ employeeId: 1 })
      .lean()
    
    console.log(`[getEmployeesByLocation] Found ${allCompanyEmployees.length} total employees for company`)
    
    // Location field is NOT encrypted (not employee PII) - use as plaintext
    const filteredByLocationName = allCompanyEmployees.filter((emp: any) => {
      if (!emp.location) return false
      
      // Location is stored as plaintext - no decryption needed
      const empLocationText = emp.location
      const empLocationLower = empLocationText.toLowerCase()
      
      // Check if any keyword appears in employee location
      const matchesKeyword = keyWords.some((keyword: string) => 
        empLocationLower.includes(keyword) || keyword.includes(empLocationLower)
      )
      
      // Also check direct/partial matches
      const directMatch = empLocationLower === locationNameLower ||
                         empLocationLower.includes(locationNameLower) ||
                         locationNameLower.includes(empLocationLower)
      
      if (matchesKeyword || directMatch) {
        console.log(`[getEmployeesByLocation] Matched employee ${emp.employeeId || emp.id}: location="${empLocationText}" with location name="${locationName}"`)
        return true
      }
      return false
    })
    
    if (filteredByLocationName.length > 0) {
      console.log(`[getEmployeesByLocation] Found ${filteredByLocationName.length} employees by location name fallback`)
      employees = filteredByLocationName
    } else {
      console.warn(`[getEmployeesByLocation] No employees found even with fallback matching. Location: "${locationName}", Keywords:`, keyWords)
      console.log(`[getEmployeesByLocation] Sample employee locations:`, 
        allCompanyEmployees.slice(0, 5).map((e: any) => ({ 
          id: e.employeeId || e.id, 
          location: e.location,
          locationId: e.locationId ? (e.locationId.id || e.locationId) : 'none'
        }))
      )
    }
  }
  
  // Decrypt employee fields (required since we use .lean())
  // CRITICAL: Include 'location' in sensitiveFields for Company Admin - they need to see decrypted locations
  const decryptedEmployees = employees.map((e: any) => {
    if (!e) return null
    const sensitiveFields = ['email', 'mobile', 'address', 'firstName', 'lastName', 'designation', 'location']
    for (const field of sensitiveFields) {
      if (e[field] && typeof e[field] === 'string' && e[field].includes(':')) {
        try {
          e[field] = decrypt(e[field])
        } catch (error) {
          // If decryption fails, keep original value
        }
      }
    }
    return e
  }).filter((e: any) => e !== null)
  
  console.log(`[getEmployeesByLocation] Returning ${decryptedEmployees.length} employees after decryption`)
  
  return decryptedEmployees.map((e: any) => toPlainObject(e))
}

export async function getCompanyByAdminEmail(email: string): Promise<any | null> {
  console.log(`[getCompanyByAdminEmail] ========================================`)
  console.log(`[getCompanyByAdminEmail] 🚀 FUNCTION CALLED`)
  console.log(`[getCompanyByAdminEmail] Input email: "${email}"`)
  console.log(`[getCompanyByAdminEmail] Input type: ${typeof email}`)
  console.log(`[getCompanyByAdminEmail] Input length: ${email?.length || 0}`)
  
  await connectDB()
  console.log(`[getCompanyByAdminEmail] ✅ Database connected`)
  
  if (!email) {
    console.error(`[getCompanyByAdminEmail] ❌ Email is empty or null`)
    console.log(`[getCompanyByAdminEmail] ========================================`)
    return null
  }
  
  // Normalize email: trim and lowercase for consistent comparison
  const normalizedEmail = email.trim().toLowerCase()
  console.log(`[getCompanyByAdminEmail] Normalized email: "${normalizedEmail}"`)
  console.log(`[getCompanyByAdminEmail] Normalization: trim="${email.trim()}", lowercase="${email.trim().toLowerCase()}"`)
  
  console.log(`[getCompanyByAdminEmail] 🔍 STEP 1: Looking up employee by email...`)
  console.log(`[getCompanyByAdminEmail] Calling getEmployeeByEmail("${normalizedEmail}")...`)
  
  const employeeStartTime = Date.now()
  // Use getEmployeeByEmail which has robust fallback logic for finding employees
  // This ensures we can find the employee even if encryption doesn't match exactly
  const employee = await getEmployeeByEmail(normalizedEmail)
  const employeeDuration = Date.now() - employeeStartTime
  
  console.log(`[getCompanyByAdminEmail] ⏱️ getEmployeeByEmail completed in ${employeeDuration}ms`)
  
  if (!employee) {
    console.error(`[getCompanyByAdminEmail] ❌ STEP 1 FAILED: Employee not found`)
    console.error(`[getCompanyByAdminEmail] Email searched: "${normalizedEmail}"`)
    console.error(`[getCompanyByAdminEmail] This means the employee does not exist in the database`)
    console.error(`[getCompanyByAdminEmail] Possible causes:`)
    console.error(`[getCompanyByAdminEmail]   1. Email not in database`)
    console.error(`[getCompanyByAdminEmail]   2. Email encryption mismatch`)
    console.error(`[getCompanyByAdminEmail]   3. Email case/whitespace mismatch`)
    console.log(`[getCompanyByAdminEmail] ========================================`)
    return null
  }
  
  console.log(`[getCompanyByAdminEmail] ✅ STEP 1 SUCCESS: Employee found`)
  console.log(`[getCompanyByAdminEmail] Employee details:`, {
    id: employee.id,
    employeeId: employee.employeeId,
    email: employee.email,
    _id: employee._id?.toString(),
    _idType: typeof employee._id,
    companyId: employee.companyId,
    companyIdType: typeof employee.companyId
  })
  
  // Find company where this employee is an admin
  // We need the employee's _id (ObjectId) to match against admin records
  // Since getEmployeeByEmail returns a plain object, we need to fetch the raw employee document
  const db = mongoose.connection.db
  if (!db) {
    console.error(`[getCompanyByAdminEmail] Database connection not available`)
    return null
  }
  
  // Use string ID for employee lookup
  const employeeIdStr = employee.id || employee.employeeId || ''
  
  console.log(`[getCompanyByAdminEmail] 🔍 Getting employee ID:`, {
    id: employee.id,
    employeeId: employee.employeeId,
    email: employee.email
  })
  
  if (!employeeIdStr) {
    console.error(`[getCompanyByAdminEmail] ❌ CRITICAL: Could not find employee ID`)
    console.error(`[getCompanyByAdminEmail] Employee object:`, {
      id: employee.id,
      employeeId: employee.employeeId,
      email: employee.email
    })
    console.error(`[getCompanyByAdminEmail] This is a critical error - cannot proceed without employee ID`)
    console.log(`[getCompanyByAdminEmail] ========================================`)
    return null
  }
  
  console.log(`[getCompanyByAdminEmail] ✅ Employee ID successfully retrieved: ${employeeIdStr}`)
  
  console.log(`[getCompanyByAdminEmail] 🔍 STEP 2: Looking for admin record`)
  console.log(`[getCompanyByAdminEmail] Employee ID: ${employeeIdStr}`)
  
  // Find admin record using string ID
  if (!db) {
    console.error(`[getCompanyByAdminEmail] Database connection not available`)
    return null
  }
  
  console.log(`[getCompanyByAdminEmail] Querying companyadmins collection with employeeId: ${employeeIdStr}`)
  let adminRecord = await db.collection('companyadmins').findOne({
    employeeId: employeeIdStr
  })
  
  if (adminRecord) {
    console.log(`[getCompanyByAdminEmail] ✅ STEP 2 SUCCESS: Admin record found via direct query`)
    console.log(`[getCompanyByAdminEmail] Admin record:`, {
      employeeId: String(adminRecord.employeeId || ''),
      companyId: String(adminRecord.companyId || ''),
      canApproveOrders: adminRecord.canApproveOrders
    })
  } else {
    // Fallback: Try to find all admins and log for debugging
    console.error(`[getCompanyByAdminEmail] ❌ Direct query failed, trying fallback...`)
    const allAdmins = await db.collection('companyadmins').find({}).toArray()
    console.error(`[getCompanyByAdminEmail] Found ${allAdmins.length} total admin records`)
    console.error(`[getCompanyByAdminEmail] 📋 All admin records:`, allAdmins.map((a: any, index: number) => ({
      index,
      employeeId: String(a.employeeId || ''),
      companyId: String(a.companyId || ''),
      canApproveOrders: a.canApproveOrders,
      matches: String(a.employeeId || '') === employeeIdStr ? '✅ MATCH' : '❌ NO MATCH'
    })))
    
    // Try fallback matching with string comparison
    const fallbackMatch = allAdmins.find((a: any) => {
      if (!a.employeeId) return false
      return String(a.employeeId) === employeeIdStr
    })
    
    if (fallbackMatch) {
      console.log(`[getCompanyByAdminEmail] ✅ Found via fallback string comparison`)
      adminRecord = fallbackMatch
    } else {
      console.error(`[getCompanyByAdminEmail] ❌ STEP 2 FAILED: No admin record found`)
      console.error(`[getCompanyByAdminEmail] Employee ID searched: ${employeeIdStr}`)
      console.error(`[getCompanyByAdminEmail] Employee details:`, {
        id: employee.id,
        employeeId: employee.employeeId,
        email: normalizedEmail,
        employeeEmail: employee.email
      })
      console.error(`[getCompanyByAdminEmail] Possible causes:`)
      console.error(`[getCompanyByAdminEmail]   1. Employee not assigned as company admin`)
      console.error(`[getCompanyByAdminEmail]   2. Admin record employeeId format mismatch`)
      console.log(`[getCompanyByAdminEmail] ========================================`)
      return null
    }
  }
  
  // Final check - if still no admin record found, return null
  if (!adminRecord) {
    console.error(`[getCompanyByAdminEmail] ❌ STEP 2 FAILED: No admin record found after all attempts`)
    console.error(`[getCompanyByAdminEmail] Employee ID searched: ${employeeIdStr}`)
    console.error(`[getCompanyByAdminEmail] Employee details:`, {
      id: employee.id,
      employeeId: employee.employeeId,
      email: normalizedEmail,
      employeeEmail: employee.email
    })
    console.error(`[getCompanyByAdminEmail] Possible causes:`)
    console.error(`[getCompanyByAdminEmail]   1. Employee not assigned as company admin`)
    console.error(`[getCompanyByAdminEmail]   2. Admin record employeeId format mismatch`)
    console.log(`[getCompanyByAdminEmail] ========================================`)
    return null
  }
  
  console.log(`[getCompanyByAdminEmail] ✅ STEP 2 SUCCESS: Admin record found`)
  console.log(`[getCompanyByAdminEmail] Admin record:`, {
    employeeId: String(adminRecord.employeeId || ''),
    companyId: String(adminRecord.companyId || ''),
    canApproveOrders: adminRecord.canApproveOrders
  })
  
  // STEP 3: Get the company using string ID
  const adminCompanyIdStr = String(adminRecord.companyId || '')
  console.log(`[getCompanyByAdminEmail] 🔍 STEP 3: Looking for company`)
  console.log(`[getCompanyByAdminEmail] Company ID: ${adminCompanyIdStr}`)
  
  // Use string ID query
  console.log(`[getCompanyByAdminEmail] Querying companies collection with id: ${adminCompanyIdStr}`)
  let companyDoc = await db.collection('companies').findOne({
    id: adminCompanyIdStr
  })
  
  if (companyDoc) {
    console.log(`[getCompanyByAdminEmail] ✅ STEP 3 SUCCESS: Company found via string ID query`)
    console.log(`[getCompanyByAdminEmail] Company: ${companyDoc.name} (id: ${companyDoc.id})`)
  } else {
    console.error(`[getCompanyByAdminEmail] ❌ STEP 3 FAILED: No company found`)
    console.error(`[getCompanyByAdminEmail] Company ID searched: ${adminCompanyIdStr}`)
    console.error(`[getCompanyByAdminEmail] Admin record companyId: ${adminRecord.companyId}`)
    console.error(`[getCompanyByAdminEmail] Possible causes:`)
    console.error(`[getCompanyByAdminEmail]   1. Company was deleted`)
    console.error(`[getCompanyByAdminEmail]   2. Admin record has incorrect companyId`)
    console.log(`[getCompanyByAdminEmail] ========================================`)
    return null
  }
  
  // Final check - if still no company found, return null
  if (!companyDoc) {
    console.error(`[getCompanyByAdminEmail] ❌ STEP 3 FAILED: No company found after all attempts`)
    console.error(`[getCompanyByAdminEmail] Company ID searched: ${adminCompanyIdStr}`)
    console.log(`[getCompanyByAdminEmail] ========================================`)
    return null
  }
  
  console.log(`[getCompanyByAdminEmail] ✅ STEP 3 SUCCESS: Company found`)
  console.log(`[getCompanyByAdminEmail] Company: ${companyDoc.name} (id: ${companyDoc.id}, type: ${typeof companyDoc.id})`)
  
  // Convert to format expected by the rest of the code
  const company = toPlainObject(companyDoc)
  
  // Ensure company.id is preserved (should be numeric now)
  if (companyDoc.id !== undefined) {
    company.id = companyDoc.id
  }
  
  console.log(`[getCompanyByAdminEmail] ✅ FINAL SUCCESS: Returning company`)
  console.log(`[getCompanyByAdminEmail] Return value:`, {
    id: company.id,
    idType: typeof company.id,
    name: company.name,
    hasId: !!company.id,
    hasName: !!company.name
  })
  console.log(`[getCompanyByAdminEmail] ========================================`)
  return company
}

// Legacy function for backward compatibility (keeps old adminId field)
export async function setCompanyAdmin(companyId: string, employeeId: string): Promise<void> {
  // Use new multiple admin system
  await addCompanyAdmin(companyId, employeeId, false)
  
  // Also update legacy adminId field for backward compatibility
  const company = await Company.findOne({ id: companyId })
  if (company) {
    const employee = await Employee.findOne({ id: employeeId })
    if (employee) {
      company.adminId = employee.id || employee.employeeId
      await company.save()
    }
  }
}

// ========== EMPLOYEE FUNCTIONS ==========

export async function getAllEmployees(): Promise<any[]> {
  await connectDB()
  
  const employees = await Employee.find()
    .populate('companyId', 'id name')
    .populate('locationId', 'id name address city state pincode')
    .lean()

  // Since we used .lean(), the post hooks don't run, so we need to manually decrypt sensitive fields
  // CRITICAL: Include 'location' in sensitiveFields for Company Admin - they need to see decrypted locations
  const { decrypt } = require('../utils/encryption')
  const decryptedEmployees = employees.map((e: any) => {
    const sensitiveFields = ['email', 'mobile', 'address', 'firstName', 'lastName', 'designation', 'location']
    for (const field of sensitiveFields) {
      if (e[field] && typeof e[field] === 'string' && e[field].includes(':')) {
        try {
          e[field] = decrypt(e[field])
        } catch (error) {
          console.warn(`Failed to decrypt field ${field} for employee ${e.id}:`, error)
        }
      }
    }
    return e
  })

  return decryptedEmployees.map((e: any) => toPlainObject(e))
}

export async function getEmployeeByEmail(email: string): Promise<any | null> {
  await connectDB()
  
  if (!email) {
    return null
  }
  
  // Normalize email: trim whitespace and convert to lowercase for consistent comparison
  // This ensures emails are compared consistently regardless of case or whitespace
  const trimmedEmail = email.trim().toLowerCase()
  
  // Since email is encrypted in the database, we need to encrypt the search term
  // or search through all employees and decrypt to match
  // The more efficient approach is to encrypt the search term and query
  
  const { encrypt, decrypt } = require('../utils/encryption')
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    console.warn('Failed to encrypt email for query, will use decryption matching:', error)
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first (faster)
  // Use raw MongoDB query to get the employee with companyId ObjectId
  const db = mongoose.connection.db
  let employee: any = null
  
  if (db && encryptedEmail) {
    // First, try with encrypted email (for encrypted data)
    // NOTE: This will only work if the email was encrypted with the EXACT same normalized value
    // Due to random IVs, even the same email encrypts differently each time
    // So this lookup is mainly for recently created employees with normalized emails
    let rawEmployee = await db.collection('employees').findOne({ email: encryptedEmail })
    
    if (rawEmployee) {
      console.log(`[getEmployeeByEmail] ✅ Found employee via encrypted email lookup (direct match)`)
    }
    
    // If not found with encrypted email, try with plain text email (for plain text data - legacy)
    if (!rawEmployee) {
      rawEmployee = await db.collection('employees').findOne({ email: trimmedEmail })
      if (rawEmployee) {
        console.log(`[getEmployeeByEmail] ✅ Found employee via plain text email lookup (legacy data)`)
      }
    }
    
    // Also try case-insensitive plain text search (for legacy data)
    if (!rawEmployee) {
      rawEmployee = await db.collection('employees').findOne({ 
        email: { $regex: new RegExp(`^${trimmedEmail.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }
      })
      if (rawEmployee) {
        console.log(`[getEmployeeByEmail] ✅ Found employee via case-insensitive plain text lookup (legacy data)`)
      }
    }
    
    if (rawEmployee) {
      console.log(`[getEmployeeByEmail] Raw employee companyId:`, rawEmployee.companyId, 'Type:', typeof rawEmployee.companyId)
      
      // Now fetch with Mongoose to get populated fields and decryption
      // Use string id field instead of _id
      const employeeId = rawEmployee.id || String(rawEmployee._id || '')
      employee = await Employee.findOne({ id: employeeId })
        .populate('companyId', 'id name')
        .populate('locationId', 'id name address city state pincode')
        .lean()
      
      console.log(`[getEmployeeByEmail] Mongoose employee companyId after populate:`, employee?.companyId, 'Type:', typeof employee?.companyId)
      
      // ALWAYS ensure companyId is set from raw document if it exists
      if (employee && rawEmployee.companyId) {
        const rawCompanyIdStr = rawEmployee.companyId.toString()
        
        // Convert companyId from ObjectId to numeric ID using helper function
        const numericCompanyId = await convertCompanyIdToNumericId(rawEmployee.companyId)
        if (numericCompanyId) {
          employee.companyId = numericCompanyId
          console.log(`[getEmployeeByEmail] Converted companyId from raw document: ${numericCompanyId}`)
        }
      } else if (employee && !employee.companyId && rawEmployee.companyId) {
        // Employee from Mongoose doesn't have companyId, but raw document does
        const numericCompanyId = await convertCompanyIdToNumericId(rawEmployee.companyId)
        if (numericCompanyId) {
          employee.companyId = numericCompanyId
          console.log(`[getEmployeeByEmail] Set companyId from raw document: ${numericCompanyId}`)
        }
      }
    }
  }
  
  // Fallback: if raw query didn't work, try Mongoose query
  if (!employee && encryptedEmail) {
    employee = await Employee.findOne({ email: encryptedEmail })
      .populate('companyId', 'id name')
      .populate('locationId', 'id name address city state pincode')
      .lean()
    
      // Convert companyId from ObjectId to numeric ID
      if (employee && employee.companyId) {
        const numericCompanyId = await convertCompanyIdToNumericId(employee.companyId)
        if (numericCompanyId) {
          employee.companyId = numericCompanyId
          console.log(`[getEmployeeByEmail] Converted companyId (Mongoose fallback): ${numericCompanyId}`)
        }
      }
  }
  
  // Fallback: if still not found, try decryption-based search (works even if encryption format doesn't match)
  // This MUST run regardless of whether encryptedEmail was set, because encryption uses random IVs
  // CRITICAL FIX: Also handle plain text emails (user may have manually replaced encrypted email with plain text)
  if (!employee) {
    console.log(`[getEmployeeByEmail] ⚠️  Primary lookups failed for: ${trimmedEmail}`)
    console.log(`[getEmployeeByEmail] Starting comprehensive fallback search...`)
    
    // Use raw MongoDB to get all employees (faster than Mongoose for bulk operations)
    const db = mongoose.connection.db
    if (db) {
      // First, try direct plain text match (handles manually replaced plain text emails)
      console.log(`[getEmployeeByEmail] Trying plain text email match...`)
      const plainTextEmployee = await db.collection('employees').findOne({ email: trimmedEmail })
      if (plainTextEmployee) {
        console.log(`[getEmployeeByEmail] ✅ Found employee via plain text email match`)
        // Fetch with Mongoose to get populated fields - use string id field instead of _id
        const employeeId = plainTextEmployee.id || String(plainTextEmployee._id || '')
        employee = await Employee.findOne({ id: employeeId })
          .populate('companyId', 'id name')
          .populate('locationId', 'id name address city state pincode')
          .lean()
        
        if (employee) {
          // Convert companyId from ObjectId to numeric ID
          if (employee.companyId) {
            const numericCompanyId = await convertCompanyIdToNumericId(employee.companyId)
            if (numericCompanyId) {
              employee.companyId = numericCompanyId
            }
          }
          console.log(`[getEmployeeByEmail] Employee ID: ${employee.id || employee.employeeId}`)
        }
      }
    }
    
    // If still not found, try decryption-based search for encrypted emails
    if (!employee) {
      console.log(`[getEmployeeByEmail] Trying decryption-based search for encrypted emails...`)
      // For encrypted values, we can't do regex search easily
      // So we'll fall back to fetching all and decrypting (less efficient but works)
      const allEmployees = await Employee.find({})
        .populate('companyId', 'id name')
        .populate('locationId', 'id name address city state pincode')
        .lean()
      
      console.log(`[getEmployeeByEmail] Checking ${allEmployees.length} employees via decryption...`)
      let checkedCount = 0
      for (const emp of allEmployees) {
        if (emp.email && typeof emp.email === 'string') {
          checkedCount++
          try {
            // Skip if already plain text (we already checked that)
            if (!emp.email.includes(':')) {
              // Plain text email - check if it matches
              if (emp.email.toLowerCase() === trimmedEmail) {
                console.log(`[getEmployeeByEmail] ✅ Found employee via plain text match in decryption loop: ${emp.email}`)
                employee = emp
                // Convert companyId from ObjectId to numeric ID
                if (employee.companyId) {
                  const numericCompanyId = await convertCompanyIdToNumericId(employee.companyId)
                  if (numericCompanyId) {
                    employee.companyId = numericCompanyId
                  }
                }
                break
              }
              continue
            }
            
            // Encrypted email - try to decrypt
            const decryptedEmail = decrypt(emp.email)
            // Check if decryption succeeded - be more lenient to avoid false negatives
            // Decryption succeeded if:
            // 1. Result is different from input (was actually encrypted)
            // 2. Result doesn't contain ':' (not still encrypted)
            // 3. Result is reasonable length (not corrupted)
            // 4. Result contains '@' (looks like an email)
            const isDecrypted = decryptedEmail && 
                               decryptedEmail !== emp.email && 
                               !decryptedEmail.includes(':') && 
                               decryptedEmail.length > 0 &&
                               decryptedEmail.length < 200 &&
                               decryptedEmail.includes('@')
            
            // Check if email matches (case-insensitive - both should already be lowercase)
            // trimmedEmail is already lowercase, so compare directly
            if (isDecrypted && decryptedEmail.toLowerCase() === trimmedEmail) {
              console.log(`[getEmployeeByEmail] ✅ Found employee via decryption fallback: ${decryptedEmail}`)
              console.log(`[getEmployeeByEmail] Employee ID: ${emp.id || emp.employeeId}, _id: ${emp._id}`)
              employee = emp
              // CRITICAL: Decrypt the email field itself so it matches what the caller expects
              employee.email = decryptedEmail
              console.log(`[getEmployeeByEmail] Set employee.email to: ${employee.email}`)
              // Decrypt all sensitive fields for this employee
              if (employee.firstName && typeof employee.firstName === 'string' && employee.firstName.includes(':')) {
                try { employee.firstName = decrypt(employee.firstName) } catch {}
              }
              if (employee.lastName && typeof employee.lastName === 'string' && employee.lastName.includes(':')) {
                try { employee.lastName = decrypt(employee.lastName) } catch {}
              }
              if (employee.mobile && typeof employee.mobile === 'string' && employee.mobile.includes(':')) {
                try { employee.mobile = decrypt(employee.mobile) } catch {}
              }
              if (employee.address && typeof employee.address === 'string' && employee.address.includes(':')) {
                try { employee.address = decrypt(employee.address) } catch {}
              }
              if (employee.designation && typeof employee.designation === 'string' && employee.designation.includes(':')) {
                try { employee.designation = decrypt(employee.designation) } catch {}
              }
              // Convert companyId from ObjectId to numeric ID
              if (employee.companyId) {
                const numericCompanyId = await convertCompanyIdToNumericId(employee.companyId)
                if (numericCompanyId) {
                  employee.companyId = numericCompanyId
                }
              }
              break
            }
          } catch (error) {
            // Skip employees with decryption errors silently (don't log for every employee)
            continue
          }
        }
      }
      console.log(`[getEmployeeByEmail] Decryption fallback completed. Checked ${checkedCount} employees. Employee found: ${!!employee}`)
    }
  }

  if (!employee) {
    console.warn(`[getEmployeeByEmail] ❌ Employee not found after all lookup methods for: ${trimmedEmail}`)
    return null
  }
  
  // Convert companyId from ObjectId to numeric ID using helper function
  // Always fetch from raw document to ensure we have the correct ObjectId
  if (employee && db) {
    let rawEmp: any = null
    
    // Try to get raw document using multiple methods
    if (encryptedEmail) {
      rawEmp = await db.collection('employees').findOne({ email: encryptedEmail })
    }
    if (!rawEmp && employee.id) {
      rawEmp = await db.collection('employees').findOne({ id: employee.id })
    }
    if (!rawEmp && employee.employeeId) {
      rawEmp = await db.collection('employees').findOne({ employeeId: employee.employeeId })
    }
    
    if (rawEmp && rawEmp.companyId) {
      // Convert companyId from ObjectId to numeric ID once
      const numericCompanyId = await convertCompanyIdToNumericId(rawEmp.companyId)
      if (numericCompanyId) {
        employee.companyId = numericCompanyId
        console.log(`[getEmployeeByEmail] Converted companyId to numeric ID: ${numericCompanyId}`)
      } else {
        console.warn(`[getEmployeeByEmail] Failed to convert companyId for employee ${employee.id || employee.employeeId}`)
      }
    } else if (rawEmp && !rawEmp.companyId) {
      console.warn(`[getEmployeeByEmail] WARNING: Raw document has no companyId for employee ${employee.id || employee.employeeId}`)
    }
  }
  
  // CRITICAL: Since we use .lean(), Mongoose post hooks don't run, so we must manually decrypt
  // Decrypt email and other sensitive fields if they're still encrypted
  if (employee) {
    const { decrypt } = require('../utils/encryption')
    const sensitiveFields = ['email', 'mobile', 'address', 'firstName', 'lastName', 'designation']
    const addressFields = ['address_line_1', 'address_line_2', 'address_line_3', 'city', 'state', 'pincode']
    
    // Decrypt sensitive fields
    for (const field of sensitiveFields) {
      if (employee[field] && typeof employee[field] === 'string' && employee[field].includes(':')) {
        try {
          const decrypted = decrypt(employee[field])
          // Only use decrypted value if decryption succeeded (different from original and reasonable length)
          // For email, also check it contains @ to ensure it's a valid email
          const isValidDecryption = decrypted && 
                                   decrypted !== employee[field] && 
                                   !decrypted.includes(':') && 
                                   decrypted.length > 0 &&
                                   decrypted.length < 200 &&
                                   (field !== 'email' || decrypted.includes('@'))
          if (isValidDecryption) {
            employee[field] = decrypted
          }
        } catch (error) {
          // Keep original if decryption fails - don't log for every employee
          continue
        }
      }
    }
    
    // CRITICAL FIX: Decrypt structured address fields
    for (const field of addressFields) {
      if (employee[field] && typeof employee[field] === 'string' && employee[field].includes(':')) {
        try {
          employee[field] = decrypt(employee[field])
        } catch (error) {
          console.warn(`Failed to decrypt address field ${field} for employee ${employee.id || employee.employeeId}:`, error)
        }
      }
    }
  }
  
  // CRITICAL: Preserve _id before calling toPlainObject (which deletes it)
  // Store employee string ID for consistency
  const employeeIdStr = employee?.id || employee?.employeeId || ''
  
  const plainEmployee = toPlainObject(employee)
  
  // Ensure id field is preserved (needed for admin lookups)
  if (employeeIdStr && !plainEmployee.id) {
    plainEmployee.id = employeeIdStr
  }
  
  // Final check: Ensure companyId is numeric ID (not ObjectId) after toPlainObject
  // If companyId is missing or is an ObjectId string, convert it using helper function
  if (plainEmployee.companyId) {
    // If it's already a numeric ID (6 digits), keep it
    if (!/^\d{6}$/.test(String(plainEmployee.companyId))) {
      // It might be an ObjectId string, convert it
      const numericCompanyId = await convertCompanyIdToNumericId(plainEmployee.companyId)
      if (numericCompanyId) {
        plainEmployee.companyId = numericCompanyId
        console.log(`[getEmployeeByEmail] Converted companyId after toPlainObject: ${numericCompanyId}`)
      }
    }
  } else if (db) {
    // If companyId is missing, try to get it from raw document one more time
    let rawEmp: any = null
    if (encryptedEmail) {
      rawEmp = await db.collection('employees').findOne({ email: encryptedEmail })
    }
    if (!rawEmp && plainEmployee.id) {
      rawEmp = await db.collection('employees').findOne({ id: plainEmployee.id })
    }
    
    if (rawEmp && rawEmp.companyId) {
      const numericCompanyId = await convertCompanyIdToNumericId(rawEmp.companyId)
      if (numericCompanyId) {
        plainEmployee.companyId = numericCompanyId
        console.log(`[getEmployeeByEmail] Recovered companyId from raw document: ${numericCompanyId}`)
      }
    }
  }
  
  // CRITICAL FIX: Create formatted address string for backward compatibility with UI
  // The frontend expects currentEmployee.address to be a string, not an object
  if (!plainEmployee) {
    return null
  }
  
  // Build address string from structured fields if they exist
  if (plainEmployee.address_line_1 || plainEmployee.city || plainEmployee.state || plainEmployee.pincode) {
    // Build address string from structured fields
    const addressParts = [
      plainEmployee.address_line_1,
      plainEmployee.address_line_2,
      plainEmployee.address_line_3,
      plainEmployee.city,
      plainEmployee.state,
      plainEmployee.pincode
    ].filter(Boolean) // Remove empty/null/undefined values
    
    if (addressParts.length > 0) {
      plainEmployee.address = addressParts.join(', ')
    } else {
      plainEmployee.address = 'Address not available'
    }
    
    // Also create address object for structured access
    plainEmployee.addressData = {
      address_line_1: plainEmployee.address_line_1 || '',
      address_line_2: plainEmployee.address_line_2 || '',
      address_line_3: plainEmployee.address_line_3 || '',
      city: plainEmployee.city || '',
      state: plainEmployee.state || '',
      pincode: plainEmployee.pincode || '',
      country: plainEmployee.country || 'India',
    }
  } else {
    // No address fields - set default
    plainEmployee.address = 'Address not available'
  }
  
  return plainEmployee
}

export async function getEmployeeById(employeeId: string): Promise<any | null> {
  await connectDB()
  
  const employee = await Employee.findOne({ id: employeeId })
    .populate('companyId', 'id name')
    .populate('locationId', 'id name address_line_1 city state pincode')
    .lean()
  
  if (!employee) return null
  
  // Since we used .lean(), the post hooks don't run, so we need to manually decrypt sensitive fields
  const { decrypt } = require('../utils/encryption')
  const sensitiveFields = ['email', 'mobile', 'firstName', 'lastName', 'designation']
  const addressFields = ['address_line_1', 'address_line_2', 'address_line_3', 'city', 'state', 'pincode']
  
  for (const field of sensitiveFields) {
    if (employee[field] && typeof employee[field] === 'string' && employee[field].includes(':')) {
      try {
        employee[field] = decrypt(employee[field])
      } catch (error) {
        console.warn(`Failed to decrypt field ${field} for employee ${employeeId}:`, error)
      }
    }
  }
  
  // Decrypt address fields
  for (const field of addressFields) {
    if (employee[field] && typeof employee[field] === 'string' && employee[field].includes(':')) {
      try {
        employee[field] = decrypt(employee[field])
      } catch (error) {
        console.warn(`Failed to decrypt address field ${field} for employee ${employeeId}:`, error)
      }
    }
  }
  
  const plainEmployee = toPlainObject(employee)
  
  // Address is now embedded, no need to extract from addressId
  // Create address object for backward compatibility with UI
  if (plainEmployee.address_line_1) {
    plainEmployee.address = {
      address_line_1: plainEmployee.address_line_1 || '',
      address_line_2: plainEmployee.address_line_2 || '',
      address_line_3: plainEmployee.address_line_3 || '',
      city: plainEmployee.city || '',
      state: plainEmployee.state || '',
      pincode: plainEmployee.pincode || '',
      country: plainEmployee.country || 'India',
    }
  }
  
  // Ensure companyId is converted to company string ID (not ObjectId)
  if (plainEmployee.companyId) {
    if (typeof plainEmployee.companyId === 'object' && plainEmployee.companyId !== null) {
      if (plainEmployee.companyId.id) {
        plainEmployee.companyId = plainEmployee.companyId.id
      } else if (plainEmployee.companyId._id) {
        const db = mongoose.connection.db
        if (db) {
          try {
            const companyIdStr = plainEmployee.companyId._id.toString()
            const allCompanies = await db.collection('companies').find({}).toArray()
            const companyDoc = allCompanies.find((c: any) => c._id.toString() === companyIdStr)
            if (companyDoc && companyDoc.id) {
              plainEmployee.companyId = companyDoc.id
            }
          } catch (error) {
            console.warn(`[getEmployeeById] Error converting companyId:`, error)
          }
        }
      }
    } else if (typeof plainEmployee.companyId === 'string' && /^[0-9a-fA-F]{24}$/.test(plainEmployee.companyId)) {
      const db = mongoose.connection.db
      if (db) {
        try {
          const allCompanies = await db.collection('companies').find({}).toArray()
          const companyDoc = allCompanies.find((c: any) => c._id.toString() === plainEmployee.companyId)
          if (companyDoc && companyDoc.id) {
            plainEmployee.companyId = companyDoc.id
          }
        } catch (error) {
          console.warn(`[getEmployeeById] Error converting companyId ObjectId:`, error)
        }
      }
    }
  }
  
  return plainEmployee
}

export async function getEmployeeByPhone(phone: string): Promise<any | null> {
  await connectDB()
  
  if (!phone) {
    return null
  }
  
  // Normalize phone number (remove spaces, dashes, etc.)
  let normalizedPhone = phone.trim().replace(/[\s\-\(\)]/g, '')
  
  // Since mobile is encrypted in the database, we need to encrypt the search term
  const { encrypt, decrypt } = require('../utils/encryption')
  
  // Generate multiple phone number format variations to try
  // Phone numbers can be stored in different formats in the database
  const phoneVariations: string[] = []
  
  // 1. Original format (as received)
  phoneVariations.push(normalizedPhone)
  
  // 2. If it starts with +91, try without +
  if (normalizedPhone.startsWith('+91')) {
    phoneVariations.push(normalizedPhone.substring(1)) // Remove +
    phoneVariations.push(normalizedPhone.substring(3)) // Remove +91
  }
  // 3. If it starts with 91 (without +), try without country code
  else if (normalizedPhone.startsWith('91') && normalizedPhone.length === 12) {
    phoneVariations.push('+' + normalizedPhone) // Add +
    phoneVariations.push(normalizedPhone.substring(2)) // Remove 91
  }
  // 4. If it's 10 digits (Indian number without country code), try with country code
  else if (normalizedPhone.length === 10 && /^\d+$/.test(normalizedPhone)) {
    phoneVariations.push('+91' + normalizedPhone) // Add +91
    phoneVariations.push('91' + normalizedPhone) // Add 91
    if (normalizedPhone.startsWith('0')) {
      phoneVariations.push(normalizedPhone.substring(1)) // Remove leading 0
      phoneVariations.push('+91' + normalizedPhone.substring(1)) // Remove 0 and add +91
    }
  }
  // 5. If it starts with 0, try without 0
  else if (normalizedPhone.startsWith('0') && normalizedPhone.length === 11) {
    phoneVariations.push(normalizedPhone.substring(1)) // Remove 0
    phoneVariations.push('+91' + normalizedPhone.substring(1)) // Remove 0 and add +91
    phoneVariations.push('91' + normalizedPhone.substring(1)) // Remove 0 and add 91
  }
  
  // Remove duplicates
  const uniqueVariations = [...new Set(phoneVariations)]
  
  console.log(`[getEmployeeByPhone] Trying phone number variations for: ${phone.substring(0, 5)}...`, uniqueVariations.length, 'variations')
  
  // Try finding with each phone number variation
  const db = mongoose.connection.db
  let employee: any = null
  
  // Try each variation
  for (const phoneVar of uniqueVariations) {
    if (!phoneVar || phoneVar.length === 0) continue
    
    let encryptedPhone: string = ''
    try {
      encryptedPhone = encrypt(phoneVar)
    } catch (error) {
      console.warn(`[getEmployeeByPhone] Failed to encrypt phone variation "${phoneVar}":`, error)
      continue
    }
    
    if (!encryptedPhone) continue
    
    // Try finding with encrypted phone
    if (db) {
      const rawEmployee = await db.collection('employees').findOne({ mobile: encryptedPhone })
      
      if (rawEmployee) {
        // Found employee! Now fetch with Mongoose to get populated fields and decryption
        employee = await Employee.findOne({ mobile: encryptedPhone })
          .populate('companyId', 'id name')
          .populate('locationId', 'id name address city state pincode')
          .lean()
        
        if (employee) {
          console.log(`[getEmployeeByPhone] ✅ Found employee with phone variation: ${phoneVar.substring(0, 5)}...`)
          break // Found employee, stop searching
        }
      }
    }
    
    // Also try Mongoose query as fallback
    if (!employee) {
      employee = await Employee.findOne({ mobile: encryptedPhone })
        .populate('companyId', 'id name')
        .populate('locationId', 'id name address city state pincode')
        .lean()
      
      if (employee) {
        console.log(`[getEmployeeByPhone] ✅ Found employee with Mongoose query (variation: ${phoneVar.substring(0, 5)}...)`)
        break // Found employee, stop searching
      }
    }
  }
  
  // If still not found, try decryption-based search (slower but more thorough)
  if (!employee && db) {
    console.log(`[getEmployeeByPhone] Trying decryption-based search...`)
    try {
      const allEmployees = await db.collection('employees').find({}).toArray()
      for (const emp of allEmployees) {
        if (emp.mobile && typeof emp.mobile === 'string') {
          try {
            const decryptedMobile = decrypt(emp.mobile)
            // Check if any variation matches
            for (const phoneVar of uniqueVariations) {
              if (decryptedMobile === phoneVar || decryptedMobile.replace(/[\s\-\(\)]/g, '') === phoneVar) {
                // Found match! Fetch with Mongoose
                const empId = emp.id || emp.employeeId || String(emp._id || '')
                employee = await Employee.findOne({ id: empId })
                  .lean()
                
                // Manually populate companyId and locationId since populate doesn't work with string IDs
                if (employee && employee.companyId) {
                  const company = await Company.findOne({ id: employee.companyId }).select('id name').lean()
                  if (company) {
                    (employee as any).companyId = company
                  }
                }
                if (employee && employee.locationId) {
                  const location = await Location.findOne({ id: employee.locationId }).select('id name address city state pincode').lean()
                  if (location) {
                    (employee as any).locationId = location
                  }
                }
                if (employee) {
                  console.log(`[getEmployeeByPhone] ✅ Found employee via decryption search`)
                  break
                }
              }
            }
            if (employee) break
          } catch (decryptError) {
            // Skip employees with decryption errors
            continue
          }
        }
      }
    } catch (error) {
      console.warn(`[getEmployeeByPhone] Decryption-based search failed:`, error)
    }
  }
  
  if (!employee) {
    console.log(`[getEmployeeByPhone] ❌ Employee not found for phone: ${phone.substring(0, 5)}... (tried ${uniqueVariations.length} variations)`)
    return null
  }
  
  // Ensure companyId is properly set
  if (employee.companyId) {
    if (typeof employee.companyId === 'object' && employee.companyId !== null) {
      if (employee.companyId.id) {
        employee.companyId = employee.companyId.id
      } else if (employee.companyId._id) {
        const db = mongoose.connection.db
        if (db) {
          try {
            const companyIdStr = employee.companyId._id.toString()
            const allCompanies = await db.collection('companies').find({}).toArray()
            const companyDoc = allCompanies.find((c: any) => c._id.toString() === companyIdStr)
            if (companyDoc && companyDoc.id) {
              employee.companyId = companyDoc.id
            }
          } catch (error) {
            console.warn(`[getEmployeeByPhone] Error converting companyId:`, error)
          }
        }
      }
    }
  }
  
  // Decrypt sensitive fields (required since we use .lean())
  const sensitiveFields = ['email', 'mobile', 'address', 'firstName', 'lastName', 'designation']
  for (const field of sensitiveFields) {
    if (employee[field] && typeof employee[field] === 'string' && employee[field].includes(':')) {
      try {
        employee[field] = decrypt(employee[field])
      } catch (error) {
        console.warn(`Failed to decrypt field ${field} for employee:`, error)
      }
    }
  }
  
  const plainEmployee = toPlainObject(employee)
  
  // Ensure companyId is converted to company string ID
  if (plainEmployee.companyId) {
    if (typeof plainEmployee.companyId === 'object' && plainEmployee.companyId !== null) {
      if (plainEmployee.companyId.id) {
        plainEmployee.companyId = plainEmployee.companyId.id
      }
    }
  }
  
  return plainEmployee
}

export async function getEmployeeByEmployeeId(employeeId: string): Promise<any | null> {
  await connectDB()
  
  const employee = await Employee.findOne({ employeeId: employeeId })
    .populate('companyId', 'id name')
    .lean()
  
  if (!employee) return null
  
  const plainEmployee = toPlainObject(employee)
  
  // Ensure companyId is converted to company string ID (not ObjectId)
  if (plainEmployee.companyId) {
    if (typeof plainEmployee.companyId === 'object' && plainEmployee.companyId !== null) {
      if (plainEmployee.companyId.id) {
        plainEmployee.companyId = plainEmployee.companyId.id
      } else if (plainEmployee.companyId._id) {
        const db = mongoose.connection.db
        if (db) {
          try {
            const companyIdStr = plainEmployee.companyId._id.toString()
            const allCompanies = await db.collection('companies').find({}).toArray()
            const companyDoc = allCompanies.find((c: any) => c._id.toString() === companyIdStr)
            if (companyDoc && companyDoc.id) {
              plainEmployee.companyId = companyDoc.id
            }
          } catch (error) {
            console.warn(`[getEmployeeByEmployeeId] Error converting companyId:`, error)
          }
        }
      }
    } else if (typeof plainEmployee.companyId === 'string' && /^[0-9a-fA-F]{24}$/.test(plainEmployee.companyId)) {
      const db = mongoose.connection.db
      if (db) {
        try {
          const allCompanies = await db.collection('companies').find({}).toArray()
          const companyDoc = allCompanies.find((c: any) => c._id.toString() === plainEmployee.companyId)
          if (companyDoc && companyDoc.id) {
            plainEmployee.companyId = companyDoc.id
          }
        } catch (error) {
          console.warn(`[getEmployeeByEmployeeId] Error converting companyId ObjectId:`, error)
        }
      }
    }
  }
  
  return plainEmployee
}

export async function getEmployeesByCompany(companyId: string): Promise<any[]> {
  await connectDB()
  
  console.log(`[getEmployeesByCompany] Looking up company with id: ${companyId}`)
  const company = await Company.findOne({ id: companyId }).select('_id id name').lean()
  if (!company) {
    console.warn(`[getEmployeesByCompany] Company not found with id: ${companyId}`)
    return []
  }

  console.log(`[getEmployeesByCompany] Found company: ${company.name} (${company.id}), ObjectId: ${company._id}`)

  // OPTIMIZATION: Use indexed query directly instead of fetch-all + filter
  // This leverages the companyId index for O(log n) lookup instead of O(n) scan
  // Direct indexed query - much faster than fetch-all
  // CRITICAL FIX: Employee.companyId is stored as STRING ID, not ObjectId
  console.log(`[getEmployeesByCompany] Querying employees with companyId: ${company.id} (string ID)`)
  const query = Employee.find({ companyId: company.id })
    .populate('companyId', 'id name')
    .populate('locationId', 'id name address city state pincode')
    .populate('addressId') // Populate the Address record

  const employees = await query.lean()
  
  console.log(`[getEmployeesByCompany] Raw query returned ${employees?.length || 0} employees`)
  
  // Extract structured address data for employees with addressId
  const { getAddressById } = require('../utils/address-service')
  for (const employee of employees) {
    if (employee.addressId) {
      if (typeof employee.addressId === 'object' && employee.addressId !== null) {
        // Address is populated
        employee.address = {
          address_line_1: employee.addressId.address_line_1 || '',
          address_line_2: employee.addressId.address_line_2 || '',
          address_line_3: employee.addressId.address_line_3 || '',
          city: employee.addressId.city || '',
          state: employee.addressId.state || '',
          pincode: employee.addressId.pincode || '',
          country: employee.addressId.country || 'India',
        }
        employee.addressId = employee.addressId._id?.toString() || employee.addressId.toString()
      } else {
        // addressId exists but not populated - fetch it
        try {
          // Safely convert addressId to string
          const addressIdStr = employee.addressId?.toString ? employee.addressId.toString() : String(employee.addressId)
          if (addressIdStr) {
            const address = await getAddressById(addressIdStr)
          if (address) {
            employee.address = {
              address_line_1: address.address_line_1 || '',
              address_line_2: address.address_line_2 || '',
              address_line_3: address.address_line_3 || '',
              city: address.city || '',
              state: address.state || '',
              pincode: address.pincode || '',
              country: address.country || 'India',
            }
          }
          }
        } catch (error: any) {
          console.warn(`Failed to fetch address for employee ${employee.id}:`, error?.message || error)
          // Continue without address - don't fail the entire request
        }
      }
    }
  }
  
  if (!employees || employees.length === 0) {
    console.warn(`[getEmployeesByCompany] No employees found for company ${companyId} (${company.name})`)
    return []
  }

  // Decrypt sensitive fields (required since we use .lean())
  // CRITICAL: Include 'location' in sensitiveFields for Company Admin - they need to see decrypted locations
  // NOTE: 'address' field is skipped if it's already an object (structured address from addressId)
  const { decrypt } = require('../utils/encryption')
  const companyIdStr = company.id || ''
  const companyStringId = company.id
  
  let decryptedEmployees: any[] = []
  try {
    decryptedEmployees = await Promise.all(employees.map(async (e: any) => {
    if (!e) return null
      try {
    const sensitiveFields = ['email', 'mobile', 'firstName', 'lastName', 'designation', 'location']
    for (const field of sensitiveFields) {
      if (e[field] && typeof e[field] === 'string' && e[field].includes(':')) {
        try {
          e[field] = decrypt(e[field])
        } catch (error) {
          // If decryption fails, keep original value
        }
      }
    }
        
        // Decrypt address fields
        const employeeAddressFields = ['address_line_1', 'address_line_2', 'address_line_3', 'city', 'state', 'pincode']
        for (const field of employeeAddressFields) {
          if (e[field] && typeof e[field] === 'string' && e[field].includes(':')) {
            try {
              e[field] = decrypt(e[field])
      } catch (error) {
        // If decryption fails, keep original value
      }
    }
        }
        
        // Create address object for backward compatibility with UI
        if (e.address_line_1) {
          e.address = {
            address_line_1: e.address_line_1 || '',
            address_line_2: e.address_line_2 || '',
            address_line_3: e.address_line_3 || '',
            city: e.city || '',
            state: e.state || '',
            pincode: e.pincode || '',
            country: e.country || 'India',
          }
        }
        
    // OPTIMIZATION: Set companyId directly from company lookup (already have it)
    if (e.companyId) {
      if (typeof e.companyId === 'object' && e.companyId._id) {
        e.companyId = e.companyId.id || companyStringId
      } else if (typeof e.companyId === 'string' && e.companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(e.companyId)) {
        // ObjectId string - use the company ID we already have
        e.companyId = companyStringId
      }
    } else {
      // Fallback: set from known company
      e.companyId = companyStringId
    }
        
        return e
      } catch (error: any) {
        console.error(`Error processing employee ${e.id}:`, error?.message || error)
        // Return the employee even if there was an error processing it
        return e
      }
    }))
    decryptedEmployees = decryptedEmployees.filter((e: any) => e !== null)
  } catch (error: any) {
    console.error('[getEmployeesByCompany] Error in Promise.all:', error?.message || error)
    console.error('[getEmployeesByCompany] Error stack:', error?.stack)
    // Return empty array or partial results instead of throwing
    decryptedEmployees = decryptedEmployees || []
  }
  
  // Convert to plain objects
  const plainEmployees = decryptedEmployees.map((e: any) => toPlainObject(e)).filter((e: any) => e !== null)
  
  return plainEmployees
}

export async function getUniqueDesignationsByCompany(companyId: string): Promise<string[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return []

  // Get all employees for this company (we need to decrypt designations)
  // CRITICAL FIX: Employee.companyId is stored as STRING ID, not ObjectId
  // Using find instead of distinct to get decrypted values through Mongoose hooks
  const employees = await Employee.find({ 
    companyId: company.id,
    designation: { $exists: true, $nin: [null, ''] }
  })
    .select('designation')
    .lean()

  // Import decrypt function
  const { decrypt } = require('../utils/encryption')
  // Use a Map to store normalized (lowercase) -> original designation mapping
  // This ensures case-insensitive uniqueness while preserving original case for display
  const designationMap = new Map<string, string>()
  
  for (const emp of employees) {
    if (emp.designation) {
      let designation = emp.designation as string
      
      // Handle both encrypted and plain text designations
      if (typeof designation === 'string') {
        // Check if it looks encrypted (contains ':' which is the separator in our encryption format)
        // But also check if it's a valid base64-like string pattern
        if (designation.includes(':') && designation.length > 20) {
          // Likely encrypted - try to decrypt
          try {
            const decrypted = decrypt(designation)
            // Only use decrypted value if it's valid (not empty, not the same as encrypted)
            if (decrypted && decrypted.trim().length > 0 && decrypted !== designation) {
              designation = decrypted
            }
            // If decryption returns empty or same value, treat as plain text
          } catch (error) {
            // Decryption failed - might be plain text that happens to contain ':'
            // Or might be corrupted data - skip encrypted-looking values
            console.warn(`[getUniqueDesignationsByCompany] Failed to decrypt designation, skipping: ${designation.substring(0, 50)}...`)
            continue
          }
        }
        // If we get here, designation is either plain text or successfully decrypted
        
        // Clean and normalize for case-insensitive uniqueness
        if (designation && typeof designation === 'string' && designation.trim().length > 0) {
          const trimmed = designation.trim()
          
          // Skip if it still looks like encrypted data (very long, base64-like)
          if (trimmed.length > 100 || /^[A-Za-z0-9+/=:]+$/.test(trimmed) && trimmed.length > 50) {
            console.warn(`[getUniqueDesignationsByCompany] Skipping potential encrypted designation: ${trimmed.substring(0, 50)}...`)
            continue
          }
          
          const normalized = trimmed.toLowerCase()
          // Store the first occurrence (or prefer capitalized versions)
          if (!designationMap.has(normalized)) {
            designationMap.set(normalized, trimmed)
          } else {
            // If we already have this designation, prefer the one with better capitalization
            // (e.g., prefer "Co-Pilot" over "co-pilot")
            const existing = designationMap.get(normalized)!
            // Prefer the one that starts with uppercase
            if (trimmed[0] && trimmed[0] === trimmed[0].toUpperCase() && 
                existing[0] && existing[0] !== existing[0].toUpperCase()) {
              designationMap.set(normalized, trimmed)
            }
          }
        }
      }
    }
  }

  // Convert to array and sort alphabetically (case-insensitive)
  return Array.from(designationMap.values()).sort((a, b) => 
    a.toLowerCase().localeCompare(b.toLowerCase())
  )
}

/**
 * Get unique shirt sizes for a company
 * @param companyId Company ID (6-digit numeric string)
 * @returns Array of unique shirt sizes
 */
export async function getUniqueShirtSizesByCompany(companyId: string): Promise<string[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return []

  const employees = await Employee.find({ 
    companyId: company._id,
    shirtSize: { $exists: true, $nin: [null, ''] }
  })
    .select('shirtSize')
    .lean()

  const { decrypt } = require('../utils/encryption')
  const sizeSet = new Set<string>()
  
  for (const emp of employees) {
    if (emp.shirtSize) {
      let size = emp.shirtSize as string
      // Check if it's encrypted
      if (typeof size === 'string' && size.includes(':')) {
        try {
          size = decrypt(size)
        } catch (error) {
          continue
        }
      }
      if (size && typeof size === 'string' && size.trim().length > 0) {
        sizeSet.add(size.trim())
      }
    }
  }

  // Sort sizes intelligently (handle numeric and alphanumeric)
  return Array.from(sizeSet).sort((a, b) => {
    // Try to parse as numbers first
    const aNum = parseFloat(a)
    const bNum = parseFloat(b)
    if (!isNaN(aNum) && !isNaN(bNum)) {
      return aNum - bNum
    }
    // Otherwise sort alphabetically
    return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
  })
}

/**
 * Get unique pant sizes for a company
 * @param companyId Company ID (6-digit numeric string)
 * @returns Array of unique pant sizes
 */
export async function getUniquePantSizesByCompany(companyId: string): Promise<string[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return []

  const employees = await Employee.find({ 
    companyId: company._id,
    pantSize: { $exists: true, $nin: [null, ''] }
  })
    .select('pantSize')
    .lean()

  const { decrypt } = require('../utils/encryption')
  const sizeSet = new Set<string>()
  
  for (const emp of employees) {
    if (emp.pantSize) {
      let size = emp.pantSize as string
      // Check if it's encrypted
      if (typeof size === 'string' && size.includes(':')) {
        try {
          size = decrypt(size)
        } catch (error) {
          continue
        }
      }
      if (size && typeof size === 'string' && size.trim().length > 0) {
        sizeSet.add(size.trim())
      }
    }
  }

  // Sort sizes intelligently (handle numeric and alphanumeric)
  return Array.from(sizeSet).sort((a, b) => {
    const aNum = parseFloat(a)
    const bNum = parseFloat(b)
    if (!isNaN(aNum) && !isNaN(bNum)) {
      return aNum - bNum
    }
    return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
  })
}

/**
 * Get unique shoe sizes for a company
 * @param companyId Company ID (6-digit numeric string)
 * @returns Array of unique shoe sizes
 */
export async function getUniqueShoeSizesByCompany(companyId: string): Promise<string[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return []

  const employees = await Employee.find({ 
    companyId: company._id,
    shoeSize: { $exists: true, $nin: [null, ''] }
  })
    .select('shoeSize')
    .lean()

  const { decrypt } = require('../utils/encryption')
  const sizeSet = new Set<string>()
  
  for (const emp of employees) {
    if (emp.shoeSize) {
      let size = emp.shoeSize as string
      // Check if it's encrypted
      if (typeof size === 'string' && size.includes(':')) {
        try {
          size = decrypt(size)
        } catch (error) {
          continue
        }
      }
      if (size && typeof size === 'string' && size.trim().length > 0) {
        sizeSet.add(size.trim())
      }
    }
  }

  // Sort sizes intelligently (handle numeric and alphanumeric)
  return Array.from(sizeSet).sort((a, b) => {
    const aNum = parseFloat(a)
    const bNum = parseFloat(b)
    if (!isNaN(aNum) && !isNaN(bNum)) {
      return aNum - bNum
    }
    return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
  })
}

export async function createEmployee(employeeData: {
  employeeId?: string
  firstName: string
  lastName: string
  designation: string
  gender: 'male' | 'female'
  location: string
  email: string
  mobile: string
  shirtSize: string
  pantSize: string
  shoeSize: string
  address?: string // DEPRECATED: Use addressData instead. Kept for backward compatibility.
  addressData?: { // New structured address format
    address_line_1: string
    address_line_2?: string
    address_line_3?: string
    city: string
    state: string
    pincode: string
    country?: string
  }
  companyId: string
  companyName?: string // Optional - will be derived from companyId lookup
  branchId?: string
  branchName?: string
  locationId?: string // Location ID (6-digit numeric string) - official delivery location
  eligibility?: { shirt: number; pant: number; shoe: number; jacket: number }
  cycleDuration?: { shirt: number; pant: number; shoe: number; jacket: number }
  dispatchPreference?: 'direct' | 'central' | 'regional'
  status?: 'active' | 'inactive'
  period?: string
  dateOfJoining?: Date
}): Promise<any> {
  await connectDB()
  
  // Find company by companyId only - companyName is not used for lookup
  const company = await Company.findOne({ id: employeeData.companyId })
  if (!company) {
    throw new Error(`Company not found: ${employeeData.companyId}`)
  }

  // Generate unique 6-digit numeric employee ID if not provided (starting from 300001)
  let employeeId = employeeData.employeeId
  if (!employeeId) {
    // Find the highest existing employee ID
    const existingEmployees = await Employee.find({})
      .sort({ id: -1 })
      .limit(1)
      .lean()
    
    let nextEmployeeId = 300001 // Start from 300001
    if (existingEmployees.length > 0) {
      const lastId = existingEmployees[0].id
      if (/^\d{6}$/.test(String(lastId))) {
        const lastIdNum = parseInt(String(lastId), 10)
        if (lastIdNum >= 300001 && lastIdNum < 400000) {
          nextEmployeeId = lastIdNum + 1
        }
      }
    }
    
    employeeId = String(nextEmployeeId).padStart(6, '0')
    
    // Check if this ID already exists (safety check)
    const existingById = await Employee.findOne({ id: employeeId })
    if (existingById) {
      // Find next available ID
      for (let i = nextEmployeeId + 1; i < 400000; i++) {
        const testId = String(i).padStart(6, '0')
        const exists = await Employee.findOne({ id: testId })
        if (!exists) {
          employeeId = testId
          break
        }
      }
    }
  }

  // Check if employee ID already exists
  const existingById = await Employee.findOne({ id: employeeId })
  if (existingById) {
    throw new Error(`Employee ID already exists: ${employeeId}`)
  }

  // Check if email already exists (email is encrypted, so we need to encrypt the search term)
  const { encrypt } = require('../utils/encryption')
  let encryptedEmail: string
  try {
    encryptedEmail = encrypt(employeeData.email.trim())
  } catch (error) {
    console.warn('Failed to encrypt email for duplicate check:', error)
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email
  let existingByEmail = null
  if (encryptedEmail) {
    existingByEmail = await Employee.findOne({ email: encryptedEmail })
  }
  
  // If not found with encrypted email, also check by decrypting all emails (fallback)
  if (!existingByEmail) {
    const allEmployees = await Employee.find({}).select('email').lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const { decrypt } = require('../utils/encryption')
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === employeeData.email.trim().toLowerCase()) {
            existingByEmail = emp
            break
          }
        } catch (error) {
          // Skip employees with decryption errors
          continue
        }
      }
    }
  }
  
  if (existingByEmail) {
    throw new Error(`Employee with email already exists: ${employeeData.email}`)
  }

  // Handle address - prepare embedded address fields
  let addressFields = {
    address_line_1: 'Address not specified',
    address_line_2: undefined as string | undefined,
    address_line_3: undefined as string | undefined,
    city: 'New Delhi',
    state: 'Delhi',
    pincode: '110001',
    country: 'India',
  }
  
  if (employeeData.addressData) {
    // Use structured address data directly
    addressFields = {
      address_line_1: employeeData.addressData.address_line_1,
      address_line_2: employeeData.addressData.address_line_2,
      address_line_3: employeeData.addressData.address_line_3,
      city: employeeData.addressData.city,
      state: employeeData.addressData.state,
      pincode: employeeData.addressData.pincode,
      country: employeeData.addressData.country || 'India',
    }
  } else if (employeeData.address) {
    // Legacy: If old address string is provided, try to parse it
    const { parseLegacyAddress } = require('../utils/address-service')
    try {
      const parsedAddress = parseLegacyAddress(employeeData.address)
      addressFields = {
        address_line_1: parsedAddress.address_line_1 || employeeData.address.substring(0, 255) || 'Address not specified',
        address_line_2: parsedAddress.address_line_2,
        address_line_3: parsedAddress.address_line_3,
        city: parsedAddress.city || 'New Delhi',
        state: parsedAddress.state || 'Delhi',
        pincode: parsedAddress.pincode || '110001',
        country: parsedAddress.country || 'India',
      }
    } catch (error: any) {
      console.warn(`Failed to parse address from legacy format for employee ${employeeId}:`, error.message)
      // Use default values
      addressFields.address_line_1 = employeeData.address.substring(0, 255) || 'Address not specified'
    }
  }

  // Get location if locationId is provided
  let locationIdObj = null
  if (employeeData.locationId) {
    const Location = require('../models/Location').default
    // Fetch location with populated companyId for reliable company ID extraction
    const location = await Location.findOne({ id: employeeData.locationId })
      .populate('companyId', 'id name')
      .lean()
    
    if (!location) {
      throw new Error(`Location not found: ${employeeData.locationId}`)
    }
    
    // Verify location belongs to the same company
    let locationCompanyId: string | null = null
    if (location.companyId) {
      if (typeof location.companyId === 'object' && location.companyId !== null && !Array.isArray(location.companyId)) {
        // Populated company object (from .populate())
        if (location.companyId.id && typeof location.companyId.id === 'string') {
          locationCompanyId = String(location.companyId.id).trim()
        } else if (location.companyId._id) {
          // Populated but no id field - fetch company using string id field
          // First try to get the id from the populated object, otherwise query by _id converted to id
          const companyIdFromPopulated = location.companyId.id || String(location.companyId._id || '')
          const locCompany = await Company.findOne({ id: companyIdFromPopulated }).select('id').lean()
          if (locCompany && locCompany.id) {
            locationCompanyId = String(locCompany.id).trim()
          }
        }
      } else if (typeof location.companyId === 'string' || location.companyId instanceof mongoose.Types.ObjectId) {
        // CRITICAL FIX: location.companyId is a STRING ID (6-digit), not ObjectId
        // Check if it's a string ID first
        if (typeof location.companyId === 'string' && /^\d{6}$/.test(location.companyId)) {
          locationCompanyId = location.companyId
        } else if (location.companyId instanceof mongoose.Types.ObjectId || (typeof location.companyId === 'string' && mongoose.Types.ObjectId.isValid(location.companyId))) {
          // It's an ObjectId - fetch company
          const locCompany = await Company.findById(location.companyId).select('id').lean()
          if (locCompany && locCompany.id) {
            locationCompanyId = String(locCompany.id).trim()
          }
        } else {
          // Try as string ID
          const locCompany = await Company.findOne({ id: String(location.companyId) }).select('id').lean()
          if (locCompany && locCompany.id) {
            locationCompanyId = String(locCompany.id).trim()
          }
        }
      }
    }
    
    // Validate that we have a valid company ID
    if (!locationCompanyId) {
      throw new Error(`Cannot determine location's company ID for location ${employeeData.locationId}. The location may have an invalid company association.`)
    }
    
    // Ensure employeeData.companyId is a string for comparison
    const employeeCompanyIdStr = String(employeeData.companyId).trim()
    
    if (locationCompanyId !== employeeCompanyIdStr) {
      throw new Error(`Location ${employeeData.locationId} does not belong to company ${employeeCompanyIdStr}`)
    }
    
    // Get location document _id (since we used .lean(), we need to fetch it again or use the _id from lean result)
    if (location._id) {
      locationIdObj = location._id
    } else {
      // Fallback: fetch location document if _id is missing (shouldn't happen)
      const locationDoc = await Location.findOne({ id: employeeData.locationId })
      if (locationDoc) {
        locationIdObj = locationDoc._id
      } else {
        throw new Error(`Location ${employeeData.locationId} not found when setting employee location`)
      }
    }
  }

  const newEmployee = new Employee({
    id: employeeId,
    employeeId: employeeId,
    firstName: employeeData.firstName,
    lastName: employeeData.lastName,
    designation: employeeData.designation,
    gender: employeeData.gender,
    location: employeeData.location,
    email: employeeData.email,
    mobile: employeeData.mobile,
    shirtSize: employeeData.shirtSize,
    pantSize: employeeData.pantSize,
    shoeSize: employeeData.shoeSize,
    // Set embedded address fields
    address_line_1: addressFields.address_line_1,
    address_line_2: addressFields.address_line_2,
    address_line_3: addressFields.address_line_3,
    city: addressFields.city,
    state: addressFields.state,
    pincode: addressFields.pincode,
    country: addressFields.country,
    companyId: company._id,
    companyName: company.name, // Derived from company lookup, not from input
    locationId: locationIdObj, // Official delivery location (optional for backward compatibility)
    eligibility: employeeData.eligibility || { shirt: 0, pant: 0, shoe: 0, jacket: 0 },
    cycleDuration: employeeData.cycleDuration || { shirt: 6, pant: 6, shoe: 6, jacket: 12 },
    dispatchPreference: employeeData.dispatchPreference || 'direct',
    status: employeeData.status || 'active',
    period: employeeData.period || '2024-2025',
    dateOfJoining: employeeData.dateOfJoining || new Date('2025-10-01T00:00:00.000Z'),
  })

  await newEmployee.save()
  
  // Fetch the created employee with populated fields
  const created = await Employee.findOne({ id: employeeId })
    .populate('companyId', 'id name')
    .populate('locationId', 'id name address city state pincode')
    .lean()

  return created ? toPlainObject(created) : null
}

export async function updateEmployee(
  employeeId: string,
  updateData: {
    firstName?: string
    lastName?: string
    designation?: string
    gender?: 'male' | 'female'
    location?: string
    email?: string
    mobile?: string
    shirtSize?: string
    pantSize?: string
    shoeSize?: string
    address?: string // DEPRECATED: Use addressData instead. Kept for backward compatibility.
    addressData?: { // New structured address format
      address_line_1: string
      address_line_2?: string
      address_line_3?: string
      city: string
      state: string
      pincode: string
      country?: string
    }
    companyId?: string
    // companyName removed - it's derived from companyId lookup only
    locationId?: string // Location ID (6-digit numeric string) - official delivery location
    eligibility?: { shirt: number; pant: number; shoe: number; jacket: number }
    cycleDuration?: { shirt: number; pant: number; shoe: number; jacket: number }
    dispatchPreference?: 'direct' | 'central' | 'regional'
    status?: 'active' | 'inactive'
    period?: string
    dateOfJoining?: Date
  }
): Promise<any> {
  await connectDB()
  
  // Fetch employee with companyId populated for proper validation
  const employee = await Employee.findOne({ id: employeeId })
    .populate('companyId', 'id name')
  
  if (!employee) {
    throw new Error(`Employee not found: ${employeeId}`)
  }

  // Check if email is being updated and if it conflicts with another employee
  // Since email is encrypted, we need to handle this carefully
  if (updateData.email) {
    // Decrypt current employee email to compare
    const { encrypt, decrypt } = require('../utils/encryption')
    let currentEmail = employee.email
    try {
      if (typeof currentEmail === 'string' && currentEmail.includes(':')) {
        currentEmail = decrypt(currentEmail)
      }
    } catch (error) {
      // If decryption fails, keep original
    }
    
    // Only check if email is actually changing
    if (updateData.email.trim().toLowerCase() !== currentEmail.toLowerCase()) {
      // Encrypt the new email to check for duplicates
      let encryptedNewEmail: string
      try {
        encryptedNewEmail = encrypt(updateData.email.trim())
      } catch (error) {
        console.warn('Failed to encrypt email for duplicate check:', error)
        encryptedNewEmail = ''
      }
      
      // Try finding with encrypted email
      let existingByEmail = null
      if (encryptedNewEmail) {
        existingByEmail = await Employee.findOne({ 
          email: encryptedNewEmail,
          id: { $ne: employee.id }
        })
      }
      
      // If not found, check by decrypting all emails (fallback)
      if (!existingByEmail) {
        const allEmployees = await Employee.find({ id: { $ne: employee.id } })
          .select('email')
          .lean()
        for (const emp of allEmployees) {
          if (emp.email && typeof emp.email === 'string') {
            try {
              const decryptedEmail = decrypt(emp.email)
              if (decryptedEmail.toLowerCase() === updateData.email.trim().toLowerCase()) {
                existingByEmail = emp
                break
              }
            } catch (error) {
              continue
            }
          }
        }
      }
      
      if (existingByEmail) {
        throw new Error(`Employee with email already exists: ${updateData.email}`)
      }
    }
  }

  // Validate and update companyId if provided - it cannot be removed or set to empty
  if (updateData.companyId !== undefined) {
    if (!updateData.companyId || (typeof updateData.companyId === 'string' && updateData.companyId.trim() === '')) {
      throw new Error('companyId cannot be empty or null. Every employee must be associated with a company.')
    }
    
    // Verify the company exists
    const company = await Company.findOne({ id: updateData.companyId })
    if (!company) {
      throw new Error(`Company not found: ${updateData.companyId}`)
    }
    
    // Update companyId - always set from company lookup
    employee.companyId = company._id
    // Update companyName to match the company (derived from companyId, for display purposes only)
    employee.companyName = company.name
  }
  
  // If companyName is provided in updateData, ignore it - it's derived from companyId only
  // This ensures companyName is always in sync with the company table

  // Update location if locationId is provided
  if (updateData.locationId !== undefined) {
    if (updateData.locationId) {
      const Location = require('../models/Location').default
      // Fetch location with populated companyId for reliable company ID extraction
      const location = await Location.findOne({ id: updateData.locationId })
        .populate('companyId', 'id name')
        .lean()
      
      if (!location) {
        throw new Error(`Location not found: ${updateData.locationId}`)
      }
      
      // Verify location belongs to the employee's company
      // Get employee's company ID - handle both populated and ObjectId cases
      let employeeCompanyId: string | null = null
      if (employee.companyId) {
        if (typeof employee.companyId === 'object' && employee.companyId !== null && !Array.isArray(employee.companyId)) {
          // Populated company object
          if (employee.companyId.id && typeof employee.companyId.id === 'string') {
            employeeCompanyId = String(employee.companyId.id).trim()
          } else if (employee.companyId._id) {
            // Populated but no id field - fetch company
            const companyIdStr = employee.companyId.id || String(employee.companyId._id || '')
            const empCompany = /^\d{6}$/.test(companyIdStr)
              ? await Company.findOne({ id: companyIdStr }).select('id').lean()
              : null
            if (empCompany && empCompany.id) {
              employeeCompanyId = String(empCompany.id).trim()
            }
          }
        } else if (typeof employee.companyId === 'string' || employee.companyId instanceof mongoose.Types.ObjectId) {
          // CRITICAL FIX: employee.companyId is a STRING ID (6-digit), not ObjectId
          // Check if it's a string ID first
          if (typeof employee.companyId === 'string' && /^\d{6}$/.test(employee.companyId)) {
            employeeCompanyId = employee.companyId
          } else if (employee.companyId instanceof mongoose.Types.ObjectId || (typeof employee.companyId === 'string' && mongoose.Types.ObjectId.isValid(employee.companyId))) {
            // It's an ObjectId - fetch company
            const empCompany = await Company.findById(employee.companyId).select('id').lean()
            if (empCompany && empCompany.id) {
              employeeCompanyId = String(empCompany.id).trim()
            }
          } else {
            // Try as string ID
            const empCompany = await Company.findOne({ id: String(employee.companyId) }).select('id').lean()
            if (empCompany && empCompany.id) {
              employeeCompanyId = String(empCompany.id).trim()
            }
          }
        }
      }
      
      // Get location's company ID - handle both populated and ObjectId cases
      let locationCompanyId: string | null = null
      if (location.companyId) {
        if (typeof location.companyId === 'object' && location.companyId !== null && !Array.isArray(location.companyId)) {
          // Populated company object (from .populate())
          if (location.companyId.id && typeof location.companyId.id === 'string') {
            locationCompanyId = String(location.companyId.id).trim()
          } else if (location.companyId._id) {
            // Populated but no id field - fetch company
            const companyIdStr = location.companyId.id || String(location.companyId._id || '')
            const locCompany = /^\d{6}$/.test(companyIdStr)
              ? await Company.findOne({ id: companyIdStr }).select('id').lean()
              : null
            if (locCompany && locCompany.id) {
              locationCompanyId = String(locCompany.id).trim()
            }
          }
        } else if (typeof location.companyId === 'string' || location.companyId instanceof mongoose.Types.ObjectId) {
          // ObjectId string or ObjectId - fetch company
          const locCompany = await Company.findById(location.companyId).select('id').lean()
          if (locCompany && locCompany.id) {
            locationCompanyId = String(locCompany.id).trim()
          }
        }
      }
      
      // Validate that we have valid company IDs
      if (!employeeCompanyId) {
        throw new Error(`Cannot determine employee's company ID. Please ensure the employee has a valid company association.`)
      }
      
      if (!locationCompanyId) {
        throw new Error(`Cannot determine location's company ID for location ${updateData.locationId}. The location may have an invalid company association.`)
      }
      
      // Debug logging
      console.log(`[updateEmployee] Location-Company validation:`, {
        employeeId: employee.employeeId || employee.id,
        locationId: updateData.locationId,
        employeeCompanyId: employeeCompanyId,
        locationCompanyId: locationCompanyId,
        match: employeeCompanyId === locationCompanyId
      })
      
      // Compare company IDs (both should be strings at this point)
      if (locationCompanyId !== employeeCompanyId) {
        throw new Error(`Location ${updateData.locationId} does not belong to employee's company. Employee company: ${employeeCompanyId}, Location company: ${locationCompanyId}`)
      }
      
      // Set locationId - .lean() preserves _id field
      if (location._id) {
        employee.locationId = location._id
      } else {
        // Fallback: fetch location document if _id is missing (shouldn't happen)
        const locationDoc = await Location.findOne({ id: updateData.locationId })
        if (locationDoc) {
          employee.locationId = locationDoc._id
        } else {
          throw new Error(`Location ${updateData.locationId} not found when setting employee location`)
        }
      }
    } else {
      employee.locationId = undefined
    }
  }

  // Handle address update - set embedded address fields directly
  if (updateData.addressData) {
    // Set structured address fields directly
    employee.address_line_1 = updateData.addressData.address_line_1
    employee.address_line_2 = updateData.addressData.address_line_2
    employee.address_line_3 = updateData.addressData.address_line_3
    employee.city = updateData.addressData.city
    employee.state = updateData.addressData.state
    employee.pincode = updateData.addressData.pincode
    employee.country = updateData.addressData.country || 'India'
  } else if (updateData.address) {
    // Legacy: If old address string is provided, try to parse and set embedded fields
    const { parseLegacyAddress } = require('../utils/address-service')
    try {
      const parsedAddress = parseLegacyAddress(updateData.address)
      // Use dummy values if parsing fails
      employee.address_line_1 = parsedAddress.address_line_1 || updateData.address.substring(0, 255) || 'Address not specified'
      employee.address_line_2 = parsedAddress.address_line_2
      employee.address_line_3 = parsedAddress.address_line_3
      employee.city = parsedAddress.city || 'New Delhi'
      employee.state = parsedAddress.state || 'Delhi'
      employee.pincode = parsedAddress.pincode || '110001'
      employee.country = parsedAddress.country || 'India'
    } catch (error: any) {
      console.warn(`Failed to parse address from legacy format for employee ${employeeId}:`, error.message)
      // Use dummy values
      employee.address_line_1 = updateData.address.substring(0, 255) || 'Address not specified'
      employee.city = 'New Delhi'
      employee.state = 'Delhi'
      employee.pincode = '110001'
      employee.country = 'India'
    }
  }

  // Update other fields
  if (updateData.firstName !== undefined) employee.firstName = updateData.firstName
  if (updateData.lastName !== undefined) employee.lastName = updateData.lastName
  if (updateData.designation !== undefined) employee.designation = updateData.designation
  if (updateData.gender !== undefined) employee.gender = updateData.gender
  if (updateData.location !== undefined) employee.location = updateData.location
  if (updateData.email !== undefined) employee.email = updateData.email
  if (updateData.mobile !== undefined) employee.mobile = updateData.mobile
  if (updateData.shirtSize !== undefined) employee.shirtSize = updateData.shirtSize
  if (updateData.pantSize !== undefined) employee.pantSize = updateData.pantSize
  if (updateData.shoeSize !== undefined) employee.shoeSize = updateData.shoeSize
  // Address fields are handled above via addressData or legacy address parsing
  if (updateData.eligibility !== undefined) employee.eligibility = updateData.eligibility
  if (updateData.cycleDuration !== undefined) employee.cycleDuration = updateData.cycleDuration
  if (updateData.dispatchPreference !== undefined) employee.dispatchPreference = updateData.dispatchPreference
  if (updateData.status !== undefined) employee.status = updateData.status
  if (updateData.period !== undefined) employee.period = updateData.period
  if (updateData.dateOfJoining !== undefined) employee.dateOfJoining = updateData.dateOfJoining

  await employee.save()
  
  // Fetch the updated employee with populated fields
  const updated = await Employee.findOne({ id: employeeId })
    .populate('companyId', 'id name')
    .populate('locationId', 'id name address city state pincode')
    .lean()

  if (!updated) return null
  
  // Since we used .lean(), the post hooks don't run, so we need to manually decrypt sensitive fields
  const { decrypt } = require('../utils/encryption')
  const sensitiveFields = ['email', 'mobile', 'address', 'firstName', 'lastName', 'designation']
  for (const field of sensitiveFields) {
    if (updated[field] && typeof updated[field] === 'string' && updated[field].includes(':')) {
      try {
        updated[field] = decrypt(updated[field])
      } catch (error) {
        console.warn(`Failed to decrypt field ${field} for employee ${employeeId}:`, error)
      }
    }
  }

  return toPlainObject(updated)
}

export async function deleteEmployee(employeeId: string): Promise<boolean> {
  await connectDB()
  
  const employee = await Employee.findOne({ id: employeeId })
  if (!employee) {
    throw new Error(`Employee not found: ${employeeId}`)
  }

  await Employee.deleteOne({ id: employeeId })
  return true
}

// ========== VENDOR-PRODUCT-COMPANY MAPPING FUNCTIONS ==========

/**
 * Find which vendor(s) supply a specific product to a specific company
 * Returns an array of vendors (for multi-vendor support), or empty array if no vendors found
 * If preferFirst is true, returns only the first vendor (for backward compatibility)
 */
export async function getVendorsForProductCompany(
  productId: string, 
  companyId: string | number, 
  preferFirst: boolean = true
): Promise<Array<{ vendorId: string, vendorName: string }>> {
  await connectDB()
  
  console.log(`[getVendorsForProductCompany] ===== FUNCTION CALLED =====`)
  console.log(`[getVendorsForProductCompany] Looking for productId=${productId} (type: ${typeof productId}), companyId=${companyId} (type: ${typeof companyId})`)
  
  // Find product and company by their string/numeric IDs
  // Handle both string and numeric product IDs
  let product = await Uniform.findOne({ id: productId })
  if (!product) {
    // If productId is numeric, try converting to string
    const productIdStr = String(productId)
    product = await Uniform.findOne({ id: productIdStr })
  }
  if (!product) {
    // If productId is string, try converting to number
    const productIdNum = Number(productId)
    if (!isNaN(productIdNum)) {
      product = await Uniform.findOne({ id: productIdNum })
    }
  }
  if (!product) {
    console.error(`[getVendorsForProductCompany] Product not found: ${productId} (type: ${typeof productId})`)
    // List available products for debugging
    const allProducts = await Uniform.find({}, 'id name').limit(5).lean()
    console.error(`[getVendorsForProductCompany] Available products (sample):`, allProducts.map((p: any) => `id=${p.id} (type: ${typeof p.id})`))
    return []
  }
  
  // Try to find company - handle both numeric and string IDs
  let company = await Company.findOne({ id: companyId })
  if (!company) {
    // If companyId is numeric, try converting to string
    const companyIdStr = String(companyId)
    company = await Company.findOne({ id: companyIdStr })
  }
  
  if (!company) {
    console.error(`[getVendorsForProductCompany] Company not found: ${companyId} (type: ${typeof companyId})`)
    // List available companies for debugging
    const allCompanies = await Company.find({}, 'id name').limit(5).lean()
    console.error(`[getVendorsForProductCompany] Available companies (sample):`, allCompanies.map((c: any) => `id=${c.id}, name=${c.name}`))
    return []
  }
  
  console.log(`[getVendorsForProductCompany] Found product: ${product.id}, company: ${company.id}`)
  console.log(`[getVendorsForProductCompany] Product _id: ${product._id}, Company _id: ${company._id}`)
  
  // Check if product is directly linked to company
  // CRITICAL FIX: ProductCompany stores productId and companyId as STRING IDs (6-digit numeric strings)
  // NOT ObjectIds - must use product.id and company.id, not product._id and company._id
  const db = mongoose.connection.db
  
  // Get string IDs for ProductCompany lookup
  const productStringId = product.id
  const companyStringId = company.id
  
  console.log(`[getVendorsForProductCompany] Looking for ProductCompany link:`)
  console.log(`[getVendorsForProductCompany]   productId (string): ${productStringId}`)
  console.log(`[getVendorsForProductCompany]   companyId (string): ${companyStringId}`)
  console.log(`[getVendorsForProductCompany]   product._id (ObjectId): ${product._id}`)
  console.log(`[getVendorsForProductCompany]   company._id (ObjectId): ${company._id}`)
  
  // Query ProductCompany using STRING IDs (not ObjectIds)
  let productCompanyLink = await ProductCompany.findOne({
    productId: productStringId, // Use string ID, not ObjectId
    companyId: companyStringId  // Use string ID, not ObjectId
  })
  
  // Fallback: use raw MongoDB collection if Mongoose lookup fails
  if (!productCompanyLink && db) {
    console.log(`[getVendorsForProductCompany] ProductCompany not found via Mongoose, trying raw MongoDB collection`)
    const rawProductCompanies = await db.collection('productcompanies').find({
      productId: productStringId, // Use string ID
      companyId: companyStringId   // Use string ID
    }).toArray()
    
    if (rawProductCompanies.length > 0) {
      console.log(`[getVendorsForProductCompany] ✓ Found ProductCompany link in raw collection`)
      // Set productCompanyLink to a truthy value so the function continues
      // We know the relationship exists, so we can proceed even if Mongoose query fails
      productCompanyLink = rawProductCompanies[0] as any
    }
  }
  
  if (!productCompanyLink) {
    console.error(`[getVendorsForProductCompany] ❌ Product ${productId} (${product.name || product.id}) is not linked to company ${companyId} (${company.name || company.id})`)
    console.error(`[getVendorsForProductCompany] Product string ID: ${productStringId}, Company string ID: ${companyStringId}`)
    console.error(`[getVendorsForProductCompany] Product _id: ${product._id}, Company _id: ${company._id}`)
    // List existing ProductCompany relationships for debugging - use string IDs
    const allProductCompanies = await ProductCompany.find({ productId: productStringId }).lean()
    console.error(`[getVendorsForProductCompany] Product is linked to companies (by string ID):`, allProductCompanies.map((pc: any) => `companyId=${pc.companyId}`))
    
    // Also check raw collection using string IDs
    if (db) {
      const rawProductCompanies = await db.collection('productcompanies').find({ productId: productStringId }).toArray()
      console.error(`[getVendorsForProductCompany] Raw ProductCompany links for product:`, rawProductCompanies.map((pc: any) => `companyId=${pc.companyId} (type: ${typeof pc.companyId})`))
    }
    return []
  }
  
  console.log(`[getVendorsForProductCompany] ✓ Product-Company link found`)
  
  // CRITICAL FIX: ProductVendor also stores productId as STRING ID (6-digit numeric string)
  // NOT ObjectId - must use product.id (string ID), not product._id (ObjectId)
  if (!db) {
    console.error(`[getVendorsForProductCompany] Database connection not available`)
    return []
  }
  
  // Use string ID for ProductVendor lookup
  const productIdStrForVendor = product.id // String ID (e.g., "200001")
  console.log(`[getVendorsForProductCompany] Searching for ProductVendor links with productId (string): ${productIdStrForVendor}`)
  console.log(`[getVendorsForProductCompany] Product _id (ObjectId): ${product._id.toString()}`)
  
  // Get all ProductVendor links from raw collection
  const rawProductVendors = await db.collection('productvendors').find({}).toArray()
  console.log(`[getVendorsForProductCompany] Total ProductVendor links in DB: ${rawProductVendors.length}`)
  
  console.log(`[getVendorsForProductCompany] Filtering by productId (string ID)=${productIdStrForVendor}`)
  
  // Filter by productId STRING ID - ProductCompany link already validates company access
  // ProductVendor links are product-vendor only (no companyId needed)
  const matchingLinks = rawProductVendors.filter((pv: any) => {
    if (!pv.productId) return false
    // ProductVendor stores productId as string ID, compare as string
    const pvProductIdStr = String(pv.productId)
    return pvProductIdStr === productIdStrForVendor
  })
  
  console.log(`[getVendorsForProductCompany] Found ${matchingLinks.length} ProductVendor link(s) for product ${productId} and company ${companyId}`)
  
  if (matchingLinks.length === 0) {
    console.error(`[getVendorsForProductCompany] ❌ No ProductVendor relationships found for product ${productId} (${product.name || product.id})`)
    console.error(`[getVendorsForProductCompany] Product string ID: ${productIdStrForVendor}`)
    console.error(`[getVendorsForProductCompany] Product _id (ObjectId): ${product._id.toString()}`)
    console.error(`[getVendorsForProductCompany] All ProductVendor links in DB:`)
    rawProductVendors.forEach((pv: any, i: number) => {
      console.error(`  ${i + 1}. productId: ${pv.productId} (type: ${typeof pv.productId}), vendorId: ${pv.vendorId} (type: ${typeof pv.vendorId})`)
    })
    return []
  }
  
  // Get all vendors for lookup
  // CRITICAL FIX: ProductVendor stores vendorId as STRING ID (6-digit numeric string)
  // Must look up vendors by their string id field, not ObjectId
  const allVendors = await db.collection('vendors').find({}).toArray()
  // Create map keyed by string ID (vendor.id) for lookup
  const vendorMap = new Map<string, { id: string, name: string, _id: any }>()
  allVendors.forEach((v: any) => {
    if (v.id) {
      // Key by string ID (e.g., "300001")
      vendorMap.set(String(v.id), { id: v.id, name: v.name, _id: v._id })
    }
  })
  
  // Extract vendor information from matching links
  const matchingVendors: Array<{ vendorId: string, vendorName: string }> = []
  const uniqueVendorIds = new Set<string>()
  
  for (const pvLink of matchingLinks) {
    if (!pvLink.vendorId) {
      console.warn(`[getVendorsForProductCompany] ProductVendor link has no vendorId`)
      continue
    }
    
    // ProductVendor stores vendorId as STRING ID (e.g., "300001"), not ObjectId
    const vendorIdStr = String(pvLink.vendorId)
    
    console.log(`[getVendorsForProductCompany] Processing ProductVendor link: vendorId=${vendorIdStr} (type: ${typeof pvLink.vendorId})`)
    
    // CRITICAL FIX: Deduplicate vendors (prevent same vendor added multiple times)
    if (uniqueVendorIds.has(vendorIdStr)) {
      console.warn(`[getVendorsForProductCompany] ⚠️ Duplicate ProductVendor link detected for vendorId: ${vendorIdStr}`)
      continue
    }
    uniqueVendorIds.add(vendorIdStr)
    
    // Look up vendor by string ID (not ObjectId)
    const vendor = vendorMap.get(vendorIdStr)
    
    if (vendor) {
      matchingVendors.push({
        vendorId: vendor.id,
        vendorName: vendor.name || 'Unknown Vendor'
      })
      console.log(`[getVendorsForProductCompany] ✓ Added vendor: ${vendor.id} (${vendor.name})`)
    } else {
      console.warn(`[getVendorsForProductCompany] Vendor not found for vendorId (string): ${vendorIdStr}`)
      console.warn(`[getVendorsForProductCompany] Available vendor IDs in map:`, Array.from(vendorMap.keys()).slice(0, 5))
    }
  }
  
  // CRITICAL VALIDATION: A product should only be linked to ONE vendor
  // If multiple vendors are found, this indicates a data integrity issue
  if (matchingVendors.length > 1) {
    console.error(`[getVendorsForProductCompany] ❌ CRITICAL: Product ${productId} (${product.name || product.id}) is linked to MULTIPLE vendors!`)
    console.error(`[getVendorsForProductCompany] This violates the business rule: "A product can only be linked to one vendor"`)
    console.error(`[getVendorsForProductCompany] Vendors found:`, matchingVendors.map(v => `${v.vendorId} (${v.vendorName})`))
    console.error(`[getVendorsForProductCompany] ⚠️ Returning FIRST vendor, but this is a DATA INTEGRITY ISSUE`)
    console.error(`[getVendorsForProductCompany] ⚠️ Please fix ProductVendor relationships in the database`)
    
    // Return first vendor but log the issue
    // In production, you might want to throw an error instead
    return [matchingVendors[0]]
  }
  
  // Return results
  if (matchingVendors.length === 0) {
    console.error(`[getVendorsForProductCompany] No vendors found for product ${productId}`)
  } else {
    console.log(`[getVendorsForProductCompany] ✓ Returning ${matchingVendors.length} vendor(s):`, matchingVendors.map(v => `${v.vendorId} (${v.vendorName})`))
  }
  
  // If preferFirst is true, return only the first vendor
  if (preferFirst && matchingVendors.length > 0) {
    return [matchingVendors[0]]
  }
  
  return matchingVendors
}

/**
 * Find which vendor supplies a specific product to a specific company
 * Returns the vendor ID and name, or null if no vendor found
 * This is a convenience wrapper that returns only the first vendor (for backward compatibility)
 */
export async function getVendorForProductCompany(productId: string, companyId: string): Promise<{ vendorId: string, vendorName: string } | null> {
  await connectDB()
  
  const vendors = await getVendorsForProductCompany(productId, companyId, true)
  return vendors.length > 0 ? vendors[0] : null
}

// ========== ORDER FUNCTIONS ==========

export async function getAllOrders(): Promise<any[]> {
  await connectDB()
  
  const orders = await Order.find()
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .sort({ orderDate: -1 })
    .lean()

  return orders.map((o: any) => toPlainObject(o))
}

export async function getOrdersByCompany(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return []

  // CRITICAL FIX: Order.companyId is stored as STRING ID, not ObjectId
  const orders = await Order.find({ companyId: company.id })
    .populate('employeeId', 'id firstName lastName email locationId')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .sort({ orderDate: -1 })
    .lean()

  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(orders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))

  const transformedOrders = orders.map((o: any) => {
    const plain = toPlainObject(o)
    // Add vendorName from vendorMap if missing
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    return plain
  })
  
  // Debug logging
  if (transformedOrders.length > 0) {
    console.log(`getOrdersByCompany(${companyId}): Found ${transformedOrders.length} orders`)
    const firstOrder = transformedOrders[0]
    console.log('Sample order:', {
      id: firstOrder.id,
      total: firstOrder.total,
      itemsCount: firstOrder.items?.length,
      vendorName: firstOrder.vendorName,
      vendorId: firstOrder.vendorId,
      items: firstOrder.items?.map((i: any) => ({ price: i.price, quantity: i.quantity, total: i.price * i.quantity }))
    })
  }
  
  return transformedOrders
}

/**
 * Get all orders for employees in a specific location
 * @param locationId Location ID (6-digit numeric string or ObjectId)
 * @returns Array of orders for employees in that location
 */
export async function getOrdersByLocation(locationId: string): Promise<any[]> {
  await connectDB()
  
  const Location = require('../models/Location').default
  const location = await Location.findOne({ id: locationId })
  
  if (!location) {
    return []
  }

  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Get all employees in this location using string ID
  const locationEmployees = await Employee.find({ locationId: location.id })
    .select('_id employeeId id')
    .lean()
  
  if (locationEmployees.length === 0) {
    return []
  }

  // CRITICAL FIX: Order.employeeId is stored as STRING ID (6-digit numeric), not ObjectId
  // Get employee string IDs (employee.id or employee.employeeId)
  const employeeStringIds = locationEmployees
    .map((e: any) => e.id || e.employeeId)
    .filter((id: any) => id && /^\d{6}$/.test(String(id)))

  if (employeeStringIds.length === 0) {
    return []
  }

  // Find orders for these employees using string IDs
  const orders = await Order.find({ employeeId: { $in: employeeStringIds } })
    .sort({ orderDate: -1 })
    .lean()

  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(orders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))

  // Manually populate employee, company, and uniform info using string IDs
  const ordersWithDetails = await Promise.all(orders.map(async (o: any) => {
    const plain = toPlainObject(o)
    
    // Manually fetch employee info using string ID
    if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
      const employee = await Employee.findOne({ 
        $or: [
          { id: plain.employeeId },
          { employeeId: plain.employeeId }
        ]
      }).select('id employeeId firstName lastName email locationId').lean()
      
      if (employee) {
        plain.employeeId = toPlainObject(employee)
      }
    }
    
    // Manually fetch company info using string ID
    if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
      const company = await Company.findOne({ id: plain.companyId })
        .select('id name')
        .lean()
      
      if (company) {
        plain.companyId = toPlainObject(company)
      }
    }
    
    // Manually fetch uniform info for items
    if (plain.items && Array.isArray(plain.items)) {
      const uniformIds = plain.items
        .map((item: any) => item.uniformId)
        .filter((id: any) => id && typeof id === 'string' && /^\d{6}$/.test(id))
      
      if (uniformIds.length > 0) {
        const Uniform = require('../models/Uniform').default
        const uniforms = await Uniform.find({ id: { $in: uniformIds } })
          .select('id name')
          .lean()
        const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
        
        plain.items = plain.items.map((item: any) => {
          if (item.uniformId && uniformMap.has(item.uniformId)) {
            item.uniformId = uniformMap.get(item.uniformId)
          }
          return item
        })
      }
    }
    
    // Add vendorName from vendorMap if missing
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    
    return plain
  }))

  return ordersWithDetails
}

export async function getOrdersByVendor(vendorId: string): Promise<any[]> {
  await connectDB()
  
  console.log(`[getOrdersByVendor] ========================================`)
  console.log(`[getOrdersByVendor] 🚀 FETCHING ORDERS FOR VENDOR: ${vendorId}`)
  
  // CRITICAL FIX: Enhanced vendor lookup using string ID only
  let vendor = await Vendor.findOne({ id: vendorId })
  
  if (!vendor) {
    console.error(`[getOrdersByVendor] ❌ Vendor not found: ${vendorId}`)
    // List available vendors for debugging
    const allVendors = await Vendor.find({}, 'id name _id').limit(5).lean()
    console.error(`[getOrdersByVendor] Available vendors (sample):`, allVendors.map((v: any) => `id=${v.id}, _id=${v._id?.toString()}`))
    return []
  }
  
  console.log(`[getOrdersByVendor] ✅ Vendor found: ${vendor.name} (id: ${vendor.id}, _id: ${vendor._id})`)

  // CRITICAL FIX: Orders now store vendorId as 6-digit numeric string, NOT ObjectId
  // Query using vendor.id (numeric string) instead of vendor._id (ObjectId)
  const vendorNumericId = String(vendor.id).trim()
  console.log(`[getOrdersByVendor] Querying orders with vendorId (numeric): ${vendorNumericId}`)
  
  // Query orders by numeric vendor ID (6-digit string)
  // CRITICAL: Vendors should ONLY see orders that are:
  // - Approved by Company Admin (pr_status = 'COMPANY_ADMIN_APPROVED')
  // - OR have PO created (pr_status = 'PO_CREATED')
  // - OR are replacement orders (orderType = 'REPLACEMENT') - these are auto-approved
  // This ensures vendors don't see orders until Company Admin approval and PO assignment
  // Replacement orders are an exception as they're created after company admin approval of return request
  const vendorOrderQuery: any = {
    vendorId: vendorNumericId,
    $or: [
      { pr_status: { $in: ['COMPANY_ADMIN_APPROVED', 'PO_CREATED'] } },
      { orderType: 'REPLACEMENT' }
    ]
  }
  
  console.log(`[getOrdersByVendor] Filtering orders: vendorId=${vendorNumericId}, (pr_status in [COMPANY_ADMIN_APPROVED, PO_CREATED] OR orderType = REPLACEMENT)`)
  
  // Include PR fields (pr_number, pr_date) for display
  // Include shipping_address fields for destination address display
  // Include orderType and returnRequestId for replacement orders
  // Note: items array includes all fields (dispatchedQuantity, deliveredQuantity) automatically
  let orders = await Order.find(vendorOrderQuery)
    .select('id employeeId employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status deliveryStatus dispatchStatus shipping_address_line_1 shipping_address_line_2 shipping_address_line_3 shipping_city shipping_state shipping_pincode shipping_country orderType returnRequestId')
    .populate('employeeId', 'id firstName lastName email locationId')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .sort({ orderDate: -1 })
    .lean()
  
  console.log(`[getOrdersByVendor] Found ${orders.length} approved order(s) with vendorId=${vendorNumericId} (after Company Admin approval filter)`)
  
  if (orders.length === 0) {
    console.log(`[getOrdersByVendor] ✅ No orders found for vendor ${vendor.name} (${vendor.id})`)
    console.log(`[getOrdersByVendor] This is expected if vendor has no orders`)
  }
  
  // Add vendor name to orders (since vendorId is now a string, not a populated reference)
  const vendorName = vendor.name
  orders = orders.map((order: any) => ({
    ...order,
    vendorName: vendorName,
    vendorId: vendorNumericId // Ensure vendorId is the numeric string
  }))
  
  // Fetch PO and PR numbers for orders via POOrder mapping
  const poMap = new Map<string, any[]>()
  
  if (orders.length > 0) {
    try {
      // CRITICAL FIX: POOrder.order_id stores Order.id (string ID), not Order._id (ObjectId)
      // Use string IDs only - no ObjectId fallback
      const orderStringIds = orders.map((o: any) => o.id).filter(Boolean)
      
      if (orderStringIds.length > 0) {
        // Query POOrder mappings using string IDs only
        const poOrderMappings = await POOrder.find({ order_id: { $in: orderStringIds } })
          .lean()
        
        // CRITICAL FIX: purchase_order_id is a STRING field, not a Mongoose reference
        // We cannot use .populate() - must manually fetch PurchaseOrder documents
        const poIds = poOrderMappings
          .map((m: any) => {
            const poId = typeof m.purchase_order_id === 'string' 
              ? m.purchase_order_id 
              : String(m.purchase_order_id || '')
            return poId
          })
          .filter(Boolean)
        
        // Fetch PurchaseOrder documents manually using string IDs
        const purchaseOrders = poIds.length > 0
          ? await PurchaseOrder.find({ id: { $in: poIds } })
              .select('id client_po_number po_date')
              .lean()
          : []
        
        // Create a map of PO ID to PO details for quick lookup
        const poDetailsMap = new Map<string, any>()
        for (const po of purchaseOrders) {
          const poId = typeof po.id === 'string' ? po.id : String(po.id || '')
          if (poId) {
            poDetailsMap.set(poId, {
              poNumber: po?.client_po_number || '',
              poId: poId,
              poDate: po?.po_date || null
            })
          }
        }
        
        // Create a map of order id (string) to PO details
        for (const mapping of poOrderMappings) {
          // order_id should be a string ID
          const orderId = typeof mapping.order_id === 'string' 
            ? mapping.order_id 
            : String(mapping.order_id || '')
          
          // Get PO ID from mapping
          const poId = typeof mapping.purchase_order_id === 'string'
            ? mapping.purchase_order_id
            : String(mapping.purchase_order_id || '')
          
          // Look up PO details from our manually fetched map
          const poDetails = poId ? poDetailsMap.get(poId) : null
          
          if (orderId && poDetails) {
            if (!poMap.has(orderId)) {
              poMap.set(orderId, [])
            }
            poMap.get(orderId)!.push(poDetails)
          }
        }
      }
    } catch (error: any) {
      console.error(`[getOrdersByVendor] ⚠️ Error fetching PO mappings:`, error.message)
      console.error(`[getOrdersByVendor] Error stack:`, error.stack)
      // Continue without PO details rather than failing completely
    }
  }
  
  // Add PO and PR numbers to orders
  // CRITICAL FIX: Use order.id (string ID) instead of order._id for PO mapping lookup
  orders = orders.map((order: any) => {
    const orderId = order.id // Use string ID, not ObjectId
    const poDetails = orderId ? (poMap.get(orderId) || []) : []
    return {
      ...order,
      poNumbers: poDetails.map((po: any) => po.poNumber).filter(Boolean),
      poDetails: poDetails, // Full PO details array
      prNumber: order.pr_number || null, // PR number is already in order
      prDate: order.pr_date || null
    }
  })
  
  // Log order details for debugging
  console.log(`[getOrdersByVendor] 📋 Order Summary:`)
  orders.forEach((order, idx) => {
    console.log(`[getOrdersByVendor]   ${idx + 1}. Order ID: ${order.id}, Status: ${order.status}, PR: ${order.prNumber || 'N/A'}, PO: ${order.poNumbers?.join(', ') || 'N/A'}, ParentOrderId: ${(order as any).parentOrderId || 'N/A'}, VendorId: ${order.vendorId || 'N/A'}`)
  })
  
  // CRITICAL: Check for split orders (orders with parentOrderId)
  const splitOrders = orders.filter((o: any) => o.parentOrderId)
  if (splitOrders.length > 0) {
    console.log(`[getOrdersByVendor] 📦 Found ${splitOrders.length} split order(s) (with parentOrderId)`)
    splitOrders.forEach((order: any) => {
      console.log(`[getOrdersByVendor]   - ${order.id} (parent: ${order.parentOrderId})`)
    })
  }
  
  console.log(`[getOrdersByVendor] ✅ Returning ${orders.length} order(s)`)
  console.log(`[getOrdersByVendor] ========================================`)

  return orders.map((o: any) => toPlainObject(o))
}

// ========== VENDOR REPORTS FUNCTIONS ==========

/**
 * Get sales patterns for a vendor (daily, weekly, monthly trends)
 */
export async function getVendorSalesPatterns(vendorId: string, period: 'daily' | 'weekly' | 'monthly' = 'monthly'): Promise<{
  period: string
  revenue: number
  orderCount: number
  avgOrderValue: number
}[]> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) return []

  // Use string ID instead of ObjectId
  const orders = await Order.find({ vendorId: vendor.id })
    .select('orderDate total status')
    .lean()

  if (orders.length === 0) return []

  // Group orders by period
  const periodMap = new Map<string, { revenue: number; orderCount: number }>()

  orders.forEach((order: any) => {
    const date = new Date(order.orderDate)
    let periodKey = ''

    if (period === 'daily') {
      periodKey = date.toISOString().split('T')[0] // YYYY-MM-DD
    } else if (period === 'weekly') {
      const weekStart = new Date(date)
      weekStart.setDate(date.getDate() - date.getDay()) // Start of week (Sunday)
      periodKey = weekStart.toISOString().split('T')[0]
    } else { // monthly
      periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}` // YYYY-MM
    }

    if (!periodMap.has(periodKey)) {
      periodMap.set(periodKey, { revenue: 0, orderCount: 0 })
    }

    const periodData = periodMap.get(periodKey)!
    periodData.revenue += order.total || 0
    periodData.orderCount += 1
  })

  // Convert to array and sort by period
  const patterns = Array.from(periodMap.entries())
    .map(([periodKey, data]) => ({
      period: periodKey,
      revenue: data.revenue,
      orderCount: data.orderCount,
      avgOrderValue: data.orderCount > 0 ? data.revenue / data.orderCount : 0
    }))
    .sort((a, b) => a.period.localeCompare(b.period))

  return patterns
}

/**
 * Get order status breakdown for a vendor
 */
export async function getVendorOrderStatusBreakdown(vendorId: string): Promise<{
  status: string
  count: number
  revenue: number
  percentage: number
}> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) return []

  const orders = await Order.find({ vendorId: vendor._id })
    .select('status total')
    .lean()

  if (orders.length === 0) return []

  const statusMap = new Map<string, { count: number; revenue: number }>()

  orders.forEach((order: any) => {
    const status = order.status || 'Unknown'
    if (!statusMap.has(status)) {
      statusMap.set(status, { count: 0, revenue: 0 })
    }
    const statusData = statusMap.get(status)!
    statusData.count += 1
    statusData.revenue += order.total || 0
  })

  const totalOrders = orders.length

  return Array.from(statusMap.entries())
    .map(([status, data]) => ({
      status,
      count: data.count,
      revenue: data.revenue,
      percentage: totalOrders > 0 ? (data.count / totalOrders) * 100 : 0
    }))
    .sort((a, b) => b.count - a.count)
}

/**
 * Get business volume per company for a vendor
 */
export async function getVendorBusinessVolumeByCompany(vendorId: string): Promise<{
  companyId: string
  companyName: string
  orderCount: number
  revenue: number
  avgOrderValue: number
  percentage: number
}> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) return []

  const orders = await Order.find({ vendorId: vendor._id })
    .populate('companyId', 'id name')
    .select('companyId total')
    .lean()

  if (orders.length === 0) return []

  const companyMap = new Map<string, { companyName: string; orderCount: number; revenue: number }>()
  let totalRevenue = 0

  orders.forEach((order: any) => {
    const companyId = order.companyId?._id?.toString() || order.companyId?.toString() || 'Unknown'
    const companyName = order.companyId?.name || 'Unknown Company'
    const revenue = order.total || 0

    if (!companyMap.has(companyId)) {
      companyMap.set(companyId, { companyName, orderCount: 0, revenue: 0 })
    }

    const companyData = companyMap.get(companyId)!
    companyData.orderCount += 1
    companyData.revenue += revenue
    totalRevenue += revenue
  })

  return Array.from(companyMap.entries())
    .map(([companyId, data]) => ({
      companyId,
      companyName: data.companyName,
      orderCount: data.orderCount,
      revenue: data.revenue,
      avgOrderValue: data.orderCount > 0 ? data.revenue / data.orderCount : 0,
      percentage: totalRevenue > 0 ? (data.revenue / totalRevenue) * 100 : 0
    }))
    .sort((a, b) => b.revenue - a.revenue)
}

/**
 * Get comprehensive vendor report data
 */
export async function getVendorReports(vendorId: string): Promise<{
  salesPatterns: {
    daily: Array<{ period: string; revenue: number; orderCount: number; avgOrderValue: number }>
    weekly: Array<{ period: string; revenue: number; orderCount: number; avgOrderValue: number }>
    monthly: Array<{ period: string; revenue: number; orderCount: number; avgOrderValue: number }>
  }
  orderStatusBreakdown: Array<{ status: string; count: number; revenue: number; percentage: number }>
  businessVolumeByCompany: Array<{ companyId: string; companyName: string; orderCount: number; revenue: number; avgOrderValue: number; percentage: number }>
  summary: {
    totalRevenue: number
    totalOrders: number
    avgOrderValue: number
    totalCompanies: number
  }
}> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }

  const [salesPatternsDaily, salesPatternsWeekly, salesPatternsMonthly, orderStatusBreakdown, businessVolumeByCompany] = await Promise.all([
    getVendorSalesPatterns(vendorId, 'daily'),
    getVendorSalesPatterns(vendorId, 'weekly'),
    getVendorSalesPatterns(vendorId, 'monthly'),
    getVendorOrderStatusBreakdown(vendorId),
    getVendorBusinessVolumeByCompany(vendorId)
  ])

  // Calculate summary
  const totalRevenue = orderStatusBreakdown.reduce((sum, item) => sum + item.revenue, 0)
  const totalOrders = orderStatusBreakdown.reduce((sum, item) => sum + item.count, 0)
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0
  const totalCompanies = businessVolumeByCompany.length

  return {
    salesPatterns: {
      daily: salesPatternsDaily,
      weekly: salesPatternsWeekly,
      monthly: salesPatternsMonthly
    },
    orderStatusBreakdown,
    businessVolumeByCompany,
    summary: {
      totalRevenue,
      totalOrders,
      avgOrderValue,
      totalCompanies
    }
  }
}

/**
 * Calculate aggregated order status for multi-vendor (split) orders
 * 
 * This function implements granular status display for employee-facing order views:
 * - Dispatch status: "Awaiting Dispatch" | "Partially Dispatched" | "Dispatched"
 * - Delivery status: "Awaiting Delivery" | "Partially Delivered" | "Delivered"
 * 
 * @param splitOrders Array of child orders (vendor suborders) for a split order
 * @returns Aggregated status string for employee display
 */
function calculateAggregatedOrderStatus(splitOrders: any[]): string {
  if (!splitOrders || splitOrders.length === 0) {
    return 'Awaiting approval'
  }
  
  // For single-vendor orders, return the status as-is (no aggregation needed)
  if (splitOrders.length === 1) {
    return splitOrders[0].status || 'Awaiting approval'
  }
  
  // Count orders by status
  const statusCounts = {
    'Awaiting approval': 0,
    'Awaiting fulfilment': 0,
    'Dispatched': 0,
    'Delivered': 0
  }
  
  splitOrders.forEach((order: any) => {
    const status = order.status || 'Awaiting approval'
    if (status in statusCounts) {
      statusCounts[status as keyof typeof statusCounts]++
    }
  })
  
  const totalOrders = splitOrders.length
  
  // DELIVERY STATUS (highest priority - check delivery first)
  const deliveredCount = statusCounts['Delivered']
  if (deliveredCount > 0) {
    if (deliveredCount === totalOrders) {
      // All orders delivered
      return 'Delivered'
    } else {
      // Some delivered, some not
      return 'Partially Delivered'
    }
  }
  
  // STEP 2: DISPATCH STATUS (check dispatch if not all delivered)
  const dispatchedCount = statusCounts['Dispatched']
  const awaitingFulfilmentCount = statusCounts['Awaiting fulfilment']
  const awaitingApprovalCount = statusCounts['Awaiting approval']
  
  // If any orders are still awaiting approval, return that status
  // (Can't have dispatch/delivery status if still in approval)
  if (awaitingApprovalCount > 0) {
    return 'Awaiting approval'
  }
  
  // All remaining orders are either "Awaiting fulfilment" or "Dispatched"
  if (dispatchedCount === 0) {
    // None dispatched - all are in "Awaiting fulfilment"
    // This means we're "Awaiting Dispatch"
    return 'Awaiting Dispatch'
  } else if (dispatchedCount === totalOrders) {
    // All dispatched (but not delivered)
    // This means we're "Awaiting Delivery"
    return 'Awaiting Delivery'
  } else {
    // Some dispatched, some still in "Awaiting fulfilment"
    return 'Partially Dispatched'
  }
}

export async function getOrdersByEmployee(employeeId: string): Promise<any[]> {
  await connectDB()
  
  // OPTIMIZATION: Combine employee lookups into single query with $or
  const employee = await Employee.findOne({
    $or: [
      { employeeId: employeeId },
      { id: employeeId }
    ]
  }).select('_id employeeId id').lean()
  
  if (!employee) {
    return []
  }

  // CRITICAL FIX: Order.employeeId is stored as STRING ID (6-digit numeric), not ObjectId
  // Use employee string ID (employee.id or employee.employeeId)
  const employeeStringId = employee.id || employee.employeeId
  if (!employeeStringId || !/^\d{6}$/.test(String(employeeStringId))) {
    return []
  }
  
  // Query orders using string ID
  const orderQuery: any = { employeeId: employeeStringId }

  // OPTIMIZATION: Use select() to limit fields, reduce payload size
  const orders = await Order.find(orderQuery)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt')
    .sort({ orderDate: -1 })
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(orders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Manually populate employee, company, and uniform info using string IDs
  const ordersWithDetails = await Promise.all(orders.map(async (o: any) => {
    const plain = toPlainObject(o)
    
    // Manually fetch employee info using string ID
    if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
      const emp = await Employee.findOne({ 
        $or: [
          { id: plain.employeeId },
          { employeeId: plain.employeeId }
        ]
      }).select('id employeeId firstName lastName email').lean()
      
      if (emp) {
        plain.employeeId = toPlainObject(emp)
      }
    }
    
    // Manually fetch company info using string ID
    if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
      const company = await Company.findOne({ id: plain.companyId })
        .select('id name')
        .lean()
      
      if (company) {
        plain.companyId = toPlainObject(company)
      }
    }
    
    // Manually fetch uniform info for items
    if (plain.items && Array.isArray(plain.items)) {
      const uniformIds = plain.items
        .map((item: any) => item.uniformId)
        .filter((id: any) => id && typeof id === 'string' && /^\d{6}$/.test(id))
      
      if (uniformIds.length > 0) {
        const Uniform = require('../models/Uniform').default
        const uniforms = await Uniform.find({ id: { $in: uniformIds } })
          .select('id name')
          .lean()
        const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
        
        plain.items = plain.items.map((item: any) => {
          if (item.uniformId && uniformMap.has(item.uniformId)) {
            item.uniformId = uniformMap.get(item.uniformId)
          }
          return item
        })
      }
    }
    
    // Add vendorName from vendorMap if missing
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    
    return plain
  }))

  // Group orders by parentOrderId if they are split orders
  const orderMap = new Map<string, any[]>()
  const standaloneOrders: any[] = []

  for (const order of orders) {
    const plainOrder = toPlainObject(order)
    if (plainOrder.parentOrderId) {
      if (!orderMap.has(plainOrder.parentOrderId)) {
        orderMap.set(plainOrder.parentOrderId, [])
      }
      orderMap.get(plainOrder.parentOrderId)!.push(plainOrder)
    } else {
      standaloneOrders.push(plainOrder)
    }
  }

  // Create grouped orders (one per parentOrderId) and add standalone orders
  const groupedOrders: any[] = []
  
  for (const [parentOrderId, splitOrders] of orderMap.entries()) {
    // Sort split orders by vendor name for consistency
    splitOrders.sort((a, b) => (a.vendorName || '').localeCompare(b.vendorName || ''))
    
    // Create a grouped order object
    const totalAmount = splitOrders.reduce((sum, o) => sum + (o.total || 0), 0)
    const totalItems = splitOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)
    const allItems = splitOrders.flatMap(o => o.items || [])
    
    // NEW STATUS AGGREGATION LOGIC: Calculate granular status for multi-vendor orders
    // This provides accurate partial progress visibility for employees:
    // - "Partially Dispatched" when some vendors dispatch but others haven't
    // - "Partially Delivered" when some vendors deliver but others haven't
    // - "Awaiting Dispatch" when none are dispatched
    // - "Awaiting Delivery" when all dispatched but none delivered
    const aggregatedStatus = calculateAggregatedOrderStatus(splitOrders)
    
    console.log(`[getOrdersByEmployee] Split order status aggregation:`, {
      parentOrderId,
      childOrders: splitOrders.map((o: any) => ({ id: o.id, status: o.status, vendor: o.vendorName })),
      aggregatedStatus,
      statusBreakdown: {
        'Awaiting approval': splitOrders.filter((o: any) => o.status === 'Awaiting approval').length,
        'Awaiting fulfilment': splitOrders.filter((o: any) => o.status === 'Awaiting fulfilment').length,
        'Dispatched': splitOrders.filter((o: any) => o.status === 'Dispatched').length,
        'Delivered': splitOrders.filter((o: any) => o.status === 'Delivered').length,
      },
      note: 'Using granular status aggregation for accurate partial progress display'
    })
    
    // For split orders, also create item-level status mapping
    // Each item should know which child order it belongs to and that order's status
    const itemsWithStatus = allItems.map((item: any, globalIndex: number) => {
      // Find which child order this item belongs to
      let currentIndex = 0
      for (const childOrder of splitOrders) {
        const childItems = childOrder.items || []
        if (globalIndex >= currentIndex && globalIndex < currentIndex + childItems.length) {
          return {
            ...item,
            _itemStatus: childOrder.status, // Store the status of the child order containing this item
            _childOrderId: childOrder.id // Store the child order ID for reference
          }
        }
        currentIndex += childItems.length
      }
      return item
    })
    
    groupedOrders.push({
      ...splitOrders[0], // Use first order as base
      id: parentOrderId, // Use parent order ID as the main ID
      isSplitOrder: true,
      splitOrders: splitOrders,
      status: aggregatedStatus, // Use calculated aggregated status
      total: totalAmount,
      items: itemsWithStatus, // Items with per-item status
      vendorCount: splitOrders.length,
      vendors: splitOrders.map(o => o.vendorName).filter(Boolean)
    })
  }

  // Combine grouped and standalone orders, sorted by date
  const allOrders = [...groupedOrders, ...standaloneOrders]
  allOrders.sort((a, b) => {
    const dateA = new Date(a.orderDate || 0).getTime()
    const dateB = new Date(b.orderDate || 0).getTime()
    return dateB - dateA
  })

  return allOrders
}

export async function getOrdersByParentOrderId(parentOrderId: string): Promise<any[]> {
  await connectDB()
  
  const orders = await Order.find({ parentOrderId: parentOrderId })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .sort({ orderDate: -1 })
    .lean()

  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(orders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))

  return orders.map((o: any) => {
    const plain = toPlainObject(o)
    // Add vendorName from vendorMap if missing
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    return plain
  })
}

/**
 * Get employee eligibility from designation rules
 * Falls back to employee-level eligibility if no designation rule exists
 * Now returns dynamic categories instead of hard-coded ones
 */
export async function getEmployeeEligibilityFromDesignation(employeeId: string): Promise<{
  eligibility: Record<string, number> // Dynamic category eligibility: { "shirt": 2, "pant": 2, "custom-category": 1, ... }
  cycleDurations: Record<string, number> // Dynamic category cycle durations: { "shirt": 6, "pant": 6, ... }
  // Legacy fields for backward compatibility
  shirt: number
  pant: number
  shoe: number
  jacket: number
}> {
  await connectDB()
  
  // Use employeeId field instead of id field
  let employee = await Employee.findOne({ employeeId: employeeId })
  if (!employee) {
    // Fallback: try by id field for backward compatibility
    employee = await Employee.findOne({ id: employeeId })
  }
  if (!employee) {
    // Return empty eligibility with defaults
    return {
      eligibility: {},
      cycleDurations: {},
      shirt: 0,
      pant: 0,
      shoe: 0,
      jacket: 0
    }
  }

  // Get company ID
  // Get company using safe helper
  const company = await getCompanyByIdSafe(employee.companyId)
  if (!company) {
    // Fallback to employee-level eligibility (legacy format)
    const legacyEligibility = {
      shirt: employee.eligibility?.shirt || 0,
      pant: employee.eligibility?.pant || 0,
      shoe: employee.eligibility?.shoe || 0,
      jacket: employee.eligibility?.jacket || 0,
    }
    const legacyCycleDurations = employee.cycleDuration || { shirt: 6, pant: 6, shoe: 6, jacket: 12 }
    
    // Convert to dynamic format
    const eligibility: Record<string, number> = {}
    const cycleDurations: Record<string, number> = {}
    
    // Map legacy categories to dynamic format
    if (legacyEligibility.shirt > 0) eligibility['shirt'] = legacyEligibility.shirt
    if (legacyEligibility.pant > 0) eligibility['pant'] = legacyEligibility.pant
    if (legacyEligibility.shoe > 0) eligibility['shoe'] = legacyEligibility.shoe
    if (legacyEligibility.jacket > 0) eligibility['jacket'] = legacyEligibility.jacket
    
    Object.keys(legacyCycleDurations).forEach(key => {
      cycleDurations[key] = (legacyCycleDurations as any)[key]
    })
    
    return {
      eligibility,
      cycleDurations,
      ...legacyEligibility
    }
  }

  // CRITICAL FIX: Use subcategory-based eligibility instead of old category-based system
  // Decrypt employee designation for matching
  const { decrypt } = require('../utils/encryption')
  let normalizedDesignation = employee.designation || ''
  if (normalizedDesignation && typeof normalizedDesignation === 'string' && normalizedDesignation.includes(':')) {
    try {
      normalizedDesignation = decrypt(normalizedDesignation)
    } catch (error) {
      console.warn('Failed to decrypt employee designation for eligibility lookup:', error)
    }
  }
  normalizedDesignation = normalizedDesignation.trim()
  
  const employeeGender = employee.gender || 'unisex'
  const genderFilter = employeeGender === 'unisex' || !employeeGender 
    ? { $in: ['male', 'female', 'unisex'] } 
    : employeeGender
  
  console.log(`[getEmployeeEligibilityFromDesignation] Checking subcategory eligibility for:`)
  console.log(`  - companyId: ${company.id} (string ID)`)
  console.log(`  - designationId: "${normalizedDesignation}"`)
  console.log(`  - gender: ${JSON.stringify(genderFilter)}`)
  
  // Query DesignationSubcategoryEligibility (subcategory-based)
  // CRITICAL FIX: Use company.id (string ID) instead of company._id (ObjectId)
  // DesignationSubcategoryEligibility stores companyId as a string ID (e.g., "100001")
  const subcategoryEligibilities = await DesignationSubcategoryEligibility.find({
    companyId: company.id, // Use string ID, not ObjectId
    designationId: normalizedDesignation,
    gender: genderFilter,
    status: 'active'
  })
    .lean()
  
  console.log(`[getEmployeeEligibilityFromDesignation] Found ${subcategoryEligibilities.length} subcategory eligibility rules`)
  
  // CRITICAL MIGRATION: Subcategory eligibility is the SINGLE source of truth
  // NO category-based fallback allowed
  if (subcategoryEligibilities.length === 0) {
    console.log(`[getEmployeeEligibilityFromDesignation] ⚠️ NO SUBCATEGORY ELIGIBILITY FOUND`)
    console.log(`[getEmployeeEligibilityFromDesignation] Returning empty eligibility (no category-based fallback)`)
    console.log(`[getEmployeeEligibilityFromDesignation] This is intentional - subcategory eligibility is required`)
    
    // Return empty eligibility - no fallback to category-based or employee-level
    // This ensures that eligibility MUST be configured at subcategory level
    return {
      eligibility: {},
      cycleDurations: {},
      shirt: 0,
      pant: 0,
      shoe: 0,
      jacket: 0
    }
    }
    
  // Process subcategory-based eligibility
  {
    // Aggregate subcategory eligibility by parent category
    const eligibility: Record<string, number> = {}
    const cycleDurations: Record<string, number> = {}
    let legacyEligibility = { shirt: 0, pant: 0, shoe: 0, jacket: 0 }
    
    // Get all subcategories with their parent categories
    // CRITICAL FIX: subCategoryId in eligibility records is a STRING ID (e.g., "600001"), not ObjectId
    const subcategoryIds = subcategoryEligibilities
      .map(e => e.subCategoryId)
      .filter(Boolean)
      .map((s: any) => {
        // subCategoryId is already a string ID, not ObjectId
        return String(s)
      })
    
    // CRITICAL FIX: Query subcategories by string id field, not _id
    // Also use company.id (string ID) instead of company._id (ObjectId)
    const subcategories = await Subcategory.find({
      id: { $in: subcategoryIds }, // Query by string id field
      companyId: company.id, // Use string ID, not ObjectId
      status: 'active'
    })
      .lean()
    
    // CRITICAL FIX: Fetch parent categories manually since parentCategoryId is also a string ID
    const uniqueParentCategoryIds = [...new Set(subcategories.map((s: any) => s.parentCategoryId).filter(Boolean))]
    const parentCategories = await Category.find({ id: { $in: uniqueParentCategoryIds } })
      .select('id name')
      .lean()
    const parentCategoryMap = new Map(parentCategories.map((c: any) => [c.id, c]))
    
    // Attach parent categories to subcategories
    // Keep original parentCategoryId (string ID) and add parentCategory object
    const subcategoriesWithParents = subcategories.map((sub: any) => ({
      ...sub,
      parentCategory: parentCategoryMap.get(sub.parentCategoryId) || null
    }))
    
    // Create map: subcategory id (string) -> subcategory data
    const subcategoryMap = new Map()
    for (const subcat of subcategoriesWithParents) {
      const subcatId = (subcat as any).id // Use string id field
      subcategoryMap.set(subcatId, subcat)
    }
    
    // Aggregate eligibility by parent category
    for (const elig of subcategoryEligibilities) {
      // subCategoryId is a string ID, not ObjectId
      const subcatId = String(elig.subCategoryId || '')
      if (!subcatId) continue
      
      const subcat = subcategoryMap.get(subcatId)
      if (!subcat || !subcat.parentCategory) continue
      
      const parentCategory = subcat.parentCategory
      const categoryName = parentCategory.name?.toLowerCase() || ''
      if (!categoryName) continue
      
      const quantity = elig.quantity || 0
      const renewalFrequency = elig.renewalFrequency || 6
      const renewalUnit = elig.renewalUnit || 'months'
      const cycleMonths = renewalUnit === 'years' ? renewalFrequency * 12 : renewalFrequency
      
      // Aggregate quantities for same category
      if (!eligibility[categoryName]) {
        eligibility[categoryName] = 0
        cycleDurations[categoryName] = cycleMonths
      }
      eligibility[categoryName] += quantity
      
      // Use the longest cycle duration for the category
      if (cycleMonths > cycleDurations[categoryName]) {
        cycleDurations[categoryName] = cycleMonths
      }
        
      // Update legacy eligibility
      const normalizedCategory = normalizeCategoryName(categoryName)
      if (normalizedCategory === 'shirt' || categoryName === 'shirt') {
        legacyEligibility.shirt += quantity
      } else if (normalizedCategory === 'pant' || categoryName === 'pant' || categoryName === 'trouser') {
        legacyEligibility.pant += quantity
      } else if (normalizedCategory === 'shoe' || categoryName === 'shoe') {
        legacyEligibility.shoe += quantity
      } else if (normalizedCategory === 'jacket' || categoryName === 'jacket' || categoryName === 'blazer') {
        legacyEligibility.jacket += quantity
        }
    }
    
    console.log(`[getEmployeeEligibilityFromDesignation] Aggregated eligibility:`, {
      eligibility,
      legacyEligibility
    })
    
    return {
      eligibility,
      cycleDurations,
      ...legacyEligibility
    }
  }

  // CRITICAL MIGRATION: No fallback to employee-level eligibility
  // Subcategory eligibility is the ONLY source of truth
  // If no subcategory eligibility exists, return empty (already handled above)
  // This code should never be reached, but included for safety
  console.warn(`[getEmployeeEligibilityFromDesignation] ⚠️ Unexpected code path - returning empty eligibility`)
  return {
    eligibility: {},
    cycleDurations: {},
    shirt: 0,
    pant: 0,
    shoe: 0,
    jacket: 0
  }
}

export async function getConsumedEligibility(employeeId: string): Promise<{
  consumed: Record<string, number> // Dynamic category consumption: { "shirt": 1, "pant": 2, "custom-category": 0, ... }
  // Legacy fields for backward compatibility
  shirt: number
  pant: number
  shoe: number
  jacket: number
}> {
  await connectDB()
  
  // Use employeeId field instead of id field
  let employee = await Employee.findOne({ employeeId: employeeId })
  if (!employee) {
    // Fallback: try by id field for backward compatibility
    employee = await Employee.findOne({ id: employeeId })
  }
  if (!employee) {
    return { consumed: {}, shirt: 0, pant: 0, shoe: 0, jacket: 0 }
  }

  // Get company using safe helper
  const company = await getCompanyByIdSafe(employee.companyId)
  if (!company) {
    return { consumed: {}, shirt: 0, pant: 0, shoe: 0, jacket: 0 }
  }

  // Ensure system categories exist
  await ensureSystemCategories(company.id)

  // Get all categories for this company
  const categories = await getCategoriesByCompany(company.id)
  const categoryMap = new Map<string, any>()
  categories.forEach(cat => {
    categoryMap.set(cat.name.toLowerCase(), cat)
    categoryMap.set(normalizeCategoryName(cat.name), cat)
  })

  // Get employee's date of joining (default to Oct 1, 2025 if not set)
  const dateOfJoining = employee.dateOfJoining 
    ? new Date(employee.dateOfJoining) 
    : new Date('2025-10-01T00:00:00.000Z')

  // Get cycle durations from designation rules (or fallback to employee-level)
  const { cycleDurations } = await getEmployeeEligibilityFromDesignation(employeeId)

  // Get all orders that count towards consumed eligibility (all except cancelled)
  // We'll filter by item-specific cycles below
  const orders = await Order.find({
    employeeId: employee._id,
    status: { $in: ['Awaiting approval', 'Awaiting fulfilment', 'Dispatched', 'Delivered'] }
  })
    .populate('items.uniformId', 'id category categoryId')
    .lean()

  // Initialize consumed eligibility for all categories
  const consumed: Record<string, number> = {}
  categories.forEach(cat => {
    consumed[cat.name.toLowerCase()] = 0
  })
  
  // Legacy consumed for backward compatibility
  const legacyConsumed = { shirt: 0, pant: 0, shoe: 0, jacket: 0 }

  // Get eligibility reset dates for this employee (if any)
  const resetDates = employee.eligibilityResetDates || {}

  // Sum up quantities by category from orders in their respective current cycles
  for (const order of orders) {
    const orderDate = order.orderDate ? new Date(order.orderDate) : null
    if (!orderDate) {
      continue
    }

    for (const item of order.items || []) {
      const uniform = item.uniformId
      if (!uniform || typeof uniform !== 'object') {
        continue
      }

      // Get category name (handle both old and new formats)
      let categoryName: string | null = null
      
      // Try new format first (categoryId)
      if ('categoryId' in uniform && uniform.categoryId) {
        const categoryId = uniform.categoryId.toString()
        const category = await getCategoryByIdOrName(company.id, categoryId)
        if (category) {
          categoryName = category.name.toLowerCase()
        }
      }
      
      // Fallback to old format (category string)
      if (!categoryName && 'category' in uniform && uniform.category) {
        categoryName = normalizeCategoryName(uniform.category as string)
        // Try to find matching category
        const category = await getCategoryByIdOrName(company.id, categoryName)
        if (category) {
          categoryName = category.name.toLowerCase()
        }
      }

      if (!categoryName) {
        continue
      }

      const quantity = item.quantity || 0
      
      // Check if order date is after the reset date for this category (if reset date exists)
      const resetDate = resetDates[categoryName as keyof typeof resetDates]
      if (resetDate && orderDate < new Date(resetDate)) {
        // Order is before reset date, skip it
        continue
      }
      
      // Get cycle duration for this category
      const cycleDuration = cycleDurations[categoryName] || cycleDurations[normalizeCategoryName(categoryName)] || 6
      
      // Check if order date is in current cycle for this specific item type
      const inCurrentCycle = isDateInCurrentCycle(orderDate, categoryName, dateOfJoining, cycleDuration)
      
      if (inCurrentCycle) {
        // Add to consumed eligibility
        if (!consumed[categoryName]) {
          consumed[categoryName] = 0
        }
        consumed[categoryName] += quantity
        
        // Update legacy consumed for backward compatibility
        if (categoryName === 'shirt') {
          legacyConsumed.shirt += quantity
        } else if (categoryName === 'pant' || categoryName === 'trouser') {
          legacyConsumed.pant += quantity
        } else if (categoryName === 'shoe') {
          legacyConsumed.shoe += quantity
        } else if (categoryName === 'jacket' || categoryName === 'blazer') {
          legacyConsumed.jacket += quantity
        }
      }
    }
  }

  return {
    consumed,
    ...legacyConsumed
  }
}

/**
 * Reusable eligibility validation function
 * Validates if order items would exceed employee eligibility limits
 * Used by both single order creation and bulk uploads
 * Now works with dynamic categories
 * 
 * @param employeeId Employee ID (6-digit numeric string)
 * @param orderItems Array of order items with category and quantity
 * @returns Validation result with success status and error details
 */
export async function validateEmployeeEligibility(
  employeeId: string,
  orderItems: Array<{
    uniformId: string
    uniformName: string
    category: string // Now accepts any category string (dynamic)
    quantity: number
  }>
): Promise<{
  valid: boolean
  errors: Array<{ item: string, category: string, error: string }>
  remainingEligibility: Record<string, number> // Dynamic: { "shirt": 2, "pant": 1, "custom-category": 0, ... }
  // Legacy fields for backward compatibility
  legacyRemainingEligibility?: { shirt: number, pant: number, shoe: number, jacket: number }
}> {
  await connectDB()
  
  // Find employee
  let employee = await Employee.findOne({ employeeId: employeeId })
  if (!employee) {
    employee = await Employee.findOne({ id: employeeId })
  }
  if (!employee) {
    return {
      valid: false,
      errors: [{ item: 'Employee', category: 'general', error: `Employee not found: ${employeeId}` }],
      remainingEligibility: {},
      legacyRemainingEligibility: { shirt: 0, pant: 0, shoe: 0, jacket: 0 }
    }
  }
  
  // Get company
  // Get company using safe helper
  const company = await getCompanyByIdSafe(employee.companyId)
  if (!company) {
    return {
      valid: false,
      errors: [{ item: 'Employee', category: 'general', error: `Company not found for employee: ${employeeId}` }],
      remainingEligibility: {},
      legacyRemainingEligibility: { shirt: 0, pant: 0, shoe: 0, jacket: 0 }
    }
  }

  // Ensure system categories exist
  await ensureSystemCategories(company.id)

  // Get all categories for this company
  const categories = await getCategoriesByCompany(company.id)
  const categoryMap = new Map<string, any>()
  categories.forEach(cat => {
    categoryMap.set(cat.name.toLowerCase(), cat)
    categoryMap.set(normalizeCategoryName(cat.name), cat)
  })
  
  // Get employee eligibility (from designation rules or employee-level)
  // Function now returns: { eligibility: Record<string, number>, cycleDurations, shirt, pant, shoe, jacket }
  const eligibilityData = await getEmployeeEligibilityFromDesignation(employeeId)
  
  // Get consumed eligibility
  const consumedData = await getConsumedEligibility(employeeId)
  
  // Calculate remaining eligibility dynamically
  const remainingEligibility: Record<string, number> = {}
  const legacyRemainingEligibility = {
    shirt: Math.max(0, (eligibilityData.shirt || 0) - (consumedData.shirt || 0)),
    pant: Math.max(0, (eligibilityData.pant || 0) - (consumedData.pant || 0)),
    shoe: Math.max(0, (eligibilityData.shoe || 0) - (consumedData.shoe || 0)),
    jacket: Math.max(0, (eligibilityData.jacket || 0) - (consumedData.jacket || 0))
  }
  
  // Build dynamic remaining eligibility for all categories
  for (const category of categories) {
    const categoryKey = category.name.toLowerCase()
    const totalElig = eligibilityData.eligibility[categoryKey] || 0
    const consumed = consumedData.consumed[categoryKey] || 0
    remainingEligibility[categoryKey] = Math.max(0, totalElig - consumed)
  }
  
  // Validate each order item
  const errors: Array<{ item: string, category: string, error: string }> = []
  const categoryQuantities: Record<string, number> = {}
  
  // Initialize category quantities
  categories.forEach(cat => {
    categoryQuantities[cat.name.toLowerCase()] = 0
  })
  
  // Sum quantities by category from order items
  for (const item of orderItems) {
    const category = normalizeCategoryName(item.category)
    
    // Find matching category
    let categoryKey = category
    for (const [key, cat] of categoryMap.entries()) {
      if (normalizeCategoryName(key) === category || key === category) {
        categoryKey = cat.name.toLowerCase()
        break
      }
    }
    
    if (!categoryQuantities[categoryKey]) {
      categoryQuantities[categoryKey] = 0
    }
    categoryQuantities[categoryKey] += item.quantity || 0
  }
  
  // Check if quantities exceed remaining eligibility for each category
  for (const [categoryKey, requestedQty] of Object.entries(categoryQuantities)) {
    const available = remainingEligibility[categoryKey] || 0
    if (requestedQty > available) {
      const item = orderItems.find(i => {
        const itemCategory = normalizeCategoryName(i.category)
        return itemCategory === categoryKey || itemCategory === normalizeCategoryName(categoryKey)
      })
      
      errors.push({
        item: item?.uniformName || categoryKey,
        category: categoryKey,
        error: `Exceeds eligibility: Requested ${requestedQty}, Available ${available}`
      })
    }
  }
  
  // Also check legacy categories for backward compatibility
  const legacyCategories = ['shirt', 'pant', 'shoe', 'jacket']
  for (const legacyCat of legacyCategories) {
    const requestedQty = categoryQuantities[legacyCat] || 0
    const available = legacyRemainingEligibility[legacyCat as keyof typeof legacyRemainingEligibility]
    if (requestedQty > available) {
      const item = orderItems.find(i => normalizeCategoryName(i.category) === legacyCat)
      if (!errors.some(e => e.category === legacyCat)) {
        errors.push({
          item: item?.uniformName || legacyCat,
          category: legacyCat,
          error: `Exceeds eligibility: Requested ${requestedQty}, Available ${available}`
        })
      }
    }
  }
  
  return {
    valid: errors.length === 0,
    errors,
    remainingEligibility,
    legacyRemainingEligibility
  }
}

/**
 * Validate bulk order item using subcategory-based eligibility
 * 
 * This function validates that:
 * 1. Employee exists and is active
 * 2. Employee has a designation
 * 3. Designation has subcategory eligibility
 * 4. Product is mapped to an eligible subcategory for the company
 * 5. Quantity doesn't exceed subcategory eligibility limits
 */
export async function validateBulkOrderItemSubcategoryEligibility(
  employeeId: string,
  productId: string,
  quantity: number,
  companyId: string
): Promise<{
  valid: boolean
  error?: string
  eligibleQuantity?: number
  subcategoryName?: string
}> {
  await connectDB()

  // Find employee
  let employee = await Employee.findOne({ employeeId: employeeId })
  if (!employee) {
    employee = await Employee.findOne({ id: employeeId })
  }
  if (!employee) {
    return { valid: false, error: `Employee not found: ${employeeId}` }
  }

  // Check employee is active
  if (employee.status !== 'active') {
    return { valid: false, error: `Employee ${employeeId} is not active` }
  }

  // Get company
  // CRITICAL FIX: companyId is a STRING ID (6-digit), not ObjectId
  let company = await Company.findOne({ id: String(companyId) })
  if (!company && typeof companyId === 'string' && mongoose.Types.ObjectId.isValid(companyId) && /^[0-9a-fA-F]{24}$/.test(companyId)) {
    // Only try ObjectId if it's a valid 24-char hex string (not a 6-digit string ID)
    company = await Company.findOne({ id: String(companyId) })
  }
  if (!company) {
    return { valid: false, error: `Company not found: ${companyId}` }
  }

  // Verify employee belongs to company
  if (employee.companyId.toString() !== company._id.toString()) {
    return { valid: false, error: `Employee ${employeeId} does not belong to company ${companyId}` }
  }

  // Get employee designation (decrypt if needed)
  let designation = employee.designation
  if (designation && typeof designation === 'string' && designation.includes(':')) {
    try {
      const { decrypt } = await import('@/lib/utils/encryption')
      designation = decrypt(designation)
    } catch (error) {
      // Keep original if decryption fails
    }
  }

  if (!designation || designation.trim().length === 0) {
    return { valid: false, error: `Employee ${employeeId} has no designation assigned` }
  }

  const normalizedDesignation = designation.trim()
  const employeeGender = employee.gender || 'unisex'
  const genderFilter = employeeGender === 'unisex' ? { $in: ['male', 'female', 'unisex'] } : employeeGender

  // Check for subcategory-based eligibility
  const subcategoryEligibilities = await DesignationSubcategoryEligibility.find({
    companyId: company._id,
    designationId: normalizedDesignation,
    gender: genderFilter,
    status: 'active'
  })
    .populate('subCategoryId', 'id name')
    .lean()

  if (subcategoryEligibilities.length === 0) {
    return { valid: false, error: `No eligibility defined for designation "${normalizedDesignation}". Employee cannot order any products.` }
  }

  // Get eligible subcategory IDs
  const eligibleSubcategoryIds = subcategoryEligibilities
    .map(e => e.subCategoryId?._id?.toString() || e.subCategoryId?.toString())
    .filter(Boolean)

  if (eligibleSubcategoryIds.length === 0) {
    return { valid: false, error: `No valid subcategories found for designation "${normalizedDesignation}"` }
  }

  // Find product by string ID
  const productIdStr = String(productId)
  const productCheck = await Uniform.findOne({ id: productIdStr }).select('id name').lean()

  if (!productCheck) {
    return { valid: false, error: `Invalid product ID: ${productId}` }
  }

  // Check if product is mapped to any eligible subcategory - use string IDs
  const productMappings = await ProductSubcategoryMapping.find({
    productId: productIdStr,
    subCategoryId: { $in: eligibleSubcategoryIds },
    companyId: company.id
  })
    .populate('subCategoryId', 'id name')
    .lean()

  if (productMappings.length === 0) {
    // Try to get product name for better error message
    let productName = productCheck.name || productCheck.id || productId
    try {
      const product = await Uniform.findOne({ id: productIdStr }).select('name id').lean()
      if (product) {
        productName = product.name || product.id || productId
      }
    } catch (error) {
      // Use productId if lookup fails
    }
    return { valid: false, error: `Product "${productName}" is not mapped to any eligible subcategory for designation "${normalizedDesignation}"` }
  }

  // Find the matching eligibility rule for the subcategory
  let maxAllowedQuantity = 0
  let matchingSubcategoryName = ''

  for (const mapping of productMappings) {
    const subcategoryId = mapping.subCategoryId?._id?.toString() || mapping.subCategoryId?.toString()
    const eligibility = subcategoryEligibilities.find(
      e => (e.subCategoryId?._id?.toString() || e.subCategoryId?.toString()) === subcategoryId
    )

    if (eligibility) {
      const eligibleQty = eligibility.quantity || 0
      if (eligibleQty > maxAllowedQuantity) {
        maxAllowedQuantity = eligibleQty
        matchingSubcategoryName = mapping.subCategoryId?.name || 'Unknown'
      }
    }
  }

  if (maxAllowedQuantity === 0) {
    return { valid: false, error: `No quantity allowed for product ${productId} under designation "${normalizedDesignation}"` }
  }

  // Check consumed eligibility (simplified - just check if quantity exceeds allowed)
  // Note: This is a simplified check. For full cycle-based validation, we'd need to check consumed eligibility
  if (quantity > maxAllowedQuantity) {
    return {
      valid: false,
      error: `Quantity ${quantity} exceeds allowed quantity ${maxAllowedQuantity} for subcategory "${matchingSubcategoryName}"`,
      eligibleQuantity: maxAllowedQuantity,
      subcategoryName: matchingSubcategoryName
    }
  }

  return {
    valid: true,
    eligibleQuantity: maxAllowedQuantity,
    subcategoryName: matchingSubcategoryName
  }
}

export async function createOrder(orderData: {
  employeeId: string
  items: Array<{
    uniformId: string
    uniformName: string
    size: string
    quantity: number
    price: number
  }>
  deliveryAddress: string
  estimatedDeliveryTime: string
  dispatchLocation?: string
  isPersonalPayment?: boolean
  personalPaymentAmount?: number
  usePersonalAddress?: boolean // Flag: true if using personal address, false if using official location (default: false)
}): Promise<any> {
  try {
    await connectDB()
  } catch (dbError: any) {
    console.error(`[createOrder] ❌ Database connection failed:`, dbError.message)
    throw new Error(`Database connection failed: ${dbError.message}`)
  }
  
  // CRITICAL: Wrap entire function in try-catch to ensure all errors are properly caught and logged
  try {
    console.log(`[createOrder] ========== STARTING ORDER CREATION ==========`)
    console.log(`[createOrder] Order data:`, {
      employeeId: orderData.employeeId,
      itemsCount: orderData.items?.length || 0,
      usePersonalAddress: orderData.usePersonalAddress
    })
  
    // Find employee and company - use employeeId field first
    console.log(`[createOrder] Looking for employee with employeeId=${orderData.employeeId} (type: ${typeof orderData.employeeId})`)
  
  // Use employeeId field first (primary lookup)
  let employee = await Employee.findOne({ employeeId: orderData.employeeId })
  
  // If not found by employeeId, try by id field (fallback for backward compatibility)
  if (!employee) {
    console.log(`[createOrder] Employee not found by employeeId, trying id field`)
    employee = await Employee.findOne({ id: orderData.employeeId })
  }
  
  // If still not found, try by _id (ObjectId)
  if (!employee && mongoose.Types.ObjectId.isValid(orderData.employeeId)) {
    console.log(`[createOrder] Employee not found by employeeId or id, trying _id lookup`)
    employee = await Employee.findById(orderData.employeeId)
  }
  
  if (!employee) {
    console.error(`[createOrder] ❌ Employee not found with any ID format: ${orderData.employeeId}`)
    // List available employees for debugging
    const sampleEmployees = await Employee.find({}, 'id employeeId email firstName lastName').limit(5).lean()
    console.error(`[createOrder] Available employees (sample):`, sampleEmployees.map((e: any) => `id=${e.id}, employeeId=${e.employeeId}, email=${e.email}`))
    throw new Error(`Employee not found: ${orderData.employeeId}. Please ensure you are logged in with a valid employee account.`)
  }
  
  console.log(`[createOrder] ✓ Found employee: id=${employee.id}, employeeId=${employee.employeeId}, email=${employee.email}`)
  console.log(`[createOrder] Employee companyId type=${typeof employee.companyId}, value=${employee.companyId}`)
  console.log(`[createOrder] Employee companyId isObject=${typeof employee.companyId === 'object'}, isNull=${employee.companyId === null}`)
  
  // CRITICAL FIX: Decrypt address fields if they're encrypted
  // Since we use .lean() or direct Mongoose queries, post hooks don't run, so we must manually decrypt
  const { decrypt } = require('../utils/encryption')
  const addressFields = ['address_line_1', 'address_line_2', 'address_line_3', 'city', 'state', 'pincode']
  for (const field of addressFields) {
    if (employee[field] && typeof employee[field] === 'string' && employee[field].includes(':')) {
      try {
        employee[field] = decrypt(employee[field])
        console.log(`[createOrder] Decrypted address field ${field}`)
      } catch (error) {
        console.warn(`[createOrder] Failed to decrypt address field ${field} for employee ${employee.id || employee.employeeId}:`, error)
      }
    }
  }
  
  console.log(`[createOrder] Employee locationId:`, {
    hasLocationId: !!employee.locationId,
    locationId: employee.locationId,
    locationIdType: typeof employee.locationId,
    isObjectId: employee.locationId instanceof mongoose.Types.ObjectId,
    isValidObjectId: employee.locationId ? mongoose.Types.ObjectId.isValid(employee.locationId) : false
  })
  console.log(`[createOrder] Employee address fields (after decryption):`, {
    hasAddressLine1: !!employee.address_line_1,
    address_line_1: employee.address_line_1,
    hasPincode: !!employee.pincode,
    pincode: employee.pincode,
    city: employee.city,
    state: employee.state
  })

  // Use raw MongoDB collection to reliably get the employee's companyId ObjectId
  // This is necessary because Mongoose populate might fail or return inconsistent data
  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  // Get raw employee document to ensure we have the actual companyId
  // Try multiple lookup methods using string ID only
  let rawEmployee = await db.collection('employees').findOne({ employeeId: orderData.employeeId })
  
  if (!rawEmployee) {
    rawEmployee = await db.collection('employees').findOne({ id: orderData.employeeId })
  }
  
  if (!rawEmployee) {
    console.error(`[createOrder] ❌ Raw employee document not found for any ID format: ${orderData.employeeId}`)
    throw new Error(`Employee not found: ${orderData.employeeId}. Please ensure you are logged in with a valid employee account.`)
  }

  console.log(`[createOrder] Raw employee companyId:`, rawEmployee.companyId, 'Type:', typeof rawEmployee.companyId)
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // If companyId is stored as ObjectId in DB, we need to convert it to string ID first
  let companyIdString: string | null = null
  
  if (rawEmployee.companyId) {
    const companyIdValue = rawEmployee.companyId.toString()
    
    // Check if it's already a string ID (6-digit numeric)
    if (/^\d{6}$/.test(companyIdValue)) {
      // It's already a string ID - use it directly
      companyIdString = companyIdValue
      console.log(`[createOrder] ✓ companyId is a string ID: ${companyIdString}`)
    } else {
      // Try to find company by the companyId value (might be stored differently)
      console.log(`[createOrder] ⚠️ companyId format not recognized, trying company lookup...`)
      const companyDoc = await Company.findOne({ id: companyIdValue }).select('id').lean()
      
      if (companyDoc && companyDoc.id) {
        companyIdString = companyDoc.id
        console.log(`[createOrder] ✓ Found company by ID: ${companyIdString}`)
      } else {
        // Invalid format
        console.error(`[createOrder] ❌ Invalid companyId format: ${companyIdValue}`)
        throw new Error(`Employee's companyId has invalid format: ${companyIdValue}. Expected 6-digit numeric string ID.`)
      }
    }
  } else {
    console.error(`[createOrder] ❌ Raw employee document has no companyId`)
    throw new Error(`Employee ${orderData.employeeId} has no companyId. Please ensure the employee is linked to a valid company.`)
  }
  
  if (!companyIdString) {
    throw new Error(`Failed to extract company string ID for employee ${orderData.employeeId}`)
  }
  
  // ENFORCEMENT: Check if employee order is enabled (only for regular employees, not admins)
  // Get employee email to check admin status
  // Note: decrypt is already imported above for address decryption
  let employeeEmail: string | null = null
  if (employee.email) {
    try {
      if (typeof employee.email === 'string' && employee.email.includes(':')) {
        employeeEmail = decrypt(employee.email)
      } else {
        employeeEmail = employee.email
      }
    } catch (error) {
      console.warn('[createOrder] Failed to decrypt employee email for enforcement check')
    }
  }
  
  // If we have employee email and company ID, check enforcement
  if (employeeEmail && companyIdString) {
    const isAdmin = await isCompanyAdmin(employeeEmail, companyIdString)
    const location = await getLocationByAdminEmail(employeeEmail)
    
    // If not an admin, check if employee order is enabled
    if (!isAdmin && !location) {
      // ARCHITECTURAL DECISION: Use ONLY string ID, NO ObjectId fallbacks
      const company = await Company.findOne({ id: companyIdString }).select('enableEmployeeOrder').lean()
      if (!company) {
        throw new Error(`Company not found with string ID: ${companyIdString}. Please ensure the employee is linked to a valid company.`)
      }
      if (company.enableEmployeeOrder === false) {
        throw new Error('Employee orders are currently disabled for your company. Please contact your administrator.')
      }
    }
  }
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // If company lookup fails with string ID, we need to fix the data, not add fallbacks
  if (!companyIdString || !/^\d{6}$/.test(companyIdString)) {
    console.error(`[createOrder] ❌ Invalid companyIdString: ${companyIdString || 'null'}`)
    throw new Error(`Employee ${orderData.employeeId} has invalid companyId. Expected 6-digit numeric string ID, got: ${companyIdString || 'null'}`)
  }
  
  console.log(`[createOrder] Looking for company by string ID: ${companyIdString}`)
  
  // Use ONLY string ID lookup - NO ObjectId fallbacks
  let company = await Company.findOne({ id: companyIdString })
    .select('id name enable_pr_po_workflow enable_site_admin_pr_approval require_company_admin_po_approval allow_multi_pr_po allowPersonalAddressDelivery')
    .lean()
  
  if (company) {
    console.log(`[createOrder] ✓ Found company by string ID: id=${company.id}, name=${company.name}`)
  } else {
    // If not found by Mongoose, try raw MongoDB collection as last resort (still using string ID)
    console.warn(`[createOrder] Company not found by Mongoose, trying raw MongoDB collection lookup by string ID`)
    
    if (db) {
      const companyDoc = await db.collection('companies').findOne({ id: companyIdString })
      if (companyDoc) {
        console.log(`[createOrder] ✓ Found company in raw collection by string ID: id=${companyDoc.id}, name=${companyDoc.name}`)
        // Now find by string ID using Mongoose
        company = await Company.findOne({ id: companyDoc.id })
          .select('id name enable_pr_po_workflow enable_site_admin_pr_approval require_company_admin_po_approval allow_multi_pr_po allowPersonalAddressDelivery')
          .lean()
      }
    }
    
    if (!company) {
      console.error(`[createOrder] ❌ Company not found with string ID: ${companyIdString}`)
      // List available companies for debugging
      const allCompaniesList = await Company.find({}, 'id name').limit(10).lean()
      console.error(`[createOrder] Available companies (sample):`, allCompaniesList.map((c: any) => `id=${c.id}, name=${c.name}`))
      throw new Error(`Company not found with string ID: ${companyIdString}. Please ensure the employee's companyId references a valid company with id="${companyIdString}".`)
    }
  }
  
  console.log(`[createOrder] ✓ Found company: id=${company.id}, name=${company.name}`)
  console.log(`[createOrder] Company workflow flags:`)
  console.log(`[createOrder]   enable_pr_po_workflow: ${company.enable_pr_po_workflow} (type: ${typeof company.enable_pr_po_workflow})`)
  console.log(`[createOrder]   enable_site_admin_pr_approval: ${company.enable_site_admin_pr_approval} (type: ${typeof company.enable_site_admin_pr_approval})`)
  console.log(`[createOrder]   require_company_admin_po_approval: ${company.require_company_admin_po_approval} (type: ${typeof company.require_company_admin_po_approval})`)

  // ========== DELIVERY LOCATION VALIDATION & SHIPPING ADDRESS EXTRACTION ==========
  // Enforce company-level delivery location rules based on allowPersonalAddressDelivery
  const allowPersonalAddressDelivery = company.allowPersonalAddressDelivery ?? false // Default: false for backward compatibility
  
  // Structured shipping address fields (required by Order model)
  let shippingAddress: {
    shipping_address_line_1: string
    shipping_address_line_2?: string
    shipping_address_line_3?: string
    shipping_city: string
    shipping_state: string
    shipping_pincode: string
    shipping_country: string
  }
  
  let deliveryAddressToUse: string // For backward compatibility/display
  
  // Helper function to extract structured address from employee
  const extractEmployeeAddress = (emp: any) => {
    // CRITICAL: Validate pincode - must be present and exactly 6 digits
    const validatePincode = (pincode: any, context: string): string => {
      if (!pincode || pincode === '') {
        throw new Error(`Employee pincode is missing. Please ensure the employee has a valid pincode in their address.`)
      }
      const pincodeStr = String(pincode).trim()
      // Validate it's 6 digits
      if (!/^\d{6}$/.test(pincodeStr)) {
        throw new Error(`Invalid employee pincode format: ${pincode}. Pincode must be exactly 6 digits (e.g., "110001").`)
      }
      return pincodeStr
    }
    
    console.log(`[createOrder] [extractEmployeeAddress] Employee address fields:`, {
      hasAddressLine1: !!emp.address_line_1,
      address_line_1: emp.address_line_1,
      hasPincode: !!emp.pincode,
      pincode: emp.pincode,
      hasLegacyAddress: !!emp.address,
      legacyAddress: emp.address ? emp.address.substring(0, 50) + '...' : null
    })
    
    if (emp.address_line_1) {
      // Employee has structured address
      console.log(`[createOrder] [extractEmployeeAddress] Using structured address fields`)
      if (!emp.pincode) {
        throw new Error(`Employee has structured address but pincode is missing. Please ensure the employee has a valid 6-digit pincode in their address.`)
      }
      return {
        shipping_address_line_1: emp.address_line_1 || '',
        shipping_address_line_2: emp.address_line_2 || '',
        shipping_address_line_3: emp.address_line_3 || '',
        shipping_city: emp.city || 'New Delhi',
        shipping_state: emp.state || 'Delhi',
        shipping_pincode: validatePincode(emp.pincode, 'employee'),
        shipping_country: emp.country || 'India',
      }
    } else if (emp.address && typeof emp.address === 'string') {
      // Legacy address string - but we still need pincode
      console.log(`[createOrder] [extractEmployeeAddress] Using legacy address string, but checking for pincode`)
      if (!emp.pincode) {
        throw new Error(`Employee has legacy address format but pincode is missing. Please update the employee's address to include a valid 6-digit pincode.`)
      }
      return {
        shipping_address_line_1: emp.address.substring(0, 255) || 'Address not available',
        shipping_address_line_2: '',
        shipping_address_line_3: '',
        shipping_city: emp.city || 'New Delhi',
        shipping_state: emp.state || 'Delhi',
        shipping_pincode: validatePincode(emp.pincode, 'employee'),
        shipping_country: 'India',
      }
    } else {
      // No address - throw error instead of using defaults
      console.error(`[createOrder] [extractEmployeeAddress] ❌ Employee has no address information`)
      console.error(`[createOrder] [extractEmployeeAddress] Employee data:`, {
        id: emp.id,
        employeeId: emp.employeeId,
        hasAddressLine1: !!emp.address_line_1,
        hasLegacyAddress: !!emp.address,
        hasPincode: !!emp.pincode
      })
      throw new Error(`Employee has no address information. Please ensure the employee has a complete address including pincode.`)
    }
  }
  
  // Helper function to extract structured address from location
  const extractLocationAddress = (loc: any) => {
    // CRITICAL: Validate pincode - must be present and exactly 6 digits
    const validatePincode = (pincode: any, context: string): string => {
      if (!pincode || pincode === '') {
        throw new Error(`Location pincode is missing. Please ensure the location "${loc.name || 'Unknown'}" has a valid pincode in its address.`)
      }
      const pincodeStr = String(pincode).trim()
      // Validate it's 6 digits
      if (!/^\d{6}$/.test(pincodeStr)) {
        throw new Error(`Invalid location pincode format: ${pincode}. Pincode must be exactly 6 digits (e.g., "110001"). Location: ${loc.name || 'Unknown'}`)
      }
      return pincodeStr
    }
    
    if (loc.address_line_1) {
      // Location has structured address
      return {
        shipping_address_line_1: loc.address_line_1 || '',
        shipping_address_line_2: loc.address_line_2 || '',
        shipping_address_line_3: loc.address_line_3 || '',
        shipping_city: loc.city || 'New Delhi',
        shipping_state: loc.state || 'Delhi',
        shipping_pincode: validatePincode(loc.pincode, 'location'),
        shipping_country: loc.country || 'India',
      }
    } else {
      // Location missing structured address - throw error instead of using defaults
      throw new Error(`Location "${loc.name || 'Unknown'}" has no address information. Please ensure the location has a complete address including pincode.`)
    }
  }
  
  // If company does NOT allow personal address delivery
  if (!allowPersonalAddressDelivery) {
    // Personal address must NOT be selectable - enforce official location delivery only
    if (orderData.usePersonalAddress === true) {
      throw new Error('Personal address delivery is not allowed for this company. Orders must be delivered to the official location.')
    }
    
    // Get employee's official location address
    if (!employee.locationId) {
      // For backward compatibility: if employee has no locationId, use their personal address as fallback
      console.warn(`[createOrder] Employee ${orderData.employeeId} has no locationId. Using personal address as fallback.`)
      console.log(`[createOrder] Employee address fields:`, {
        address_line_1: employee.address_line_1,
        address_line_2: employee.address_line_2,
        city: employee.city,
        state: employee.state,
        pincode: employee.pincode,
        address: employee.address
      })
      try {
        shippingAddress = extractEmployeeAddress(employee)
        console.log(`[createOrder] ✓ Successfully extracted employee address`)
      } catch (addressError: any) {
        console.error(`[createOrder] ❌ Failed to extract employee address:`, addressError.message)
        console.error(`[createOrder] Employee data:`, {
          id: employee.id,
          employeeId: employee.employeeId,
          hasAddressLine1: !!employee.address_line_1,
          hasPincode: !!employee.pincode,
          pincodeValue: employee.pincode
        })
        throw new Error(`Cannot use employee's personal address: ${addressError.message}. Please ensure the employee has a complete address with a valid 6-digit pincode.`)
      }
      deliveryAddressToUse = orderData.deliveryAddress || employee.address || shippingAddress?.shipping_address_line_1 || 'Address not available'
    } else {
      // Employee has locationId - fetch location and use its address
      // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
      // Convert locationId to string ID if it's an ObjectId
      let locationIdString: string | null = null
      if (typeof employee.locationId === 'string' && /^\d{6}$/.test(employee.locationId)) {
        // Already a string ID
        locationIdString = employee.locationId
      } else if (employee.locationId instanceof mongoose.Types.ObjectId || 
                 (typeof employee.locationId === 'string' && /^[0-9a-fA-F]{24}$/.test(employee.locationId))) {
        // It's a 24-char hex string (likely ObjectId format) - try to look up as id field
        console.log(`[createOrder] ⚠️ Employee locationId appears to be in ObjectId format, looking up by id field...`)
        const Location = require('../models/Location').default
        const locationDoc = await Location.findOne({ id: String(employee.locationId) }).select('id').lean()
        
        if (locationDoc && locationDoc.id) {
          locationIdString = locationDoc.id
          console.log(`[createOrder] ✓ Converted ObjectId to string ID: ${locationIdString}`)
        } else {
          throw new Error(`Employee's locationId is stored as ObjectId but location not found. This indicates a data integrity issue.`)
        }
      } else {
        throw new Error(`Employee's locationId has invalid format: ${employee.locationId}. Expected 6-digit numeric string ID.`)
      }
      
      const Location = require('../models/Location').default
      const location = await Location.findOne({ id: locationIdString })
      
      if (!location) {
        throw new Error(`Employee's assigned location not found with string ID: ${locationIdString}. Please ensure the employee has a valid location assigned.`)
      }
      
      try {
        shippingAddress = extractLocationAddress(location)
      } catch (addressError: any) {
        console.error(`[createOrder] ❌ Failed to extract location address:`, addressError.message)
        throw new Error(`Cannot use location address: ${addressError.message}. Please ensure the location "${location.name || 'Unknown'}" has a complete address with a valid 6-digit pincode.`)
      }
      
      // Build location address string for display/backward compatibility
      const locationAddressParts = [
        location.address_line_1,
        location.address_line_2,
        location.address_line_3,
        location.city,
        location.state,
        location.pincode
      ].filter(Boolean)
      
      deliveryAddressToUse = locationAddressParts.length > 0
        ? locationAddressParts.join(', ')
        : location.name || 'Location address not available'
      
      console.log(`[createOrder] Using official location address: ${deliveryAddressToUse}`)
    }
  } else {
    // Company ALLOWS personal address delivery
    if (orderData.usePersonalAddress === true) {
      // Employee explicitly chose personal address
      try {
        shippingAddress = extractEmployeeAddress(employee)
      } catch (addressError: any) {
        console.error(`[createOrder] ❌ Failed to extract employee address:`, addressError.message)
        throw new Error(`Cannot use employee's personal address: ${addressError.message}. Please ensure the employee has a complete address with a valid 6-digit pincode.`)
      }
      deliveryAddressToUse = orderData.deliveryAddress || employee.address || 'Address not available'
      console.log(`[createOrder] Using personal address (explicitly chosen): ${deliveryAddressToUse}`)
    } else {
      // Default: use official location address
      if (!employee.locationId) {
        // Fallback to personal address if no locationId
        console.warn(`[createOrder] Employee ${orderData.employeeId} has no locationId. Using personal address as default.`)
        try {
          shippingAddress = extractEmployeeAddress(employee)
        } catch (addressError: any) {
          console.error(`[createOrder] ❌ Failed to extract employee address:`, addressError.message)
          throw new Error(`Cannot use employee's personal address: ${addressError.message}. Please ensure the employee has a complete address with a valid 6-digit pincode.`)
        }
        deliveryAddressToUse = orderData.deliveryAddress || employee.address || 'Address not available'
      } else {
        // Employee has locationId - use official location address as default
        // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
        // Convert locationId to string ID if it's an ObjectId
        let locationIdString: string | null = null
        if (typeof employee.locationId === 'string' && /^\d{6}$/.test(employee.locationId)) {
          // Already a string ID
          locationIdString = employee.locationId
        } else if (employee.locationId instanceof mongoose.Types.ObjectId || 
                   (typeof employee.locationId === 'string' && /^[0-9a-fA-F]{24}$/.test(employee.locationId))) {
          // It's a 24-char hex string (likely ObjectId format) - try to look up by id field
          console.log(`[createOrder] ⚠️ Employee locationId appears to be in ObjectId format, looking up by id field...`)
          const Location = require('../models/Location').default
          const locationDoc = await Location.findOne({ id: String(employee.locationId) }).select('id').lean()
          
          if (locationDoc && locationDoc.id) {
            locationIdString = locationDoc.id
            console.log(`[createOrder] ✓ Converted ObjectId to string ID: ${locationIdString}`)
          } else {
            console.warn(`[createOrder] Employee's locationId is stored as ObjectId but location not found. Using personal address as fallback.`)
            try {
              shippingAddress = extractEmployeeAddress(employee)
            } catch (addressError: any) {
              console.error(`[createOrder] ❌ Failed to extract employee address:`, addressError.message)
              throw new Error(`Cannot use employee's personal address: ${addressError.message}. Please ensure the employee has a complete address with a valid 6-digit pincode.`)
            }
            deliveryAddressToUse = orderData.deliveryAddress || employee.address || 'Address not available'
          }
        } else {
          console.warn(`[createOrder] Employee's locationId has invalid format: ${employee.locationId}. Using personal address as fallback.`)
          try {
            shippingAddress = extractEmployeeAddress(employee)
          } catch (addressError: any) {
            console.error(`[createOrder] ❌ Failed to extract employee address:`, addressError.message)
            throw new Error(`Cannot use employee's personal address: ${addressError.message}. Please ensure the employee has a complete address with a valid 6-digit pincode.`)
          }
          deliveryAddressToUse = orderData.deliveryAddress || employee.address || 'Address not available'
        }
        
        if (locationIdString) {
          const Location = require('../models/Location').default
          const location = await Location.findOne({ id: locationIdString })
          
          if (!location) {
            // Fallback to personal address if location not found
            console.warn(`[createOrder] Employee's location not found with string ID: ${locationIdString}. Using personal address as fallback.`)
            try {
              shippingAddress = extractEmployeeAddress(employee)
            } catch (addressError: any) {
              console.error(`[createOrder] ❌ Failed to extract employee address:`, addressError.message)
              throw new Error(`Cannot use employee's personal address: ${addressError.message}. Please ensure the employee has a complete address with a valid 6-digit pincode.`)
            }
            deliveryAddressToUse = orderData.deliveryAddress || employee.address || 'Address not available'
          } else {
            try {
              shippingAddress = extractLocationAddress(location)
            } catch (addressError: any) {
              console.error(`[createOrder] ❌ Failed to extract location address:`, addressError.message)
              throw new Error(`Cannot use location address: ${addressError.message}. Please ensure the location "${location.name || 'Unknown'}" has a complete address with a valid 6-digit pincode.`)
            }
            
            // Build location address string for display
            const locationAddressParts = [
              location.address_line_1,
              location.address_line_2,
              location.address_line_3,
              location.city,
              location.state,
              location.pincode
            ].filter(Boolean)
            
            deliveryAddressToUse = locationAddressParts.length > 0
              ? locationAddressParts.join(', ')
              : location.name || 'Location address not available'
            
            console.log(`[createOrder] Using official location address (default): ${deliveryAddressToUse}`)
          }
        }
      }
    }
  }
  
  // Validate required shipping address fields
  if (!shippingAddress.shipping_address_line_1 || !shippingAddress.shipping_city || !shippingAddress.shipping_state || !shippingAddress.shipping_pincode) {
    console.error(`[createOrder] ❌ Missing required shipping address fields:`, shippingAddress)
    throw new Error('Shipping address is incomplete. Please ensure the employee or location has a complete address (L1, City, State, Pincode).')
  }
  
  // ========== END DELIVERY LOCATION VALIDATION & SHIPPING ADDRESS EXTRACTION ==========

  // Get company numeric ID for vendor lookup
  const companyStringId = company.id
  if (!companyStringId) {
    console.error(`[createOrder] Company found but has no numeric id field! Company _id: ${company._id}`)
    throw new Error(`Company found but missing numeric ID. Please ensure the company has a valid numeric ID.`)
  }
  console.log(`[createOrder] Using company ID for vendor lookup: ${companyStringId}`)

  // Group items by vendor
  // CRITICAL FIX: uniformId must be STRING ID (6-digit numeric), not ObjectId
  // OrderItemSchema validates uniformId as a 6-digit numeric string
  const itemsByVendor = new Map<string, Array<{
    uniformId: string // String ID (6-digit numeric string, e.g., "200001"), NOT ObjectId
    productId: string // Numeric/string product ID for correlation
    uniformName: string
    size: string
    quantity: number
    price: number
  }>>()

  const vendorInfoMap = new Map<string, { vendorId: string, vendorName: string, vendorObjectId: mongoose.Types.ObjectId }>()

  // Process each item and find its vendor
  for (const item of orderData.items) {
      console.log(`[createOrder] Processing order item: productId=${item.uniformId}, productName=${item.uniformName}, companyId=${companyStringId}`)
      
      // Find product by string ID only (no ObjectId fallback)
      const uniform = await Uniform.findOne({ id: item.uniformId })
      
      if (!uniform) {
        console.error(`[createOrder] Uniform not found for productId=${item.uniformId}`)
        throw new Error(`Product not found: ${item.uniformName || item.uniformId}`)
      }

      // Use price from item if provided and > 0, otherwise use product price
      const itemPrice = (item.price && item.price > 0) ? item.price : (uniform.price || 0)

    // Find all vendors for this product-company combination (multi-vendor support)
    // CRITICAL: Use uniform.id (string ID from database) instead of item.uniformId
    // This ensures we always use the correct string ID format for vendor lookup
    console.log(`[createOrder] Looking for vendors for product ${uniform.id} (${uniform.name || item.uniformName}) and company ${companyStringId}`)
    const vendors = await getVendorsForProductCompany(uniform.id, companyStringId, false)
    console.log(`[createOrder] Found ${vendors.length} vendor(s) for product ${item.uniformId}`)
    
    if (!vendors || vendors.length === 0) {
      console.error(`[createOrder] ❌ No vendor found for product ${item.uniformId} (${uniform.name || item.uniformName}) and company ${companyStringId}`)
      console.error(`[createOrder] This means either:`)
      console.error(`[createOrder]   1. Product ${item.uniformId} is not linked to company ${companyStringId} (ProductCompany relationship missing)`)
      console.error(`[createOrder]   2. Product ${item.uniformId} is not linked to any vendor (ProductVendor relationship missing)`)
      throw new Error(`No vendor found for product "${uniform.name || item.uniformName}" (${item.uniformId}). Please ensure the product is linked to your company and to at least one vendor.`)
    }

    // CRITICAL VALIDATION: Ensure only one vendor is returned
    // A product should only be linked to ONE vendor (business rule)
    if (vendors.length > 1) {
      console.error(`[createOrder] ❌ CRITICAL: Product ${item.uniformId} (${uniform.name || item.uniformName}) is linked to MULTIPLE vendors!`)
      console.error(`[createOrder] Vendors:`, vendors.map(v => `${v.vendorId} (${v.vendorName})`))
      console.error(`[createOrder] This violates the business rule: "A product can only be linked to one vendor"`)
      throw new Error(`Product "${uniform.name || item.uniformName}" is linked to multiple vendors. Please fix ProductVendor relationships in the database.`)
    }
    
    if (vendors.length === 0) {
      console.error(`[createOrder] ❌ No vendors returned for product ${item.uniformId}`)
      throw new Error(`No vendor found for product "${uniform.name || item.uniformName}" (${item.uniformId}).`)
    }
    
    // Use the single vendor (business rule: one product = one vendor)
    const vendorInfo = vendors[0]
    console.log(`[createOrder] ✅ Using vendor: ${vendorInfo.vendorId} (${vendorInfo.vendorName})`)
    console.log(`[createOrder]    Product: ${item.uniformId} (${uniform.name || item.uniformName})`)

    // CRITICAL FIX: Get vendor ObjectId from database - verify vendor exists
    const vendor = await Vendor.findOne({ id: vendorInfo.vendorId })
    if (!vendor) {
      console.error(`[createOrder] ❌ Vendor not found: ${vendorInfo.vendorId}`)
      throw new Error(`Vendor not found: ${vendorInfo.vendorId}`)
    }
    console.log(`[createOrder] ✓ Vendor found: ${vendor.id}, _id=${vendor._id}`)
    
    // CRITICAL VALIDATION: Verify vendorId matches
    if (vendor.id !== vendorInfo.vendorId) {
      console.error(`[createOrder] ❌ CRITICAL: Vendor ID mismatch!`)
      console.error(`[createOrder]    Expected: ${vendorInfo.vendorId}`)
      console.error(`[createOrder]    Found: ${vendor.id}`)
      throw new Error(`Vendor ID mismatch: Expected ${vendorInfo.vendorId}, but found ${vendor.id}`)
    }
    
    // CRITICAL FIX: Use vendor._id.toString() as key to ensure consistency
    const vendorKey = vendor._id.toString()

    // Group items by vendor
    if (!itemsByVendor.has(vendorKey)) {
      itemsByVendor.set(vendorKey, [])
      vendorInfoMap.set(vendorKey, {
        vendorId: vendor.id, // Use vendor.id from database
        vendorName: vendor.name, // Use vendor.name from database (not vendorInfo.vendorName)
        vendorObjectId: vendor._id // Use vendor._id from database
      })
      console.log(`[createOrder] Added vendor to map: ${vendorKey} -> ${vendor.id} (${vendor.name})`)
    }

    itemsByVendor.get(vendorKey)!.push({
        uniformId: uniform.id, // CRITICAL FIX: Use string ID (6-digit numeric), not ObjectId
        productId: uniform.id, // Store numeric/string product ID for correlation
        uniformName: item.uniformName,
        size: item.size,
        quantity: item.quantity,
        price: itemPrice,
    })
  }

  // Generate parent order ID (for grouping split orders)
  const parentOrderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`

  // Create separate orders for each vendor
  const createdOrders = []
  const employeeName = `${employee.firstName} ${employee.lastName}`
  
  // Get numeric IDs for correlation
  const employeeIdNum = employee.employeeId || employee.id // Use employeeId field first, fallback to id
  const companyIdNum = company.id // Company.id is already numeric

  console.log(`[createOrder] ========================================`)
  console.log(`[createOrder] 📦 CREATING MULTI-VENDOR ORDER`)
  console.log(`[createOrder] Parent Order ID: ${parentOrderId}`)
  console.log(`[createOrder] Vendors: ${itemsByVendor.size}`)
  itemsByVendor.forEach((items, vid) => {
    const vendorInfo = vendorInfoMap.get(vid)!
    console.log(`[createOrder]   - Vendor: ${vendorInfo.vendorName} (${vid}), Items: ${items.length}`)
  })
  console.log(`[createOrder] ========================================`)

  let isFirstOrder = true
  for (const [vendorKey, items] of itemsByVendor.entries()) {
    const vendorInfo = vendorInfoMap.get(vendorKey)
    if (!vendorInfo) {
      console.error(`[createOrder] ❌ CRITICAL: Vendor info not found for key: ${vendorKey}`)
      throw new Error(`Vendor info not found for key: ${vendorKey}`)
    }
    
    // CRITICAL FIX: Re-verify vendor exists in database before creating order
    // This ensures we use the actual vendor data from the database, not cached data
    // Use string id field (most reliable) since we already have it
    let vendor = await Vendor.findOne({ id: vendorInfo.vendorId })
    
    if (!vendor) {
      console.error(`[createOrder] ❌ CRITICAL: Vendor not found in database`)
      console.error(`[createOrder]    vendorId: ${vendorInfo.vendorId}`)
      console.error(`[createOrder]    vendorName: ${vendorInfo.vendorName}`)
      
      // List available vendors for debugging
      const allVendors = await Vendor.find({}, 'id name').limit(5).lean()
      console.error(`[createOrder] Available vendors (sample):`, allVendors.map((v: any) => `id=${v.id}, name=${v.name}`))
      
      throw new Error(`Vendor not found: ${vendorInfo.vendorId}. Please ensure the vendor exists in the database.`)
    }
    
    // Verify vendorId matches
    if (vendor.id !== vendorInfo.vendorId) {
      console.error(`[createOrder] ❌ CRITICAL: Vendor ID mismatch!`)
      console.error(`[createOrder]    vendorInfo.vendorId: ${vendorInfo.vendorId}`)
      console.error(`[createOrder]    vendor.id: ${vendor.id}`)
      throw new Error(`Vendor ID mismatch`)
    }
    
    console.log(`[createOrder] Processing vendor: ${vendor.id} (${vendor.name}), Key: ${vendorKey}`)
    
    // Calculate total for this vendor's order
    const total = items.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0)

    // Generate unique order ID for this vendor order
    // Use vendor.id (numeric/string) for order ID generation, not vendorKey (ObjectId string)
    const orderId = `${parentOrderId}-${vendor.id.substring(0, 8).toUpperCase()}`

    // CRITICAL FIX: For split orders, ALL orders should start with 'Awaiting approval'
    // This ensures all vendor orders are visible in the approval queue
    // The previous logic that set child orders to 'Awaiting fulfilment' was causing them to be invisible
    // After approval, ALL orders will be updated to 'Awaiting fulfilment' atomically
    const orderStatus = 'Awaiting approval' // All orders require approval, even split orders
    
    // Determine PR status based on workflow configuration
    let prStatus: string | undefined = undefined
    let prNumber: string | undefined = undefined
    let prDate: Date | undefined = undefined
    
    // Check if PR/PO workflow is enabled
    // Use explicit boolean check and handle undefined/null cases
    const isWorkflowEnabled = company.enable_pr_po_workflow === true || company.enable_pr_po_workflow === 'true'
    const isSiteAdminApprovalRequired = company.enable_site_admin_pr_approval === true || company.enable_site_admin_pr_approval === 'true'
    
    console.log(`[createOrder] Workflow configuration check:`)
    console.log(`[createOrder]   enable_pr_po_workflow (raw): ${company.enable_pr_po_workflow} (type: ${typeof company.enable_pr_po_workflow})`)
    console.log(`[createOrder]   enable_site_admin_pr_approval (raw): ${company.enable_site_admin_pr_approval} (type: ${typeof company.enable_site_admin_pr_approval})`)
    console.log(`[createOrder]   isWorkflowEnabled: ${isWorkflowEnabled}`)
    console.log(`[createOrder]   isSiteAdminApprovalRequired: ${isSiteAdminApprovalRequired}`)
    
    if (isWorkflowEnabled) {
      // Check if site admin approval is required
      if (isSiteAdminApprovalRequired) {
        // Order must go to Site Admin first
        // IMPORTANT: Do NOT generate PR number/date here - Location Admin will enter them during approval
        prNumber = undefined
        prDate = undefined
        prStatus = 'PENDING_SITE_ADMIN_APPROVAL'
        console.log(`[createOrder] ✅ PR workflow enabled with Site Admin approval required. Setting PR status to: ${prStatus}`)
        console.log(`[createOrder] ⚠️ PR Number/Date will be entered by Location Admin during approval`)
      } else {
        // Skip site admin approval, go directly to Company Admin
        // For Company Admin approval, we can generate PR number/date if needed
        // (Company Admin might also enter them, but we can provide defaults)
        prNumber = `PR-${company.id}-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`
        prDate = new Date()
        prStatus = 'PENDING_COMPANY_ADMIN_APPROVAL'
        console.log(`[createOrder] ✅ PR workflow enabled but Site Admin approval not required. Setting PR status to: ${prStatus}`)
      }
    } else {
      // PR/PO workflow not enabled - use legacy approval flow
      console.log(`[createOrder] ⚠️ PR/PO workflow not enabled (enable_pr_po_workflow=${company.enable_pr_po_workflow}). Using legacy approval flow.`)
    }
    
    console.log(`[createOrder] Creating order for vendor ${vendor.name} (${vendor.id}):`)
    console.log(`[createOrder]   Order ID: ${orderId}`)
    console.log(`[createOrder]   Status: ${orderStatus}`)
    console.log(`[createOrder]   PR Status: ${prStatus || 'N/A'}`)
    console.log(`[createOrder]   PR Number: ${prNumber || 'N/A'}`)
    console.log(`[createOrder]   Parent Order ID: ${parentOrderId}`)
    console.log(`[createOrder]   Vendor ObjectId: ${vendor._id.toString()}`)
    console.log(`[createOrder]   Items: ${items.length}, Total: ₹${total}`)

    // CRITICAL FIX: Create order using vendor data from database, NOT from vendorInfo map
    // This ensures we use the actual vendor name and _id from the database
    // CRITICAL FIX: Order model expects employeeId and companyId as STRING IDs (6-digit numeric strings)
    // NOT ObjectIds - must use employee.id/employeeId and company.id, not employee._id and company._id
    const employeeStringId = employee.employeeId || employee.id // Use string ID
    const companyStringId = company.id // Use string ID
    
    console.log(`[createOrder] Creating order with IDs:`)
    console.log(`[createOrder]   employeeId (string): ${employeeStringId}`)
    console.log(`[createOrder]   companyId (string): ${companyStringId}`)
    console.log(`[createOrder]   vendorId (string): ${vendor.id}`)
    console.log(`[createOrder]   employee._id (ObjectId): ${employee._id}`)
    console.log(`[createOrder]   company._id (ObjectId): ${company._id}`)
    
    // CRITICAL VALIDATION: Verify all IDs are 6-digit numeric strings before creating order
    // Order model schema has strict validation that will throw errors if IDs don't match format
    if (!/^\d{6}$/.test(employeeStringId)) {
      console.error(`[createOrder] ❌ CRITICAL: employeeId is not a 6-digit numeric string: ${employeeStringId}`)
      throw new Error(`Invalid employeeId format: ${employeeStringId}. Must be exactly 6 digits (e.g., "300001").`)
    }
    if (!/^\d{6}$/.test(companyStringId)) {
      console.error(`[createOrder] ❌ CRITICAL: companyId is not a 6-digit numeric string: ${companyStringId}`)
      throw new Error(`Invalid companyId format: ${companyStringId}. Must be exactly 6 digits (e.g., "100001").`)
    }
    if (!/^\d{6}$/.test(vendor.id)) {
      console.error(`[createOrder] ❌ CRITICAL: vendorId is not a 6-digit numeric string: ${vendor.id}`)
      throw new Error(`Invalid vendorId format: ${vendor.id}. Must be exactly 6 digits (e.g., "400001").`)
    }
    
    // Validate all items have valid uniformId (6-digit numeric string)
    for (const item of items) {
      if (!item.uniformId || !/^\d{6}$/.test(String(item.uniformId))) {
        console.error(`[createOrder] ❌ CRITICAL: Item has invalid uniformId: ${item.uniformId}`)
        console.error(`[createOrder] Item details:`, JSON.stringify(item, null, 2))
        throw new Error(`Invalid uniformId format in item "${item.uniformName}": ${item.uniformId}. Must be exactly 6 digits (e.g., "200001").`)
      }
    }
    
    console.log(`[createOrder] ✅ All ID validations passed`)
    
    // CRITICAL: Log all values before creating order to debug validation issues
    console.log(`[createOrder] ========== PRE-CREATE VALIDATION LOG ==========`)
    console.log(`[createOrder] Order ID: ${orderId}`)
    console.log(`[createOrder] Employee ID: ${employeeStringId} (type: ${typeof employeeStringId}, length: ${employeeStringId?.length})`)
    console.log(`[createOrder] Company ID: ${companyStringId} (type: ${typeof companyStringId}, length: ${companyStringId?.length})`)
    console.log(`[createOrder] Vendor ID: ${vendor.id} (type: ${typeof vendor.id}, length: ${vendor.id?.length})`)
    console.log(`[createOrder] Items count: ${items.length}`)
    items.forEach((item: any, idx: number) => {
      console.log(`[createOrder]   Item ${idx + 1}:`)
      console.log(`[createOrder]     uniformId: ${item.uniformId} (type: ${typeof item.uniformId}, length: ${item.uniformId?.length})`)
      console.log(`[createOrder]     productId: ${item.productId} (type: ${typeof item.productId})`)
      console.log(`[createOrder]     uniformName: ${item.uniformName}`)
      console.log(`[createOrder]     size: ${item.size}`)
      console.log(`[createOrder]     quantity: ${item.quantity} (type: ${typeof item.quantity})`)
      console.log(`[createOrder]     price: ${item.price} (type: ${typeof item.price})`)
    })
    console.log(`[createOrder] Total: ${total}`)
    console.log(`[createOrder] Status: ${orderStatus}`)
    console.log(`[createOrder] Shipping Address:`)
    console.log(`[createOrder]   L1: ${shippingAddress.shipping_address_line_1}`)
    console.log(`[createOrder]   City: ${shippingAddress.shipping_city}`)
    console.log(`[createOrder]   State: ${shippingAddress.shipping_state}`)
    console.log(`[createOrder]   Pincode: ${shippingAddress.shipping_pincode} (type: ${typeof shippingAddress.shipping_pincode})`)
    console.log(`[createOrder] ===============================================`)
    
    // CRITICAL: Wrap Order.create in try-catch to catch validation errors
    let order
    try {
      order = await Order.create({
        id: orderId,
        employeeId: employeeStringId, // Use string ID, not ObjectId
        employeeIdNum: employeeIdNum, // Numeric/string employee ID for correlation
        employeeName: employeeName,
        items: items, // Each item already has uniformId as string ID (6-digit numeric)
        total: total,
        status: orderStatus,
        orderDate: new Date(),
        dispatchLocation: orderData.dispatchLocation || employee.dispatchPreference || 'standard',
        companyId: companyStringId, // Use string ID, not ObjectId
        companyIdNum: companyIdNum, // Numeric company ID for correlation
        // Structured shipping address fields (REQUIRED by Order model)
        shipping_address_line_1: shippingAddress.shipping_address_line_1,
        shipping_address_line_2: shippingAddress.shipping_address_line_2,
        shipping_address_line_3: shippingAddress.shipping_address_line_3,
        shipping_city: shippingAddress.shipping_city,
        shipping_state: shippingAddress.shipping_state,
        shipping_pincode: shippingAddress.shipping_pincode,
        shipping_country: shippingAddress.shipping_country || 'India',
        // Legacy field for backward compatibility (deprecated)
        deliveryAddress: deliveryAddressToUse,
        estimatedDeliveryTime: orderData.estimatedDeliveryTime,
        parentOrderId: parentOrderId, // Link to parent order
        vendorId: vendor.id, // CRITICAL FIX: Store 6-digit numeric vendor ID (not ObjectId)
        vendorName: vendor.name, // CRITICAL FIX: Use vendor.name from database, not vendorInfo.vendorName
        isPersonalPayment: orderData.isPersonalPayment || false,
        personalPaymentAmount: orderData.personalPaymentAmount || 0,
        // PR (Purchase Requisition) Extension Fields
        pr_number: prNumber,
        pr_date: prDate,
        pr_status: prStatus,
      })
    } catch (validationError: any) {
      console.error(`[createOrder] ❌ CRITICAL: Order validation failed!`)
      console.error(`[createOrder] Error name: ${validationError?.name}`)
      console.error(`[createOrder] Error message: ${validationError?.message}`)
      console.error(`[createOrder] Error errors:`, JSON.stringify(validationError?.errors || {}, null, 2))
      console.error(`[createOrder] Order data being created:`)
      console.error(`[createOrder]   id: ${orderId}`)
      console.error(`[createOrder]   employeeId: ${employeeStringId} (type: ${typeof employeeStringId})`)
      console.error(`[createOrder]   companyId: ${companyStringId} (type: ${typeof companyStringId})`)
      console.error(`[createOrder]   vendorId: ${vendor.id} (type: ${typeof vendor.id})`)
      console.error(`[createOrder]   items:`, JSON.stringify(items.map((i: any) => ({ uniformId: i.uniformId, uniformName: i.uniformName })), null, 2))
      
      // Extract validation error details
      if (validationError?.errors) {
        const errorDetails = Object.keys(validationError.errors).map(key => {
          const err = validationError.errors[key]
          return `${key}: ${err.message || err.toString()}`
        }).join(', ')
        throw new Error(`Order validation failed: ${errorDetails}. Original error: ${validationError.message}`)
      }
      
      throw new Error(`Order creation failed: ${validationError.message || validationError.toString()}`)
    }
    
    // CRITICAL VERIFICATION: Verify order was created with correct vendorId (numeric ID)
    if (order.vendorId !== vendor.id) {
      console.error(`[createOrder] ❌ CRITICAL: Order created with WRONG vendorId!`)
      console.error(`[createOrder]    Expected: ${vendor.id} (numeric ID)`)
      console.error(`[createOrder]    Actual: ${order.vendorId}`)
      throw new Error(`Order created with incorrect vendorId. Expected ${vendor.id}, but got ${order.vendorId}`)
    }
    
    console.log(`[createOrder] ✅ Order created successfully:`)
    console.log(`[createOrder]    Order ID: ${order.id}`)
    console.log(`[createOrder]    Order _id: ${order._id}`)
    console.log(`[createOrder]    VendorId: ${order.vendorId} (numeric ID)`)
    console.log(`[createOrder]    VendorName: ${order.vendorName}`)
    console.log(`[createOrder]    Items: ${items.length}`)

    console.log(`[createOrder] ✅ Order created: ${order.id}, _id: ${order._id}, vendorId: ${order.vendorId?.toString()}`)

    isFirstOrder = false

    // Use string id field - populate doesn't work with string IDs, so manually fetch related data
    const orderIdStr = order.id || String(order._id || '')
    const populatedOrder = await Order.findOne({ id: orderIdStr }).lean()
    
    // Manually populate employeeId, companyId, items.uniformId, and vendorId
    if (populatedOrder) {
      if (populatedOrder.employeeId) {
        const employee = await Employee.findOne({ id: populatedOrder.employeeId }).select('id firstName lastName email').lean()
        if (employee) {
          (populatedOrder as any).employeeId = employee
        }
      }
      if (populatedOrder.companyId) {
        const company = await Company.findOne({ id: populatedOrder.companyId }).select('id name').lean()
        if (company) {
          (populatedOrder as any).companyId = company
        }
      }
      if (populatedOrder.vendorId) {
        const vendor = await Vendor.findOne({ id: populatedOrder.vendorId }).select('id name').lean()
        if (vendor) {
          (populatedOrder as any).vendorId = vendor
        }
      }
      if (populatedOrder.items && Array.isArray(populatedOrder.items)) {
        for (const item of populatedOrder.items) {
          if (item.uniformId) {
            const uniform = await Uniform.findOne({ id: item.uniformId }).select('id name').lean()
            if (uniform) {
              (item as any).uniformId = uniform
            }
          }
        }
      }
    }

    createdOrders.push(toPlainObject(populatedOrder))
  }

  // If only one order was created, return it directly
  // Otherwise, return the first order with metadata about split orders
  if (createdOrders.length === 1) {
    return createdOrders[0]
  }

  // Return the first order with information about split orders
  // The frontend can query for all orders with the same parentOrderId
  return {
    ...createdOrders[0],
    isSplitOrder: true,
    parentOrderId: parentOrderId,
    totalOrders: createdOrders.length,
    splitOrders: createdOrders.map(o => ({
      orderId: o.id,
      vendorName: o.vendorName,
      total: o.total,
      itemCount: o.items?.length || 0
    }))
  }
  } catch (error: any) {
    // CRITICAL: Catch ALL errors in createOrder and provide detailed logging
    console.error(`[createOrder] ❌ CRITICAL ERROR in createOrder function:`)
    console.error(`[createOrder] Error name: ${error?.name}`)
    console.error(`[createOrder] Error message: ${error?.message}`)
    console.error(`[createOrder] Error stack: ${error?.stack}`)
    console.error(`[createOrder] Order data received:`, {
      employeeId: orderData.employeeId,
      itemsCount: orderData.items?.length || 0,
      items: orderData.items?.map((i: any) => ({ uniformId: i.uniformId, uniformName: i.uniformName }))
    })
    
    // Re-throw the error so it can be caught by the API route
    throw error
  }
}

export async function approveOrder(orderId: string, adminEmail: string, prNumber?: string, prDate?: Date): Promise<any> {
  await connectDB()
  
  console.log(`[approveOrder] ========================================`)
  console.log(`[approveOrder] 🚀 APPROVING ORDER: ${orderId}`)
  console.log(`[approveOrder] Admin Email: ${adminEmail}`)
  console.log(`[approveOrder] PR Number: ${prNumber || 'N/A'}`)
  console.log(`[approveOrder] PR Date: ${prDate ? prDate.toISOString() : 'N/A'}`)
  
  // First, try to find order by id field
  let order = await Order.findOne({ id: orderId })
  
  // If not found by id, check if orderId is a parentOrderId (from grouped approval view)
  // This happens when getPendingApprovals returns parent order ID as the id field
  if (!order) {
    console.log(`[approveOrder] Order not found by id, checking if orderId is a parentOrderId...`)
    const ordersWithParent = await Order.find({ parentOrderId: orderId })
    if (ordersWithParent.length > 0) {
      console.log(`[approveOrder] ✅ Found ${ordersWithParent.length} child order(s) with parentOrderId: ${orderId}`)
      console.log(`[approveOrder] Redirecting to approveOrderByParentId...`)
      // This is a parent order ID, approve all child orders
      return await approveOrderByParentId(orderId, adminEmail, prNumber, prDate)
    }
    
    // If still not found, throw error
    console.error(`[approveOrder] ❌ Order not found: ${orderId}`)
    throw new Error(`Order not found: ${orderId}`)
  }
  
  console.log(`[approveOrder] ✅ Order found: ${order.id}, Status: ${order.status}, PR Status: ${order.pr_status || 'N/A'}, ParentOrderId: ${order.parentOrderId || 'N/A'}`)
  
  // CRITICAL FIX: If this order has a parentOrderId, approve ALL child orders atomically
  // This ensures all vendor orders in a split order are approved together
  if (order.parentOrderId) {
    console.log(`[approveOrder] Order has parentOrderId: ${order.parentOrderId}`)
    console.log(`[approveOrder] Redirecting to approveOrderByParentId to approve all child orders...`)
    return await approveOrderByParentId(order.parentOrderId, adminEmail, prNumber, prDate)
  }
  
  // Get company to check workflow settings
  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  // CRITICAL FIX: order.companyId is a STRING ID (6-digit), not ObjectId
  // Try string ID lookup first
  const companyIdStr = String(order.companyId)
  let company: any = null
  if (/^\d{6}$/.test(companyIdStr)) {
    // It's a string ID - use findOne
    company = await Company.findOne({ id: companyIdStr })
  } else if (mongoose.Types.ObjectId.isValid(companyIdStr) && /^[0-9a-fA-F]{24}$/.test(companyIdStr)) {
    // It's an ObjectId string - use findById
    company = await Company.findById(companyIdStr)
  } else {
    // Try as string ID anyway
    company = await Company.findOne({ id: companyIdStr })
  }
  
  // Fallback: Try alternative lookup methods if company not found
  if (!company) {
    console.log(`[approveOrder] Company not found by string ID ${companyIdStr}, trying alternative lookup methods`)
    
    // Try lookup by business ID (companyIdNum from order)
    if (order.companyIdNum) {
      console.log(`[approveOrder] Trying lookup by business ID: ${order.companyIdNum}`)
      company = await Company.findOne({ id: String(order.companyIdNum) })
    }
    
    // If still not found, try to extract companyId from order.companyId if it's an object
    if (!company && order.companyId && typeof order.companyId === 'object') {
      const companyIdFromOrder = (order.companyId as any).id || (order.companyId as any)._id
      if (companyIdFromOrder) {
        console.log(`[approveOrder] Trying lookup by extracted companyId: ${companyIdFromOrder}`)
        if (/^\d{6}$/.test(String(companyIdFromOrder))) {
          company = await Company.findOne({ id: String(companyIdFromOrder) })
        }
      }
    }
    
    if (!company) {
      console.error(`[approveOrder] Company not found for order ${orderId}, companyId: ${companyIdStr}, companyIdNum: ${order.companyIdNum}`)
      throw new Error(`Company not found for order ${orderId}`)
    }
  }
  
  // For PR workflow, check pr_status instead of status
  const isSiteAdminApproval = order.pr_status === 'PENDING_SITE_ADMIN_APPROVAL'
  const isCompanyAdminApproval = order.pr_status === 'PENDING_COMPANY_ADMIN_APPROVAL'
  
  // If pr_status is not set but company has PR workflow enabled, determine the correct status
  let shouldBeSiteAdminApproval = false
  if (!order.pr_status && company.enable_pr_po_workflow === true && company.enable_site_admin_pr_approval === true) {
    // Order was created before PR workflow was fully enabled, but company now requires site admin approval
    // Check if order is in a state that would require site admin approval
    if (order.status === 'Awaiting approval' || !order.status) {
      shouldBeSiteAdminApproval = true
      console.log(`[approveOrder] ⚠️ Order ${orderId} has no pr_status but company requires site admin approval. Treating as site admin approval.`)
    }
  }
  
  console.log(`[approveOrder] PR Workflow Check:`)
  console.log(`[approveOrder]   isSiteAdminApproval: ${isSiteAdminApproval}`)
  console.log(`[approveOrder]   isCompanyAdminApproval: ${isCompanyAdminApproval}`)
  console.log(`[approveOrder]   shouldBeSiteAdminApproval: ${shouldBeSiteAdminApproval}`)
  console.log(`[approveOrder]   order.pr_status: ${order.pr_status || 'undefined'}`)
  console.log(`[approveOrder]   company.enable_pr_po_workflow: ${company.enable_pr_po_workflow}`)
  console.log(`[approveOrder]   company.enable_site_admin_pr_approval: ${company.enable_site_admin_pr_approval}`)
  
  // Only check status for legacy orders (no PR workflow)
  if (!isSiteAdminApproval && !isCompanyAdminApproval && !shouldBeSiteAdminApproval && order.status !== 'Awaiting approval') {
    throw new Error(`Order ${orderId} is not in 'Awaiting approval' status (current: ${order.status}, pr_status: ${order.pr_status || 'N/A'})`)
  }
  
  // Find employee by email (handle encryption)
  // Use the same pattern as canApproveOrders for reliable lookup
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = adminEmail.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    throw new Error(`Employee not found: ${adminEmail}`)
  }
  
  // Check if this is a Site Admin approval (PR workflow)
  // Use the already computed values from above (computed before employee lookup)
  const finalIsSiteAdminApproval = isSiteAdminApproval || shouldBeSiteAdminApproval
  
  console.log(`[approveOrder] Final approval type determination:`)
  console.log(`[approveOrder]   finalIsSiteAdminApproval: ${finalIsSiteAdminApproval}`)
  console.log(`[approveOrder]   isCompanyAdminApproval: ${isCompanyAdminApproval}`)
  
  if (finalIsSiteAdminApproval) {
    // Site Admin approval flow
    console.log(`[approveOrder] Processing Site Admin approval for order ${orderId}`)
    
    // Get the order's employee (the one who placed the order)
    // CRITICAL FIX: order.employeeId is a STRING ID (6-digit numeric), not ObjectId
    const employeeIdStr = String(order.employeeId)
    let orderEmployee: any = null
    if (/^\d{6}$/.test(employeeIdStr)) {
      orderEmployee = await Employee.findOne({ id: employeeIdStr }).lean()
    } else {
      orderEmployee = await Employee.findOne({ employeeId: employeeIdStr }).lean()
    }
    
    if (!orderEmployee || !orderEmployee.locationId) {
      throw new Error(`Order's employee not found or has no location assigned`)
    }
    
    // Verify user is a Site Admin (Location Admin) for the order's employee's location
    // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
    const Location = require('../models/Location').default
    const employeeLocation = await Location.findOne({ id: orderEmployee.locationId }).lean()
    
    if (!employeeLocation || !employeeLocation.adminId) {
      throw new Error(`Order's employee location not found or has no admin assigned`)
    }
    
    // Check if the approving user is the location admin
    // CRITICAL FIX: Use string ID comparison, not ObjectId
    const locationAdminIdStr = String(employeeLocation.adminId)
    const approvingEmployeeIdStr = String(employee.id || employee.employeeId)
    
    console.log(`[approveOrder] Site Admin authorization check:`)
    console.log(`[approveOrder]   locationAdminId: ${locationAdminIdStr} (type: ${typeof locationAdminIdStr})`)
    console.log(`[approveOrder]   approvingEmployeeId: ${approvingEmployeeIdStr} (type: ${typeof approvingEmployeeIdStr})`)
    
    if (locationAdminIdStr !== approvingEmployeeIdStr) {
      // Additional check: try comparing by numeric employee ID as fallback
      let locationAdminEmployee: any = null
      let approvingEmployeeCheck: any = null
      
      // Lookup location admin employee by string ID
      if (/^\d{6}$/.test(locationAdminIdStr)) {
        locationAdminEmployee = await Employee.findOne({ id: locationAdminIdStr }).lean()
      } else {
        locationAdminEmployee = await Employee.findOne({ employeeId: locationAdminIdStr }).lean()
      }
      
      // Lookup approving employee by string ID
      if (/^\d{6}$/.test(approvingEmployeeIdStr)) {
        approvingEmployeeCheck = await Employee.findOne({ id: approvingEmployeeIdStr }).lean()
      } else {
        approvingEmployeeCheck = await Employee.findOne({ employeeId: approvingEmployeeIdStr }).lean()
      }
      
      if (locationAdminEmployee && approvingEmployeeCheck) {
        const locationAdminEmployeeId = locationAdminEmployee.id || locationAdminEmployee.employeeId
        const approvingEmployeeIdNum = approvingEmployeeCheck.id || approvingEmployeeCheck.employeeId
        
        console.log(`[approveOrder] Fallback check by numeric ID:`)
        console.log(`[approveOrder]   locationAdminEmployeeId: ${locationAdminEmployeeId}`)
        console.log(`[approveOrder]   approvingEmployeeIdNum: ${approvingEmployeeIdNum}`)
        
        if (locationAdminEmployeeId && approvingEmployeeIdNum && locationAdminEmployeeId.toString() === approvingEmployeeIdNum.toString()) {
          console.log(`[approveOrder] ✅ Authorization passed via numeric ID fallback`)
        } else {
          throw new Error(`User ${adminEmail} is not the Site Admin (Location Admin) for this order's location`)
        }
      } else {
        throw new Error(`User ${adminEmail} is not the Site Admin (Location Admin) for this order's location`)
      }
    } else {
      console.log(`[approveOrder] ✅ Authorization passed via string ID comparison`)
    }
    
    // Update PR status to SITE_ADMIN_APPROVED
    // PR number and date MUST be provided by Site Admin (required for site admin approval)
    if (!prNumber || !prNumber.trim()) {
      throw new Error('PR Number is required for Site Admin approval')
    }
    if (!prDate) {
      throw new Error('PR Date is required for Site Admin approval')
    }
    
    // Set PR number and date (overwrite any auto-generated values)
    order.pr_number = prNumber.trim()
    order.pr_date = prDate
    console.log(`[approveOrder] Site Admin provided PR number: ${prNumber.trim()}`)
    console.log(`[approveOrder] Site Admin provided PR date: ${prDate.toISOString()}`)
    
    order.pr_status = 'SITE_ADMIN_APPROVED'
    // CRITICAL FIX: Use string ID, not ObjectId
    order.site_admin_approved_by = employee.id || employee.employeeId
    order.site_admin_approved_at = new Date()
    
    // Check if company admin approval is required
    if (company.require_company_admin_po_approval === true) {
      // Move to Company Admin approval
      order.pr_status = 'PENDING_COMPANY_ADMIN_APPROVAL'
      console.log(`[approveOrder] Site Admin approved. Moving to Company Admin approval.`)
    } else {
      // No company admin approval needed, move to fulfilment
      order.status = 'Awaiting fulfilment'
      console.log(`[approveOrder] Site Admin approved. No Company Admin approval required. Moving to fulfilment.`)
    }
  } else if (isCompanyAdminApproval) {
    // Company Admin approval flow
    console.log(`[approveOrder] Processing Company Admin approval for order ${orderId}`)
    
    const canApprove = await canApproveOrders(adminEmail, company.id)
    if (!canApprove) {
      throw new Error(`User ${adminEmail} does not have permission to approve orders as Company Admin`)
    }
    
    // Update PR status to COMPANY_ADMIN_APPROVED
    order.pr_status = 'COMPANY_ADMIN_APPROVED'
    // CRITICAL FIX: Use string ID, not ObjectId
    order.company_admin_approved_by = employee.id || employee.employeeId
    order.company_admin_approved_at = new Date()
    order.status = 'Awaiting fulfilment'
    console.log(`[approveOrder] Company Admin approved. Moving to fulfilment.`)
  } else {
    // Legacy approval flow (no PR workflow)
    console.log(`[approveOrder] Processing legacy approval for order ${orderId}`)
  
  const canApprove = await canApproveOrders(adminEmail, company.id)
  if (!canApprove) {
    throw new Error(`User ${adminEmail} does not have permission to approve orders`)
  }
  
  // Update order status
  order.status = 'Awaiting fulfilment'
  }
  
  await order.save()
  
  // Use string id field - populate doesn't work with string IDs, so manually fetch related data
  const orderIdStr = order.id || String(order._id || '')
  const populatedOrder = await Order.findOne({ id: orderIdStr }).lean()
  
  // Manually populate employeeId, companyId, and items.uniformId
  if (populatedOrder) {
    if (populatedOrder.employeeId) {
      const employee = await Employee.findOne({ id: populatedOrder.employeeId }).select('id firstName lastName email').lean()
      if (employee) {
        (populatedOrder as any).employeeId = employee
      }
    }
    if (populatedOrder.companyId) {
      const company = await Company.findOne({ id: populatedOrder.companyId }).select('id name').lean()
      if (company) {
        (populatedOrder as any).companyId = company
      }
    }
    if (populatedOrder.items && Array.isArray(populatedOrder.items)) {
      for (const item of populatedOrder.items) {
        if (item.uniformId) {
          const uniform = await Uniform.findOne({ id: item.uniformId }).select('id name').lean()
          if (uniform) {
            (item as any).uniformId = uniform
          }
        }
      }
    }
  }
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Manually fetch vendor information if vendorId exists
  let vendorName = null
  if (populatedOrder && (populatedOrder as any).vendorId) {
    const vendorIdValue = (populatedOrder as any).vendorId
    // vendorId is now a string (6-digit numeric), not ObjectId
    if (typeof vendorIdValue === 'string' && /^\d{6}$/.test(vendorIdValue)) {
      const vendor = await Vendor.findOne({ id: vendorIdValue }).select('id name').lean()
      if (vendor) {
        vendorName = (vendor as any).name
      }
    }
  }
  
  const result = toPlainObject(populatedOrder)
  if (vendorName) {
    (result as any).vendorName = vendorName
  }
  
  return result
}

async function approveOrderByParentId(parentOrderId: string, adminEmail: string, prNumber?: string, prDate?: Date): Promise<any> {
  await connectDB()
  
  console.log(`[approveOrderByParentId] ========================================`)
  console.log(`[approveOrderByParentId] 🚀 APPROVING PARENT ORDER: ${parentOrderId}`)
  console.log(`[approveOrderByParentId] Admin Email: ${adminEmail}`)
  console.log(`[approveOrderByParentId] PR Number: ${prNumber || 'N/A'}`)
  console.log(`[approveOrderByParentId] PR Date: ${prDate ? prDate.toISOString() : 'N/A'}`)
  
  // Find all orders with this parentOrderId
  const childOrders = await Order.find({ parentOrderId: parentOrderId })
  console.log(`[approveOrderByParentId] Found ${childOrders.length} child order(s) with parentOrderId: ${parentOrderId}`)
  
  if (childOrders.length === 0) {
    console.error(`[approveOrderByParentId] ❌ No orders found with parentOrderId: ${parentOrderId}`)
    throw new Error(`No orders found with parentOrderId: ${parentOrderId}`)
  }
  
  // Log all child orders before approval
  childOrders.forEach((order, idx) => {
    console.log(`[approveOrderByParentId] Child Order ${idx + 1}:`, {
      orderId: order.id,
      status: order.status,
      pr_status: order.pr_status || 'N/A',
      vendorId: order.vendorId?.toString() || 'N/A',
      vendorName: (order as any).vendorName || 'N/A',
      itemCount: order.items?.length || 0,
      total: order.total
    })
  })
  
  // Verify admin can approve orders (check once using first order's company)
  const firstOrder = childOrders[0]
  
  // CRITICAL FIX: order.companyId is a STRING ID (6-digit numeric), not ObjectId
  // Try string ID lookup first
  const companyIdStr = String(firstOrder.companyId)
  let company: any = null
  if (/^\d{6}$/.test(companyIdStr)) {
    // It's a string ID - use findOne
    company = await Company.findOne({ id: companyIdStr })
  } else if (mongoose.Types.ObjectId.isValid(companyIdStr) && /^[0-9a-fA-F]{24}$/.test(companyIdStr)) {
    // It's an ObjectId string - try findById (legacy support)
    company = await Company.findById(companyIdStr)
  } else {
    // Try as string ID anyway
    company = await Company.findOne({ id: companyIdStr })
  }
  
  // Fallback: Try alternative lookup methods if company not found
  if (!company) {
    console.log(`[approveOrderByParentId] Company not found by string ID ${companyIdStr}, trying alternative lookup methods`)
    
    // Try lookup by business ID (companyIdNum from order)
    if (firstOrder.companyIdNum) {
      console.log(`[approveOrderByParentId] Trying lookup by business ID: ${firstOrder.companyIdNum}`)
      company = await Company.findOne({ id: String(firstOrder.companyIdNum) })
    }
    
    if (!company) {
      console.error(`[approveOrderByParentId] Company not found for parent order ${parentOrderId}, companyId: ${companyIdStr}, companyIdNum: ${firstOrder.companyIdNum}`)
      const allCompanies = await Company.find({}, 'id name _id').limit(5).lean()
      console.error(`[approveOrderByParentId] Available companies:`, allCompanies.map((c: any) => `id=${c.id}, _id=${c._id?.toString()}`))
      throw new Error(`Company not found for parent order ${parentOrderId}`)
    }
  }
  
  // Find employee by email (handle encryption)
  // Use the same pattern as canApproveOrders for reliable lookup
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = adminEmail.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    throw new Error(`Employee not found: ${adminEmail}`)
  }
  
  // CRITICAL FIX: Validate orders can be approved based on pr_status (when PR workflow enabled) or status (legacy)
  // When PR workflow is enabled, pr_status is the source of truth, not status
  const isWorkflowEnabled = company.enable_pr_po_workflow === true || company.enable_pr_po_workflow === 'true'
  
  if (isWorkflowEnabled) {
    // PR workflow enabled - check pr_status
    const pendingSiteAdminOrders = childOrders.filter(o => o.pr_status === 'PENDING_SITE_ADMIN_APPROVAL')
    const pendingCompanyAdminOrders = childOrders.filter(o => o.pr_status === 'PENDING_COMPANY_ADMIN_APPROVAL')
    const approvedOrders = childOrders.filter(o => 
      o.pr_status === 'SITE_ADMIN_APPROVED' || 
      o.pr_status === 'COMPANY_ADMIN_APPROVED' ||
      o.pr_status === 'PO_CREATED'
    )
    
    console.log(`[approveOrderByParentId] PR Workflow Status breakdown:`, {
      pendingSiteAdmin: pendingSiteAdminOrders.length,
      pendingCompanyAdmin: pendingCompanyAdminOrders.length,
      alreadyApproved: approvedOrders.length,
      total: childOrders.length,
      allPRStatuses: childOrders.map(o => o.pr_status || 'N/A')
    })
    
    // If no orders are pending approval, check if they're already processed
    if (pendingSiteAdminOrders.length === 0 && pendingCompanyAdminOrders.length === 0) {
      if (approvedOrders.length === 0) {
        // Orders might have invalid or missing pr_status
        console.error(`[approveOrderByParentId] ❌ No orders with parentOrderId ${parentOrderId} are in pending approval status`)
        console.error(`[approveOrderByParentId] All orders pr_status:`, childOrders.map(o => ({ id: o.id, pr_status: o.pr_status || 'N/A', status: o.status })))
        throw new Error(`No orders with parentOrderId ${parentOrderId} are in pending approval status. All orders are already processed or have invalid pr_status.`)
      } else {
        console.log(`[approveOrderByParentId] ⚠️ All orders are already approved (pr_status: ${approvedOrders[0]?.pr_status}), but proceeding to ensure synchronization`)
      }
    }
  } else {
    // Legacy workflow - check status field
    const pendingOrders = childOrders.filter(o => o.status === 'Awaiting approval')
    const fulfilmentOrders = childOrders.filter(o => o.status === 'Awaiting fulfilment')
    
    console.log(`[approveOrderByParentId] Legacy Status breakdown:`, {
      awaitingApproval: pendingOrders.length,
      awaitingFulfilment: fulfilmentOrders.length,
      total: childOrders.length,
      allStatuses: childOrders.map(o => o.status)
    })
    
    if (pendingOrders.length === 0 && fulfilmentOrders.length === 0) {
      console.error(`[approveOrderByParentId] ❌ No orders with parentOrderId ${parentOrderId} are in 'Awaiting approval' or 'Awaiting fulfilment' status`)
      console.error(`[approveOrderByParentId] All orders are in status:`, childOrders.map(o => o.status))
      throw new Error(`No orders with parentOrderId ${parentOrderId} are in 'Awaiting approval' or 'Awaiting fulfilment' status. All orders are already processed.`)
    }
  }
  
  // Check if this is a site admin approval (PR workflow)
  // Check the first order's PR status to determine the approval type
  const firstOrderPRStatus = firstOrder.pr_status
  const isSiteAdminApproval = firstOrderPRStatus === 'PENDING_SITE_ADMIN_APPROVAL'
  const isCompanyAdminApproval = firstOrderPRStatus === 'PENDING_COMPANY_ADMIN_APPROVAL'
  
  if (isSiteAdminApproval) {
    // Site Admin approval flow for split orders
    console.log(`[approveOrderByParentId] Processing Site Admin approval for parent order ${parentOrderId}`)
    
    // Get the first order's employee (the one who placed the order)
    // CRITICAL FIX: firstOrder.employeeId is a STRING ID (6-digit numeric), not ObjectId
    const employeeIdStr = String(firstOrder.employeeId)
    let orderEmployee: any = null
    if (/^\d{6}$/.test(employeeIdStr)) {
      orderEmployee = await Employee.findOne({ id: employeeIdStr }).lean()
    } else {
      orderEmployee = await Employee.findOne({ employeeId: employeeIdStr }).lean()
    }
    
    if (!orderEmployee || !orderEmployee.locationId) {
      throw new Error(`Order's employee not found or has no location assigned`)
    }
    
    // Verify user is a Site Admin (Location Admin) for the order's employee's location
    // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
    const Location = require('../models/Location').default
    const employeeLocation = await Location.findOne({ id: orderEmployee.locationId }).lean()
    
    if (!employeeLocation || !employeeLocation.adminId) {
      throw new Error(`Order's employee location not found or has no admin assigned`)
    }
    
    // Check if the approving user is the location admin
    // CRITICAL FIX: Use string ID comparison, not ObjectId
    const locationAdminIdStr = String(employeeLocation.adminId)
    const approvingEmployeeIdStr = String(employee.id || employee.employeeId)
    
    console.log(`[approveOrderByParentId] Site Admin authorization check:`)
    console.log(`[approveOrderByParentId]   locationAdminId: ${locationAdminIdStr} (type: ${typeof locationAdminIdStr})`)
    console.log(`[approveOrderByParentId]   approvingEmployeeId: ${approvingEmployeeIdStr} (type: ${typeof approvingEmployeeIdStr})`)
    
    if (locationAdminIdStr !== approvingEmployeeIdStr) {
      // Additional check: try comparing by numeric employee ID as fallback
      let locationAdminEmployee: any = null
      let approvingEmployeeCheck: any = null
      
      // Lookup location admin employee by string ID
      if (/^\d{6}$/.test(locationAdminIdStr)) {
        locationAdminEmployee = await Employee.findOne({ id: locationAdminIdStr }).lean()
      } else {
        locationAdminEmployee = await Employee.findOne({ employeeId: locationAdminIdStr }).lean()
      }
      
      // Lookup approving employee by string ID
      if (/^\d{6}$/.test(approvingEmployeeIdStr)) {
        approvingEmployeeCheck = await Employee.findOne({ id: approvingEmployeeIdStr }).lean()
      } else {
        approvingEmployeeCheck = await Employee.findOne({ employeeId: approvingEmployeeIdStr }).lean()
      }
      
      if (locationAdminEmployee && approvingEmployeeCheck) {
        const locationAdminEmployeeId = locationAdminEmployee.id || locationAdminEmployee.employeeId
        const approvingEmployeeIdNum = approvingEmployeeCheck.id || approvingEmployeeCheck.employeeId
        
        console.log(`[approveOrderByParentId] Fallback check by numeric ID:`)
        console.log(`[approveOrderByParentId]   locationAdminEmployeeId: ${locationAdminEmployeeId}`)
        console.log(`[approveOrderByParentId]   approvingEmployeeIdNum: ${approvingEmployeeIdNum}`)
        
        if (locationAdminEmployeeId && approvingEmployeeIdNum && locationAdminEmployeeId.toString() === approvingEmployeeIdNum.toString()) {
          console.log(`[approveOrderByParentId] ✅ Authorization passed via numeric ID fallback`)
        } else {
          throw new Error(`User ${adminEmail} is not the Site Admin (Location Admin) for this order's location`)
        }
      } else {
        throw new Error(`User ${adminEmail} is not the Site Admin (Location Admin) for this order's location`)
      }
    } else {
      console.log(`[approveOrderByParentId] ✅ Authorization passed via string ID comparison`)
    }
    
    // Update all child orders with site admin approval
    console.log(`[approveOrderByParentId] 🔄 Updating all child orders with Site Admin approval...`)
    
    let updatedCount = 0
    for (const childOrder of childOrders) {
      const previousStatus = childOrder.status
      const previousPRStatus = childOrder.pr_status
      
      // PR number and date MUST be provided by Site Admin (required for site admin approval)
      if (!prNumber || !prNumber.trim()) {
        throw new Error(`PR Number is required for Site Admin approval of order ${childOrder.id}`)
      }
      if (!prDate) {
        throw new Error(`PR Date is required for Site Admin approval of order ${childOrder.id}`)
      }
      
      // Set PR number and date (overwrite any auto-generated values)
      childOrder.pr_number = prNumber.trim()
      childOrder.pr_date = prDate
      console.log(`[approveOrderByParentId] Site Admin provided PR number: ${prNumber.trim()} for order ${childOrder.id}`)
      console.log(`[approveOrderByParentId] Site Admin provided PR date: ${prDate.toISOString()} for order ${childOrder.id}`)
      
      // Update PR status to SITE_ADMIN_APPROVED
      childOrder.pr_status = 'SITE_ADMIN_APPROVED'
      // CRITICAL FIX: Use string ID, not ObjectId
      childOrder.site_admin_approved_by = employee.id || employee.employeeId
      childOrder.site_admin_approved_at = new Date()
      
      // Check if company admin approval is required
      if (company.require_company_admin_po_approval === true) {
        // Move to Company Admin approval
        childOrder.pr_status = 'PENDING_COMPANY_ADMIN_APPROVAL'
        console.log(`[approveOrderByParentId] Site Admin approved order ${childOrder.id}. Moving to Company Admin approval.`)
      } else {
        // No company admin approval needed, move to fulfilment
        childOrder.status = 'Awaiting fulfilment'
        console.log(`[approveOrderByParentId] Site Admin approved order ${childOrder.id}. No Company Admin approval required. Moving to fulfilment.`)
      }
      
      await childOrder.save()
      updatedCount++
      console.log(`[approveOrderByParentId] ✅ Updated order ${childOrder.id}: status=${previousStatus}→${childOrder.status}, pr_status=${previousPRStatus}→${childOrder.pr_status}`)
    }
    
    console.log(`[approveOrderByParentId] ✅ Updated ${updatedCount} of ${childOrders.length} child order(s) with Site Admin approval`)
    
    // Return the first order as representative - use string id field instead of _id
    const firstOrderId = firstOrder.id || String(firstOrder._id || '')
    const populatedOrder = await Order.findOne({ id: firstOrderId })
      .populate('employeeId', 'id firstName lastName email')
      .populate('companyId', 'id name')
      .populate('items.uniformId', 'id name')
      .lean()
    
    // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
    // Manually fetch vendor information if vendorId exists
    let vendorName = null
    if (populatedOrder && (populatedOrder as any).vendorId) {
      const vendorIdValue = (populatedOrder as any).vendorId
      // vendorId is now a string (6-digit numeric), not ObjectId
      if (typeof vendorIdValue === 'string' && /^\d{6}$/.test(vendorIdValue)) {
        const vendor = await Vendor.findOne({ id: vendorIdValue }).select('id name').lean()
        if (vendor) {
          vendorName = (vendor as any).name
        }
      }
    }
    
    const result = toPlainObject(populatedOrder)
    if (vendorName) {
      (result as any).vendorName = vendorName
    }
    
    return result
  } else if (isCompanyAdminApproval) {
    // Company Admin approval flow
    console.log(`[approveOrderByParentId] Processing Company Admin approval for parent order ${parentOrderId}`)
    
    const canApprove = await canApproveOrders(adminEmail, company.id)
    if (!canApprove) {
      throw new Error(`User ${adminEmail} does not have permission to approve orders as Company Admin`)
    }
    
    // Update all child orders with company admin approval
    console.log(`[approveOrderByParentId] 🔄 Updating all child orders with Company Admin approval...`)
    
    let updatedCount = 0
    for (const childOrder of childOrders) {
      const previousStatus = childOrder.status
      
      // Update PR status to COMPANY_ADMIN_APPROVED
      childOrder.pr_status = 'COMPANY_ADMIN_APPROVED'
      // CRITICAL FIX: Use string ID, not ObjectId
      childOrder.company_admin_approved_by = employee.id || employee.employeeId
      childOrder.company_admin_approved_at = new Date()
      childOrder.status = 'Awaiting fulfilment'
      
      await childOrder.save()
      updatedCount++
      console.log(`[approveOrderByParentId] ✅ Updated order ${childOrder.id}: ${previousStatus} → Awaiting fulfilment`)
    }
    
    console.log(`[approveOrderByParentId] ✅ Updated ${updatedCount} of ${childOrders.length} child order(s) with Company Admin approval`)
    
    // Return the first order as representative - use string id field instead of _id
    const firstOrderId = firstOrder.id || String(firstOrder._id || '')
    const populatedOrder = await Order.findOne({ id: firstOrderId })
      .populate('employeeId', 'id firstName lastName email')
      .populate('companyId', 'id name')
      .populate('items.uniformId', 'id name')
      .lean()
    
    // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
    // Manually fetch vendor information if vendorId exists
    let vendorName = null
    if (populatedOrder && (populatedOrder as any).vendorId) {
      const vendorIdValue = (populatedOrder as any).vendorId
      // vendorId is now a string (6-digit numeric), not ObjectId
      if (typeof vendorIdValue === 'string' && /^\d{6}$/.test(vendorIdValue)) {
        const vendor = await Vendor.findOne({ id: vendorIdValue }).select('id name').lean()
        if (vendor) {
          vendorName = (vendor as any).name
        }
      }
    }
    
    const result = toPlainObject(populatedOrder)
    if (vendorName) {
      (result as any).vendorName = vendorName
    }
    
    return result
  } else {
    // Legacy approval flow (no PR workflow)
    console.log(`[approveOrderByParentId] Processing legacy approval for parent order ${parentOrderId}`)
  
  const canApprove = await canApproveOrders(adminEmail, company.id)
  if (!canApprove) {
    throw new Error(`User ${adminEmail} does not have permission to approve orders`)
  }
  
  // CRITICAL FIX: Approve ALL child orders (including those that skipped approval)
  // This ensures all vendor orders are synchronized to "Awaiting fulfilment" status
  // and are visible to vendors after parent approval
  console.log(`[approveOrderByParentId] 🔄 Updating all child orders to 'Awaiting fulfilment' status...`)
  
  let updatedCount = 0
  for (const childOrder of childOrders) {
    const previousStatus = childOrder.status
    if (childOrder.status === 'Awaiting approval' || childOrder.status === 'Awaiting fulfilment') {
      childOrder.status = 'Awaiting fulfilment'
      await childOrder.save()
      updatedCount++
      console.log(`[approveOrderByParentId] ✅ Updated order ${childOrder.id}: ${previousStatus} → Awaiting fulfilment`)
      console.log(`[approveOrderByParentId]    Vendor: ${(childOrder as any).vendorName || 'N/A'} (${childOrder.vendorId?.toString() || 'N/A'})`)
    } else {
      console.log(`[approveOrderByParentId] ⚠️ Skipping order ${childOrder.id} (status: ${previousStatus}, not awaiting approval/fulfilment)`)
    }
  }
  
  console.log(`[approveOrderByParentId] ✅ Updated ${updatedCount} of ${childOrders.length} child order(s)`)
  
  // CRITICAL: Verify all orders were updated correctly
  const verifyOrders = await Order.find({ parentOrderId: parentOrderId }).select('id status vendorId vendorName').lean()
  console.log(`[approveOrderByParentId] 🔍 Verification - Orders after approval:`)
  verifyOrders.forEach((order, idx) => {
    console.log(`[approveOrderByParentId]   ${idx + 1}. ${order.id}: status=${order.status}, vendorId=${order.vendorId?.toString() || 'N/A'}, vendorName=${(order as any).vendorName || 'N/A'}`)
  })
  
  // Return the first order as representative - use string id field instead of _id
  const firstOrderId = firstOrder.id || String(firstOrder._id || '')
  const populatedOrder = await Order.findOne({ id: firstOrderId })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Manually fetch vendor information if vendorId exists
  let vendorName = null
  if (populatedOrder && (populatedOrder as any).vendorId) {
    const vendorIdValue = (populatedOrder as any).vendorId
    // vendorId is now a string (6-digit numeric), not ObjectId
    if (typeof vendorIdValue === 'string' && /^\d{6}$/.test(vendorIdValue)) {
      const vendor = await Vendor.findOne({ id: vendorIdValue }).select('id name').lean()
      if (vendor) {
        vendorName = (vendor as any).name
      }
    }
  }
  
  const result = toPlainObject(populatedOrder)
  if (vendorName) {
    (result as any).vendorName = vendorName
  }
  
  return result
  }
}

export async function bulkApproveOrders(orderIds: string[], adminEmail: string, prDataMap?: Map<string, { prNumber: string, prDate: Date }>): Promise<{ success: string[], failed: Array<{ orderId: string, error: string }> }> {
  await connectDB()
  
  const results = {
    success: [] as string[],
    failed: [] as Array<{ orderId: string, error: string }>
  }
  
  // Verify admin can approve orders (check once for all orders)
  // Find employee by email (handle encryption)
  // Use the same pattern as canApproveOrders for reliable lookup
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = adminEmail.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // Try finding with encrypted email first
  let employee = await Employee.findOne({ email: encryptedEmail }).lean()
  
  // If not found, try decryption matching
  if (!employee && encryptedEmail) {
    const allEmployees = await Employee.find({}).lean()
    for (const emp of allEmployees) {
      if (emp.email && typeof emp.email === 'string') {
        try {
          const decryptedEmail = decrypt(emp.email)
          if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
            employee = emp
            break
          }
        } catch (error) {
          continue
        }
      }
    }
  }
  
  if (!employee) {
    throw new Error(`Employee not found: ${adminEmail}`)
  }
  
  // Track processed parentOrderIds to avoid duplicate approvals
  const processedParentIds = new Set<string>()
  
  // Process each order
  for (const orderId of orderIds) {
    try {
      // First, try to find order by id field
      let order = await Order.findOne({ id: orderId })
      
      // If not found by id, check if orderId is a parentOrderId (from grouped approval view)
      if (!order) {
        const ordersWithParent = await Order.find({ parentOrderId: orderId })
        if (ordersWithParent.length > 0) {
          // This is a parent order ID, approve all child orders
          if (processedParentIds.has(orderId)) {
            // Already processed this parent order, skip
            results.success.push(orderId)
            continue
          }
          processedParentIds.add(orderId)
          
          // Approve all orders with this parentOrderId
          const childOrders = await Order.find({ parentOrderId: orderId })
          if (childOrders.length === 0) {
            results.failed.push({ orderId, error: 'No child orders found' })
            continue
          }
          
          // Verify admin can approve orders for this company (check once per parent)
          // CRITICAL FIX: childOrders[0].companyId is a STRING ID (6-digit numeric), not ObjectId
          const childCompanyIdStr = String(childOrders[0].companyId)
          let company: any = null
          
          if (/^\d{6}$/.test(childCompanyIdStr)) {
            // It's a string ID - use findOne
            company = await Company.findOne({ id: childCompanyIdStr })
          } else if (mongoose.Types.ObjectId.isValid(childCompanyIdStr) && /^[0-9a-fA-F]{24}$/.test(childCompanyIdStr)) {
            // It's an ObjectId string - try findById (legacy support)
            company = await Company.findById(childCompanyIdStr)
          } else {
            // Try as string ID anyway
            company = await Company.findOne({ id: childCompanyIdStr })
          }
          
          // Fallback: Try alternative lookup methods if company not found
          if (!company) {
            console.log(`[bulkApproveOrders] Company not found by string ID ${childCompanyIdStr}, trying alternative lookup methods`)
            
            // Try lookup by business ID (companyIdNum from order)
            if (childOrders[0].companyIdNum) {
              company = await Company.findOne({ id: String(childOrders[0].companyIdNum) })
            }
            
            // If still not found, try to extract companyId from order.companyId if it's an object
            if (!company && childOrders[0].companyId && typeof childOrders[0].companyId === 'object') {
              const companyIdFromOrder = (childOrders[0].companyId as any).id || (childOrders[0].companyId as any)._id
              if (companyIdFromOrder) {
                if (/^\d{6}$/.test(String(companyIdFromOrder))) {
                  company = await Company.findOne({ id: String(companyIdFromOrder) })
                }
              }
            }
          }
          
          if (!company) {
            results.failed.push({ orderId, error: 'Company not found' })
            continue
          }
          
          // Check if this is a site admin approval (PR workflow)
          const firstChildOrderPRStatus = childOrders[0].pr_status
          const isSiteAdminApproval = firstChildOrderPRStatus === 'PENDING_SITE_ADMIN_APPROVAL'
          const isCompanyAdminApproval = firstChildOrderPRStatus === 'PENDING_COMPANY_ADMIN_APPROVAL'
          
          if (isSiteAdminApproval) {
            // Site Admin approval flow for split orders
            // REQUIRED: Validate PR data is provided
            const prData = prDataMap?.get(orderId)
            if (!prData || !prData.prNumber || !prData.prNumber.trim() || !prData.prDate) {
              results.failed.push({ orderId, error: 'PR Number and PR Date are required for site admin approval' })
              continue
            }
            
            // Get the first order's employee (the one who placed the order)
            // CRITICAL FIX: childOrders[0].employeeId is a STRING ID (6-digit numeric), not ObjectId
            const employeeIdStr = String(childOrders[0].employeeId)
            let orderEmployee: any = null
            if (/^\d{6}$/.test(employeeIdStr)) {
              orderEmployee = await Employee.findOne({ id: employeeIdStr }).lean()
            } else {
              orderEmployee = await Employee.findOne({ employeeId: employeeIdStr }).lean()
            }
            
            if (!orderEmployee || !orderEmployee.locationId) {
              results.failed.push({ orderId, error: 'Order employee not found or has no location' })
              continue
            }
            
            // Verify user is a Site Admin (Location Admin) for the order's employee's location
            const Location = require('../models/Location').default
            const employeeLocation = await Location.findOne({ id: orderEmployee.locationId }).lean()
            
            if (!employeeLocation || !employeeLocation.adminId) {
              results.failed.push({ orderId, error: 'Location not found or has no admin' })
              continue
            }
            
            // Check if approving user is the location admin
            // CRITICAL FIX: Use string ID comparison, not ObjectId
            const locationAdminIdStr = String(employeeLocation.adminId)
            const approvingEmployeeIdStr = String(employee.id || employee.employeeId)
            
            if (locationAdminIdStr !== approvingEmployeeIdStr) {
              // Fallback: try numeric ID comparison
              let locationAdminEmployee: any = null
              if (/^\d{6}$/.test(locationAdminIdStr)) {
                locationAdminEmployee = await Employee.findOne({ id: locationAdminIdStr }).lean()
              } else {
                locationAdminEmployee = await Employee.findOne({ employeeId: locationAdminIdStr }).lean()
              }
              
              if (locationAdminEmployee && (locationAdminEmployee.id || locationAdminEmployee.employeeId)) {
                const locationAdminEmployeeId = locationAdminEmployee.id || locationAdminEmployee.employeeId
                const approvingEmployeeIdNum = employee.id || employee.employeeId
                if (locationAdminEmployeeId && approvingEmployeeIdNum && locationAdminEmployeeId.toString() === approvingEmployeeIdNum.toString()) {
                  // Authorization passed via numeric ID
                } else {
                  results.failed.push({ orderId, error: 'User is not the Site Admin for this order\'s location' })
                  continue
                }
              } else {
                results.failed.push({ orderId, error: 'User is not the Site Admin for this order\'s location' })
                continue
              }
            }
            
            // Site admin can approve - update all child orders with PR data
            for (const childOrder of childOrders) {
              // Set PR number and date
              childOrder.pr_number = prData.prNumber.trim()
              childOrder.pr_date = prData.prDate
              childOrder.pr_status = 'SITE_ADMIN_APPROVED'
              // CRITICAL FIX: Use string ID, not ObjectId
              childOrder.site_admin_approved_by = employee.id || employee.employeeId
              childOrder.site_admin_approved_at = new Date()
              
              if (company.require_company_admin_po_approval === true) {
                childOrder.pr_status = 'PENDING_COMPANY_ADMIN_APPROVAL'
              } else {
                childOrder.status = 'Awaiting fulfilment'
              }
              
              await childOrder.save()
            }
            
            results.success.push(orderId)
            continue
          } else if (isCompanyAdminApproval) {
            // Company Admin approval flow
            const canApprove = await canApproveOrders(adminEmail, company.id)
            if (!canApprove) {
              results.failed.push({ orderId, error: 'User does not have permission to approve orders as Company Admin' })
              continue
            }
            
            // Update all child orders with company admin approval
            for (const childOrder of childOrders) {
              childOrder.pr_status = 'COMPANY_ADMIN_APPROVED'
              // CRITICAL FIX: Use string ID, not ObjectId
              childOrder.company_admin_approved_by = employee.id || employee.employeeId
              childOrder.company_admin_approved_at = new Date()
              childOrder.status = 'Awaiting fulfilment'
              await childOrder.save()
            }
            
            results.success.push(orderId)
            continue
          } else {
            // Legacy approval flow (no PR workflow)
          const canApprove = await canApproveOrders(adminEmail, company.id)
          if (!canApprove) {
            results.failed.push({ orderId, error: 'User does not have permission to approve orders' })
            continue
          }
          
          // Approve all child orders
          for (const childOrder of childOrders) {
            if (childOrder.status === 'Awaiting approval' || childOrder.status === 'Awaiting fulfilment') {
              childOrder.status = 'Awaiting fulfilment'
              await childOrder.save()
            }
          }
          
          results.success.push(orderId)
          continue
          }
        }
        
        // If still not found, mark as failed
        results.failed.push({ orderId, error: 'Order not found' })
        continue
      }
      
      // If this order has a parentOrderId, check if we've already processed it
      if (order.parentOrderId) {
        if (processedParentIds.has(order.parentOrderId)) {
          // Already processed this parent order, skip
          results.success.push(orderId)
          continue
        }
        processedParentIds.add(order.parentOrderId)
        
        // Approve all orders with this parentOrderId
        const childOrders = await Order.find({ parentOrderId: order.parentOrderId })
        if (childOrders.length === 0) {
          results.failed.push({ orderId, error: 'No child orders found' })
          continue
        }
        
        // Verify admin can approve orders for this company (check once per parent)
        // CRITICAL FIX: order.companyId is a STRING ID (6-digit numeric), not ObjectId
        const orderCompanyIdStr = String(order.companyId)
        let company: any = null
        
        if (/^\d{6}$/.test(orderCompanyIdStr)) {
          // It's a string ID - use findOne
          company = await Company.findOne({ id: orderCompanyIdStr })
        } else if (mongoose.Types.ObjectId.isValid(orderCompanyIdStr) && /^[0-9a-fA-F]{24}$/.test(orderCompanyIdStr)) {
          // It's an ObjectId string - try findById (legacy support)
          company = await Company.findById(orderCompanyIdStr)
        } else {
          // Try as string ID anyway
          company = await Company.findOne({ id: orderCompanyIdStr })
        }
        
        // Fallback: Try alternative lookup methods if company not found
        if (!company) {
          console.log(`[bulkApproveOrders] Company not found by string ID ${orderCompanyIdStr}, trying alternative lookup methods`)
          
          // Try lookup by business ID (companyIdNum from order)
          if (order.companyIdNum) {
            company = await Company.findOne({ id: String(order.companyIdNum) })
          }
          
          // If still not found, try to extract companyId from order.companyId if it's an object
          if (!company && order.companyId && typeof order.companyId === 'object') {
            const companyIdFromOrder = (order.companyId as any).id || (order.companyId as any)._id
            if (companyIdFromOrder) {
              if (/^\d{6}$/.test(String(companyIdFromOrder))) {
                company = await Company.findOne({ id: String(companyIdFromOrder) })
              }
            }
          }
        }
        
        if (!company) {
          results.failed.push({ orderId, error: 'Company not found' })
          continue
        }
        
        // Check if this is a site admin approval (PR workflow)
        const firstChildOrderPRStatus = childOrders[0].pr_status
        const isSiteAdminApproval = firstChildOrderPRStatus === 'PENDING_SITE_ADMIN_APPROVAL'
        const isCompanyAdminApproval = firstChildOrderPRStatus === 'PENDING_COMPANY_ADMIN_APPROVAL'
        
        if (isSiteAdminApproval) {
          // Site Admin approval flow for split orders
          // Get the first order's employee (the one who placed the order)
          // CRITICAL FIX: childOrders[0].employeeId is a STRING ID (6-digit numeric), not ObjectId
          const employeeIdStr = String(childOrders[0].employeeId)
          let orderEmployee: any = null
          if (/^\d{6}$/.test(employeeIdStr)) {
            orderEmployee = await Employee.findOne({ id: employeeIdStr }).lean()
          } else {
            orderEmployee = await Employee.findOne({ employeeId: employeeIdStr }).lean()
          }
          
          if (!orderEmployee || !orderEmployee.locationId) {
            results.failed.push({ orderId, error: 'Order employee not found or has no location' })
            continue
          }
          
          // Verify user is a Site Admin (Location Admin) for the order's employee's location
          const Location = require('../models/Location').default
          const employeeLocation = await Location.findOne({ id: orderEmployee.locationId }).lean()
          
          if (!employeeLocation || !employeeLocation.adminId) {
            results.failed.push({ orderId, error: 'Location not found or has no admin' })
            continue
          }
          
          // Check if approving user is the location admin
          // CRITICAL FIX: Use string ID comparison, not ObjectId
          const locationAdminIdStr = String(employeeLocation.adminId)
          const approvingEmployeeIdStr = String(employee.id || employee.employeeId)
          
          if (locationAdminIdStr !== approvingEmployeeIdStr) {
            // Fallback: try numeric ID comparison
            let locationAdminEmployee: any = null
            if (/^\d{6}$/.test(locationAdminIdStr)) {
              locationAdminEmployee = await Employee.findOne({ id: locationAdminIdStr }).lean()
            } else {
              locationAdminEmployee = await Employee.findOne({ employeeId: locationAdminIdStr }).lean()
            }
            
            if (locationAdminEmployee && (locationAdminEmployee.id || locationAdminEmployee.employeeId)) {
              const locationAdminEmployeeId = locationAdminEmployee.id || locationAdminEmployee.employeeId
              const approvingEmployeeIdNum = employee.id || employee.employeeId
              if (locationAdminEmployeeId && approvingEmployeeIdNum && locationAdminEmployeeId.toString() === approvingEmployeeIdNum.toString()) {
                // Authorization passed via numeric ID
              } else {
                results.failed.push({ orderId, error: 'User is not the Site Admin for this order\'s location' })
                continue
              }
            } else {
              results.failed.push({ orderId, error: 'User is not the Site Admin for this order\'s location' })
              continue
            }
          }
          
          // Site admin can approve - update all child orders
          for (const childOrder of childOrders) {
            childOrder.pr_status = 'SITE_ADMIN_APPROVED'
            // CRITICAL FIX: Use string ID, not ObjectId
            childOrder.site_admin_approved_by = employee.id || employee.employeeId
            childOrder.site_admin_approved_at = new Date()
            
            if (company.require_company_admin_po_approval === true) {
              childOrder.pr_status = 'PENDING_COMPANY_ADMIN_APPROVAL'
            } else {
              childOrder.status = 'Awaiting fulfilment'
            }
            
            await childOrder.save()
          }
          
          results.success.push(orderId)
        } else if (isCompanyAdminApproval) {
          // Company Admin approval flow
          const canApprove = await canApproveOrders(adminEmail, company.id)
          if (!canApprove) {
            results.failed.push({ orderId, error: 'User does not have permission to approve orders as Company Admin' })
            continue
          }
          
          // Update all child orders with company admin approval
          for (const childOrder of childOrders) {
            childOrder.pr_status = 'COMPANY_ADMIN_APPROVED'
            // CRITICAL FIX: Use string ID, not ObjectId
            childOrder.company_admin_approved_by = employee.id || employee.employeeId
            childOrder.company_admin_approved_at = new Date()
            childOrder.status = 'Awaiting fulfilment'
            await childOrder.save()
          }
          
          results.success.push(orderId)
        } else {
          // Legacy approval flow (no PR workflow)
        const canApprove = await canApproveOrders(adminEmail, company.id)
        if (!canApprove) {
          results.failed.push({ orderId, error: 'User does not have permission to approve orders' })
          continue
        }
        
        // Approve all child orders
        for (const childOrder of childOrders) {
          if (childOrder.status === 'Awaiting approval' || childOrder.status === 'Awaiting fulfilment') {
            childOrder.status = 'Awaiting fulfilment'
            await childOrder.save()
          }
        }
        
        results.success.push(orderId)
        }
      } else {
        // Standalone order
        // For PR workflow, check pr_status instead of status
        const orderIsSiteAdminApproval = order.pr_status === 'PENDING_SITE_ADMIN_APPROVAL'
        const orderIsCompanyAdminApproval = order.pr_status === 'PENDING_COMPANY_ADMIN_APPROVAL'
        
        // Only check status for legacy orders (no PR workflow)
        if (!orderIsSiteAdminApproval && !orderIsCompanyAdminApproval && order.status !== 'Awaiting approval') {
        results.failed.push({ orderId, error: `Order is not in 'Awaiting approval' status (current: ${order.status})` })
        continue
      }
      
      // Verify admin can approve orders for this company
      // Use raw MongoDB for reliable ObjectId lookup
      const db = mongoose.connection.db
      let company = null
      
      // CRITICAL FIX: order.companyId is a STRING ID (6-digit), not ObjectId
      // Try string ID lookup first
      const companyIdStr = String(order.companyId)
      if (/^\d{6}$/.test(companyIdStr)) {
        // It's a string ID - use findOne
        company = await Company.findOne({ id: companyIdStr })
      } else if (mongoose.Types.ObjectId.isValid(companyIdStr) && /^[0-9a-fA-F]{24}$/.test(companyIdStr)) {
        // It's an ObjectId string - use findById
        company = await Company.findById(companyIdStr)
      } else {
        // Try as string ID anyway
        company = await Company.findOne({ id: companyIdStr })
      }
      
      // Fallback: Use raw MongoDB if Mongoose lookup fails
      if (!company && db) {
        // Try to find company by string ID in raw collection
        const rawCompany = await db.collection('companies').findOne({ id: companyIdStr })
        if (rawCompany && rawCompany.id) {
          company = await Company.findOne({ id: rawCompany.id })
        }
        
        // If still not found, try lookup by business ID
        if (!company && order.companyIdNum) {
          company = await Company.findOne({ id: String(order.companyIdNum) })
        }
      }
      
      if (!company) {
        results.failed.push({ orderId, error: 'Company not found' })
        continue
      }
      
        if (orderIsSiteAdminApproval) {
        // Site Admin approval - REQUIRED: Validate PR data is provided
        const prData = prDataMap?.get(orderId)
        if (!prData || !prData.prNumber || !prData.prNumber.trim() || !prData.prDate) {
          results.failed.push({ orderId, error: 'PR Number and PR Date are required for site admin approval' })
          continue
        }
        
        // Site Admin approval - check if user is location admin
        const { encrypt, decrypt } = require('../utils/encryption')
        const trimmedEmail = adminEmail.trim()
        let encryptedEmail: string
        
        try {
          encryptedEmail = encrypt(trimmedEmail)
        } catch (error) {
          encryptedEmail = ''
        }
        
        // Find approving employee
        let approvingEmployee = await Employee.findOne({ email: encryptedEmail }).lean()
        if (!approvingEmployee && encryptedEmail) {
          const allEmployees = await Employee.find({}).lean()
          for (const emp of allEmployees) {
            if (emp.email && typeof emp.email === 'string') {
              try {
                const decryptedEmail = decrypt(emp.email)
                if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
                  approvingEmployee = emp
                  break
                }
              } catch (error) {
                continue
              }
            }
          }
        }
        
        if (!approvingEmployee) {
          results.failed.push({ orderId, error: 'Employee not found' })
          continue
        }
        
        // Get order's employee and their location
        // CRITICAL FIX: order.employeeId is a STRING ID (6-digit numeric), not ObjectId
        const employeeIdStr = String(order.employeeId)
        let orderEmployee: any = null
        if (/^\d{6}$/.test(employeeIdStr)) {
          orderEmployee = await Employee.findOne({ id: employeeIdStr }).lean()
        } else {
          orderEmployee = await Employee.findOne({ employeeId: employeeIdStr }).lean()
        }
        
        if (!orderEmployee || !orderEmployee.locationId) {
          results.failed.push({ orderId, error: 'Order employee not found or has no location' })
          continue
        }
        
        // Verify user is location admin
        const Location = require('../models/Location').default
        const employeeLocation = await Location.findOne({ id: orderEmployee.locationId }).lean()
        
        if (!employeeLocation || !employeeLocation.adminId) {
          results.failed.push({ orderId, error: 'Location not found or has no admin' })
          continue
        }
        
        // Check if approving user is the location admin
        // CRITICAL FIX: Use string ID comparison, not ObjectId
        const locationAdminIdStr = String(employeeLocation.adminId)
        const approvingEmployeeIdStr = String(approvingEmployee.id || approvingEmployee.employeeId)
        
        if (locationAdminIdStr !== approvingEmployeeIdStr) {
          // Fallback: try numeric ID comparison
          let locationAdminEmployee: any = null
          if (/^\d{6}$/.test(locationAdminIdStr)) {
            locationAdminEmployee = await Employee.findOne({ id: locationAdminIdStr }).lean()
          } else {
            locationAdminEmployee = await Employee.findOne({ employeeId: locationAdminIdStr }).lean()
          }
          
          if (locationAdminEmployee && (locationAdminEmployee.id || locationAdminEmployee.employeeId)) {
            const locationAdminEmployeeId = locationAdminEmployee.id || locationAdminEmployee.employeeId
            const approvingEmployeeIdNum = approvingEmployee.id || approvingEmployee.employeeId
            if (locationAdminEmployeeId && approvingEmployeeIdNum && locationAdminEmployeeId.toString() === approvingEmployeeIdNum.toString()) {
              // Authorization passed via numeric ID
            } else {
              results.failed.push({ orderId, error: 'User is not the Site Admin for this order\'s location' })
              continue
            }
          } else {
            results.failed.push({ orderId, error: 'User is not the Site Admin for this order\'s location' })
            continue
          }
        }
        
        // Site admin can approve - update PR status with PR data
        order.pr_number = prData.prNumber.trim()
        order.pr_date = prData.prDate
        order.pr_status = 'SITE_ADMIN_APPROVED'
        // CRITICAL FIX: Use string ID, not ObjectId
        order.site_admin_approved_by = approvingEmployee.id || approvingEmployee.employeeId
        order.site_admin_approved_at = new Date()
        
        // Check if company admin approval is required
        if (company.require_company_admin_po_approval === true) {
          order.pr_status = 'PENDING_COMPANY_ADMIN_APPROVAL'
        } else {
          order.status = 'Awaiting fulfilment'
        }
        
        await order.save()
        results.success.push(orderId)
      } else if (orderIsCompanyAdminApproval) {
        // Company Admin approval flow
      const canApprove = await canApproveOrders(adminEmail, company.id)
      if (!canApprove) {
          results.failed.push({ orderId, error: 'User does not have permission to approve orders as Company Admin' })
        continue
      }
      
      // Update order status
        order.pr_status = 'COMPANY_ADMIN_APPROVED'
        // CRITICAL FIX: Use string ID, not ObjectId
        order.company_admin_approved_by = employee.id || employee.employeeId
        order.company_admin_approved_at = new Date()
      order.status = 'Awaiting fulfilment'
        
      await order.save()
        results.success.push(orderId)
      } else {
        // Legacy approval flow (no PR workflow) - check canApproveOrders
        const canApprove = await canApproveOrders(adminEmail, company.id)
        if (!canApprove) {
          results.failed.push({ orderId, error: 'User does not have permission to approve orders' })
          continue
        }
        
        // Update order status
        order.status = 'Awaiting fulfilment'
        await order.save()
      results.success.push(orderId)
      }
      }
    } catch (error: any) {
      results.failed.push({ orderId, error: error.message || 'Unknown error' })
    }
  }
  
  return results
}

export async function updateOrderStatus(orderId: string, status: 'Awaiting approval' | 'Awaiting fulfilment' | 'Dispatched' | 'Delivered', requestingVendorId?: string): Promise<any> {
  console.log(`\n[updateOrderStatus] 🚀 ========== STARTING ORDER STATUS UPDATE ==========`)
  console.log(`[updateOrderStatus] 📋 Parameters: orderId=${orderId}, status=${status}, requestingVendorId=${requestingVendorId || 'N/A'}`)
  console.log(`[updateOrderStatus] ⏰ Timestamp: ${new Date().toISOString()}`)
  
  await connectDB()
  console.log(`[updateOrderStatus] ✅ Database connected`)
  
  // First, get order without populate to see raw data
  const orderRaw = await Order.findOne({ id: orderId }).lean()
  if (!orderRaw) {
    console.error(`[updateOrderStatus] ❌ Order not found: ${orderId}`)
    throw new Error(`Order not found: ${orderId}`)
  }
  
  console.log(`[updateOrderStatus] 🔍 Raw order data:`, {
    orderId: orderRaw.id,
    vendorIdRaw: orderRaw.vendorId,
    vendorIdType: typeof orderRaw.vendorId,
    vendorName: (orderRaw as any).vendorName,
    status: orderRaw.status
  })
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, NOT an ObjectId
  // Get order without populate since vendorId is a string field
  const order = await Order.findOne({ id: orderId })
    .populate('items.uniformId', 'id')
  
  if (!order) {
    console.error(`[updateOrderStatus] ❌ Order not found: ${orderId}`)
    throw new Error(`Order not found: ${orderId}`)
  }
  
  // Extract vendorId - should be a 6-digit numeric string
  let vendorIdValue: string | null = null
  
  // vendorId is stored as a 6-digit numeric string in the order
  if (orderRaw.vendorId) {
    if (typeof orderRaw.vendorId === 'string') {
      vendorIdValue = orderRaw.vendorId.trim()
      // Validate it's a 6-digit numeric string
      if (!/^\d{6}$/.test(vendorIdValue)) {
        console.warn(`[updateOrderStatus] ⚠️ Order has invalid vendorId format: ${vendorIdValue} (expected 6-digit numeric string)`)
        // Try to find vendor by this ID anyway (might be legacy data)
        const vendor = await Vendor.findOne({ id: vendorIdValue })
        if (vendor) {
          console.log(`[updateOrderStatus] ✅ Found vendor with ID: ${vendorIdValue}`)
        } else {
          console.error(`[updateOrderStatus] ❌ Vendor not found for vendorId: ${vendorIdValue}`)
        }
      } else {
        console.log(`[updateOrderStatus] ✅ Valid vendorId found: ${vendorIdValue}`)
      }
    } else if (orderRaw.vendorId instanceof mongoose.Types.ObjectId) {
      // Legacy: Handle ObjectId vendorId - convert to numeric ID
      console.log(`[updateOrderStatus] ⚠️ Legacy ObjectId vendorId detected, converting to numeric ID...`)
      const legacyVendor = await Vendor.findById(orderRaw.vendorId)
      if (legacyVendor && legacyVendor.id) {
        vendorIdValue = String(legacyVendor.id).trim()
        // Update order to use numeric ID
        await Order.updateOne({ id: orderId }, { vendorId: vendorIdValue })
        console.log(`[updateOrderStatus] ✅ Migrated order to use numeric vendorId: ${vendorIdValue}`)
      } else {
        console.error(`[updateOrderStatus] ❌ Could not find vendor for legacy ObjectId: ${orderRaw.vendorId}`)
      }
    } else {
      console.warn(`[updateOrderStatus] ⚠️ Unexpected vendorId type: ${typeof orderRaw.vendorId}`)
    }
  }
  
  // Fallback: Try to find vendor by name if vendorId is missing
  if (!vendorIdValue && (orderRaw as any).vendorName) {
    console.log(`[updateOrderStatus] ⚠️ Order has vendorName but no vendorId, attempting to find vendor by name: ${(orderRaw as any).vendorName}`)
    const vendorByName = await Vendor.findOne({ name: (orderRaw as any).vendorName })
    if (vendorByName && vendorByName.id) {
      vendorIdValue = String(vendorByName.id).trim()
      // Update the order with the vendorId for future use
      await Order.updateOne({ id: orderId }, { vendorId: vendorIdValue })
      console.log(`[updateOrderStatus] ✅ Found and updated vendorId for order: ${vendorIdValue}`)
    } else {
      console.error(`[updateOrderStatus] ❌ Could not find vendor by name: ${(orderRaw as any).vendorName}`)
    }
  }
  
  console.log(`[updateOrderStatus] ✅ Order found:`, {
    orderId: order.id,
    currentStatus: order.status,
    vendorId: vendorIdValue || 'N/A',
    vendorName: (orderRaw as any).vendorName || 'N/A',
    itemsCount: order.items?.length || 0
  })
  
  // CRITICAL SECURITY: Validate vendor authorization if requestingVendorId is provided
  // This ensures vendors can ONLY update orders that belong to them
  if (requestingVendorId) {
    console.log(`[updateOrderStatus] 🔒 Validating vendor authorization...`)
    console.log(`[updateOrderStatus]   Requesting vendor ID: ${requestingVendorId}`)
    console.log(`[updateOrderStatus]   Order vendor ID: ${vendorIdValue || 'N/A'}`)
    
    // Validate requestingVendorId is a 6-digit numeric string
    const requestingVendorIdClean = String(requestingVendorId).trim()
    if (!/^\d{6}$/.test(requestingVendorIdClean)) {
      console.error(`[updateOrderStatus] ❌ SECURITY VIOLATION: Invalid requestingVendorId format: ${requestingVendorId}`)
      throw new Error(`Vendor authorization failed: Invalid vendor ID format`)
    }
    
    // Compare numeric vendor IDs directly
    if (vendorIdValue && vendorIdValue !== requestingVendorIdClean) {
      console.error(`[updateOrderStatus] ❌❌❌ CRITICAL SECURITY VIOLATION: VENDOR AUTHORIZATION FAILED ❌❌❌`)
      console.error(`[updateOrderStatus]   Requesting vendor ID: ${requestingVendorIdClean}`)
      console.error(`[updateOrderStatus]   Order belongs to vendor ID: ${vendorIdValue}`)
      console.error(`[updateOrderStatus]   Order ID: ${orderId}`)
      console.error(`[updateOrderStatus]   Attempted action: Update status to ${status}`)
      throw new Error(`Authorization failed: You do not have permission to update this order. This order belongs to a different vendor.`)
    }
    
    if (!vendorIdValue) {
      console.error(`[updateOrderStatus] ❌ SECURITY VIOLATION: Order has no vendorId assigned`)
      throw new Error(`Vendor authorization failed: Order does not have a vendor assigned`)
    }
    
    console.log(`[updateOrderStatus] ✅ Vendor authorization validated: Vendor ${requestingVendorIdClean} owns this order`)
  } else {
    console.log(`[updateOrderStatus] ⚠️ No requestingVendorId provided - skipping vendor authorization check`)
    console.log(`[updateOrderStatus] ⚠️ This should only happen for admin/system updates, not vendor updates`)
  }
  
  // CRITICAL VALIDATION: Prevent "Dispatched" status without valid transition
  // This ensures status integrity - "Dispatched" should ONLY be set when vendor explicitly dispatches
  // and order is in "Awaiting fulfilment" status
  if (status === 'Dispatched') {
    console.log(`[updateOrderStatus] 🔒 Validating Dispatched status transition...`)
    
    // Check if this is a valid transition
    const validTransitionsToDispatched = ['Awaiting fulfilment']
    if (!validTransitionsToDispatched.includes(order.status)) {
      console.error(`[updateOrderStatus] ❌ INVALID STATUS TRANSITION: Cannot transition from "${order.status}" to "Dispatched"`)
      console.error(`[updateOrderStatus] ❌ Valid transitions to "Dispatched": ${validTransitionsToDispatched.join(', ')}`)
      console.error(`[updateOrderStatus] ❌ Order ID: ${orderId}, Current Status: ${order.status}`)
      throw new Error(`Invalid status transition: Cannot mark order as "Dispatched" from "${order.status}" status. Order must be in "Awaiting fulfilment" status first.`)
    }
    
    // Additional validation: Ensure vendor is authorized (already checked above, but log for audit)
    if (!requestingVendorId) {
      console.warn(`[updateOrderStatus] ⚠️ WARNING: Setting status to "Dispatched" without requestingVendorId`)
      console.warn(`[updateOrderStatus] ⚠️ This should only happen for admin/system updates, not vendor updates`)
    }
    
    console.log(`[updateOrderStatus] ✅ Dispatched status transition validated: ${order.status} -> Dispatched`)
  }
  
  const previousStatus = order.status
  order.status = status
  
  // OPTION 1 ENHANCEMENT: Automatically set all required shipment/delivery fields
  // This ensures GRN eligibility works correctly when vendors mark orders as Dispatched/Delivered
  
  if (status === 'Dispatched') {
    console.log(`[updateOrderStatus] 📦 Setting shipment fields for Dispatched status...`)
    
    // Set dispatch status
    order.dispatchStatus = 'SHIPPED'
    
    // Set dispatched date if not already set
    if (!order.dispatchedDate) {
      order.dispatchedDate = new Date()
    }
    
    // Update all items: set dispatchedQuantity = quantity if not already set
    const items = order.items || []
    const updatedItems = items.map((item: any) => {
      const dispatchedQty = item.dispatchedQuantity || item.quantity || 0
      const deliveredQty = item.deliveredQuantity || 0
      
      // Determine item shipment status
      let itemShipmentStatus: 'PENDING' | 'DISPATCHED' | 'DELIVERED' = 'PENDING'
      if (deliveredQty >= item.quantity && item.quantity > 0) {
        itemShipmentStatus = 'DELIVERED'
      } else if (dispatchedQty > 0) {
        itemShipmentStatus = 'DISPATCHED'
      }
      
      return {
        ...item.toObject(),
        dispatchedQuantity: dispatchedQty,
        deliveredQuantity: deliveredQty,
        itemShipmentStatus
      }
    })
    
    order.items = updatedItems as any
    console.log(`[updateOrderStatus] ✅ Set dispatchStatus=SHIPPED, dispatchedQuantity for ${items.length} item(s)`)
  }
  
  if (status === 'Delivered') {
    console.log(`[updateOrderStatus] 📦 Setting delivery fields for Delivered status...`)
    
    // Set delivery status
    order.deliveryStatus = 'DELIVERED'
    
    // Set delivered date if not already set
    if (!order.deliveredDate) {
      order.deliveredDate = new Date()
    }
    
    // Ensure dispatch status is set (should be SHIPPED before delivery)
    if (!order.dispatchStatus || order.dispatchStatus === 'AWAITING_FULFILMENT') {
      order.dispatchStatus = 'SHIPPED'
      if (!order.dispatchedDate) {
        order.dispatchedDate = order.deliveredDate // Use delivered date as fallback
      }
    }
    
    // Update all items: set deliveredQuantity = quantity if not already set
    const items = order.items || []
    const updatedItems = items.map((item: any) => {
      const orderedQty = item.quantity || 0
      const dispatchedQty = item.dispatchedQuantity || orderedQty // Default to ordered quantity if not set
      const deliveredQty = item.deliveredQuantity || orderedQty // Default to ordered quantity if not set
      
      // Ensure deliveredQuantity doesn't exceed ordered quantity
      const finalDeliveredQty = Math.min(deliveredQty, orderedQty)
      
      // Determine item shipment status
      let itemShipmentStatus: 'PENDING' | 'DISPATCHED' | 'DELIVERED' = 'DELIVERED'
      if (finalDeliveredQty < orderedQty) {
        itemShipmentStatus = 'DISPATCHED' // Partial delivery
      }
      
      return {
        ...item.toObject(),
        dispatchedQuantity: dispatchedQty,
        deliveredQuantity: finalDeliveredQty,
        itemShipmentStatus
      }
    })
    
    order.items = updatedItems as any
    console.log(`[updateOrderStatus] ✅ Set deliveryStatus=DELIVERED, deliveredQuantity for ${items.length} item(s)`)
    
    // Trigger PO status update after marking as delivered
    try {
      await updatePOStatusFromPRDelivery(orderId)
      console.log(`[updateOrderStatus] ✅ Triggered PO status update for delivered PR`)
    } catch (error: any) {
      console.warn(`[updateOrderStatus] ⚠️ Could not update PO status: ${error.message}`)
      // Don't fail the order update if PO update fails
    }
  }
  
  await order.save()
  console.log(`[updateOrderStatus] ✅ Order status updated: ${previousStatus} -> ${status}`)
  
  // If this is a replacement order being shipped or delivered, handle return request and inventory updates
  // Business Rules:
  // 1. When shipped (Dispatched): DECREMENT inventory for NEW size (replacement item being shipped out) - handled by normal flow below
  // 2. When delivered (Delivered): INCREMENT inventory for ORIGINAL size (returned item being received back) - handled here
  // NOTE: 
  //   - Replacement size (M): DECREMENTED when shipped (stock is consumed)
  //   - Returned size (XXL): INCREMENTED when delivered (item is returned/restocked)
  const isReplacementOrder = (order as any).orderType === 'REPLACEMENT'
  const hasReturnRequestId = (order as any).returnRequestId
  
  if ((status === 'Dispatched' || status === 'Delivered') && isReplacementOrder && hasReturnRequestId) {
    try {
      const returnRequestId = (order as any).returnRequestId
      console.log(`[updateOrderStatus] 🔄 Replacement order ${status.toLowerCase()}, processing return request: ${returnRequestId}`)
      
      const returnRequest = await ReturnRequest.findOne({ returnRequestId })
        .populate('uniformId', 'id name')
        .lean()
      
      if (!returnRequest) {
        console.warn(`[updateOrderStatus] ⚠️ Return request not found:`, returnRequestId)
        // For replacement orders, missing return request is critical
        throw new Error(`Return request ${returnRequestId} not found for replacement order ${orderId}`)
      }
      
      if (returnRequest.status === 'APPROVED') {
        // Only update return request status to COMPLETED when delivered
        if (status === 'Delivered') {
          await ReturnRequest.updateOne(
            { returnRequestId },
            { status: 'COMPLETED' }
          )
          console.log(`[updateOrderStatus] ✅ Return request completed: ${returnRequestId}`)
        }
        
        // Increment inventory for the returned item (original size) when delivered
        // Business rule: Inventory for returned item increases ONLY when replacement is delivered/confirmed
        if (status === 'Delivered' && returnRequest.uniformId && returnRequest.originalSize && returnRequest.requestedQty) {
          try {
            console.log(`[updateOrderStatus] 📦 Incrementing inventory for returned item (ORIGINAL size):`, {
              productId: (returnRequest.uniformId as any)?._id || returnRequest.uniformId,
              originalSize: returnRequest.originalSize,
              quantity: returnRequest.requestedQty,
              note: 'This is the size being returned (e.g., XXL)'
            })
            
            // Get the vendor from the replacement order
            // vendorId is now a 6-digit numeric string
            const replacementOrderVendorId = vendorIdValue || (orderRaw as any).vendorId
            if (!replacementOrderVendorId) {
              console.warn(`[updateOrderStatus] ⚠️ Replacement order has no vendorId, cannot increment inventory for returned item`)
            } else {
              // Validate vendorId is a 6-digit numeric string
              const vendorIdClean = String(replacementOrderVendorId).trim()
              if (!/^\d{6}$/.test(vendorIdClean)) {
                console.error(`[updateOrderStatus] ❌ Invalid vendorId format for inventory update: ${vendorIdClean}`)
                throw new Error(`Invalid vendor ID format: ${vendorIdClean}`)
              }
              
              // Get vendor ObjectId for inventory update (VendorInventory uses ObjectId)
              const vendor = await Vendor.findOne({ id: vendorIdClean })
              if (!vendor) {
                throw new Error(`Vendor not found: ${vendorIdClean}`)
              }
              const returnVendorObjectId = vendor._id
              
              // Get product ObjectId
              const productObjectId = (returnRequest.uniformId as any)?._id || returnRequest.uniformId
              if (!productObjectId) {
                throw new Error('Product ID not found in return request')
              }
              
              const product = await Uniform.findById(productObjectId)
              if (!product) {
                throw new Error(`Product not found: ${productObjectId}`)
              }
              
              // Update inventory (without transaction for standalone MongoDB)
              try {
                // Find or create inventory record
                let inventory = await VendorInventory.findOne({
                  vendorId: returnVendorObjectId,
                  productId: product._id,
                })
                
                if (!inventory) {
                  console.warn(`[updateOrderStatus] ⚠️ No inventory record found for vendor ${returnVendorObjectId} and product ${product.id}, creating one`)
                  const inventoryId = `VEND-INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
                  inventory = await VendorInventory.create({
                    id: inventoryId,
                    vendorId: returnVendorObjectId,
                    productId: product._id,
                    sizeInventory: new Map(),
                    totalStock: 0,
                    lowInventoryThreshold: new Map(),
                  })
                }
                
                // Get current size inventory
                const sizeInventory = inventory.sizeInventory instanceof Map
                  ? new Map(inventory.sizeInventory)
                  : new Map(Object.entries(inventory.sizeInventory || {}))
                
                // Increment inventory for the returned size
                const originalSize = returnRequest.originalSize
                const returnedQty = returnRequest.requestedQty
                const currentStock = sizeInventory.get(originalSize) || 0
                const newStock = currentStock + returnedQty
                
                console.log(`[updateOrderStatus] 📊 Return inventory calculation:`, {
                  originalSize,
                  currentStock,
                  returnedQty,
                  newStock,
                  calculation: `${currentStock} + ${returnedQty} = ${newStock}`
                })
                
                sizeInventory.set(originalSize, newStock)
                
                // Calculate new total stock
                let totalStock = 0
                for (const qty of sizeInventory.values()) {
                  totalStock += qty
                }
                
                // Update inventory
                inventory.sizeInventory = sizeInventory
                inventory.totalStock = totalStock
                inventory.markModified('sizeInventory')
                
                await inventory.save()
                
                console.log(`[updateOrderStatus] ✅ Successfully incremented inventory for returned item: product ${product.id}, size ${originalSize}, ${currentStock} -> ${newStock} (incremented ${returnedQty})`)
              } catch (error: any) {
                console.error(`[updateOrderStatus] ❌ Error incrementing inventory for returned item:`, error)
                throw error
              }
            }
          } catch (error: any) {
            console.error(`[updateOrderStatus] ❌ Failed to increment inventory for returned item: ${error.message}`)
            console.error(`[updateOrderStatus] ❌ Error stack:`, error.stack)
            // For replacement orders, inventory update is critical - rethrow the error
            throw error
          }
        }
      } else {
        console.warn(`[updateOrderStatus] ⚠️ Return request not in APPROVED status:`, {
          returnRequestId,
          status: returnRequest.status,
          orderStatus: status
        })
        // For replacement orders, this is unexpected - log but don't throw (status might be COMPLETED already)
      }
    } catch (error: any) {
      console.error(`[updateOrderStatus] ❌ Failed to process return request for replacement order: ${error.message}`)
      console.error(`[updateOrderStatus] ❌ Error stack:`, error.stack)
      // For replacement orders, this is critical - rethrow the error to prevent silent failures
      throw error
    }
  }
  
  // If status is being changed to "Dispatched" or "Delivered", decrement inventory
  // IMPORTANT: We need to check if inventory was already decremented by looking at order history
  // For now, we'll decrement when:
  // 1. Order goes from "Awaiting fulfilment" -> "Dispatched" (normal flow)
  // 2. Order goes from "Awaiting fulfilment" -> "Delivered" (direct delivery, skipping dispatch)
  // 3. Order goes from "Dispatched" -> "Delivered" (only if inventory wasn't decremented during Dispatched)
  // 
  // NOTE: We check previousStatus to avoid double-decrementing, but if the order was marked as "Dispatched"
  // without inventory being updated (due to missing vendorId or other error), we should still update when marking as "Delivered"
  const shouldUpdateInventory = (status === 'Dispatched' || status === 'Delivered') && 
                                 previousStatus !== 'Dispatched' && 
                                 previousStatus !== 'Delivered'
  
  // SPECIAL CASE: If going from "Dispatched" to "Delivered" and vendorId exists but wasn't processed before,
  // we should still update inventory (in case the previous Dispatched update failed)
  // CRITICAL: For replacement orders, we should NOT decrement again on "Delivered" - replacement size was already decremented on "Dispatched"
  // Only the returned size should be incremented on "Delivered" (handled separately above)
  const isDispatchedToDelivered = status === 'Delivered' && previousStatus === 'Dispatched'
  const isReplacementOrderForDeliveredCheck = (order as any).orderType === 'REPLACEMENT'
  const shouldUpdateInventoryForDelivered = isDispatchedToDelivered && vendorIdValue !== null && !isReplacementOrderForDeliveredCheck
  
  const isReplacementOrderForLogging = (order as any).orderType === 'REPLACEMENT'
  console.log(`[updateOrderStatus] 🔍 Inventory update check:`, {
    shouldUpdate: shouldUpdateInventory,
    shouldUpdateForDelivered: shouldUpdateInventoryForDelivered,
    status,
    previousStatus,
    isDispatchedToDelivered,
    hasVendorId: vendorIdValue !== null,
    orderType: isReplacementOrderForLogging ? 'REPLACEMENT' : 'NORMAL',
    returnRequestId: (order as any).returnRequestId || 'N/A',
    condition1: status === 'Dispatched' || status === 'Delivered',
    condition2: previousStatus !== 'Dispatched',
    condition3: previousStatus !== 'Delivered',
    skipDeliveredUpdateForReplacement: isReplacementOrderForDeliveredCheck && isDispatchedToDelivered
  })
  
  // Update inventory if either condition is true
  // NOTE: This applies to BOTH normal orders AND replacement orders
  // For replacement orders: DECREMENT inventory for the NEW size (replacement item being shipped out)
  // For normal orders: DECREMENT inventory for ordered items - stock is consumed
  // NOTE: Returned size (original) is incremented separately when replacement order is Delivered
  if (shouldUpdateInventory || shouldUpdateInventoryForDelivered) {
    const isReplacementOrder = (order as any).orderType === 'REPLACEMENT'
    console.log(`\n[updateOrderStatus] 📦 ========== INVENTORY UPDATE REQUIRED ==========`)
    console.log(`[updateOrderStatus] 📦 Order ${orderId}: ${previousStatus} -> ${status}, will decrement inventory`)
    console.log(`[updateOrderStatus] 📦 Order type: ${isReplacementOrder ? 'REPLACEMENT' : 'NORMAL'}`)
    console.log(`[updateOrderStatus] 📦 Update reason: ${shouldUpdateInventory ? 'Normal flow' : 'Dispatched->Delivered (recovery)'}`)
    
    if (!vendorIdValue) {
      const isReplacementOrder = (order as any).orderType === 'REPLACEMENT'
      console.error(`[updateOrderStatus] ❌ Order ${orderId} has no vendorId, cannot update inventory`)
      console.error(`[updateOrderStatus] ❌ Order details:`, {
        vendorId: order.vendorId,
        vendorName: (order as any).vendorName,
        vendorIdValue: vendorIdValue,
        orderType: isReplacementOrder ? 'REPLACEMENT' : 'NORMAL',
        returnRequestId: (order as any).returnRequestId || 'N/A'
      })
      // For replacement orders, this is critical - throw error instead of silently failing
      if (isReplacementOrder) {
        throw new Error(`Replacement order ${orderId} has no vendorId - inventory update cannot proceed. This will cause inventory discrepancies.`)
      }
    } else {
      try {
        console.log(`[updateOrderStatus] 🔍 Processing vendor for inventory update`)
        console.log(`[updateOrderStatus] 🔍 Using vendorId: ${vendorIdValue}`)
        
        // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId
        // Look up vendor by numeric ID to get ObjectId for inventory operations
        let vendor = await Vendor.findOne({ id: vendorIdValue })
        if (!vendor && (order as any).vendorName) {
          console.log(`[updateOrderStatus] ⚠️ Vendor not found by id, trying by name: ${(order as any).vendorName}`)
          vendor = await Vendor.findOne({ name: (order as any).vendorName })
        }
        
        if (!vendor) {
          console.error(`[updateOrderStatus] ❌ Vendor not found for order ${orderId}`)
          console.error(`[updateOrderStatus] ❌ Tried: id=${vendorIdValue}, name=${(order as any).vendorName || 'N/A'}`)
          throw new Error(`Vendor not found for vendorId: ${vendorIdValue}`)
        }
        
        // Get vendor ObjectId for inventory operations (VendorInventory uses ObjectId)
        const vendorObjectIdToUse = vendor._id
        
        console.log(`[updateOrderStatus] ✅ Vendor found:`, {
          vendorId: vendor.id,
          vendorName: vendor.name,
          vendorObjectId: vendorObjectIdToUse.toString(),
          lookupMethod: 'by numeric id'
        })
        
        const isReplacementOrder = (order as any).orderType === 'REPLACEMENT'
        console.log(`[updateOrderStatus] 📦 Processing ${order.items.length} order items`)
        if (isReplacementOrder) {
          console.log(`[updateOrderStatus] 🔄 REPLACEMENT ORDER: Will DECREMENT inventory for NEW size (replacement item being shipped out)`)
          console.log(`[updateOrderStatus] 🔄 REPLACEMENT ORDER: Note - Returned size (original, e.g., XXL) will be INCREMENTED when order is Delivered`)
        } else {
          console.log(`[updateOrderStatus] 🔄 NORMAL ORDER: Will decrement inventory for ordered items`)
        }
        
        // Process each item in the order
        let itemIndex = 0
        for (const item of order.items) {
            itemIndex++
            console.log(`\n[updateOrderStatus] 📦 ========== PROCESSING ITEM ${itemIndex}/${order.items.length} ==========`)
            console.log(`[updateOrderStatus] 📦 Item details:`, {
              uniformId: item.uniformId,
              uniformName: item.uniformName || 'N/A',
              size: item.size,
              quantity: item.quantity,
              price: item.price
            })
            // Get product ObjectId - handle both populated and unpopulated cases
            let productObjectId: mongoose.Types.ObjectId
            if (item.uniformId instanceof mongoose.Types.ObjectId) {
              productObjectId = item.uniformId
              console.log(`[updateOrderStatus] 🔍 Product ID is ObjectId: ${productObjectId.toString()}`)
            } else {
              // Populated product document
              productObjectId = (item.uniformId as any)._id || item.uniformId
              console.log(`[updateOrderStatus] 🔍 Product ID from populated doc: ${productObjectId?.toString() || 'N/A'}`)
            }
            
            const size = item.size
            const quantity = item.quantity
            
            if (!size || !quantity) {
              console.error(`[updateOrderStatus] ❌ Order ${orderId} item ${itemIndex} missing size or quantity:`, {
                size,
                quantity,
                item
              })
              continue
            }
            
            console.log(`[updateOrderStatus] 🔍 Looking up product:`, {
              productObjectId: productObjectId.toString(),
              size,
              quantity
            })
            
            // Get product to verify it exists
            const product = await Uniform.findById(productObjectId)
            
            if (!product) {
              console.error(`[updateOrderStatus] ❌ Product not found for order ${orderId}, item ${itemIndex}:`, {
                productObjectId: productObjectId.toString(),
                item
              })
              continue
            }
          
            console.log(`[updateOrderStatus] ✅ Product found:`, {
              productId: product.id,
              productName: product.name,
              productObjectId: product._id.toString()
            })
          
          // Update inventory (without transaction for standalone MongoDB)
          console.log(`[updateOrderStatus] 🔄 Starting inventory update (standalone MongoDB - no transactions)`)
          
          try {
            // Find or create inventory record
            console.log(`[updateOrderStatus] 🔍 Looking up VendorInventory:`, {
              vendorId: vendor._id.toString(),
              vendorIdString: vendor.id,
              productId: product._id.toString(),
              productIdString: product.id
            })
            
            let inventory = await VendorInventory.findOne({
              vendorId: vendor._id,
              productId: product._id,
            })
            
            if (!inventory) {
              console.warn(`[updateOrderStatus] ⚠️ No inventory record found for vendor ${vendor.id} and product ${product.id}, creating one with 0 stock`)
              // Create inventory record with 0 stock if it doesn't exist
              const inventoryId = `VEND-INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
              inventory = await VendorInventory.create({
                id: inventoryId,
                vendorId: vendor._id,
                productId: product._id,
                sizeInventory: new Map(),
                totalStock: 0,
                lowInventoryThreshold: new Map(),
              })
            }
              
              console.log(`[updateOrderStatus] ✅ Inventory record found/created:`, {
                inventoryId: inventory.id,
                currentSizeInventory: inventory.sizeInventory instanceof Map 
                  ? Object.fromEntries(inventory.sizeInventory)
                  : inventory.sizeInventory,
                currentTotalStock: inventory.totalStock
              })
            
            // Get current size inventory
            const sizeInventory = inventory.sizeInventory instanceof Map
              ? new Map(inventory.sizeInventory)
              : new Map(Object.entries(inventory.sizeInventory || {}))
            
              console.log(`[updateOrderStatus] 🔍 Current sizeInventory Map:`, Object.fromEntries(sizeInventory))
              
              // CRITICAL FIX: For replacement orders, DECREMENT inventory for replacement size (being shipped out)
              // For normal orders, also DECREMENT inventory (stock is consumed)
              // NOTE: Returned size (original) is incremented separately when order is Delivered
            const currentStock = sizeInventory.get(size) || 0
              let newStock: number
              let operation: string
              
              // Both replacement and normal orders DECREMENT inventory when shipped
              // Replacement order: Decrement replacement size (M) because we're shipping it out
              // Normal order: Decrement ordered size because stock is consumed
            if (currentStock < quantity) {
                console.warn(`[updateOrderStatus] ⚠️ Insufficient inventory for order ${orderId}: product ${product.id}, size ${size}. Current: ${currentStock}, Requested: ${quantity}`)
                // Still allow the order to be shipped, but inventory goes to 0 (not negative)
              }
              newStock = Math.max(0, currentStock - quantity) // Don't go below 0
              operation = 'decrement'
              
              if (isReplacementOrder) {
                console.log(`[updateOrderStatus] 📊 REPLACEMENT ORDER - Stock calculation:`, {
                  size,
                  currentStock,
                  quantity,
                  newStock,
                  calculation: `${currentStock} - ${quantity} = ${newStock}`,
                  note: 'Replacement order: DECREMENTING inventory for replacement size (being shipped out). Returned size will be incremented when delivered.'
                })
              } else {
                console.log(`[updateOrderStatus] 📊 NORMAL ORDER - Stock calculation:`, {
                  size,
                  currentStock,
                  quantity,
                  newStock,
                  calculation: `${currentStock} - ${quantity} = ${newStock}`,
                  note: 'Normal order: decrementing inventory'
                })
              }
              
              console.log(`[updateOrderStatus] 📊 Stock calculation result:`, {
                orderType: isReplacementOrder ? 'REPLACEMENT' : 'NORMAL',
                operation,
                currentStock,
                quantity,
                newStock,
                calculation: `${currentStock} - ${quantity} = ${newStock}`,
                note: isReplacementOrder 
                  ? 'Replacement order: decrementing replacement size (being shipped out)'
                  : 'Normal order: decrementing inventory'
              })
            
            sizeInventory.set(size, newStock)
              console.log(`[updateOrderStatus] ✅ Updated sizeInventory Map:`, Object.fromEntries(sizeInventory))
            
            // Calculate new total stock
            let totalStock = 0
            for (const qty of sizeInventory.values()) {
              totalStock += qty
            }
            
              // Update inventory atomically
              console.log(`[updateOrderStatus] 🔄 Updating inventory object...`)
              console.log(`[updateOrderStatus] 🔄 Before assignment:`, {
                inventorySizeInventoryType: typeof inventory.sizeInventory,
                inventorySizeInventoryIsMap: inventory.sizeInventory instanceof Map,
                newSizeInventoryType: typeof sizeInventory,
                newSizeInventoryIsMap: sizeInventory instanceof Map
              })
              
            inventory.sizeInventory = sizeInventory
            inventory.totalStock = totalStock
              
              console.log(`[updateOrderStatus] 🔄 After assignment:`, {
                inventorySizeInventoryType: typeof inventory.sizeInventory,
                inventorySizeInventoryIsMap: inventory.sizeInventory instanceof Map,
                inventorySizeInventoryValue: inventory.sizeInventory instanceof Map
                  ? Object.fromEntries(inventory.sizeInventory)
                  : inventory.sizeInventory
              })
              
              // CRITICAL: Mark Map fields as modified to ensure Mongoose saves them
              // Mongoose doesn't always detect changes to Map objects, so we must explicitly mark them
              console.log(`[updateOrderStatus] 🔄 Marking sizeInventory as modified...`)
              inventory.markModified('sizeInventory')
              console.log(`[updateOrderStatus] ✅ markModified('sizeInventory') called`)
              console.log(`[updateOrderStatus] 🔄 Modified paths after markModified:`, inventory.modifiedPaths())
              
              console.log(`[Inventory Update] 🔍 Before save - inventory record:`, {
                inventoryId: inventory.id,
                vendorId: vendor.id,
                productId: product.id,
                size: size,
                sizeInventory: Object.fromEntries(sizeInventory),
                totalStock: totalStock,
                currentStock: currentStock,
                newStock: newStock,
                quantity: quantity
              })
              
              console.log(`[updateOrderStatus] 💾 ========== SAVING INVENTORY ==========`)
              console.log(`[updateOrderStatus] 💾 Attempting to save inventory with session...`)
              console.log(`[updateOrderStatus] 💾 Pre-save state:`, {
                inventoryId: inventory.id,
                inventoryIsNew: inventory.isNew,
                inventoryIsModified: inventory.isModified(),
                modifiedPaths: inventory.modifiedPaths(),
                sizeInventoryBeforeSave: inventory.sizeInventory instanceof Map
                  ? Object.fromEntries(inventory.sizeInventory)
                  : inventory.sizeInventory,
                totalStockBeforeSave: inventory.totalStock,
                markModifiedCalled: true // We called it above
              })
              
              const saveResult = await inventory.save()
              
              console.log(`[updateOrderStatus] ✅ Inventory save() completed:`, {
                inventoryId: saveResult.id,
                savedSizeInventory: saveResult.sizeInventory instanceof Map
                  ? Object.fromEntries(saveResult.sizeInventory)
                  : saveResult.sizeInventory,
                savedTotalStock: saveResult.totalStock,
                savedSizeStock: saveResult.sizeInventory instanceof Map
                  ? saveResult.sizeInventory.get(size)
                  : (saveResult.sizeInventory as any)?.[size],
                expectedSizeStock: newStock,
                saveMatch: (saveResult.sizeInventory instanceof Map
                  ? saveResult.sizeInventory.get(size)
                  : (saveResult.sizeInventory as any)?.[size]) === newStock
              })
              
              console.log(`[updateOrderStatus] ✅ Inventory update saved successfully (standalone MongoDB)`)
              
              const operationText = isReplacementOrder ? 'incremented' : 'decremented'
              console.log(`[updateOrderStatus] ✅ Successfully updated VendorInventory for order ${orderId}: product ${product.id}, size ${size}, ${currentStock} -> ${newStock} (${operationText} ${quantity})`)
              console.log(`[updateOrderStatus] ✅ Order type: ${isReplacementOrder ? 'REPLACEMENT' : 'NORMAL'}`)
              
              // CRITICAL VERIFICATION: Query database directly to confirm update persisted
              // IMPORTANT: Query OUTSIDE the transaction session to see committed data
              console.log(`[updateOrderStatus] 🔍 ========== POST-SAVE VERIFICATION ==========`)
              console.log(`[updateOrderStatus] 🔍 Waiting 200ms for database write to complete...`)
              await new Promise(resolve => setTimeout(resolve, 200))
              
              // Query using raw MongoDB to bypass any Mongoose caching
              // Query WITHOUT session to see committed data
              const db = mongoose.connection.db
              const vendorInventoriesCollection = db.collection('vendorinventories')
              
              console.log(`[updateOrderStatus] 🔍 Querying raw MongoDB (outside transaction)...`)
              const rawInventoryDoc = await vendorInventoriesCollection.findOne({
                vendorId: vendor._id,
                productId: product._id,
              })
              
              console.log(`[updateOrderStatus] 🔍 Raw MongoDB query result:`, {
                found: !!rawInventoryDoc,
                inventoryId: rawInventoryDoc?.id,
                sizeInventory: rawInventoryDoc?.sizeInventory,
                totalStock: rawInventoryDoc?.totalStock,
                sizeStock: rawInventoryDoc?.sizeInventory?.[size],
                expectedStock: newStock
              })
              
              // Also verify using Mongoose (without session to see committed data)
              console.log(`[updateOrderStatus] 🔍 Querying Mongoose (outside transaction)...`)
              const verifyInventory = await VendorInventory.findOne({
                vendorId: vendor._id,
                productId: product._id,
              }).lean()
              
              if (verifyInventory) {
                const verifySizeStock = verifyInventory.sizeInventory instanceof Map
                  ? verifyInventory.sizeInventory.get(size)
                  : (verifyInventory.sizeInventory as any)?.[size]
                const verifyTotalStock = verifyInventory.totalStock
                
                console.log(`[updateOrderStatus] ✅ Mongoose verification result:`, {
                  inventoryId: verifyInventory.id,
                  size,
                  expectedStock: newStock,
                  actualStock: verifySizeStock,
                  match: verifySizeStock === newStock,
                  expectedTotal: totalStock,
                  actualTotal: verifyTotalStock,
                  totalMatch: verifyTotalStock === totalStock,
                  sizeInventoryType: typeof verifyInventory.sizeInventory,
                  sizeInventoryIsMap: verifyInventory.sizeInventory instanceof Map,
                  sizeInventoryKeys: verifyInventory.sizeInventory instanceof Map 
                    ? Array.from(verifyInventory.sizeInventory.keys())
                    : Object.keys(verifyInventory.sizeInventory || {})
                })
                
                // Compare raw MongoDB vs Mongoose
                const rawSizeStock = rawInventoryDoc?.sizeInventory?.[size]
                console.log(`[updateOrderStatus] 🔍 Raw vs Mongoose comparison:`, {
                  rawSizeStock,
                  mongooseSizeStock: verifySizeStock,
                  match: rawSizeStock === verifySizeStock
                })
                
                if (verifySizeStock !== newStock) {
                  console.error(`[updateOrderStatus] ❌❌❌ VERIFICATION FAILED: Expected stock ${newStock} but got ${verifySizeStock}`)
                  console.error(`[updateOrderStatus] ❌❌❌ This indicates the inventory update did NOT persist!`)
                  console.error(`[updateOrderStatus] ❌❌❌ Debug info:`, {
                    beforeSave: currentStock,
                    quantity: quantity,
                    calculatedNewStock: newStock,
                    afterSave: verifySizeStock,
                    rawMongoDB: rawSizeStock
                  })
                } else {
                  console.log(`[updateOrderStatus] ✅✅✅ VERIFICATION PASSED: Stock correctly saved and persisted`)
                  const operationText = 'decremented'
                  const calculationText = `${currentStock} - ${quantity} = ${newStock}`
                  const note = isReplacementOrder 
                    ? ' (Replacement order: replacement size decremented, returned size will be incremented on delivery)'
                    : ' (Normal order: inventory decremented)'
                  console.log(`[updateOrderStatus] ✅✅✅ Inventory ${operationText}: ${calculationText}${note}`)
                }
              } else {
                console.error(`[updateOrderStatus] ❌ Verification failed: Could not find inventory record after save`)
                console.error(`[updateOrderStatus] ❌ Query used:`, {
                  vendorId: vendor._id.toString(),
                  productId: product._id.toString()
                })
              }
              
              console.log(`[updateOrderStatus] 📦 ========== ITEM ${itemIndex} PROCESSING COMPLETE ==========\n`)
            } catch (error: any) {
              console.error(`[updateOrderStatus] ❌ Error updating inventory for item ${itemIndex}:`, error)
              console.error(`[updateOrderStatus] ❌ Error details:`, {
                message: error?.message,
                stack: error?.stack,
                name: error?.name
              })
              throw error
            }
          }
          
          console.log(`[updateOrderStatus] 📦 ========== ALL ITEMS PROCESSED ==========`)
          
          // FINAL VERIFICATION: Query all inventory records for this vendor-product to confirm
          console.log(`[updateOrderStatus] 🔍 ========== FINAL INVENTORY VERIFICATION ==========`)
          const finalInventoryCheck = await VendorInventory.find({
            vendorId: vendor._id,
            productId: product._id,
          }).lean()
          
          console.log(`[updateOrderStatus] 🔍 Final inventory check found ${finalInventoryCheck.length} record(s):`)
          finalInventoryCheck.forEach((inv, idx) => {
            console.log(`[updateOrderStatus] 🔍 Inventory record ${idx + 1}:`, {
              id: inv.id,
              sizeInventory: inv.sizeInventory,
              totalStock: inv.totalStock,
              sizeInventoryType: typeof inv.sizeInventory,
              sizeInventoryKeys: inv.sizeInventory instanceof Map
                ? Array.from(inv.sizeInventory.keys())
                : Object.keys(inv.sizeInventory || {})
            })
          })
          console.log(`[updateOrderStatus] 📦 ========== ALL ITEMS PROCESSED ==========\n`)
        } catch (error: any) {
          console.error(`[updateOrderStatus] ❌❌❌ CRITICAL ERROR updating inventory for order ${orderId}:`, error)
          console.error(`[updateOrderStatus] ❌ Error details:`, {
            message: error?.message,
            stack: error?.stack,
            name: error?.name,
            code: error?.code
          })
          // Don't throw - we still want to update the order status even if inventory update fails
        }
      }
    } else {
    // Log when inventory update is skipped
    if (status === 'Dispatched' || status === 'Delivered') {
      console.log(`[updateOrderStatus] ⏭️ Skipping inventory update for order ${orderId}: ${previousStatus} -> ${status} (already processed or invalid transition)`)
    }
  }
  
  // Populate and return - use string id field instead of _id
  console.log(`[updateOrderStatus] 🔄 Populating order for response...`)
  // Use the orderId parameter directly (order.id should already match it)
  const populatedOrder = await Order.findOne({ id: orderId })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .lean()
  
  console.log(`[updateOrderStatus] ✅ Order populated successfully`)
  console.log(`[updateOrderStatus] 🚀 ========== ORDER STATUS UPDATE COMPLETE ==========\n`)
  
  return toPlainObject(populatedOrder)
}

export async function getPendingApprovals(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id name enable_pr_po_workflow require_company_admin_po_approval').lean()
  if (!company) {
    return []
  }
  
  // Build query filter based on workflow configuration
  // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
  const queryFilter: any = {
    companyId: company.id,
  }
  
  // If PR/PO workflow is enabled, only show orders pending COMPANY ADMIN approval
  // (Site Admin approvals are handled separately)
  // CRITICAL: When PR workflow is enabled, filter ONLY by pr_status, NOT by status
  // Orders can have status 'Awaiting approval' or 'Awaiting fulfilment' but still need company admin approval
  if (company.enable_pr_po_workflow === true) {
    queryFilter.pr_status = 'PENDING_COMPANY_ADMIN_APPROVAL'
    // Don't filter by status - pr_status is the source of truth for PR workflow
    console.log(`[getPendingApprovals] PR/PO workflow enabled. Filtering for PENDING_COMPANY_ADMIN_APPROVAL orders only (ignoring status field).`)
  } else {
    // Legacy workflow: show all orders with status 'Awaiting approval'
    // Exclude orders that are pending site admin approval (if any exist)
    queryFilter.status = 'Awaiting approval'
    queryFilter.$or = [
      { pr_status: { $exists: false } }, // Legacy orders without PR status
      { pr_status: null }, // Legacy orders with null PR status
      { pr_status: { $ne: 'PENDING_SITE_ADMIN_APPROVAL' } }, // Exclude site admin pending
    ]
    console.log(`[getPendingApprovals] Legacy workflow. Showing all orders with status 'Awaiting approval' except PENDING_SITE_ADMIN_APPROVAL.`)
  }
  
  // OPTIMIZATION: Fetch all pending orders (parent + child) in single query using $or
  // This eliminates the need for two separate queries
  // CRITICAL: Don't use populate since Order.employeeId and Order.companyId are string IDs
  const pendingOrders = await Order.find(queryFilter)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at')
    .sort({ orderDate: -1 })
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(pendingOrders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Manually populate employee, company, and uniform info using string IDs
  const pendingOrdersWithDetails = await Promise.all(pendingOrders.map(async (o: any) => {
    const plain = toPlainObject(o)
    
    // Manually fetch employee info using string ID
    if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
      const employee = await Employee.findOne({ 
        $or: [
          { id: plain.employeeId },
          { employeeId: plain.employeeId }
        ]
      }).select('id employeeId firstName lastName email').lean()
      
      if (employee) {
        // Decrypt employee fields since we used .lean()
        const { decrypt } = require('../utils/encryption')
        const decryptedEmployee: any = { ...employee }
        const sensitiveFields = ['firstName', 'lastName', 'email']
        
        for (const field of sensitiveFields) {
          if (decryptedEmployee[field] && typeof decryptedEmployee[field] === 'string' && decryptedEmployee[field].includes(':')) {
            try {
              decryptedEmployee[field] = decrypt(decryptedEmployee[field])
            } catch (error) {
              // If decryption fails, keep original value
            }
          }
        }
        
        plain.employeeId = toPlainObject(decryptedEmployee)
      }
    }
    
    // Manually fetch company info using string ID
    if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
      const company = await Company.findOne({ id: plain.companyId })
        .select('id name')
        .lean()
      if (company) {
        plain.companyId = toPlainObject(company)
      }
    }
    
    // Manually fetch uniform info for items
    if (plain.items && Array.isArray(plain.items)) {
      const uniformIds = [...new Set(plain.items.map((item: any) => item.uniformId).filter(Boolean))]
      if (uniformIds.length > 0) {
        const Uniform = require('../models/Uniform').default
        const uniforms = await Uniform.find({ id: { $in: uniformIds } })
          .select('id name')
          .lean()
        const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
        
        plain.items = plain.items.map((item: any) => {
          if (item.uniformId && uniformMap.has(item.uniformId)) {
            item.uniformId = uniformMap.get(item.uniformId)
          }
          return item
        })
      }
    }
    
    // Add vendorName
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    
    return plain
  }))
  
  // OPTIMIZATION: Also fetch child orders in same query using aggregation or separate optimized query
  const parentOrderIds = new Set<string>()
  const standaloneOrders: any[] = []
  const plainOrders = pendingOrdersWithDetails

  for (const order of plainOrders) {
    if (order.parentOrderId) {
      parentOrderIds.add(order.parentOrderId)
    } else {
      standaloneOrders.push(order)
    }
  }

  // OPTIMIZATION: Fetch child orders with field projection to reduce payload
  const orderMap = new Map<string, any[]>()
  if (parentOrderIds.size > 0) {
    // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
    const allChildOrders = await Order.find({
      companyId: company.id,
      parentOrderId: { $in: Array.from(parentOrderIds) }
    })
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at')
      .lean()
    
    // Manually populate child orders with employee, company, and uniform info
    const allChildOrdersPlain = await Promise.all(allChildOrders.map(async (o: any) => {
      const plain = toPlainObject(o)
      
      // Manually fetch employee info using string ID
      if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
        const employee = await Employee.findOne({ 
          $or: [
            { id: plain.employeeId },
            { employeeId: plain.employeeId }
          ]
        }).select('id employeeId firstName lastName email').lean()
        
        if (employee) {
          // Decrypt employee fields since we used .lean()
          const { decrypt } = require('../utils/encryption')
          const decryptedEmployee: any = { ...employee }
          const sensitiveFields = ['firstName', 'lastName', 'email']
          
          for (const field of sensitiveFields) {
            if (decryptedEmployee[field] && typeof decryptedEmployee[field] === 'string' && decryptedEmployee[field].includes(':')) {
              try {
                decryptedEmployee[field] = decrypt(decryptedEmployee[field])
              } catch (error) {
                // If decryption fails, keep original value
              }
            }
          }
          
          plain.employeeId = toPlainObject(decryptedEmployee)
        }
      }
      
      // Manually fetch company info using string ID
      if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
        const companyDoc = await Company.findOne({ id: plain.companyId })
          .select('id name')
          .lean()
        if (companyDoc) {
          plain.companyId = toPlainObject(companyDoc)
        }
      }
      
      // Manually fetch uniform info for items
      if (plain.items && Array.isArray(plain.items)) {
        const uniformIds = [...new Set(plain.items.map((item: any) => item.uniformId).filter(Boolean))]
        if (uniformIds.length > 0) {
          const Uniform = require('../models/Uniform').default
          const uniforms = await Uniform.find({ id: { $in: uniformIds } })
            .select('id name')
            .lean()
          const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
          
          plain.items = plain.items.map((item: any) => {
            if (item.uniformId && uniformMap.has(item.uniformId)) {
              item.uniformId = uniformMap.get(item.uniformId)
            }
            return item
          })
        }
      }
      
      // Add vendorName
      if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
        plain.vendorName = vendorMap.get(plain.vendorId)
      }
      
      return plain
    }))
    
    for (const order of allChildOrdersPlain) {
    if (order.parentOrderId) {
      if (!orderMap.has(order.parentOrderId)) {
        orderMap.set(order.parentOrderId, [])
      }
      orderMap.get(order.parentOrderId)!.push(order)
      }
    }
  }

  // Create grouped orders (one per parentOrderId) and add standalone orders
  const groupedOrders: any[] = []
  
  for (const [parentOrderId, splitOrders] of orderMap.entries()) {
    // Sort split orders by vendor name for consistency
    splitOrders.sort((a, b) => (a.vendorName || '').localeCompare(b.vendorName || ''))
    
    // Create a grouped order object
    const totalAmount = splitOrders.reduce((sum, o) => sum + (o.total || 0), 0)
    const totalItems = splitOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)
    const allItems = splitOrders.flatMap(o => o.items || [])
    
    groupedOrders.push({
      ...splitOrders[0], // Use first order as base
      id: parentOrderId, // Use parent order ID as the main ID
      isSplitOrder: true,
      splitOrders: splitOrders,
      splitOrderIds: splitOrders.map(o => o.id), // Store all order IDs for bulk approval
      total: totalAmount,
      items: allItems,
      vendorCount: splitOrders.length,
      vendors: splitOrders.map(o => o.vendorName).filter(Boolean)
    })
  }

  // Combine grouped and standalone orders, sorted by date
  const allOrders = [...groupedOrders, ...standaloneOrders]
  allOrders.sort((a, b) => {
    const dateA = new Date(a.orderDate || 0).getTime()
    const dateB = new Date(b.orderDate || 0).getTime()
    return dateB - dateA // Most recent first
  })

  return allOrders
}

/**
 * Get pending PRs for Site Admin (Location Admin)
 * Tab 1: Pending Approval - Shows PRs with pr_status = PENDING_SITE_ADMIN_APPROVAL
 * PR visibility driven ONLY by PR.status, PR.createdDate, PR.locationId
 * NO filtering based on PO/GRN existence
 * @param adminEmail Location Admin email
 * @param fromDate Optional date filter - PRs created on or after this date
 * @param toDate Optional date filter - PRs created on or before this date
 */
export async function getPendingApprovalsForSiteAdmin(
  adminEmail: string,
  fromDate?: Date,
  toDate?: Date
): Promise<any[]> {
  await connectDB()
  
  // Get location for this site admin
  const location = await getLocationByAdminEmail(adminEmail)
  if (!location) {
    console.log(`[getPendingApprovalsForSiteAdmin] No location found for admin: ${adminEmail}`)
    return []
  }
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Employees have locationId stored as string ID (location.id), not ObjectId
  if (!location.id || !/^\d{6}$/.test(location.id)) {
    console.log(`[getPendingApprovalsForSiteAdmin] ❌ Invalid location string ID: ${location.id}`)
    return []
  }
  
  const locationIdString = location.id
  console.log(`[getPendingApprovalsForSiteAdmin] Found location: ${locationIdString} (${location.name}) for admin: ${adminEmail}`)
  
  // Find all employees assigned to this location using string ID
  const employees = await Employee.find({ locationId: locationIdString })
    .select('_id id employeeId')
    .lean()
  
  if (employees.length === 0) {
    console.log(`[getPendingApprovalsForSiteAdmin] No employees found for location: ${locationIdString}`)
    console.log(`[getPendingApprovalsForSiteAdmin] Employees must have locationId set to location's string ID: "${locationIdString}"`)
    return []
  }
  
  // CRITICAL FIX: Order.employeeId is stored as STRING ID (6-digit numeric), not ObjectId
  // Get employee string IDs (employee.id or employee.employeeId)
  const employeeStringIds = employees
    .map((e: any) => e.id || e.employeeId)
    .filter((id: any) => id && /^\d{6}$/.test(String(id)))
  
  if (employeeStringIds.length === 0) {
    console.log(`[getPendingApprovalsForSiteAdmin] No valid employee string IDs found for location: ${locationIdString}`)
    return []
  }
  
  console.log(`[getPendingApprovalsForSiteAdmin] Found ${employeeStringIds.length} employee(s) for location: ${location.id}`)
  console.log(`[getPendingApprovalsForSiteAdmin] Employee string IDs:`, employeeStringIds)
  
  // Build query filter - PR visibility driven ONLY by pr_status and createdAt (date filter)
  // NO filtering based on PO/GRN existence
  // CRITICAL: Use string IDs, not ObjectIds
  const queryFilter: any = {
    employeeId: { $in: employeeStringIds },
    pr_status: 'PENDING_SITE_ADMIN_APPROVAL', // Tab 1: Only pending site admin approval
  }
  
  // Apply date filter on PR.createdAt if provided
  if (fromDate || toDate) {
    queryFilter.createdAt = {}
    if (fromDate) {
      queryFilter.createdAt.$gte = fromDate
    }
    if (toDate) {
      // Include entire day for toDate
      const endOfDay = new Date(toDate)
      endOfDay.setHours(23, 59, 59, 999)
      queryFilter.createdAt.$lte = endOfDay
    }
  }
  
  // Find orders pending site admin approval for employees in this location
  // NO status filter on order.status - only pr_status matters
  // CRITICAL: Don't use populate since Order.employeeId is a string ID
  const pendingOrders = await Order.find(queryFilter)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status createdAt')
    .sort({ orderDate: -1 })
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(pendingOrders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Manually populate employee, company, and uniform info using string IDs
  const pendingOrdersWithDetails = await Promise.all(pendingOrders.map(async (o: any) => {
    const plain = toPlainObject(o)
    
    // Manually fetch employee info using string ID
    if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
      const employee = await Employee.findOne({ 
        $or: [
          { id: plain.employeeId },
          { employeeId: plain.employeeId }
        ]
      }).select('id employeeId firstName lastName email locationId').lean()
      
      if (employee) {
        // Decrypt employee fields since we used .lean()
        const { decrypt } = require('../utils/encryption')
        const decryptedEmployee: any = { ...employee }
        const sensitiveFields = ['firstName', 'lastName', 'email']
        
        for (const field of sensitiveFields) {
          if (decryptedEmployee[field] && typeof decryptedEmployee[field] === 'string' && decryptedEmployee[field].includes(':')) {
            try {
              decryptedEmployee[field] = decrypt(decryptedEmployee[field])
            } catch (error) {
              // If decryption fails, keep original value
            }
          }
        }
        
        // Construct employeeName from decrypted firstName and lastName
        const decryptedFirstName = decryptedEmployee.firstName || ''
        const decryptedLastName = decryptedEmployee.lastName || ''
        const decryptedEmployeeName = `${decryptedFirstName} ${decryptedLastName}`.trim() || 'Employee'
        plain.employeeName = decryptedEmployeeName
        
        plain.employeeId = toPlainObject(decryptedEmployee)
      }
    }
    
    // Manually fetch company info using string ID
    if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
      const company = await Company.findOne({ id: plain.companyId })
        .select('id name')
        .lean()
      if (company) {
        plain.companyId = toPlainObject(company)
      }
    }
    
    // Manually fetch uniform info for items
    if (plain.items && Array.isArray(plain.items)) {
      const uniformIds = [...new Set(plain.items.map((item: any) => item.uniformId).filter(Boolean))]
      if (uniformIds.length > 0) {
        const Uniform = require('../models/Uniform').default
        const uniforms = await Uniform.find({ id: { $in: uniformIds } })
          .select('id name')
          .lean()
        const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
        
        plain.items = plain.items.map((item: any) => {
          if (item.uniformId && uniformMap.has(item.uniformId)) {
            item.uniformId = uniformMap.get(item.uniformId)
          }
          return item
        })
      }
    }
    
    // Add vendorName
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    
    return plain
  }))
  
  console.log(`[getPendingApprovalsForSiteAdmin] Found ${pendingOrdersWithDetails.length} order(s) pending site admin approval`)
  
  // Group orders by parentOrderId (similar to getPendingApprovals)
  const parentOrderIds = new Set<string>()
  const standaloneOrders: any[] = []
  const plainOrders = pendingOrdersWithDetails

  for (const order of plainOrders) {
    if (order.parentOrderId) {
      parentOrderIds.add(order.parentOrderId)
    } else {
      standaloneOrders.push(order)
    }
  }

  // Fetch child orders - CRITICAL: Use string IDs, not ObjectIds
  const orderMap = new Map<string, any[]>()
  if (parentOrderIds.size > 0) {
    const allChildOrders = await Order.find({
      employeeId: { $in: employeeStringIds }, // Use string IDs, not ObjectIds
      parentOrderId: { $in: Array.from(parentOrderIds) },
      pr_status: 'PENDING_SITE_ADMIN_APPROVAL',
    })
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status createdAt')
      .lean()
    
    // Manually populate child orders
    const allChildOrdersWithDetails = await Promise.all(allChildOrders.map(async (o: any) => {
      const plain = toPlainObject(o)
      
      // Manually fetch employee info
      if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
        const employee = await Employee.findOne({ 
          $or: [
            { id: plain.employeeId },
            { employeeId: plain.employeeId }
          ]
        }).select('id employeeId firstName lastName email locationId').lean()
        
        if (employee) {
          // Decrypt employee fields
          const { decrypt } = require('../utils/encryption')
          const decryptedEmployee: any = { ...employee }
          const sensitiveFields = ['firstName', 'lastName', 'email']
          
          for (const field of sensitiveFields) {
            if (decryptedEmployee[field] && typeof decryptedEmployee[field] === 'string' && decryptedEmployee[field].includes(':')) {
              try {
                decryptedEmployee[field] = decrypt(decryptedEmployee[field])
              } catch (error) {
                // If decryption fails, keep original value
              }
            }
          }
          
          // Construct employeeName from decrypted firstName and lastName
          const decryptedFirstName = decryptedEmployee.firstName || ''
          const decryptedLastName = decryptedEmployee.lastName || ''
          const decryptedEmployeeName = `${decryptedFirstName} ${decryptedLastName}`.trim() || 'Employee'
          plain.employeeName = decryptedEmployeeName
          
          plain.employeeId = toPlainObject(decryptedEmployee)
        }
      }
      
      // Manually fetch company info
      if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
        const company = await Company.findOne({ id: plain.companyId })
          .select('id name')
          .lean()
        if (company) {
          plain.companyId = toPlainObject(company)
        }
      }
      
      // Manually fetch uniform info
      if (plain.items && Array.isArray(plain.items)) {
        const uniformIds = [...new Set(plain.items.map((item: any) => item.uniformId).filter(Boolean))]
        if (uniformIds.length > 0) {
          const Uniform = require('../models/Uniform').default
          const uniforms = await Uniform.find({ id: { $in: uniformIds } })
            .select('id name')
            .lean()
          const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
          
          plain.items = plain.items.map((item: any) => {
            if (item.uniformId && uniformMap.has(item.uniformId)) {
              item.uniformId = uniformMap.get(item.uniformId)
            }
            return item
          })
        }
      }
      
      // Add vendorName
      if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
        plain.vendorName = vendorMap.get(plain.vendorId)
      }
      
      return plain
    }))
    
    const allChildOrdersPlain = allChildOrdersWithDetails
    
    for (const order of allChildOrdersPlain) {
      if (order.parentOrderId) {
        if (!orderMap.has(order.parentOrderId)) {
          orderMap.set(order.parentOrderId, [])
        }
        orderMap.get(order.parentOrderId)!.push(order)
      }
    }
  }

  // Create grouped orders (one per parentOrderId) and add standalone orders
  const groupedOrders: any[] = []
  
  for (const [parentOrderId, splitOrders] of orderMap.entries()) {
    // Sort split orders by vendor name for consistency
    splitOrders.sort((a, b) => (a.vendorName || '').localeCompare(b.vendorName || ''))
    
    // Calculate totals
    const totalItems = splitOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)
    const totalAmount = splitOrders.reduce((sum, o) => sum + (o.total || 0), 0)
    
    groupedOrders.push({
      id: parentOrderId, // Use parentOrderId as the main ID for grouped orders
      parentOrderId: parentOrderId,
      employeeId: splitOrders[0]?.employeeId,
      employeeIdNum: splitOrders[0]?.employeeIdNum,
      employeeName: splitOrders[0]?.employeeName,
      items: splitOrders.flatMap((o: any) => o.items || []),
      total: totalAmount,
      status: 'Awaiting approval',
      orderDate: splitOrders[0]?.orderDate,
      dispatchLocation: splitOrders[0]?.dispatchLocation,
      companyId: splitOrders[0]?.companyId,
      deliveryAddress: splitOrders[0]?.deliveryAddress,
      pr_number: splitOrders[0]?.pr_number,
      pr_date: splitOrders[0]?.pr_date,
      pr_status: splitOrders[0]?.pr_status,
      isSplitOrder: true,
      splitOrders: splitOrders.map((o: any) => ({
        orderId: o.id,
        vendorName: o.vendorName,
        total: o.total,
        itemCount: o.items?.length || 0
      })),
      vendorId: null, // Multiple vendors for split orders
      vendorName: null, // Multiple vendors for split orders
      isPersonalPayment: splitOrders[0]?.isPersonalPayment || false,
      personalPaymentAmount: splitOrders[0]?.personalPaymentAmount || 0,
      createdAt: splitOrders[0]?.createdAt,
    })
  }
  
  // Add standalone orders
  groupedOrders.push(...standaloneOrders)
  
  // Sort by order date (newest first)
  groupedOrders.sort((a, b) => {
    const dateA = a.orderDate ? new Date(a.orderDate).getTime() : 0
    const dateB = b.orderDate ? new Date(b.orderDate).getTime() : 0
    return dateB - dateA
  })
  
  console.log(`[getPendingApprovalsForSiteAdmin] Returning ${groupedOrders.length} order(s) (${groupedOrders.filter(o => o.isSplitOrder).length} grouped, ${groupedOrders.filter(o => !o.isSplitOrder).length} standalone)`)
  
  return groupedOrders
}

/**
 * Get all PRs raised by Location Admin (historical view - downstream statuses)
 * Tab 3: My PRs - Shows PRs with downstream statuses after approvals
 * PR visibility driven ONLY by PR.status, PR.createdDate, PR.locationId
 * NO filtering based on PO/GRN existence
 * @param adminEmail Location Admin email
 * @param fromDate Optional date filter - PRs created on or after this date
 * @param toDate Optional date filter - PRs created on or before this date
 * @returns Array of all PRs/orders with downstream statuses
 */
export async function getAllPRsForSiteAdmin(
  adminEmail: string,
  fromDate?: Date,
  toDate?: Date
): Promise<any[]> {
  await connectDB()
  
  console.log(`[getAllPRsForSiteAdmin] 🔍 Starting query for admin email: ${adminEmail}`)
  console.log(`[getAllPRsForSiteAdmin] 📅 Date filters: fromDate=${fromDate ? fromDate.toISOString() : 'none'}, toDate=${toDate ? toDate.toISOString() : 'none'}`)
  
  // Get location for this site admin
  const location = await getLocationByAdminEmail(adminEmail)
  if (!location) {
    console.log(`[getAllPRsForSiteAdmin] ❌ No location found for admin: ${adminEmail}`)
    console.log(`[getAllPRsForSiteAdmin] ⚠️  This means getLocationByAdminEmail returned null - check if employee exists and is set as location admin`)
    return []
  }
  
  console.log(`[getAllPRsForSiteAdmin] ✅ Found location: ${location.id} (${location.name})`)
  console.log(`[getAllPRsForSiteAdmin] 📍 Location details: _id=${location._id}, id=${location.id}, adminId=${location.adminId}`)
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Employees have locationId stored as string ID (location.id), not ObjectId
  if (!location.id || !/^\d{6}$/.test(location.id)) {
    console.log(`[getAllPRsForSiteAdmin] ❌ Invalid location string ID: ${location.id}`)
    return []
  }
  
  const locationIdString = location.id
  console.log(`[getAllPRsForSiteAdmin] 📍 Using locationId (string): ${locationIdString}`)
  
  // Find all employees assigned to this location using string ID
  const employees = await Employee.find({ locationId: locationIdString })
    .select('_id id employeeId firstName lastName')
    .lean()
  
  console.log(`[getAllPRsForSiteAdmin] 👥 Found ${employees.length} employee(s) for location: ${locationIdString}`)
  if (employees.length > 0) {
    employees.forEach((emp: any, idx: number) => {
      console.log(`[getAllPRsForSiteAdmin]   ${idx + 1}. ${emp.firstName} ${emp.lastName} (ID: ${emp.id}, EmployeeID: ${emp.employeeId}, ObjectId: ${emp._id})`)
    })
  } else {
    console.log(`[getAllPRsForSiteAdmin] ⚠️  No employees found for location: ${locationIdString}`)
    console.log(`[getAllPRsForSiteAdmin] ⚠️  Employees must have locationId set to location's string ID: "${locationIdString}"`)
    return []
  }
  
  // CRITICAL FIX: Order.employeeId is stored as STRING ID (6-digit numeric), not ObjectId
  // Get employee string IDs (employee.id or employee.employeeId)
  const employeeStringIds = employees
    .map((e: any) => e.id || e.employeeId)
    .filter((id: any) => id && /^\d{6}$/.test(String(id)))
  
  if (employeeStringIds.length === 0) {
    console.log(`[getAllPRsForSiteAdmin] No valid employee string IDs found for location: ${locationIdString}`)
    return []
  }
  
  console.log(`[getAllPRsForSiteAdmin] 👥 Employee string IDs: ${employeeStringIds.join(', ')}`)
  
  // Build query filter - Tab 3: Show ALL downstream PRs (after approvals)
  // Include: COMPANY_ADMIN_APPROVED, PO_CREATED, and any other downstream statuses
  // Exclude: PENDING_SITE_ADMIN_APPROVAL (Tab 1), PENDING_COMPANY_ADMIN_APPROVAL (Tab 2)
  // PR visibility driven ONLY by pr_status and createdAt (date filter)
  // NO filtering based on PO/GRN existence
  // CRITICAL: Include orders where pr_status is null/undefined for backward compatibility
  // CRITICAL: Use string IDs, not ObjectIds
  const queryFilter: any = {
    employeeId: { $in: employeeStringIds },
    $or: [
      {
        pr_status: { 
          $in: [
            'COMPANY_ADMIN_APPROVED',  // Approved by company admin
            'PO_CREATED',              // PO created
            'REJECTED_BY_SITE_ADMIN',  // Rejected PRs
            'REJECTED_BY_COMPANY_ADMIN', // Rejected PRs
            'DRAFT',                    // Draft PRs
            'SUBMITTED',                // Submitted PRs
            'SITE_ADMIN_APPROVED'       // Site admin approved (but not yet sent to company admin - edge case)
          ]
        }
      },
      {
        pr_status: { $exists: false }  // Backward compatibility: include orders without pr_status
      },
      {
        pr_status: null  // Backward compatibility: include orders with null pr_status
      }
    ]
  }
  
  console.log(`[getAllPRsForSiteAdmin] 🔍 Query filter (before date filter):`, JSON.stringify(queryFilter, null, 2))
  
  // Apply date filter on PR.createdAt if provided
  if (fromDate || toDate) {
    queryFilter.createdAt = {}
    if (fromDate) {
      queryFilter.createdAt.$gte = fromDate
    }
    if (toDate) {
      // Include entire day for toDate
      const endOfDay = new Date(toDate)
      endOfDay.setHours(23, 59, 59, 999)
      queryFilter.createdAt.$lte = endOfDay
    }
    console.log(`[getAllPRsForSiteAdmin] 📅 Applied date filter:`, queryFilter.createdAt)
  }
  
  console.log(`[getAllPRsForSiteAdmin] 🔍 Final query filter:`, JSON.stringify(queryFilter, null, 2))
  
  // Find ALL orders from employees at this location with downstream statuses
  // NO status filter on order.status - only pr_status matters
  // NO filtering based on PO/GRN existence - PR-only records MUST appear
  const allOrders = await Order.find(queryFilter)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at company_admin_approved_by company_admin_approved_at createdAt')
    .populate('employeeId', 'id employeeId firstName lastName email locationId')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .sort({ createdAt: -1, orderDate: -1 })
    .lean()
  
  console.log(`[getAllPRsForSiteAdmin] 📊 Query returned ${allOrders.length} order(s)`)
  if (allOrders.length > 0) {
    console.log(`[getAllPRsForSiteAdmin] 📋 Sample orders (first 3):`)
    allOrders.slice(0, 3).forEach((order: any, idx: number) => {
      console.log(`  ${idx + 1}. Order ID: ${order.id}, PR Status: ${order.pr_status || 'N/A'}, PR Number: ${order.pr_number || 'N/A'}`)
    })
  } else {
    console.log(`[getAllPRsForSiteAdmin] ⚠️  No orders found matching query filter`)
    console.log(`[getAllPRsForSiteAdmin] 🔍 Checking if any orders exist for these employees (without pr_status filter)...`)
    
    // Check if orders exist without pr_status filter
    const allOrdersNoStatusFilter = await Order.find({ employeeId: { $in: employeeStringIds } })
      .select('id pr_status pr_number')
      .limit(10)
      .lean()
    
    console.log(`[getAllPRsForSiteAdmin] 📊 Found ${allOrdersNoStatusFilter.length} total order(s) for these employees`)
    if (allOrdersNoStatusFilter.length > 0) {
      const statusCounts: Record<string, number> = {}
      allOrdersNoStatusFilter.forEach((o: any) => {
        const status = o.pr_status || 'NULL'
        statusCounts[status] = (statusCounts[status] || 0) + 1
      })
      console.log(`[getAllPRsForSiteAdmin] 📊 PR Status breakdown:`)
      Object.entries(statusCounts).forEach(([status, count]) => {
        console.log(`  ${status}: ${count}`)
      })
      console.log(`[getAllPRsForSiteAdmin] ⚠️  These statuses are NOT in the "My PRs" filter list!`)
    }
  }
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(allOrders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Add vendorName to orders
  allOrders.forEach((o: any) => {
    if (!o.vendorName && o.vendorId && vendorMap.has(o.vendorId)) {
      o.vendorName = vendorMap.get(o.vendorId)
    }
  })
  
  console.log(`[getAllPRsForSiteAdmin] Found ${allOrders.length} order(s) for location: ${location.id}`)
  
  // Group orders by parentOrderId (similar to other functions)
  const parentOrderIds = new Set<string>()
  const standaloneOrders: any[] = []
  const plainOrders = allOrders.map((o: any) => toPlainObject(o))

  console.log(`[getAllPRsForSiteAdmin] 📊 Processing ${plainOrders.length} order(s) for grouping...`)
  
  for (const order of plainOrders) {
    if (order.parentOrderId) {
      parentOrderIds.add(order.parentOrderId)
      console.log(`[getAllPRsForSiteAdmin]   Order ${order.id} has parentOrderId: ${order.parentOrderId}`)
    } else {
      standaloneOrders.push(order)
      console.log(`[getAllPRsForSiteAdmin]   Order ${order.id} is standalone (no parentOrderId)`)
    }
  }
  
  console.log(`[getAllPRsForSiteAdmin] 📊 Grouping summary: ${parentOrderIds.size} parent order ID(s), ${standaloneOrders.length} standalone order(s)`)

  // Fetch child orders with same status and date filter
  const orderMap = new Map<string, any[]>()
  if (parentOrderIds.size > 0) {
    // Build child orders query filter - same status filter as parent orders
    // CRITICAL: Include backward compatibility for null/undefined pr_status
    // CRITICAL: Use string IDs, not ObjectIds
    const childQueryFilter: any = {
      employeeId: { $in: employeeStringIds },
      parentOrderId: { $in: Array.from(parentOrderIds) },
      $or: [
        {
          pr_status: { 
            $in: [
              'COMPANY_ADMIN_APPROVED',
              'PO_CREATED',
              'REJECTED_BY_SITE_ADMIN',
              'REJECTED_BY_COMPANY_ADMIN',
              'DRAFT',
              'SUBMITTED',
              'SITE_ADMIN_APPROVED'
            ]
          }
        },
        {
          pr_status: { $exists: false }  // Backward compatibility: include orders without pr_status
        },
        {
          pr_status: null  // Backward compatibility: include orders with null pr_status
        }
      ]
    }
    
    // Apply same date filter to child orders
    if (fromDate || toDate) {
      childQueryFilter.createdAt = {}
      if (fromDate) {
        childQueryFilter.createdAt.$gte = fromDate
      }
      if (toDate) {
        const endOfDay = new Date(toDate)
        endOfDay.setHours(23, 59, 59, 999)
        childQueryFilter.createdAt.$lte = endOfDay
      }
    }
    
    const allChildOrders = await Order.find(childQueryFilter)
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at company_admin_approved_by company_admin_approved_at createdAt')
      .populate('employeeId', 'id employeeId firstName lastName email locationId')
      .populate('companyId', 'id name')
      .populate('items.uniformId', 'id name')
      .lean()
    
    const allChildOrdersPlain = allChildOrders.map((o: any) => toPlainObject(o))
    
    // Add vendor names to child orders
    allChildOrdersPlain.forEach((o: any) => {
      if (!o.vendorName && o.vendorId && vendorMap.has(o.vendorId)) {
        o.vendorName = vendorMap.get(o.vendorId)
      }
    })
    
    for (const childOrder of allChildOrdersPlain) {
      const parentId = childOrder.parentOrderId
      if (!orderMap.has(parentId)) {
        orderMap.set(parentId, [])
      }
      orderMap.get(parentId)!.push(childOrder)
    }
  }

  // Group parent orders with their children
  const groupedOrders: any[] = []
  
  // CRITICAL FIX: Handle case where parent orders might not be in query results
  // If parentOrderId exists but parent order is not in plainOrders, fetch it separately
  const missingParentIds: string[] = []
  for (const parentId of parentOrderIds) {
    const parentOrder = plainOrders.find((o: any) => o.id === parentId)
    if (!parentOrder) {
      missingParentIds.push(parentId)
    }
  }
  
  // Fetch missing parent orders if any
  let missingParents: any[] = []
  if (missingParentIds.length > 0) {
    console.log(`[getAllPRsForSiteAdmin] ⚠️  Found ${missingParentIds.length} parent order(s) not in query results, fetching separately...`)
    const missingParentOrders = await Order.find({
      id: { $in: missingParentIds }
    })
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at company_admin_approved_by company_admin_approved_at createdAt')
      .populate('employeeId', 'id employeeId firstName lastName email locationId')
      .populate('companyId', 'id name')
      .populate('items.uniformId', 'id name')
      .lean()
    
    missingParents = missingParentOrders.map((o: any) => toPlainObject(o))
    
    // Add vendor names to missing parents
    missingParents.forEach((o: any) => {
      if (!o.vendorName && o.vendorId && vendorMap.has(o.vendorId)) {
        o.vendorName = vendorMap.get(o.vendorId)
      }
    })
    
    console.log(`[getAllPRsForSiteAdmin] ✅ Fetched ${missingParents.length} missing parent order(s)`)
  }
  
  // Combine plainOrders with missing parents for parent lookup
  const allParentOrders = [...plainOrders, ...missingParents]
  
  // Add standalone orders (no parent, no children)
  console.log(`[getAllPRsForSiteAdmin] 📊 Adding ${standaloneOrders.length} standalone order(s)...`)
  for (const order of standaloneOrders) {
    if (!parentOrderIds.has(order.id)) {
      groupedOrders.push({
        ...order,
        childOrders: [],
        isParent: false,
        totalChildAmount: 0,
        totalChildItems: 0
      })
      console.log(`[getAllPRsForSiteAdmin]   ✅ Added standalone order: ${order.id}`)
    } else {
      console.log(`[getAllPRsForSiteAdmin]   ⚠️  Skipping standalone order ${order.id} - it's also a parentOrderId`)
    }
  }
  
  // Add parent orders with their children
  console.log(`[getAllPRsForSiteAdmin] 📊 Processing ${parentOrderIds.size} parent order ID(s)...`)
  for (const parentId of parentOrderIds) {
    const parentOrder = allParentOrders.find((o: any) => o.id === parentId)
    if (parentOrder) {
      const childOrders = orderMap.get(parentId) || []
      const totalChildAmount = childOrders.reduce((sum, child) => sum + (child.total || 0), 0)
      const totalChildItems = childOrders.reduce((sum, child) => sum + (child.items?.length || 0), 0)
      
      console.log(`[getAllPRsForSiteAdmin]   ✅ Found parent order ${parentId} with ${childOrders.length} child order(s)`)
      
      groupedOrders.push({
        ...parentOrder,
        childOrders: childOrders,
        isParent: true,
        totalChildAmount,
        totalChildItems,
        totalAmount: (parentOrder.total || 0) + totalChildAmount,
        totalItems: (parentOrder.items?.length || 0) + totalChildItems
      })
    } else {
      // If parent order still not found, create a grouped order from child orders only
      const childOrders = orderMap.get(parentId) || []
      if (childOrders.length > 0) {
        console.log(`[getAllPRsForSiteAdmin] ⚠️  Parent order ${parentId} not found, creating grouped order from ${childOrders.length} child order(s)`)
        const firstChild = childOrders[0]
        const totalChildAmount = childOrders.reduce((sum, child) => sum + (child.total || 0), 0)
        const totalChildItems = childOrders.reduce((sum, child) => sum + (child.items?.length || 0), 0)
        
        groupedOrders.push({
          id: parentId,
          parentOrderId: parentId,
          employeeId: firstChild.employeeId,
          employeeIdNum: firstChild.employeeIdNum,
          employeeName: firstChild.employeeName,
          items: childOrders.flatMap((o: any) => o.items || []),
          total: totalChildAmount,
          status: firstChild.status,
          orderDate: firstChild.orderDate,
          dispatchLocation: firstChild.dispatchLocation,
          companyId: firstChild.companyId,
          deliveryAddress: firstChild.deliveryAddress,
          pr_number: firstChild.pr_number,
          pr_date: firstChild.pr_date,
          pr_status: firstChild.pr_status,
          childOrders: childOrders,
          isParent: true,
          isSplitOrder: true,
          splitOrders: childOrders.map((o: any) => ({
            orderId: o.id,
            vendorName: o.vendorName,
            total: o.total,
            itemCount: o.items?.length || 0
          })),
          totalChildAmount,
          totalChildItems,
          totalAmount: totalChildAmount,
          totalItems: totalChildItems,
          vendorId: null,
          vendorName: null,
          isPersonalPayment: firstChild.isPersonalPayment || false,
          personalPaymentAmount: firstChild.personalPaymentAmount || 0,
          createdAt: firstChild.createdAt,
        })
      }
    }
  }
  
  // Sort by creation date (most recent first)
  groupedOrders.sort((a, b) => {
    const dateA = new Date(a.createdAt || a.orderDate || 0).getTime()
    const dateB = new Date(b.createdAt || b.orderDate || 0).getTime()
    return dateB - dateA
  })
  
  console.log(`[getAllPRsForSiteAdmin] Returning ${groupedOrders.length} grouped order(s)`)
  
  return groupedOrders
}

export async function getApprovedPRsForSiteAdmin(
  adminEmail: string,
  fromDate?: Date,
  toDate?: Date
): Promise<any[]> {
  await connectDB()
  
  // Get location for this site admin
  const location = await getLocationByAdminEmail(adminEmail)
  if (!location) {
    console.log(`[getApprovedPRsForSiteAdmin] No location found for admin: ${adminEmail}`)
    return []
  }
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Employees have locationId stored as string ID (location.id), not ObjectId
  if (!location.id || !/^\d{6}$/.test(location.id)) {
    console.log(`[getApprovedPRsForSiteAdmin] ❌ Invalid location string ID: ${location.id}`)
    return []
  }
  
  const locationIdString = location.id
  console.log(`[getApprovedPRsForSiteAdmin] Found location: ${locationIdString} (${location.name}) for admin: ${adminEmail}`)
  
  // Find all employees assigned to this location using string ID
  const employees = await Employee.find({ locationId: locationIdString })
    .select('_id id employeeId')
    .lean()
  
  if (employees.length === 0) {
    console.log(`[getApprovedPRsForSiteAdmin] No employees found for location: ${locationIdString}`)
    console.log(`[getApprovedPRsForSiteAdmin] Employees must have locationId set to location's string ID: "${locationIdString}"`)
    return []
  }
  
  // CRITICAL FIX: Order.employeeId is stored as STRING ID (6-digit numeric), not ObjectId
  // Get employee string IDs (employee.id or employee.employeeId)
  const employeeStringIds = employees
    .map((e: any) => e.id || e.employeeId)
    .filter((id: any) => id && /^\d{6}$/.test(String(id)))
  
  if (employeeStringIds.length === 0) {
    console.log(`[getApprovedPRsForSiteAdmin] No valid employee string IDs found for location: ${locationIdString}`)
    return []
  }
  
  console.log(`[getApprovedPRsForSiteAdmin] Found ${employeeStringIds.length} employee(s) for location: ${location.id}`)
  console.log(`[getApprovedPRsForSiteAdmin] Employee string IDs:`, employeeStringIds)
  
  // Build query filter - Tab 2: Only PENDING_COMPANY_ADMIN_APPROVAL
  // PR visibility driven ONLY by pr_status and createdAt (date filter)
  // NO filtering based on PO/GRN existence
  // CRITICAL: Use string IDs, not ObjectIds
  const queryFilter: any = {
    employeeId: { $in: employeeStringIds },
    pr_status: 'PENDING_COMPANY_ADMIN_APPROVAL', // Tab 2: Only pending company admin approval
  }
  
  // Apply date filter on PR.createdAt if provided
  if (fromDate || toDate) {
    queryFilter.createdAt = {}
    if (fromDate) {
      queryFilter.createdAt.$gte = fromDate
    }
    if (toDate) {
      // Include entire day for toDate
      const endOfDay = new Date(toDate)
      endOfDay.setHours(23, 59, 59, 999)
      queryFilter.createdAt.$lte = endOfDay
    }
  }
  
  // Find orders approved by site admin and pending company admin approval
  // NO status filter on order.status - only pr_status matters
  // CRITICAL: Don't use populate since Order.employeeId is a string ID
  const approvedOrders = await Order.find(queryFilter)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at createdAt')
    .sort({ site_admin_approved_at: -1, orderDate: -1 })
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(approvedOrders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Manually populate employee, company, and uniform info using string IDs
  const approvedOrdersWithDetails = await Promise.all(approvedOrders.map(async (o: any) => {
    const plain = toPlainObject(o)
    
    // Manually fetch employee info using string ID
    if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
      const employee = await Employee.findOne({ 
        $or: [
          { id: plain.employeeId },
          { employeeId: plain.employeeId }
        ]
      }).select('id employeeId firstName lastName email locationId').lean()
      
      if (employee) {
        // Decrypt employee fields since we used .lean()
        const { decrypt } = require('../utils/encryption')
        const decryptedEmployee: any = { ...employee }
        const sensitiveFields = ['firstName', 'lastName', 'email']
        
        for (const field of sensitiveFields) {
          if (decryptedEmployee[field] && typeof decryptedEmployee[field] === 'string' && decryptedEmployee[field].includes(':')) {
            try {
              decryptedEmployee[field] = decrypt(decryptedEmployee[field])
            } catch (error) {
              // If decryption fails, keep original value
            }
          }
        }
        
        // Construct employeeName from decrypted firstName and lastName
        const decryptedFirstName = decryptedEmployee.firstName || ''
        const decryptedLastName = decryptedEmployee.lastName || ''
        const decryptedEmployeeName = `${decryptedFirstName} ${decryptedLastName}`.trim() || 'Employee'
        plain.employeeName = decryptedEmployeeName
        
        plain.employeeId = toPlainObject(decryptedEmployee)
      }
    }
    
    // Manually fetch company info using string ID
    if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
      const company = await Company.findOne({ id: plain.companyId })
        .select('id name')
        .lean()
      if (company) {
        plain.companyId = toPlainObject(company)
      }
    }
    
    // Manually fetch uniform info for items
    if (plain.items && Array.isArray(plain.items)) {
      const uniformIds = [...new Set(plain.items.map((item: any) => item.uniformId).filter(Boolean))]
      if (uniformIds.length > 0) {
        const Uniform = require('../models/Uniform').default
        const uniforms = await Uniform.find({ id: { $in: uniformIds } })
          .select('id name')
          .lean()
        const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
        
        plain.items = plain.items.map((item: any) => {
          if (item.uniformId && uniformMap.has(item.uniformId)) {
            item.uniformId = uniformMap.get(item.uniformId)
          }
          return item
        })
      }
    }
    
    // Add vendorName
    if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
      plain.vendorName = vendorMap.get(plain.vendorId)
    }
    
    return plain
  }))
  
  console.log(`[getApprovedPRsForSiteAdmin] Found ${approvedOrdersWithDetails.length} order(s) approved by site admin`)
  
  // Group orders by parentOrderId (similar to getPendingApprovalsForSiteAdmin)
  const parentOrderIds = new Set<string>()
  const standaloneOrders: any[] = []
  const plainOrders = approvedOrdersWithDetails

  for (const order of plainOrders) {
    if (order.parentOrderId) {
      parentOrderIds.add(order.parentOrderId)
    } else {
      standaloneOrders.push(order)
    }
  }

  // Fetch child orders
  const orderMap = new Map<string, any[]>()
  if (parentOrderIds.size > 0) {
    // Build child orders query filter - same status and date filter as parent orders
    // CRITICAL: Use string IDs, not ObjectIds
    const childQueryFilter: any = {
      employeeId: { $in: employeeStringIds },
      parentOrderId: { $in: Array.from(parentOrderIds) },
      pr_status: 'PENDING_COMPANY_ADMIN_APPROVAL',
    }
    
    // Apply same date filter to child orders
    if (fromDate || toDate) {
      childQueryFilter.createdAt = {}
      if (fromDate) {
        childQueryFilter.createdAt.$gte = fromDate
      }
      if (toDate) {
        const endOfDay = new Date(toDate)
        endOfDay.setHours(23, 59, 59, 999)
        childQueryFilter.createdAt.$lte = endOfDay
      }
    }
    
    const allChildOrders = await Order.find(childQueryFilter)
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount pr_number pr_date pr_status site_admin_approved_by site_admin_approved_at createdAt')
      .lean()
    
    // Manually populate child orders with employee, company, and uniform info
    const allChildOrdersPlain = await Promise.all(allChildOrders.map(async (o: any) => {
      const plain = toPlainObject(o)
      
      // Manually fetch employee info using string ID
      if (plain.employeeId && typeof plain.employeeId === 'string' && /^\d{6}$/.test(plain.employeeId)) {
        const employee = await Employee.findOne({ 
          $or: [
            { id: plain.employeeId },
            { employeeId: plain.employeeId }
          ]
        }).select('id employeeId firstName lastName email locationId').lean()
        
        if (employee) {
          // Decrypt employee fields since we used .lean()
          const { decrypt } = require('../utils/encryption')
          const decryptedEmployee: any = { ...employee }
          const sensitiveFields = ['firstName', 'lastName', 'email']
          
          for (const field of sensitiveFields) {
            if (decryptedEmployee[field] && typeof decryptedEmployee[field] === 'string' && decryptedEmployee[field].includes(':')) {
              try {
                decryptedEmployee[field] = decrypt(decryptedEmployee[field])
              } catch (error) {
                // If decryption fails, keep original value
              }
            }
          }
          
          // Construct employeeName from decrypted firstName and lastName
          const decryptedFirstName = decryptedEmployee.firstName || ''
          const decryptedLastName = decryptedEmployee.lastName || ''
          const decryptedEmployeeName = `${decryptedFirstName} ${decryptedLastName}`.trim() || 'Employee'
          plain.employeeName = decryptedEmployeeName
          
          plain.employeeId = toPlainObject(decryptedEmployee)
        }
      }
      
      // Manually fetch company info using string ID
      if (plain.companyId && typeof plain.companyId === 'string' && /^\d{6}$/.test(plain.companyId)) {
        const company = await Company.findOne({ id: plain.companyId })
          .select('id name')
          .lean()
        if (company) {
          plain.companyId = toPlainObject(company)
        }
      }
      
      // Manually fetch uniform info for items
      if (plain.items && Array.isArray(plain.items)) {
        const uniformIds = [...new Set(plain.items.map((item: any) => item.uniformId).filter(Boolean))]
        if (uniformIds.length > 0) {
          const Uniform = require('../models/Uniform').default
          const uniforms = await Uniform.find({ id: { $in: uniformIds } })
            .select('id name')
            .lean()
          const uniformMap = new Map(uniforms.map((u: any) => [u.id, toPlainObject(u)]))
          
          plain.items = plain.items.map((item: any) => {
            if (item.uniformId && uniformMap.has(item.uniformId)) {
              item.uniformId = uniformMap.get(item.uniformId)
            }
            return item
          })
        }
      }
      
      // Add vendorName
      if (!plain.vendorName && plain.vendorId && vendorMap.has(plain.vendorId)) {
        plain.vendorName = vendorMap.get(plain.vendorId)
      }
      
      return plain
    }))
    
    for (const order of allChildOrdersPlain) {
      if (order.parentOrderId) {
        if (!orderMap.has(order.parentOrderId)) {
          orderMap.set(order.parentOrderId, [])
        }
        orderMap.get(order.parentOrderId)!.push(order)
      }
    }
  }

  // Create grouped orders (one per parentOrderId) and add standalone orders
  const groupedOrders: any[] = []
  
  for (const [parentOrderId, splitOrders] of orderMap.entries()) {
    // Sort split orders by vendor name for consistency
    splitOrders.sort((a, b) => (a.vendorName || '').localeCompare(b.vendorName || ''))
    
    // Calculate totals
    const totalItems = splitOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)
    const totalAmount = splitOrders.reduce((sum, o) => sum + (o.total || 0), 0)
    
    groupedOrders.push({
      id: parentOrderId, // Use parentOrderId as the main ID for grouped orders
      parentOrderId: parentOrderId,
      employeeId: splitOrders[0]?.employeeId,
      employeeIdNum: splitOrders[0]?.employeeIdNum,
      employeeName: splitOrders[0]?.employeeName,
      items: splitOrders.flatMap((o: any) => o.items || []),
      total: totalAmount,
      status: splitOrders[0]?.status,
      orderDate: splitOrders[0]?.orderDate,
      dispatchLocation: splitOrders[0]?.dispatchLocation,
      companyId: splitOrders[0]?.companyId,
      deliveryAddress: splitOrders[0]?.deliveryAddress,
      pr_number: splitOrders[0]?.pr_number,
      pr_date: splitOrders[0]?.pr_date,
      pr_status: splitOrders[0]?.pr_status,
      site_admin_approved_at: splitOrders[0]?.site_admin_approved_at,
      isSplitOrder: true,
      splitOrders: splitOrders.map((o: any) => ({
        orderId: o.id,
        vendorName: o.vendorName,
        total: o.total,
        itemCount: o.items?.length || 0
      })),
      vendorId: null, // Multiple vendors for split orders
      vendorName: null, // Multiple vendors for split orders
      isPersonalPayment: splitOrders[0]?.isPersonalPayment || false,
      personalPaymentAmount: splitOrders[0]?.personalPaymentAmount || 0,
      createdAt: splitOrders[0]?.createdAt,
    })
  }
  
  // Add standalone orders
  groupedOrders.push(...standaloneOrders)
  
  // Sort by approval date (newest first)
  groupedOrders.sort((a, b) => {
    const dateA = a.site_admin_approved_at ? new Date(a.site_admin_approved_at).getTime() : (a.orderDate ? new Date(a.orderDate).getTime() : 0)
    const dateB = b.site_admin_approved_at ? new Date(b.site_admin_approved_at).getTime() : (b.orderDate ? new Date(b.orderDate).getTime() : 0)
    return dateB - dateA
  })
  
  console.log(`[getApprovedPRsForSiteAdmin] Returning ${groupedOrders.length} order(s) (${groupedOrders.filter(o => o.isSplitOrder).length} grouped, ${groupedOrders.filter(o => !o.isSplitOrder).length} standalone)`)
  
  return groupedOrders
}

/**
 * Create Purchase Order(s) from approved PRs and trigger vendor fulfilment
 * Creates one PO per vendor automatically
 * @param orderIds Array of order IDs (PRs) to include in PO(s)
 * @param poNumber Client-generated PO number
 * @param poDate PO creation date
 * @param companyId Company ID
 * @param createdByUserId Employee ID of the user creating the PO
 * @returns Created PO(s) with fulfilment status
 */
export async function createPurchaseOrderFromPRs(
  orderIds: string[],
  poNumber: string,
  poDate: Date,
  companyId: string,
  createdByUserId: string
): Promise<{ success: boolean, purchaseOrders: any[], message: string }> {
  await connectDB()
  
  console.log(`[createPurchaseOrderFromPRs] ========================================`)
  console.log(`[createPurchaseOrderFromPRs] 🚀 CREATING PO FROM PRs`)
  console.log(`[createPurchaseOrderFromPRs] PO Number: ${poNumber}`)
  console.log(`[createPurchaseOrderFromPRs] PO Date: ${poDate.toISOString()}`)
  console.log(`[createPurchaseOrderFromPRs] Order IDs: ${orderIds.join(', ')}`)
  console.log(`[createPurchaseOrderFromPRs] Company ID: ${companyId}`)
  console.log(`[createPurchaseOrderFromPRs] Created By: ${createdByUserId}`)
  
  // Validate inputs
  if (!orderIds || orderIds.length === 0) {
    throw new Error('At least one order ID is required')
  }
  if (!poNumber || !poNumber.trim()) {
    throw new Error('PO Number is required')
  }
  if (!poDate) {
    throw new Error('PO Date is required')
  }
  
  // Find company
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }
  
  // Find creating user (employee)
  const creatingEmployee = await Employee.findOne({ id: createdByUserId })
  if (!creatingEmployee) {
    throw new Error(`Employee not found: ${createdByUserId}`)
  }
  
  // Fetch all orders (PRs) - handle both parent order IDs and child order IDs
  const allOrderIds = new Set<string>()
  const ordersToProcess: any[] = []
  
  for (const orderId of orderIds) {
    // CRITICAL FIX: Fetch order and immediately convert to plain object to ensure vendorId is accessible
    // Use lean() to get plain JavaScript object with all fields guaranteed to be present
    let order = await Order.findOne({ id: orderId }).lean()
    
    // If not found, check if it's a parent order ID
    if (!order) {
      const childOrders = await Order.find({ parentOrderId: orderId }).lean()
      if (childOrders.length > 0) {
        // It's a parent order - add all child orders
        for (const childOrder of childOrders) {
          if (!allOrderIds.has(childOrder.id)) {
            allOrderIds.add(childOrder.id)
            ordersToProcess.push(childOrder)
          }
        }
        continue
      } else {
        throw new Error(`Order not found: ${orderId}`)
      }
    }
    
    // Check if this order has a parentOrderId (it's a child order)
    if (order.parentOrderId) {
      // Fetch all sibling orders
      const siblingOrders = await Order.find({ parentOrderId: order.parentOrderId }).lean()
      for (const siblingOrder of siblingOrders) {
        if (!allOrderIds.has(siblingOrder.id)) {
          allOrderIds.add(siblingOrder.id)
          ordersToProcess.push(siblingOrder)
        }
      }
    } else {
      // Standalone order
      if (!allOrderIds.has(order.id)) {
        allOrderIds.add(order.id)
        ordersToProcess.push(order)
      }
    }
  }
  
  console.log(`[createPurchaseOrderFromPRs] Found ${ordersToProcess.length} order(s) to process`)
  
  // CRITICAL: Pre-validate all orders have valid vendorId BEFORE processing
  // This fails fast and provides clear error messages
  const ordersWithInvalidVendorId: Array<{ orderId: string, vendorId: any, reason: string }> = []
  
  for (const order of ordersToProcess) {
    console.log(`[createPurchaseOrderFromPRs] 📋 Pre-validating order ${order.id}:`)
    console.log(`[createPurchaseOrderFromPRs]   - _id: ${order._id?.toString()}`)
    console.log(`[createPurchaseOrderFromPRs]   - vendorId: ${order.vendorId} (type: ${typeof order.vendorId})`)
    console.log(`[createPurchaseOrderFromPRs]   - vendorName: ${order.vendorName}`)
    console.log(`[createPurchaseOrderFromPRs]   - Has vendorId property: ${'vendorId' in order}`)
    
    // Validate vendorId exists and is in correct format
    if (!order.vendorId || order.vendorId === null || order.vendorId === undefined) {
      ordersWithInvalidVendorId.push({
        orderId: order.id,
        vendorId: order.vendorId,
        reason: 'vendorId is null or undefined'
      })
      continue
    }
    
    // Check if vendorId is in correct format (6-digit numeric string)
    const vendorIdStr = typeof order.vendorId === 'string' 
      ? order.vendorId.trim() 
      : String(order.vendorId).trim()
    
    if (!/^\d{6}$/.test(vendorIdStr)) {
      ordersWithInvalidVendorId.push({
        orderId: order.id,
        vendorId: order.vendorId,
        reason: `vendorId is not a 6-digit numeric string. Received: "${vendorIdStr}" (type: ${typeof order.vendorId})`
      })
    }
  }
  
  // Fail fast if any orders have invalid vendorId
  if (ordersWithInvalidVendorId.length > 0) {
    console.error(`[createPurchaseOrderFromPRs] ❌ PRE-VALIDATION FAILED: ${ordersWithInvalidVendorId.length} order(s) have invalid vendorId`)
    for (const invalid of ordersWithInvalidVendorId) {
      console.error(`[createPurchaseOrderFromPRs]   - Order ${invalid.orderId}: ${invalid.reason}`)
    }
    throw new Error(
      `Cannot create PO: ${ordersWithInvalidVendorId.length} order(s) have invalid vendorId. ` +
      `Orders: ${ordersWithInvalidVendorId.map(o => o.orderId).join(', ')}. ` +
      `Please ensure all orders have a valid 6-digit numeric vendorId before creating PO.`
    )
  }
  
  // Validate all orders are approved PRs or already have PO created
  // BUSINESS RULE: PO creation is allowed when pr_status is:
  // - PENDING_COMPANY_ADMIN_APPROVAL (awaiting Company Admin approval)
  // - SITE_ADMIN_APPROVED (Site Admin approved, no Company Admin approval needed)
  // - PO_CREATED (PR already has PO created - allows re-creating or updating PO)
  for (const order of ordersToProcess) {
    const validStatuses = ['PENDING_COMPANY_ADMIN_APPROVAL', 'SITE_ADMIN_APPROVED', 'PO_CREATED']
    if (!validStatuses.includes(order.pr_status)) {
      throw new Error(`Order ${order.id} is not in a valid status for PO creation. Current status: ${order.pr_status}. Valid statuses: ${validStatuses.join(', ')}`)
    }
    // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
    // Compare with company.id (string ID) instead of company._id (ObjectId)
    const orderCompanyId = String(order.companyId || '').trim()
    const companyIdStr = String(company.id || '').trim()
    if (orderCompanyId !== companyIdStr) {
      throw new Error(`Order ${order.id} does not belong to company ${companyId}. Order companyId: ${orderCompanyId}, Expected: ${companyIdStr}`)
    }
  }
  
  console.log(`[createPurchaseOrderFromPRs] ✅ Pre-validation passed: All ${ordersToProcess.length} order(s) have valid vendorId`)
  
  // Group orders by vendor - first resolve vendors to get their numeric IDs
  const ordersByVendor = new Map<string, any[]>()
  const vendorIdMap = new Map<string, any>() // Map: vendor numeric ID -> vendor document
  
  for (const order of ordersToProcess) {
    console.log(`[createPurchaseOrderFromPRs] 🔍 Processing order: ${order.id}`)
    
    // CRITICAL FIX: Orders are fetched with .lean() so they're plain JavaScript objects
    // vendorId should be directly accessible as order.vendorId
    let vendorIdValue: string | null = null
    
    // Direct property access - orders are plain objects from .lean()
    if (order.vendorId !== undefined && order.vendorId !== null) {
      const rawVendorId = order.vendorId
      console.log(`[createPurchaseOrderFromPRs]   Found vendorId in order: ${rawVendorId} (type: ${typeof rawVendorId})`)
      
      // Handle different formats (defensive programming)
      if (typeof rawVendorId === 'string') {
        vendorIdValue = rawVendorId.trim()
      } else if (typeof rawVendorId === 'object' && rawVendorId !== null) {
        // Legacy: handle populated object (shouldn't happen with .lean(), but defensive)
        if ((rawVendorId as any).id && /^\d{6}$/.test(String((rawVendorId as any).id))) {
          vendorIdValue = String((rawVendorId as any).id).trim()
        } else {
          vendorIdValue = String((rawVendorId as any)._id || rawVendorId).trim()
        }
      } else {
        vendorIdValue = String(rawVendorId).trim()
      }
      
      console.log(`[createPurchaseOrderFromPRs]   Processed vendorId: ${vendorIdValue}`)
    } else {
      console.error(`[createPurchaseOrderFromPRs] ❌ Order ${order.id} has null/undefined vendorId`)
      console.error(`[createPurchaseOrderFromPRs]   Order keys:`, Object.keys(order))
      console.error(`[createPurchaseOrderFromPRs]   Order vendorId property exists: ${'vendorId' in order}`)
    }
    
    // Validate vendorId format - must be exactly 6 digits
    if (!vendorIdValue || vendorIdValue === 'null' || vendorIdValue === 'undefined' || !/^\d{6}$/.test(vendorIdValue)) {
      console.error(`[createPurchaseOrderFromPRs] ❌ Order ${order.id} missing or invalid vendorId`)
      console.error(`[createPurchaseOrderFromPRs]   Order data:`, {
        id: order.id,
        _id: order._id?.toString(),
        vendorId: order.vendorId,
        vendorIdValue: vendorIdValue,
        vendorIdType: typeof order.vendorId,
        vendorName: order.vendorName,
        parentOrderId: order.parentOrderId,
        orderKeys: Object.keys(order)
      })
      
      // Try one more time with direct database query - check what's actually stored
      try {
        console.log(`[createPurchaseOrderFromPRs] 🔍 Attempting direct database query for order ${order.id}...`)
        const directOrder = await Order.findOne({ id: order.id }).lean()
        
        if (!directOrder) {
          console.error(`[createPurchaseOrderFromPRs] ❌ Order ${order.id} not found in database!`)
        } else {
          console.log(`[createPurchaseOrderFromPRs] 📊 Direct order query result:`)
          console.log(`[createPurchaseOrderFromPRs]   - vendorId: ${directOrder.vendorId}`)
          console.log(`[createPurchaseOrderFromPRs]   - vendorId type: ${typeof directOrder.vendorId}`)
          console.log(`[createPurchaseOrderFromPRs]   - vendorName: ${directOrder.vendorName}`)
          console.log(`[createPurchaseOrderFromPRs]   - All order fields:`, Object.keys(directOrder))
          
          if (directOrder.vendorId) {
            let directVendorId = typeof directOrder.vendorId === 'string' 
              ? directOrder.vendorId.trim() 
              : String(directOrder.vendorId).trim()
            
            console.log(`[createPurchaseOrderFromPRs]   - Processed vendorId: ${directVendorId}`)
            console.log(`[createPurchaseOrderFromPRs]   - Is 6-digit format: ${/^\d{6}$/.test(directVendorId)}`)
            
            // If it's not a 6-digit format, try to look up the vendor by string ID
            if (!/^\d{6}$/.test(directVendorId)) {
              console.log(`[createPurchaseOrderFromPRs] ⚠️ Order ${order.id} has non-standard vendorId: ${directVendorId}, looking up vendor...`)
              try {
                const legacyVendor = await Vendor.findOne({ id: directVendorId })
                if (legacyVendor && legacyVendor.id) {
                  directVendorId = String(legacyVendor.id).trim()
                  console.log(`[createPurchaseOrderFromPRs] ✅ Converted legacy ObjectId to numeric ID: ${directVendorId}`)
                  
                  // Update the order in database to use numeric ID
                  await Order.updateOne({ id: order.id }, { vendorId: directVendorId })
                  console.log(`[createPurchaseOrderFromPRs] ✅ Updated order ${order.id} to use numeric vendorId`)
                } else {
                  console.error(`[createPurchaseOrderFromPRs] ❌ Legacy vendor not found for ObjectId: ${directVendorId}`)
                }
              } catch (legacyError) {
                console.error(`[createPurchaseOrderFromPRs] Error looking up legacy vendor:`, legacyError)
              }
            }
            
            if (/^\d{6}$/.test(directVendorId)) {
              console.log(`[createPurchaseOrderFromPRs] ✅ Found valid vendorId via direct query: ${directVendorId}`)
              vendorIdValue = directVendorId
            } else {
              console.error(`[createPurchaseOrderFromPRs] ❌ Direct query vendorId is not in 6-digit format: ${directVendorId}`)
            }
          } else {
            console.error(`[createPurchaseOrderFromPRs] ❌ Direct order query shows vendorId is null/undefined`)
            
            // Last resort: try to get vendor from order items
            console.log(`[createPurchaseOrderFromPRs] 🔍 Attempting to get vendor from order items...`)
            if (directOrder.items && directOrder.items.length > 0) {
              const firstItem = directOrder.items[0]
              if (firstItem && firstItem.productId) {
                try {
                  const Uniform = (await import('@/lib/models/Uniform')).default
                  const ProductVendor = (await import('@/lib/models/Relationship')).ProductVendor
                  
                  const product = await Uniform.findOne({ id: firstItem.productId }).lean()
                  if (product && product._id) {
                    const productVendorLink = await ProductVendor.findOne({ 
                      productId: product._id 
                    }).populate('vendorId', 'id name').lean()
                    
                    if (productVendorLink && productVendorLink.vendorId) {
                      const vendorObj = productVendorLink.vendorId as any
                      const extractedVendorId = vendorObj.id || String(vendorObj._id)
                      if (/^\d{6}$/.test(String(extractedVendorId))) {
                        console.log(`[createPurchaseOrderFromPRs] ✅ Found vendorId from ProductVendor: ${extractedVendorId}`)
                        vendorIdValue = String(extractedVendorId).trim()
                        
                        // Update the order with the found vendorId
                        await Order.updateOne({ id: order.id }, { 
                          vendorId: vendorIdValue,
                          vendorName: vendorObj.name || order.vendorName
                        })
                        console.log(`[createPurchaseOrderFromPRs] ✅ Updated order ${order.id} with vendorId from ProductVendor`)
                      }
                    }
                  }
                } catch (itemError) {
                  console.error(`[createPurchaseOrderFromPRs] Error getting vendor from items:`, itemError)
                }
              }
            }
          }
        }
      } catch (directError) {
        console.error(`[createPurchaseOrderFromPRs] Direct query also failed:`, directError)
        console.error(`[createPurchaseOrderFromPRs] Error stack:`, directError.stack)
      }
      
      // Final check after direct query and all fallbacks
      if (!vendorIdValue || !/^\d{6}$/.test(vendorIdValue)) {
        // CRITICAL: Log the actual database state for debugging
        const dbOrder = await Order.findOne({ id: order.id }).lean()
        console.error(`[createPurchaseOrderFromPRs] ❌ FINAL VALIDATION FAILED for order ${order.id}`)
        console.error(`[createPurchaseOrderFromPRs]   Database vendorId: ${dbOrder?.vendorId}`)
        console.error(`[createPurchaseOrderFromPRs]   Database vendorId type: ${typeof dbOrder?.vendorId}`)
        console.error(`[createPurchaseOrderFromPRs]   Extracted vendorIdValue: ${vendorIdValue}`)
        throw new Error(`Order ${order.id} does not have a valid vendor assigned. Vendor ID must be a 6-digit numeric string. Received: ${vendorIdValue || 'null/undefined'}`)
      }
    }
    
    // Look up vendor by numeric ID (6-digit string)
    const vendor = await Vendor.findOne({ id: vendorIdValue })
    
    if (!vendor) {
      console.error(`[createPurchaseOrderFromPRs] ⚠️ Could not find vendor with ID: ${vendorIdValue}`)
      console.error(`[createPurchaseOrderFromPRs]   Order ID: ${order.id}`)
      
      // List available vendors for debugging
      const sampleVendors = await Vendor.find({}, 'id name _id').limit(5).lean()
      console.error(`[createPurchaseOrderFromPRs] Available vendors (sample):`, 
        sampleVendors.map((v: any) => `id=${v.id}, _id=${v._id?.toString()}, name=${v.name}`))
      
      throw new Error(`Vendor not found for order ${order.id}. Vendor ID: ${vendorIdValue}`)
    }
    
    // Use vendor's numeric ID as the key for grouping
    const vendorKey = vendor.id // Numeric vendor ID (e.g., "100001")
    
    if (!vendorIdMap.has(vendorKey)) {
      vendorIdMap.set(vendorKey, vendor)
    }
    
    if (!ordersByVendor.has(vendorKey)) {
      ordersByVendor.set(vendorKey, [])
    }
    ordersByVendor.get(vendorKey)!.push(order)
  }
  
  console.log(`[createPurchaseOrderFromPRs] Orders grouped into ${ordersByVendor.size} vendor(s)`)
  
  // Create one PO per vendor
  const createdPOs: any[] = []
  
  for (const [vendorNumericId, vendorOrders] of ordersByVendor.entries()) {
    // Get vendor document from map
    const vendor = vendorIdMap.get(vendorNumericId)
    
    if (!vendor) {
      throw new Error(`Vendor not found in map: ${vendorNumericId}`)
    }
    
    console.log(`[createPurchaseOrderFromPRs] Creating PO for vendor: ${vendor.name} (${vendor.id})`)
    console.log(`[createPurchaseOrderFromPRs]   Orders: ${vendorOrders.length}`)
    
    // Generate PO ID
    const poId = `PO-${company.id}-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`
    
    // Create PO - use vendor numeric ID (6-digit string) instead of ObjectId
    // CRITICAL FIX: PurchaseOrder.companyId and PurchaseOrder.created_by_user_id are STRING IDs (6-digit numeric), not ObjectIds
    const purchaseOrder = await PurchaseOrder.create({
      id: poId,
      companyId: company.id, // Use string ID (6-digit numeric), not ObjectId
      vendorId: vendor.id, // Use vendor numeric ID (6-digit string, e.g., "100001")
      client_po_number: poNumber.trim(),
      po_date: poDate,
      po_status: 'SENT_TO_VENDOR', // Immediately send to vendor for fulfilment
      created_by_user_id: creatingEmployee.id || creatingEmployee.employeeId // Use string ID (6-digit numeric), not ObjectId
    })
    
    console.log(`[createPurchaseOrderFromPRs] ✅ Created PO: ${poId} for vendor ${vendor.name}`)
    
    // Create POOrder mappings for all orders in this vendor group
    for (const orderDoc of vendorOrders) {
      // CRITICAL FIX: POOrder.purchase_order_id and POOrder.order_id are STRING IDs, not ObjectIds
      // Use PurchaseOrder.id and Order.id (string IDs) instead of _id (ObjectIds)
      const orderIdString = orderDoc.id
      if (!orderIdString) {
        throw new Error(`Order document missing id: ${JSON.stringify(orderDoc)}`)
      }
      
      // Create POOrder mapping using string IDs
      await POOrder.create({
        purchase_order_id: purchaseOrder.id, // Use PurchaseOrder.id (string ID), not _id (ObjectId)
        order_id: orderIdString // Use Order.id (string ID), not ObjectId
      })
      
      // Update order status using string ID
      const updateResult = await Order.updateOne(
        { id: orderIdString },
        { 
          $set: {
            status: 'Awaiting fulfilment',
            pr_status: 'PO_CREATED'
          }
        }
      )
      
      if (updateResult.matchedCount === 0) {
        throw new Error(`Order not found for update: ${orderIdString}`)
      }
      
      console.log(`[createPurchaseOrderFromPRs]   ✅ Linked order ${orderIdString} to PO ${poId}`)
      console.log(`[createPurchaseOrderFromPRs]   ✅ Updated order ${orderIdString} status to 'Awaiting fulfilment'`)
    }
    
    // Fetch vendor details separately since vendorId is now numeric ID, not ObjectId reference
    const vendorDetails = await Vendor.findOne({ id: vendor.id })
      .select('id name')
      .lean()
    
    // Populate company and employee, then add vendor details manually
    const populatedPO = await PurchaseOrder.findOne({ id: purchaseOrder.id })
      .populate('companyId', 'id name')
      .populate('created_by_user_id', 'id employeeId firstName lastName email')
      .lean()
    
    // Add vendor details to the PO object
    const poWithVendor = {
      ...populatedPO,
      vendorId: vendor.id, // Numeric vendor ID
      vendor: vendorDetails ? {
        id: vendorDetails.id,
        name: vendorDetails.name
      } : null
    }
    
    createdPOs.push(toPlainObject(poWithVendor))
  }
  
  console.log(`[createPurchaseOrderFromPRs] ========================================`)
  console.log(`[createPurchaseOrderFromPRs] ✅ PO CREATION COMPLETE`)
  console.log(`[createPurchaseOrderFromPRs] Created ${createdPOs.length} PO(s)`)
  console.log(`[createPurchaseOrderFromPRs] Linked ${ordersToProcess.length} order(s)`)
  console.log(`[createPurchaseOrderFromPRs] ========================================`)
  
  return {
    success: true,
    purchaseOrders: createdPOs,
    message: `Successfully created ${createdPOs.length} Purchase Order(s) and triggered vendor fulfilment for ${ordersToProcess.length} order(s)`
  }
}

export async function getPendingApprovalCount(companyId: string): Promise<number> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    return 0
  }
  
  const count = await Order.countDocuments({
    companyId: company._id,
    status: 'Awaiting approval',
  })
  
  return count
}

/**
 * Derive PO shipping status from PR data (source of truth)
 * PO shipping status is DERIVED dynamically, not persisted
 * @param poId Purchase Order ID
 * @returns Derived shipping status: AWAITING_SHIPMENT | PARTIALLY_SHIPPED | FULLY_SHIPPED | FULLY_DELIVERED
 */
export async function derivePOShippingStatus(poId: string): Promise<'AWAITING_SHIPMENT' | 'PARTIALLY_SHIPPED' | 'FULLY_SHIPPED' | 'FULLY_DELIVERED'> {
  await connectDB()
  
  // Get PO
  const po = await PurchaseOrder.findOne({ id: poId })
  if (!po) {
    throw new Error(`Purchase Order not found: ${poId}`)
  }
  
  // Get all PRs (Orders) linked to this PO via POOrder mappings (use string ID)
  const poOrderMappings = await POOrder.find({ purchase_order_id: po.id }).lean()
  if (poOrderMappings.length === 0) {
    return 'AWAITING_SHIPMENT' // No PRs linked yet
  }
  
  const orderIds = poOrderMappings.map(m => m.order_id)
  const prs = await Order.find({ id: { $in: orderIds } })
    .select('id status dispatchStatus deliveryStatus items')
    .lean()
  
  if (prs.length === 0) {
    return 'AWAITING_SHIPMENT'
  }
  
  // Analyze all PR items
  let totalItems = 0
  let itemsShipped = 0
  let itemsDelivered = 0
  
  console.log(`[derivePOShippingStatus] Analyzing ${prs.length} PR(s) for PO ${poId}`)
  
  for (const pr of prs) {
    const items = pr.items || []
    const prDeliveryStatus = pr.deliveryStatus || 'NOT_DELIVERED'
    const prStatus = (pr as any).status || ''
    
    console.log(`[derivePOShippingStatus] PR ${pr.id}: deliveryStatus=${prDeliveryStatus}, status=${prStatus}, items=${items.length}`)
    
    // If PR is marked as DELIVERED at order level, consider all items delivered
    // This handles cases where updateOrderStatus was used instead of updatePRDeliveryStatus
    const isOrderMarkedDelivered = prDeliveryStatus === 'DELIVERED' || prStatus === 'Delivered'
    
    for (const item of items) {
      const orderedQty = item.quantity || 0
      const dispatchedQty = item.dispatchedQuantity || 0
      const deliveredQty = item.deliveredQuantity || 0
      
      totalItems++
      
      if (dispatchedQty > 0) {
        itemsShipped++
      }
      
      // Check if item is delivered: either via item-level quantity OR order-level status
      if (isOrderMarkedDelivered) {
        // If order is marked as delivered, assume all items are delivered
        itemsDelivered++
        console.log(`[derivePOShippingStatus] PR ${pr.id} item marked as delivered (order-level status)`)
      } else if (deliveredQty >= orderedQty && orderedQty > 0) {
        // Otherwise, check item-level deliveredQuantity
        itemsDelivered++
        console.log(`[derivePOShippingStatus] PR ${pr.id} item marked as delivered (item-level: ${deliveredQty}/${orderedQty})`)
      } else {
        console.log(`[derivePOShippingStatus] PR ${pr.id} item NOT delivered (ordered: ${orderedQty}, delivered: ${deliveredQty}, orderStatus: ${prStatus}, deliveryStatus: ${prDeliveryStatus})`)
      }
    }
  }
  
  console.log(`[derivePOShippingStatus] Summary: totalItems=${totalItems}, itemsShipped=${itemsShipped}, itemsDelivered=${itemsDelivered}`)
  
  // Derivation logic
  if (itemsDelivered === totalItems && totalItems > 0) {
    console.log(`[derivePOShippingStatus] ✅ PO ${poId} is FULLY_DELIVERED`)
    return 'FULLY_DELIVERED'
  }
  
  if (itemsShipped === totalItems && totalItems > 0) {
    return 'FULLY_SHIPPED'
  }
  
  if (itemsShipped > 0 && itemsShipped < totalItems) {
    return 'PARTIALLY_SHIPPED'
  }
  
  return 'AWAITING_SHIPMENT'
}

/**
 * Update PR shipment status (vendor marks items as SHIPPED)
 * MANDATORY VALIDATION: shipperName, dispatchedDate, modeOfTransport, and at least one item dispatchedQuantity > 0
 * @param prId PR (Order) ID
 * @param shipmentData Shipment details
 * @param vendorId Vendor ID (for authorization)
 * @returns Updated PR
 */
export async function updatePRShipmentStatus(
  prId: string,
  shipmentData: {
    shipperName: string
    carrierName?: string
    modeOfTransport: 'ROAD' | 'AIR' | 'RAIL' | 'COURIER' | 'OTHER'
    trackingNumber?: string
    dispatchedDate: Date
    expectedDeliveryDate?: Date
    shipmentReferenceNumber?: string
    itemDispatchedQuantities: Array<{ itemIndex: number, dispatchedQuantity: number }> // Item-level dispatched quantities
    // Package data (optional)
    shipmentPackageId?: string
    lengthCm?: number
    breadthCm?: number
    heightCm?: number
    volumetricWeight?: number
    // Shipping cost (optional)
    shippingCost?: number
  },
  vendorId: string
): Promise<any> {
  await connectDB()
  
  // Get PR (Order)
  const pr = await Order.findOne({ id: prId })
  if (!pr) {
    throw new Error(`PR (Order) not found: ${prId}`)
  }
  
  // Validate vendor authorization
  if (pr.vendorId !== vendorId) {
    throw new Error(`Vendor ${vendorId} is not authorized to update PR ${prId}`)
  }
  
  // Validate PR is in correct status
  if (pr.pr_status !== 'PO_CREATED') {
    throw new Error(`PR ${prId} is not in PO_CREATED status (current: ${pr.pr_status})`)
  }
  
  // MANDATORY VALIDATION: Check required fields
  if (!shipmentData.shipperName || !shipmentData.shipperName.trim()) {
    throw new Error('shipperName is required when marking items as SHIPPED')
  }
  
  if (!shipmentData.dispatchedDate) {
    throw new Error('dispatchedDate is required when marking items as SHIPPED')
  }
  
  if (!shipmentData.modeOfTransport) {
    throw new Error('modeOfTransport is required when marking items as SHIPPED')
  }
  
  // Validate at least one item has dispatchedQuantity > 0
  const hasDispatchedItems = shipmentData.itemDispatchedQuantities.some(
    item => item.dispatchedQuantity > 0
  )
  
  if (!hasDispatchedItems) {
    throw new Error('At least one item must have dispatchedQuantity > 0')
  }
  
  // Validate item indices and quantities
  const items = pr.items || []
  for (const itemDispatch of shipmentData.itemDispatchedQuantities) {
    if (itemDispatch.itemIndex < 0 || itemDispatch.itemIndex >= items.length) {
      throw new Error(`Invalid itemIndex: ${itemDispatch.itemIndex} (PR has ${items.length} items)`)
    }
    
    const item = items[itemDispatch.itemIndex]
    if (itemDispatch.dispatchedQuantity > item.quantity) {
      throw new Error(`dispatchedQuantity (${itemDispatch.dispatchedQuantity}) cannot exceed ordered quantity (${item.quantity}) for item ${itemDispatch.itemIndex}`)
    }
    
    if (itemDispatch.dispatchedQuantity < 0) {
      throw new Error(`dispatchedQuantity cannot be negative for item ${itemDispatch.itemIndex}`)
    }
  }
  
  // Generate numeric shipmentId for Order (must be 6-10 digits per Order schema validation)
  // Note: shipmentReferenceNumber can be alphanumeric (references Shipment.shipmentId)
  // But Order.shipmentId must be numeric
  let shipmentId: string
  if (shipmentData.shipmentReferenceNumber) {
    // If shipmentReferenceNumber is provided, check if it's already numeric
    const refNumber = shipmentData.shipmentReferenceNumber.trim()
    if (/^\d{6,10}$/.test(refNumber)) {
      // It's already a valid numeric ID, use it
      shipmentId = refNumber
      console.log(`[updatePRShipmentStatus] ✅ Using numeric shipmentReferenceNumber as shipmentId: ${shipmentId} for PR: ${prId}`)
    } else {
      // It's alphanumeric (e.g., SHIP_XXXXX from Shipment model), generate new numeric ID
      shipmentId = String(Date.now()).slice(-10).padStart(6, '0')
      console.log(`[updatePRShipmentStatus] ⚠️ shipmentReferenceNumber is alphanumeric (${refNumber}), generated new numeric shipmentId: ${shipmentId} for PR: ${prId}`)
      console.log(`[updatePRShipmentStatus]    shipmentReferenceNumber will be stored separately: ${refNumber}`)
    }
  } else {
    // No shipmentReferenceNumber provided, generate new numeric ID
    shipmentId = String(Date.now()).slice(-10).padStart(6, '0')
    console.log(`[updatePRShipmentStatus] ⚠️ No shipmentReferenceNumber provided, generated new numeric shipmentId: ${shipmentId} for PR: ${prId}`)
  }
  
  // Update PR with shipment data
  const updatedItems = items.map((item, index) => {
    const itemDispatch = shipmentData.itemDispatchedQuantities.find(
      id => id.itemIndex === index
    )
    
    const dispatchedQty = itemDispatch?.dispatchedQuantity || 0
    const deliveredQty = item.deliveredQuantity || 0
    
    // Determine item shipment status
    let itemShipmentStatus: 'PENDING' | 'DISPATCHED' | 'DELIVERED' = 'PENDING'
    if (deliveredQty >= item.quantity && item.quantity > 0) {
      itemShipmentStatus = 'DELIVERED'
    } else if (dispatchedQty > 0) {
      itemShipmentStatus = 'DISPATCHED'
    }
    
    return {
      ...item.toObject(),
      dispatchedQuantity: dispatchedQty,
      deliveredQuantity: deliveredQty,
      itemShipmentStatus
    }
  })
  
  // Determine overall delivery status
  const allDelivered = updatedItems.every(
    item => (item.deliveredQuantity || 0) >= item.quantity && item.quantity > 0
  )
  const someDelivered = updatedItems.some(
    item => (item.deliveredQuantity || 0) > 0
  )
  
  let deliveryStatus: 'NOT_DELIVERED' | 'PARTIALLY_DELIVERED' | 'DELIVERED' = 'NOT_DELIVERED'
  if (allDelivered) {
    deliveryStatus = 'DELIVERED'
  } else if (someDelivered) {
    deliveryStatus = 'PARTIALLY_DELIVERED'
  }
  
  // Update PR
  pr.shipmentId = shipmentId
  pr.shipmentReferenceNumber = shipmentData.shipmentReferenceNumber
  pr.shipperName = shipmentData.shipperName.trim()
  pr.carrierName = shipmentData.carrierName?.trim()
  pr.modeOfTransport = shipmentData.modeOfTransport
  pr.trackingNumber = shipmentData.trackingNumber?.trim()
  pr.dispatchStatus = 'SHIPPED'
  pr.dispatchedDate = shipmentData.dispatchedDate
  pr.expectedDeliveryDate = shipmentData.expectedDeliveryDate
  pr.deliveryStatus = deliveryStatus
  pr.items = updatedItems as any
  
  // AUTO-UPDATE: Update Order status to Dispatched when items are shipped
  pr.status = 'Dispatched'
  
  await pr.save()
  
  // Update or create Shipment document for MANUAL shipments (for consistency with API shipments)
  // Note: API shipments already have Shipment documents created in createApiShipment
  // For MANUAL shipments: The manual-shipment API route creates the shipment first,
  // so we should update the existing shipment instead of creating a duplicate
  try {
    const Shipment = await import('../models/Shipment').then(m => m.default)
    const prNumber = pr.pr_number || pr.id
    
    // CRITICAL FIX: Check for existing shipment by prNumber (not shipmentId) to avoid duplicates
    // Manual shipments are created via /api/prs/manual-shipment route with a different shipmentId
    // So we need to find by prNumber and shipmentMode to update the correct record
    const existingShipment = await Shipment.findOne({ 
      prNumber: prNumber,
      shipmentMode: 'MANUAL',
      vendorId: vendorId
    }).lean()
    
    if (existingShipment) {
      // Update existing MANUAL shipment with any additional data from updatePRShipmentStatus
      const updateFields: any = {}
      
      // Update tracking number if provided and different
      if (shipmentData.trackingNumber?.trim() && shipmentData.trackingNumber.trim() !== existingShipment.trackingNumber) {
        updateFields.trackingNumber = shipmentData.trackingNumber.trim()
      }
      
      // Update providerShipmentReference if provided and different
      if (shipmentData.shipmentReferenceNumber && shipmentData.shipmentReferenceNumber !== existingShipment.providerShipmentReference) {
        updateFields.providerShipmentReference = shipmentData.shipmentReferenceNumber
      }
      
      // Update package data if provided
      if (shipmentData.shipmentPackageId) updateFields.shipmentPackageId = shipmentData.shipmentPackageId
      if (shipmentData.lengthCm !== undefined) updateFields.lengthCm = shipmentData.lengthCm
      if (shipmentData.breadthCm !== undefined) updateFields.breadthCm = shipmentData.breadthCm
      if (shipmentData.heightCm !== undefined) updateFields.heightCm = shipmentData.heightCm
      if (shipmentData.volumetricWeight !== undefined) updateFields.volumetricWeight = shipmentData.volumetricWeight
      if (shipmentData.shippingCost !== undefined) updateFields.shippingCost = shipmentData.shippingCost
      
      // Update warehouse info if provided
      if (shipmentData.warehouseRefId) updateFields.warehouseRefId = shipmentData.warehouseRefId
      
      if (Object.keys(updateFields).length > 0) {
        await Shipment.updateOne(
          { shipmentId: existingShipment.shipmentId },
          { $set: updateFields }
        )
        console.log(`[updatePRShipmentStatus] ✅ Updated existing MANUAL shipment ${existingShipment.shipmentId} with additional data`)
      } else {
        console.log(`[updatePRShipmentStatus] ℹ️ MANUAL shipment ${existingShipment.shipmentId} already exists, no updates needed`)
      }
    } else {
      // No existing shipment found - create one (for backward compatibility with other code paths)
      // This handles cases where updatePRShipmentStatus is called directly without going through manual-shipment route
      await Shipment.create({
        shipmentId,
        prNumber: prNumber,
        poNumber: undefined, // TODO: Get from PO mapping if available
        vendorId: vendorId,
        shipmentMode: 'MANUAL',
        // Provider fields are null for MANUAL shipments
        providerId: undefined,
        companyShippingProviderId: undefined,
        providerShipmentReference: shipmentData.shipmentReferenceNumber,
        trackingNumber: shipmentData.trackingNumber?.trim(),
        trackingUrl: undefined, // Manual shipments don't have tracking URLs
        warehouseRefId: shipmentData.warehouseRefId || undefined,
        warehousePincode: undefined,
        // Package data
        shipmentPackageId: shipmentData.shipmentPackageId,
        lengthCm: shipmentData.lengthCm,
        breadthCm: shipmentData.breadthCm,
        heightCm: shipmentData.heightCm,
        volumetricWeight: shipmentData.volumetricWeight,
        shippingCost: shipmentData.shippingCost,
        shipmentStatus: 'CREATED', // Default status for manual shipments
        lastProviderSyncAt: undefined, // Not applicable for manual shipments
        rawProviderResponse: undefined,
      })
      console.log(`[updatePRShipmentStatus] ✅ Created Shipment document for MANUAL shipment: ${shipmentId}`)
    }
  } catch (shipmentError: any) {
    // Log error but don't fail the entire operation
    console.error(`[updatePRShipmentStatus] ⚠️ Failed to update/create Shipment document:`, shipmentError.message)
    // Continue with order update even if shipment document update fails
  }
  
  // AUTO-UPDATE: Update PO status based on PR shipment status
  await updatePOStatusFromPRDelivery(prId)
  
  // Return updated PR - use string id field instead of _id
  const prIdStr = pr.id || String(pr._id || '')
  const updatedPR = await Order.findOne({ id: prIdStr })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .lean()
  
  // Add vendor name
  let vendorName = null
  if (updatedPR && updatedPR.vendorId) {
    const vendor = await Vendor.findOne({ id: updatedPR.vendorId }).select('id name').lean()
    if (vendor) {
      vendorName = (vendor as any).name
    }
  }
  
  const result = toPlainObject(updatedPR)
  if (vendorName) {
    (result as any).vendorName = vendorName
  }
  
  return result
}

/**
 * Update PO status automatically based on PR delivery status
 * This function is called whenever a PR's delivery status changes
 * @param prId PR (Order) ID
 */
async function updatePOStatusFromPRDelivery(prId: string): Promise<void> {
  await connectDB()
  
  // Get PR using string ID
  const pr = await Order.findOne({ id: prId }).lean()
  if (!pr) {
    console.warn(`[updatePOStatusFromPRDelivery] PR not found: ${prId}`)
    return
  }
  
  // CRITICAL FIX: POOrder.order_id stores Order.id (string ID), not Order._id (ObjectId)
  // Find all POs linked to this PR via POOrder mappings using string ID
  const poOrderMappings = await POOrder.find({ order_id: prId }).lean()
  if (poOrderMappings.length === 0) {
    // PR is not linked to any PO yet, nothing to update
    return
  }
  
  // CRITICAL FIX: POOrder.purchase_order_id stores PurchaseOrder.id (string ID), not _id (ObjectId)
  // Get all PO string IDs linked to this PR
  const poIds = poOrderMappings
    .map(m => typeof m.purchase_order_id === 'string' ? m.purchase_order_id : String(m.purchase_order_id || ''))
    .filter(Boolean)
  
  if (poIds.length === 0) {
    return
  }
  
  // Fetch POs using string IDs
  const pos = await PurchaseOrder.find({ id: { $in: poIds } }).lean()
  
  // Update each PO's status based on all its PRs
  for (const po of pos) {
    const poId = typeof po.id === 'string' ? po.id : String(po.id || '')
    if (poId) {
      await updateSinglePOStatus(poId)
    }
  }
}

/**
 * Update a single PO's status based on all its linked PRs
 * CRITICAL FIX: Use string ID instead of ObjectId
 * @param poId PO string ID
 */
async function updateSinglePOStatus(poId: string): Promise<void> {
  await connectDB()
  
  // CRITICAL FIX: POOrder.purchase_order_id stores PurchaseOrder.id (string ID), not _id (ObjectId)
  // Get all PRs linked to this PO using string ID
  const poOrderMappings = await POOrder.find({ purchase_order_id: poId }).lean()
  if (poOrderMappings.length === 0) {
    return
  }
  
  // CRITICAL FIX: POOrder.order_id stores Order.id (string ID), not Order._id (ObjectId)
  // Extract order string IDs from mappings
  const orderIds = poOrderMappings
    .map(m => typeof m.order_id === 'string' ? m.order_id : String(m.order_id || ''))
    .filter(Boolean)
  
  if (orderIds.length === 0) {
    return
  }
  
  // Fetch PRs using string IDs
  const prs = await Order.find({ id: { $in: orderIds } })
    .select('id dispatchStatus deliveryStatus items pr_status pr_number')
    .lean()
  
  if (prs.length === 0) {
    return
  }
  
  // CRITICAL FIX: Check PR status (pr_status = 'FULLY_DELIVERED' or deliveryStatus = 'DELIVERED')
  // instead of item-level checks to properly handle shipment-based delivery
  let allPRsDelivered = true
  let allPRsShipped = true
  let anyPRShipped = false
  let anyPRDelivered = false
  
  for (const pr of prs) {
    // Check PR status: PR is fully delivered if pr_status = 'FULLY_DELIVERED' or deliveryStatus = 'DELIVERED'
    const prFullyDelivered = pr.pr_status === 'FULLY_DELIVERED' || pr.deliveryStatus === 'DELIVERED'
    const prShipped = pr.dispatchStatus === 'SHIPPED'
    const prDelivered = pr.deliveryStatus === 'DELIVERED' || pr.deliveryStatus === 'PARTIALLY_DELIVERED'
    
    if (!prFullyDelivered) {
      allPRsDelivered = false
    }
    if (!prShipped) {
      allPRsShipped = false
    }
    if (prShipped) {
      anyPRShipped = true
    }
    if (prDelivered) {
      anyPRDelivered = true
    }
  }
  
  // Get PO using string ID
  const currentPO = await PurchaseOrder.findOne({ id: poId })
  
  if (!currentPO) {
    console.warn(`[updateSinglePOStatus] PO not found: ${poId}`)
    return
  }
  
  // Determine new PO status
  let newPOStatus: 'CREATED' | 'SENT_TO_VENDOR' | 'ACKNOWLEDGED' | 'IN_FULFILMENT' | 'COMPLETED' | 'CANCELLED'
  
  // If all PRs are fully delivered, PO is COMPLETED
  if (allPRsDelivered && prs.length > 0) {
    newPOStatus = 'COMPLETED'
  }
  // If all PRs are shipped (but not all delivered), PO is IN_FULFILMENT
  else if (allPRsShipped && !allPRsDelivered) {
    newPOStatus = 'IN_FULFILMENT'
  }
  // If any PR is shipped, PO is IN_FULFILMENT
  else if (anyPRShipped) {
    newPOStatus = 'IN_FULFILMENT'
  }
  // If PO was already SENT_TO_VENDOR or later, keep it (don't downgrade)
  else if (['SENT_TO_VENDOR', 'ACKNOWLEDGED', 'IN_FULFILMENT', 'COMPLETED'].includes(currentPO.po_status)) {
    newPOStatus = currentPO.po_status
  }
  // Otherwise, keep current status or default to SENT_TO_VENDOR
  else {
    newPOStatus = currentPO.po_status || 'SENT_TO_VENDOR'
  }
  
  // Update PO status if it changed
  if (currentPO.po_status !== newPOStatus) {
    await PurchaseOrder.updateOne(
      { id: poId },
      { $set: { po_status: newPOStatus } }
    )
    console.log(`[updateSinglePOStatus] Updated PO ${poId} status from ${currentPO.po_status} to ${newPOStatus}`)
  }
  
  // CRITICAL FIX: When PO is COMPLETED (all PRs fully delivered), update all PRs' pr_status to FULLY_DELIVERED
  // Check both new status and current status to handle cases where PO is already COMPLETED
  const finalPOStatus = newPOStatus || currentPO.po_status
  if (finalPOStatus === 'COMPLETED') {
    const prStringIds = prs.map(pr => typeof pr.id === 'string' ? pr.id : String(pr.id || '')).filter(Boolean)
    
    if (prStringIds.length > 0) {
      // Only update PRs that don't already have FULLY_DELIVERED status
      const prsToUpdate = prs.filter(pr => {
        const prId = typeof pr.id === 'string' ? pr.id : String(pr.id || '')
        return prId && pr.pr_status !== 'FULLY_DELIVERED'
      }).map(pr => typeof pr.id === 'string' ? pr.id : String(pr.id || '')).filter(Boolean)
      
      if (prsToUpdate.length > 0) {
        await Order.updateMany(
          { id: { $in: prsToUpdate } },
          { $set: { pr_status: 'FULLY_DELIVERED' } }
        )
        console.log(`[updateSinglePOStatus] ✅ Updated ${prsToUpdate.length} PR(s) pr_status to FULLY_DELIVERED for PO ${poId}`)
      }
    }
    
    // CRITICAL FIX: When PO becomes fully delivered, sync ALL shipments under this PO to DELIVERED status
    try {
      const Shipment = await import('../models/Shipment').then(m => m.default)
      
      // Get all PR numbers for this PO
      const prNumbers = prs
        .map(pr => pr.pr_number || pr.id)
        .filter(Boolean)
        .map(prNum => typeof prNum === 'string' ? prNum : String(prNum || ''))
      
      if (prNumbers.length > 0) {
        // Update all shipments for all PRs under this PO to DELIVERED status
        const shipmentUpdateResult = await Shipment.updateMany(
          { prNumber: { $in: prNumbers }, shipmentStatus: { $ne: 'DELIVERED' } },
          { $set: { shipmentStatus: 'DELIVERED' } }
        )
        
        if (shipmentUpdateResult.modifiedCount > 0) {
          console.log(`[updateSinglePOStatus] ✅ Updated ${shipmentUpdateResult.modifiedCount} shipment(s) to DELIVERED status for PO ${poId}`)
        }
      }
    } catch (shipmentSyncError: any) {
      // Log error but don't fail the operation
      console.error(`[updateSinglePOStatus] ⚠️ Error syncing shipments for PO ${poId}:`, shipmentSyncError.message)
    }
  }
}

/**
 * Update manual shipment status to "Shipped" (IN_TRANSIT) and trigger cascading updates
 * This function handles the complete cascade: Shipment → PR → PO → Shipments
 * @param shipmentId Shipment ID (string)
 * @param vendorId Vendor ID (string) for authorization
 * @returns Result object with success status and update flags
 */
export async function updateManualShipmentStatus(
  shipmentId: string,
  vendorId: string
): Promise<{
  success: boolean
  error?: string
  shipment?: any
  prUpdated?: boolean
  poUpdated?: boolean
}> {
  await connectDB()
  
  try {
    console.log(`[updateManualShipmentStatus] 🚀 Starting shipment status update for ${shipmentId}`)
    
    // Step 1: Update the shipment status to IN_TRANSIT (Shipped)
    const Shipment = await import('../models/Shipment').then(m => m.default)
    const shipment = await Shipment.findOne({ shipmentId: shipmentId }).lean()
    
    if (!shipment) {
      return {
        success: false,
        error: `Shipment not found: ${shipmentId}`
      }
    }
    
    // Validate vendor authorization
    const shipmentVendorId = typeof shipment.vendorId === 'string' ? shipment.vendorId : String(shipment.vendorId || '')
    if (shipmentVendorId !== vendorId) {
      return {
        success: false,
        error: `Vendor ${vendorId} is not authorized to update shipment ${shipmentId}`
      }
    }
    
    // Update shipment status to IN_TRANSIT (Shipped)
    await Shipment.updateOne(
      { shipmentId: shipmentId },
      { $set: { shipmentStatus: 'IN_TRANSIT' } }
    )
    console.log(`[updateManualShipmentStatus] ✅ Step 1: Updated shipment ${shipmentId} status to IN_TRANSIT`)
    
    // Get updated shipment
    const updatedShipment = await Shipment.findOne({ shipmentId: shipmentId }).lean()
    
    // Step 2: Check all shipments for this PR and update PR status if needed
    const prNumber = shipment.prNumber || ''
    if (!prNumber) {
      return {
        success: false,
        error: `Shipment ${shipmentId} has no prNumber`
      }
    }
    
    // Get all shipments for this PR using string prNumber
    const allShipmentsForPR = await Shipment.find({ prNumber: prNumber }).lean()
    console.log(`[updateManualShipmentStatus] 📦 Step 2: Found ${allShipmentsForPR.length} shipment(s) for PR ${prNumber}`)
    
    // Check if ALL shipments are shipped (IN_TRANSIT) or delivered (DELIVERED)
    const allShipmentsShippedOrDelivered = allShipmentsForPR.length > 0 && allShipmentsForPR.every(
      s => s.shipmentStatus === 'IN_TRANSIT' || s.shipmentStatus === 'DELIVERED'
    )
    
    let prUpdated = false
    if (allShipmentsShippedOrDelivered) {
      // Find PR by pr_number or id
      const pr = await Order.findOne({ 
        $or: [
          { pr_number: prNumber },
          { id: prNumber }
        ]
      })
      
      if (pr) {
        const prId = typeof pr.id === 'string' ? pr.id : String(pr.id || '')
        
        // Check if all shipments are DELIVERED (not just shipped)
        const allShipmentsDelivered = allShipmentsForPR.every(
          s => s.shipmentStatus === 'DELIVERED'
        )
        
        // Check if all shipments are shipped (IN_TRANSIT) but not all delivered
        const allShipmentsShipped = allShipmentsForPR.every(
          s => s.shipmentStatus === 'IN_TRANSIT' || s.shipmentStatus === 'DELIVERED'
        )
        
        if (allShipmentsDelivered) {
          // All shipments are delivered - mark PR as fully delivered
          await Order.updateOne(
            { id: prId },
            { 
              $set: { 
                dispatchStatus: 'SHIPPED',
                deliveryStatus: 'DELIVERED',
                pr_status: 'FULLY_DELIVERED',
                status: 'Delivered',
                dispatchedDate: pr.dispatchedDate || new Date()
              } 
            }
          )
          console.log(`[updateManualShipmentStatus] ✅ Step 2: Updated PR ${prId} to FULLY_DELIVERED (all ${allShipmentsForPR.length} shipment(s) delivered)`)
          prUpdated = true
        } else if (allShipmentsShipped) {
          // All shipments are shipped but not all delivered - mark PR as dispatched
          await Order.updateOne(
            { id: prId },
            { 
              $set: { 
                dispatchStatus: 'SHIPPED',
                status: 'Dispatched',
                dispatchedDate: pr.dispatchedDate || new Date()
              } 
            }
          )
          console.log(`[updateManualShipmentStatus] ✅ Step 2: Updated PR ${prId} to Dispatched (all ${allShipmentsForPR.length} shipment(s) shipped)`)
          prUpdated = true
        }
        
        // Step 3: Check all PRs for the PO and update PO status if needed
        const poOrderMappings = await POOrder.find({ order_id: prId }).lean()
        if (poOrderMappings.length > 0) {
          const poIds = poOrderMappings
            .map(m => typeof m.purchase_order_id === 'string' ? m.purchase_order_id : String(m.purchase_order_id || ''))
            .filter(Boolean)
          
          let poUpdated = false
          
          for (const poId of poIds) {
            // Use existing updateSinglePOStatus function to check and update PO
            await updateSinglePOStatus(poId)
            poUpdated = true
            console.log(`[updateManualShipmentStatus] ✅ Step 3: Updated PO ${poId} status`)
          }
          
          return {
            success: true,
            shipment: updatedShipment,
            prUpdated: true,
            poUpdated: poUpdated
          }
        }
        
        return {
          success: true,
          shipment: updatedShipment,
          prUpdated: true,
          poUpdated: false
        }
      } else {
        console.warn(`[updateManualShipmentStatus] ⚠️ PR not found for prNumber: ${prNumber}`)
      }
    }
    
    return {
      success: true,
      shipment: updatedShipment,
      prUpdated: prUpdated,
      poUpdated: false
    }
  } catch (error: any) {
    console.error(`[updateManualShipmentStatus] ❌ Error:`, error)
    return {
      success: false,
      error: error.message || 'Unknown error updating shipment status'
    }
  }
}

/**
 * Update PR delivery status (mark items as DELIVERED)
 * @param prId PR (Order) ID
 * @param deliveryData Delivery details
 * @param vendorId Vendor ID (for authorization)
 * @returns Updated PR
 */
export async function updatePRDeliveryStatus(
  prId: string,
  deliveryData: {
    deliveredDate: Date
    receivedBy?: string
    deliveryRemarks?: string
    itemDeliveredQuantities: Array<{ itemIndex: number, deliveredQuantity: number }> // Item-level delivered quantities
  },
  vendorId: string
): Promise<any> {
  await connectDB()
  
  // Get PR (Order)
  const pr = await Order.findOne({ id: prId })
  if (!pr) {
    throw new Error(`PR (Order) not found: ${prId}`)
  }
  
  // Validate vendor authorization
  if (pr.vendorId !== vendorId) {
    throw new Error(`Vendor ${vendorId} is not authorized to update PR ${prId}`)
  }
  
  // Validate PR is in SHIPPED status
  if (pr.dispatchStatus !== 'SHIPPED') {
    throw new Error(`PR ${prId} must be in SHIPPED status before marking as DELIVERED (current: ${pr.dispatchStatus || 'AWAITING_FULFILMENT'})`)
  }
  
  // Validate item indices and quantities
  const items = pr.items || []
  for (const itemDelivery of deliveryData.itemDeliveredQuantities) {
    if (itemDelivery.itemIndex < 0 || itemDelivery.itemIndex >= items.length) {
      throw new Error(`Invalid itemIndex: ${itemDelivery.itemIndex} (PR has ${items.length} items)`)
    }
    
    const item = items[itemDelivery.itemIndex]
    const dispatchedQty = item.dispatchedQuantity || 0
    
    if (itemDelivery.deliveredQuantity > dispatchedQty) {
      throw new Error(`deliveredQuantity (${itemDelivery.deliveredQuantity}) cannot exceed dispatched quantity (${dispatchedQty}) for item ${itemDelivery.itemIndex}`)
    }
    
    if (itemDelivery.deliveredQuantity < 0) {
      throw new Error(`deliveredQuantity cannot be negative for item ${itemDelivery.itemIndex}`)
    }
  }
  
  // Update PR with delivery data
  const updatedItems = items.map((item, index) => {
    const itemDelivery = deliveryData.itemDeliveredQuantities.find(
      id => id.itemIndex === index
    )
    
    const deliveredQty = itemDelivery?.deliveredQuantity || (item.deliveredQuantity || 0)
    const dispatchedQty = item.dispatchedQuantity || 0
    
    // Determine item shipment status
    let itemShipmentStatus: 'PENDING' | 'DISPATCHED' | 'DELIVERED' = 'PENDING'
    if (deliveredQty >= item.quantity && item.quantity > 0) {
      itemShipmentStatus = 'DELIVERED'
    } else if (dispatchedQty > 0) {
      itemShipmentStatus = 'DISPATCHED'
    }
    
    return {
      ...item.toObject(),
      deliveredQuantity: deliveredQty,
      itemShipmentStatus
    }
  })
  
  // Determine overall delivery status
  const allDelivered = updatedItems.every(
    item => (item.deliveredQuantity || 0) >= item.quantity && item.quantity > 0
  )
  const someDelivered = updatedItems.some(
    item => (item.deliveredQuantity || 0) > 0
  )
  
  let deliveryStatus: 'NOT_DELIVERED' | 'PARTIALLY_DELIVERED' | 'DELIVERED' = 'NOT_DELIVERED'
  if (allDelivered) {
    deliveryStatus = 'DELIVERED'
  } else if (someDelivered) {
    deliveryStatus = 'PARTIALLY_DELIVERED'
  }
  
  // Update PR
  pr.deliveredDate = deliveryData.deliveredDate
  pr.receivedBy = deliveryData.receivedBy?.trim()
  pr.deliveryRemarks = deliveryData.deliveryRemarks?.trim()
  pr.deliveryStatus = deliveryStatus
  pr.items = updatedItems as any
  
  // AUTO-UPDATE: Update Order status based on delivery status
  if (deliveryStatus === 'DELIVERED') {
    pr.status = 'Delivered'
  } else if (deliveryStatus === 'PARTIALLY_DELIVERED') {
    pr.status = 'Dispatched' // Keep as Dispatched if partially delivered
  }
  // If NOT_DELIVERED, keep current status (should be Dispatched)
  
  await pr.save()
  
  // CRITICAL FIX: Check ALL shipments linked to this PR to determine if PR is fully delivered
  // A PR is fully delivered only when ALL shipments are DELIVERED
  // Also update shipments to DELIVERED when PR is marked as delivered
  try {
    const Shipment = await import('../models/Shipment').then(m => m.default)
    const prNumber = typeof pr.pr_number === 'string' ? pr.pr_number : String(pr.pr_number || pr.id || '')
    
    // Get all shipments for this PR using string prNumber
    const allShipments = await Shipment.find({ prNumber: prNumber }).lean()
    
    if (allShipments.length > 0) {
      // Check if ALL shipments are DELIVERED
      const allShipmentsDelivered = allShipments.every(
        shipment => shipment.shipmentStatus === 'DELIVERED'
      )
      
      if (deliveryStatus === 'DELIVERED') {
        // CRITICAL FIX: When PR is marked as DELIVERED, update all shipments to DELIVERED
        // This ensures shipments reflect the PR delivery status
        const shipmentsToUpdate = allShipments.filter(
          s => s.shipmentStatus !== 'DELIVERED'
        )
        
        if (shipmentsToUpdate.length > 0) {
          const shipmentIds = shipmentsToUpdate
            .map(s => typeof s.shipmentId === 'string' ? s.shipmentId : String(s.shipmentId || ''))
            .filter(Boolean)
          
          if (shipmentIds.length > 0) {
            await Shipment.updateMany(
              { shipmentId: { $in: shipmentIds } },
              { $set: { shipmentStatus: 'DELIVERED' } }
            )
            console.log(`[updatePRDeliveryStatus] ✅ Updated ${shipmentIds.length} shipment(s) to DELIVERED for PR ${prId}`)
          }
        }
        
        // Now check again if all shipments are DELIVERED
        const updatedShipments = await Shipment.find({ prNumber: prNumber }).lean()
        const allNowDelivered = updatedShipments.every(
          shipment => shipment.shipmentStatus === 'DELIVERED'
        )
        
        if (allNowDelivered) {
          // All shipments are delivered and PR items are delivered - mark PR as fully delivered
          await Order.updateOne(
            { id: prId },
            { $set: { pr_status: 'FULLY_DELIVERED' } }
          )
          console.log(`[updatePRDeliveryStatus] ✅ Marked PR ${prId} as FULLY_DELIVERED (all ${updatedShipments.length} shipment(s) are DELIVERED)`)
        }
      }
    } else {
      // No shipments found - if PR items are fully delivered, mark PR as fully delivered
      if (deliveryStatus === 'DELIVERED') {
        await Order.updateOne(
          { id: prId },
          { $set: { pr_status: 'FULLY_DELIVERED' } }
        )
        console.log(`[updatePRDeliveryStatus] ✅ Marked PR ${prId} as FULLY_DELIVERED (no shipments, items fully delivered)`)
      }
    }
  } catch (shipmentCheckError: any) {
    // Log error but don't fail the operation
    console.error(`[updatePRDeliveryStatus] ⚠️ Error checking/updating shipments for PR ${prId}:`, shipmentCheckError.message)
  }
  
  // AUTO-UPDATE: Update PO status based on PR delivery status
  await updatePOStatusFromPRDelivery(prId)
  
  // Return updated PR - use string id field instead of _id
  const prIdStr = pr.id || String(pr._id || '')
  const updatedPR = await Order.findOne({ id: prIdStr })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .lean()
  
  // Add vendor name
  let vendorName = null
  if (updatedPR && updatedPR.vendorId) {
    const vendor = await Vendor.findOne({ id: updatedPR.vendorId }).select('id name').lean()
    if (vendor) {
      vendorName = (vendor as any).name
    }
  }
  
  const result = toPlainObject(updatedPR)
  if (vendorName) {
    (result as any).vendorName = vendorName
  }
  
  return result
}

/**
 * Update existing PR and PO statuses based on underlying order delivery status
 * This function retroactively updates PR and PO statuses based on current delivery data
 * Can be used as a migration or maintenance function
 * @param companyId Optional company ID to limit update scope (if not provided, updates all)
 * @returns Summary of updates performed
 */
export async function updatePRAndPOStatusesFromDelivery(companyId?: string): Promise<{
  prsUpdated: number
  posUpdated: number
  errors: string[]
}> {
  await connectDB()
  
  const result = {
    prsUpdated: 0,
    posUpdated: 0,
    errors: [] as string[]
  }
  
  try {
    // Build query for PRs (Orders with PO_CREATED status)
    const prQuery: any = {
      pr_status: 'PO_CREATED'
    }
    
    if (companyId) {
      const company = await Company.findOne({ id: companyId })
      if (!company) {
        throw new Error(`Company not found: ${companyId}`)
      }
      prQuery.companyId = company._id
    }
    
    // Get all PRs that have PO created
    const prs = await Order.find(prQuery)
      .select('id companyId vendorId items dispatchStatus deliveryStatus status pr_status')
      .lean()
    
    console.log(`[updatePRAndPOStatusesFromDelivery] Found ${prs.length} PRs to process`)
    
    // Update each PR's status based on delivery data
    for (const pr of prs) {
      try {
        const items = pr.items || []
        
        // Determine PR status based on item-level delivery
        let allItemsDelivered = true
        let allItemsShipped = true
        let anyItemShipped = false
        let anyItemDelivered = false
        
        for (const item of items) {
          const orderedQty = item.quantity || 0
          const dispatchedQty = item.dispatchedQuantity || 0
          const deliveredQty = item.deliveredQuantity || 0
          
          if (orderedQty > 0) {
            if (dispatchedQty > 0) {
              anyItemShipped = true
            }
            if (deliveredQty > 0) {
              anyItemDelivered = true
            }
            if (dispatchedQty < orderedQty) {
              allItemsShipped = false
            }
            if (deliveredQty < orderedQty) {
              allItemsDelivered = false
            }
          }
        }
        
        // Determine new PR status
        let newPRStatus: 'Awaiting approval' | 'Awaiting fulfilment' | 'Dispatched' | 'Delivered'
        let newDispatchStatus: 'AWAITING_FULFILMENT' | 'SHIPPED' = pr.dispatchStatus || 'AWAITING_FULFILMENT'
        let newDeliveryStatus: 'NOT_DELIVERED' | 'PARTIALLY_DELIVERED' | 'DELIVERED' = pr.deliveryStatus || 'NOT_DELIVERED'
        
        if (allItemsDelivered && items.length > 0) {
          newPRStatus = 'Delivered'
          newDeliveryStatus = 'DELIVERED'
          if (anyItemShipped) {
            newDispatchStatus = 'SHIPPED'
          }
        } else if (allItemsShipped && !allItemsDelivered) {
          newPRStatus = 'Dispatched'
          newDispatchStatus = 'SHIPPED'
          if (anyItemDelivered) {
            newDeliveryStatus = 'PARTIALLY_DELIVERED'
          }
        } else if (anyItemShipped) {
          newPRStatus = 'Dispatched'
          newDispatchStatus = 'SHIPPED'
          if (anyItemDelivered) {
            newDeliveryStatus = 'PARTIALLY_DELIVERED'
          }
        } else {
          // No items shipped yet
          newPRStatus = 'Awaiting fulfilment'
          newDispatchStatus = 'AWAITING_FULFILMENT'
          newDeliveryStatus = 'NOT_DELIVERED'
        }
        
        // Update PR if status changed
        const prDoc = await Order.findOne({ id: pr.id })
        if (prDoc) {
          let prUpdated = false
          
          if (prDoc.status !== newPRStatus) {
            prDoc.status = newPRStatus
            prUpdated = true
          }
          
          if (prDoc.dispatchStatus !== newDispatchStatus) {
            prDoc.dispatchStatus = newDispatchStatus
            prUpdated = true
          }
          
          if (prDoc.deliveryStatus !== newDeliveryStatus) {
            prDoc.deliveryStatus = newDeliveryStatus
            prUpdated = true
          }
          
          if (prUpdated) {
            await prDoc.save()
            result.prsUpdated++
            console.log(`[updatePRAndPOStatusesFromDelivery] Updated PR ${pr.id}: status=${newPRStatus}, dispatchStatus=${newDispatchStatus}, deliveryStatus=${newDeliveryStatus}`)
          }
        }
      } catch (error: any) {
        const errorMsg = `Error updating PR ${pr.id}: ${error.message}`
        console.error(`[updatePRAndPOStatusesFromDelivery] ${errorMsg}`)
        result.errors.push(errorMsg)
      }
    }
    
    // Now update all PO statuses based on their linked PRs
    const poQuery: any = {}
    if (companyId) {
      const company = await Company.findOne({ id: companyId })
      if (company) {
        poQuery.companyId = company._id
      }
    }
    
    const pos = await PurchaseOrder.find(poQuery).lean()
    console.log(`[updatePRAndPOStatusesFromDelivery] Found ${pos.length} POs to process`)
    
    for (const po of pos) {
      try {
        // CRITICAL FIX: Use string ID (po.id) instead of ObjectId (po._id)
        const poId = typeof po.id === 'string' ? po.id : String(po.id || '')
        if (poId) {
          await updateSinglePOStatus(poId)
          result.posUpdated++
        }
      } catch (error: any) {
        const errorMsg = `Error updating PO ${po.id}: ${error.message}`
        console.error(`[updatePRAndPOStatusesFromDelivery] ${errorMsg}`)
        result.errors.push(errorMsg)
      }
    }
    
    console.log(`[updatePRAndPOStatusesFromDelivery] ✅ Update complete: ${result.prsUpdated} PRs updated, ${result.posUpdated} POs updated, ${result.errors.length} errors`)
    
    return result
  } catch (error: any) {
    const errorMsg = `Fatal error in updatePRAndPOStatusesFromDelivery: ${error.message}`
    console.error(`[updatePRAndPOStatusesFromDelivery] ${errorMsg}`)
    result.errors.push(errorMsg)
    return result
  }
}

/**
 * Get approved orders for Company Admin (orders approved by Company Admin)
 * @param companyId Company ID
 * @returns Array of approved orders with PR details
 */
export async function getApprovedOrdersForCompanyAdmin(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id name enable_pr_po_workflow').lean()
  if (!company) {
    return []
  }
  
  // Find orders approved by Company Admin
  // Status: COMPANY_ADMIN_APPROVED (legacy) or orders that have been approved but not yet PO created
  // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
  const queryFilter: any = {
    companyId: company.id,
    $and: [
      {
        $or: [
          { pr_status: 'COMPANY_ADMIN_APPROVED' },
          { company_admin_approved_by: { $exists: true, $ne: null } }
        ]
      },
      { pr_status: { $ne: 'PO_CREATED' } } // Exclude orders that already have PO created
    ]
  }
  
  // CRITICAL FIX: Don't use populate since Order.employeeId and Order.companyId are string IDs
  const approvedOrders = await Order.find(queryFilter)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status company_admin_approved_by company_admin_approved_at')
    .sort({ company_admin_approved_at: -1, orderDate: -1 })
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(approvedOrders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Add vendorName to orders
  approvedOrders.forEach((o: any) => {
    if (!o.vendorName && o.vendorId && vendorMap.has(o.vendorId)) {
      o.vendorName = vendorMap.get(o.vendorId)
    }
  })
  
  // Group orders similar to getPendingApprovals
  const parentOrderIds = new Set<string>()
  const standaloneOrders: any[] = []
  const plainOrders = approvedOrders.map((o: any) => toPlainObject(o))
  
  for (const order of plainOrders) {
    if (order.parentOrderId) {
      parentOrderIds.add(order.parentOrderId)
    } else {
      standaloneOrders.push(order)
    }
  }
  
  const orderMap = new Map<string, any[]>()
  if (parentOrderIds.size > 0) {
    // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
    const allChildOrders = await Order.find({
      companyId: company.id,
      parentOrderId: { $in: Array.from(parentOrderIds) }
    })
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status company_admin_approved_by company_admin_approved_at')
      .lean()
    
    // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
    // Fetch vendor names for child orders
    const childVendorIds = [...new Set(allChildOrders.map((o: any) => o.vendorId).filter(Boolean))]
    if (childVendorIds.length > 0) {
      const childVendors = await Vendor.find({ id: { $in: childVendorIds } }).select('id name').lean()
      const childVendorMap = new Map(childVendors.map((v: any) => [v.id, v.name]))
      allChildOrders.forEach((o: any) => {
        if (!o.vendorName && o.vendorId && childVendorMap.has(o.vendorId)) {
          o.vendorName = childVendorMap.get(o.vendorId)
        }
      })
    }
    
    const allChildOrdersPlain = allChildOrders.map((o: any) => toPlainObject(o))
    
    for (const order of allChildOrdersPlain) {
      if (order.parentOrderId) {
        if (!orderMap.has(order.parentOrderId)) {
          orderMap.set(order.parentOrderId, [])
        }
        orderMap.get(order.parentOrderId)!.push(order)
      }
    }
  }
  
  const groupedOrders: any[] = []
  
  for (const [parentOrderId, splitOrders] of orderMap.entries()) {
    splitOrders.sort((a, b) => (a.vendorName || '').localeCompare(b.vendorName || ''))
    
    const totalAmount = splitOrders.reduce((sum, o) => sum + (o.total || 0), 0)
    const totalItems = splitOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)
    const allItems = splitOrders.flatMap(o => o.items || [])
    
    groupedOrders.push({
      ...splitOrders[0],
      id: parentOrderId,
      isSplitOrder: true,
      splitOrders: splitOrders,
      splitOrderIds: splitOrders.map(o => o.id),
      total: totalAmount,
      items: allItems,
      vendorCount: splitOrders.length,
      vendors: splitOrders.map(o => o.vendorName).filter(Boolean)
    })
  }
  
  const allOrders = [...groupedOrders, ...standaloneOrders]
  allOrders.sort((a, b) => {
    const dateA = new Date(a.company_admin_approved_at || a.orderDate || 0).getTime()
    const dateB = new Date(b.company_admin_approved_at || b.orderDate || 0).getTime()
    return dateB - dateA
  })
  
  return allOrders
}

/**
 * Get orders with PO created for Company Admin
 * @param companyId Company ID
 * @returns Array of orders with PO details
 */
export async function getPOCreatedOrdersForCompanyAdmin(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id name').lean()
  if (!company) {
    return []
  }
  
  // Find orders with PO created status
  // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
  const queryFilter: any = {
    companyId: company.id,
    pr_status: 'PO_CREATED'
  }
  
  // CRITICAL FIX: Don't use populate since Order.employeeId and Order.companyId are string IDs
  const poCreatedOrders = await Order.find(queryFilter)
    .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status')
    .sort({ orderDate: -1 })
    .lean()
  
  // CRITICAL FIX: vendorId is now a 6-digit numeric string, not an ObjectId reference
  // Fetch vendor names for all unique vendorIds
  const vendorIds = [...new Set(poCreatedOrders.map((o: any) => o.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } }).select('id name').lean()
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  // Add vendorName to orders
  poCreatedOrders.forEach((o: any) => {
    if (!o.vendorName && o.vendorId && vendorMap.has(o.vendorId)) {
      o.vendorName = vendorMap.get(o.vendorId)
    }
  })
  
  // Get PO details for these orders via POOrder mapping
  // CRITICAL FIX: POOrder.order_id stores Order.id (string ID), not Order._id (ObjectId)
  const orderIds = poCreatedOrders.map((o: any) => o.id).filter(Boolean)
  const poOrderMappings = await POOrder.find({ order_id: { $in: orderIds } })
    .populate('purchase_order_id')
    .lean()
  
  // Group POs by order
  const poMap = new Map<string, any[]>()
  for (const mapping of poOrderMappings) {
    const orderId = mapping.order_id?.toString()
    if (orderId) {
      if (!poMap.has(orderId)) {
        poMap.set(orderId, [])
      }
      poMap.get(orderId)!.push(mapping.purchase_order_id)
    }
  }
  
  // Group orders similar to other functions
  const parentOrderIds = new Set<string>()
  const standaloneOrders: any[] = []
  const plainOrders = poCreatedOrders.map((o: any) => toPlainObject(o))
  
  for (const order of plainOrders) {
    if (order.parentOrderId) {
      parentOrderIds.add(order.parentOrderId)
    } else {
      standaloneOrders.push(order)
    }
  }
  
  const orderMap = new Map<string, any[]>()
  if (parentOrderIds.size > 0) {
    // CRITICAL FIX: Order.companyId is a STRING ID (6-digit numeric), not ObjectId
    const allChildOrders = await Order.find({
      companyId: company.id,
      parentOrderId: { $in: Array.from(parentOrderIds) },
      pr_status: 'PO_CREATED'
    })
      .select('id employeeId employeeIdNum employeeName items total status orderDate dispatchLocation companyId deliveryAddress parentOrderId vendorId vendorName isPersonalPayment personalPaymentAmount createdAt pr_number pr_date pr_status')
      .lean()
    
    const allChildOrdersPlain = allChildOrders.map((o: any) => toPlainObject(o))
    
    for (const order of allChildOrdersPlain) {
      if (order.parentOrderId) {
        if (!orderMap.has(order.parentOrderId)) {
          orderMap.set(order.parentOrderId, [])
        }
        orderMap.get(order.parentOrderId)!.push(order)
      }
    }
  }
  
  const groupedOrders: any[] = []
  
  for (const [parentOrderId, splitOrders] of orderMap.entries()) {
    splitOrders.sort((a, b) => (a.vendorName || '').localeCompare(b.vendorName || ''))
    
    const totalAmount = splitOrders.reduce((sum, o) => sum + (o.total || 0), 0)
    const totalItems = splitOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)
    const allItems = splitOrders.flatMap(o => o.items || [])
    
    // Get POs for all child orders
    const childOrderIds = splitOrders.map((o: any) => o._id?.toString()).filter(Boolean)
    const childPOs = childOrderIds.flatMap(id => poMap.get(id) || [])
    
    groupedOrders.push({
      ...splitOrders[0],
      id: parentOrderId,
      isSplitOrder: true,
      splitOrders: splitOrders,
      splitOrderIds: splitOrders.map(o => o.id),
      total: totalAmount,
      items: allItems,
      vendorCount: splitOrders.length,
      vendors: splitOrders.map(o => o.vendorName).filter(Boolean),
      purchaseOrders: childPOs
    })
  }
  
  // Add PO details to standalone orders
  const allOrders = [...groupedOrders, ...standaloneOrders.map(order => {
    const orderId = order._id?.toString()
    const pos = orderId ? poMap.get(orderId) || [] : []
    return { ...order, purchaseOrders: pos }
  })]
  
  allOrders.sort((a, b) => {
    const dateA = new Date(a.orderDate || 0).getTime()
    const dateB = new Date(b.orderDate || 0).getTime()
    return dateB - dateA
  })
  
  return allOrders
}

/**
 * Get pending return request count for a company
 */
export async function getPendingReturnRequestCount(companyId: string): Promise<number> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id').lean()
  if (!company) {
    // Try with _id if companyId looks like ObjectId
    if (companyId && companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(companyId)) {
      const companyById = await Company.findById(companyId).select('_id id').lean()
      if (!companyById) return 0
      return await ReturnRequest.countDocuments({
        companyId: companyById._id,
        status: 'REQUESTED',
      })
    }
    return 0
  }
  
  const count = await ReturnRequest.countDocuments({
    companyId: company._id,
    status: 'REQUESTED',
  })
  
  return count
}

/**
 * Get new (unread) feedback count for a company
 * Only counts feedback that hasn't been viewed yet (viewedAt is null or doesn't exist)
 */
export async function getNewFeedbackCount(companyId: string): Promise<number> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id').lean()
  if (!company) {
    // Try with _id if companyId looks like ObjectId
    if (companyId && companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(companyId)) {
      const companyById = await Company.findById(companyId).select('_id id').lean()
      if (!companyById) return 0
      return await ProductFeedback.countDocuments({
        companyId: companyById._id,
        $or: [
          { viewedAt: { $exists: false } },
          { viewedAt: null }
        ]
      })
    }
    return 0
  }
  
  const count = await ProductFeedback.countDocuments({
    companyId: company._id,
    $or: [
      { viewedAt: { $exists: false } },
      { viewedAt: null }
    ]
  })
  
  return count
}

/**
 * Mark feedback as viewed by a company admin
 * Updates all feedback for a company to mark them as viewed
 */
export async function markFeedbackAsViewed(companyId: string, adminEmail: string): Promise<void> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id').lean()
  if (!company) {
    // Try with _id if companyId looks like ObjectId
    if (companyId && companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(companyId)) {
      const companyById = await Company.findById(companyId).select('_id id').lean()
      if (!companyById) {
        throw new Error(`Company not found: ${companyId}`)
      }
      
      // Mark all unread feedback for this company as viewed
      await ProductFeedback.updateMany(
        {
          companyId: companyById._id,
          $or: [
            { viewedAt: { $exists: false } },
            { viewedAt: null }
          ]
        },
        {
          $set: { viewedAt: new Date() },
          $addToSet: { viewedBy: adminEmail }
        }
      )
      return
    }
    throw new Error(`Company not found: ${companyId}`)
  }
  
  // Mark all unread feedback for this company as viewed
  await ProductFeedback.updateMany(
    {
      companyId: company._id,
      $or: [
        { viewedAt: { $exists: false } },
        { viewedAt: null }
      ]
    },
    {
      $set: { viewedAt: new Date() },
      $addToSet: { viewedBy: adminEmail }
    }
  )
}

/**
 * Get pending order approval count for a location (for Location Admin)
 */
export async function getPendingApprovalCountByLocation(locationId: string): Promise<number> {
  await connectDB()
  
  const location = await Location.findOne({ id: locationId }).select('_id id companyId').lean()
  if (!location) {
    return 0
  }
  
  // ARCHITECTURAL DECISION: Use ONLY string ID (6-digit numeric), NO ObjectId fallbacks
  // Get all employees in this location using string ID
  const employees = await Employee.find({ locationId: location.id }).select('_id').lean()
  const employeeIds = employees.map(e => e._id)
  
  if (employeeIds.length === 0) {
    return 0
  }
  
  const count = await Order.countDocuments({
    employeeId: { $in: employeeIds },
    status: 'Awaiting approval',
  })
  
  return count
}

/**
 * Get pending order count for a vendor (orders awaiting fulfilment/dispatch)
 */
export async function getPendingOrderCountByVendor(vendorId: string): Promise<number> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId }).select('_id id').lean()
  if (!vendor) {
    return 0
  }
  
  // Count orders that are awaiting fulfilment or dispatched (vendor needs to act on)
  const count = await Order.countDocuments({
    vendorId: vendor._id,
    status: { $in: ['Awaiting fulfilment', 'Dispatched'] },
  })
  
  return count
}

/**
 * Get pending replacement order count for a vendor
 */
export async function getPendingReplacementOrderCountByVendor(vendorId: string): Promise<number> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId }).select('_id id').lean()
  if (!vendor) {
    return 0
  }
  
  // Count replacement orders that are awaiting fulfilment or dispatched
  const count = await Order.countDocuments({
    vendorId: vendor._id,
    orderType: 'REPLACEMENT',
    status: { $in: ['Awaiting fulfilment', 'Dispatched'] },
  })
  
  return count
}

/**
 * Get new (unread) invoice count for a company admin
 * Counts invoices with status 'RAISED' (awaiting approval)
 */
export async function getNewInvoiceCount(companyId: string): Promise<number> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId }).select('_id id').lean()
  if (!company) {
    // Try with _id if companyId looks like ObjectId
    if (companyId && companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(companyId)) {
      const companyById = await Company.findById(companyId).select('_id id').lean()
      if (!companyById) return 0
      return await Invoice.countDocuments({
        companyId: companyById._id,
        invoiceStatus: 'RAISED'
      })
    }
    return 0
  }
  
  const count = await Invoice.countDocuments({
    companyId: company._id,
    invoiceStatus: 'RAISED'
  })
  
  return count
}

/**
 * Get new GRN count for a vendor
 * Counts GRN that are newly available (status 'CREATED' or 'ACKNOWLEDGED')
 */
export async function getNewGRNCount(vendorId: string): Promise<number> {
  await connectDB()
  
  // GRN uses vendorId as string (6-digit numeric), not ObjectId
  // Count GRN that are newly available (CREATED or ACKNOWLEDGED status)
  const count = await GRN.countDocuments({
    vendorId: vendorId,
    status: { $in: ['CREATED', 'ACKNOWLEDGED'] }
  })
  
  return count
}

/**
 * Get approved GRN count for a vendor
 * Counts GRN that have been approved by company admin (grnStatus = 'APPROVED')
 */
export async function getApprovedGRNCount(vendorId: string): Promise<number> {
  await connectDB()
  
  // GRN uses vendorId as string (6-digit numeric), not ObjectId
  // Count GRN that have been approved by company admin
  const count = await GRN.countDocuments({
    vendorId: vendorId,
    grnStatus: 'APPROVED'
  })
  
  return count
}

/**
 * Get approved invoice count for a vendor
 * Counts invoices that have been approved by company admin (invoiceStatus = 'APPROVED')
 */
export async function getApprovedInvoiceCount(vendorId: string): Promise<number> {
  await connectDB()
  
  // Invoice uses vendorId as string (6-digit numeric), not ObjectId
  // Count invoices that have been approved by company admin
  const count = await Invoice.countDocuments({
    vendorId: vendorId,
    invoiceStatus: 'APPROVED'
  })
  
  return count
}

// ========== RELATIONSHIP FUNCTIONS ==========

export async function getProductCompanies(): Promise<any[]> {
  await connectDB()
  
  // Query products and companies using string ID only
  const allProducts = await Uniform.find({}).select('id').lean()
  const allCompanies = await Company.find({}).select('id').lean()
  
  // Create sets of valid string IDs
  const validProductIds = new Set<string>()
  const validCompanyIds = new Set<string>()
  
  allProducts.forEach((p: any) => {
    if (p.id && typeof p.id === 'string') {
      validProductIds.add(p.id)
    }
  })
  
  allCompanies.forEach((c: any) => {
    if (c.id && typeof c.id === 'string') {
      validCompanyIds.add(c.id)
    }
  })
  
  // Query relationships and filter to only those with valid string IDs
  const relationships = await ProductCompany.find({}).lean()
  
  return relationships
    .map((rel: any) => {
      // Extract productId and companyId as strings
      const productId = rel.productId?.toString() || ''
      const companyId = rel.companyId?.toString() || ''
      
      // Only return relationships where both IDs are valid string IDs
      // Skip any that look like ObjectIds (24 hex chars) or don't match valid IDs
      const isProductIdValid = productId && validProductIds.has(productId)
      const isCompanyIdValid = companyId && validCompanyIds.has(companyId)
      
      if (isProductIdValid && isCompanyIdValid) {
        return {
          productId: productId,
          companyId: companyId,
        }
      }
      return null
    })
    .filter((rel: any) => rel !== null)
}

export async function getProductVendors(): Promise<any[]> {
  await connectDB()
  
  // Use raw MongoDB collection for reliable ObjectId comparison
  const db = mongoose.connection.db
  if (!db) return []
  
  const rawRelationships = await db.collection('productvendors').find({}).toArray()
  
  // Get all products and vendors for mapping
  const allProducts = await db.collection('uniforms').find({}).toArray()
  const allVendors = await db.collection('vendors').find({}).toArray()
  
  // Create maps for quick lookup
  const productMap = new Map()
  const vendorMap = new Map()
  
  allProducts.forEach((p: any) => {
    productMap.set(p._id.toString(), p.id)
  })
  
  allVendors.forEach((v: any) => {
    vendorMap.set(v._id.toString(), v.id)
  })
  
  // Map relationships to use string IDs (companyId removed from ProductVendor)
  return rawRelationships.map((rel: any) => {
    const productIdStr = rel.productId?.id || String(rel.productId || '')
    const vendorIdStr = rel.vendorId?.id || String(rel.vendorId || '')
    
    return {
      productId: productMap.get(productIdStr) || productIdStr,
      vendorId: vendorMap.get(vendorIdStr) || vendorIdStr,
    }
  }).filter((rel: any) => rel.productId && rel.vendorId)
}

export async function getVendorCompanies(): Promise<any[]> {
  // Vendor-company relationships are no longer used
  // Products are linked to companies directly, and vendors supply products
  // No explicit vendor-company relationship is needed
  return []
}

// ========== CREATE/UPDATE FUNCTIONS ==========

export async function createProductCompany(productId: string, companyId: string): Promise<void> {
  await connectDB()
  
  console.log('createProductCompany - Looking for productId:', productId, 'companyId:', companyId)
  
  const product = await Uniform.findOne({ id: productId })
  const company = await Company.findOne({ id: companyId })
  
  console.log('createProductCompany - Product found:', product ? product.id : 'NOT FOUND')
  console.log('createProductCompany - Company found:', company ? company.id : 'NOT FOUND')
  
  if (!product) {
    // List available product IDs for debugging
    const allProducts = await Uniform.find({}, 'id name').limit(5).lean()
    console.log('Available products (sample):', allProducts.map(p => p.id))
    throw new Error(`Product not found: ${productId}`)
  }
  
  if (!company) {
    // List available company IDs for debugging
    const allCompanies = await Company.find({}, 'id name').limit(5).lean()
    console.log('Available companies (sample):', allCompanies.map(c => c.id))
    throw new Error(`Company not found: ${companyId}`)
  }

  await ProductCompany.findOneAndUpdate(
    { productId: product.id, companyId: company.id },
    { productId: product.id, companyId: company.id },
    { upsert: true }
  )
  
  console.log('createProductCompany - Successfully created relationship')
}

export async function createProductCompanyBatch(productIds: string[], companyId: string): Promise<{ success: string[], failed: Array<{ productId: string, error: string }> }> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }

  const success: string[] = []
  const failed: Array<{ productId: string, error: string }> = []

  for (const productId of productIds) {
    try {
      const product = await Uniform.findOne({ id: productId })
      if (!product) {
        failed.push({ productId, error: `Product not found: ${productId}` })
        continue
      }

      await ProductCompany.findOneAndUpdate(
        { productId: product.id, companyId: company.id },
        { productId: product.id, companyId: company.id },
        { upsert: true }
      )

      success.push(productId)
      console.log(`createProductCompanyBatch - Successfully linked product ${productId} to company ${companyId}`)
    } catch (error: any) {
      failed.push({ productId, error: error.message || 'Unknown error' })
    }
  }

  return { success, failed }
}

export async function deleteProductCompany(productId: string, companyId: string): Promise<void> {
  await connectDB()
  
  const product = await Uniform.findOne({ id: productId })
  const company = await Company.findOne({ id: companyId })
  
  if (!product) {
    throw new Error(`Product not found: ${productId}`)
  }
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }

  // Use raw MongoDB collection for reliable ObjectId comparison
  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  const productIdStr = product.id || ''
  const companyIdStr = company.id || ''

  // Use string IDs for deletion
  const result = await db.collection('productcompanies').deleteOne({
    productId: productIdStr,
    companyId: companyIdStr
  })
  
  if (result.deletedCount === 0) {
    throw new Error(`No relationship found to delete between product ${productId} and company ${companyId}`)
  } else {
    console.log(`Successfully deleted relationship between product ${productId} and company ${companyId}`)
  }
}

export async function createProductVendor(productId: string, vendorId: string): Promise<void> {
  await connectDB()
  
  console.log('[createProductVendor] Looking for productId:', productId, 'vendorId:', vendorId)
  
  // Try to find product by id field first, then fallback to _id if productId looks like ObjectId
  let product = await Uniform.findOne({ id: productId })
  if (!product && mongoose.Types.ObjectId.isValid(productId)) {
    // Fallback: try finding by _id if productId is a valid ObjectId
    product = await Uniform.findById(productId)
    if (product) {
      console.log('[createProductVendor] Found product by _id, using product.id:', product.id)
    }
  }
  
  const vendor = await Vendor.findOne({ id: vendorId })
  
  console.log('[createProductVendor] Product found:', product ? product.id : 'NOT FOUND')
  console.log('[createProductVendor] Vendor found:', vendor ? vendor.id : 'NOT FOUND')
  
  if (!product) {
    // List available product IDs for debugging
    const allProducts = await Uniform.find({}, 'id name').limit(5).lean()
    console.log('[createProductVendor] Available products (sample):', allProducts.map(p => p.id))
    throw new Error(`Product not found: ${productId}`)
  }
  
  if (!vendor) {
    // List available vendor IDs for debugging
    const allVendors = await Vendor.find({}, 'id name').limit(5).lean()
    console.log('Available vendors (sample):', allVendors.map(v => v.id))
    throw new Error(`Vendor not found: ${vendorId}`)
  }

  // Validate: Product can only be linked to ONE vendor
  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  const existingLinks = await db.collection('productvendors').find({ productId: product._id }).toArray()
  if (existingLinks.length > 0) {
    const existingVendorIdStr = existingLinks[0].vendorId?.toString()
    const newVendorIdStr = vendor._id.toString()
    
    if (existingVendorIdStr !== newVendorIdStr) {
      const existingVendor = await Vendor.findById(existingLinks[0].vendorId)
      throw new Error(`Product "${product.name || productId}" is already linked to vendor "${existingVendor?.name || existingVendorIdStr}". A product can only be linked to one vendor.`)
    }
  }

  // Create ProductVendor relationship (without transaction for standalone MongoDB)
  try {
    await ProductVendor.findOneAndUpdate(
      { productId: product._id, vendorId: vendor._id },
      { productId: product._id, vendorId: vendor._id },
      { upsert: true }
    )
    
    console.log('[createProductVendor] ✅ Successfully created ProductVendor relationship')
    
    // Auto-create VendorInventory record with all sizes initialized
    // Note: Without transactions, if inventory creation fails, the ProductVendor link will still exist
    // This is acceptable as inventory can be created separately if needed
    try {
      await ensureVendorInventoryExists(vendor._id, product._id)
      console.log('[createProductVendor] ✅ VendorInventory initialized')
    } catch (inventoryError: any) {
      // Log but don't fail the entire operation if inventory creation fails
      console.warn('[createProductVendor] ⚠️ ProductVendor link created, but inventory initialization failed:', inventoryError.message)
      console.warn('[createProductVendor] ⚠️ Inventory can be created separately if needed')
    }
    
    console.log('[createProductVendor] ✅ Product-Vendor link created successfully')
  } catch (error: any) {
    console.error('[createProductVendor] ❌ Error creating ProductVendor relationship:', {
      vendorId: vendor.id,
      productId: product.id,
      error: error.message,
    })
    throw error
  }
}

export async function createProductVendorBatch(productIds: string[], vendorId: string): Promise<{ success: string[], failed: Array<{ productId: string, error: string }> }> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }

  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  const success: string[] = []
  const failed: Array<{ productId: string, error: string }> = []

  for (const productId of productIds) {
    try {
      // Try to find product by id field first, then fallback to _id if productId looks like ObjectId
      let product = await Uniform.findOne({ id: productId })
      if (!product && mongoose.Types.ObjectId.isValid(productId)) {
        // Fallback: try finding by _id if productId is a valid ObjectId
        product = await Uniform.findById(productId)
        if (product) {
          console.log(`[createProductVendorBatch] Found product ${productId} by _id, using product.id: ${product.id}`)
        }
      }
      
      if (!product) {
        failed.push({ productId, error: `Product not found: ${productId}` })
        continue
      }

      // Validate: Product can only be linked to ONE vendor
      const existingLinks = await db.collection('productvendors').find({ productId: product._id }).toArray()
      if (existingLinks.length > 0) {
        const existingVendorIdStr = existingLinks[0].vendorId?.toString()
        const newVendorIdStr = vendor._id.toString()
        
        if (existingVendorIdStr !== newVendorIdStr) {
          const existingVendor = await Vendor.findById(existingLinks[0].vendorId)
          failed.push({ 
            productId, 
            error: `Already linked to vendor "${existingVendor?.name || existingVendorIdStr}". A product can only be linked to one vendor.` 
          })
          continue
        }
      }

      // Create ProductVendor relationship (without transaction for standalone MongoDB)
      try {
        // Create ProductVendor relationship
        await ProductVendor.findOneAndUpdate(
          { productId: product._id, vendorId: vendor._id },
          { productId: product._id, vendorId: vendor._id },
          { upsert: true }
        )

        // Auto-create VendorInventory record with all sizes initialized
        // Note: Without transactions, if inventory creation fails, the ProductVendor link will still exist
        // This is acceptable as inventory can be created separately if needed
        try {
          await ensureVendorInventoryExists(vendor._id, product._id)
          console.log(`[createProductVendorBatch] ✅ Inventory initialized for product ${productId}`)
        } catch (inventoryError: any) {
          // Log but don't fail the entire operation if inventory creation fails
          console.warn(`[createProductVendorBatch] ⚠️ ProductVendor link created for ${productId}, but inventory initialization failed:`, inventoryError.message)
        }
        
        success.push(productId)
        console.log(`[createProductVendorBatch] ✅ Successfully linked product ${productId} to vendor ${vendorId}`)
      } catch (error: any) {
        console.error(`[createProductVendorBatch] ❌ Error linking product ${productId}:`, error.message)
        failed.push({ productId, error: error.message || 'Unknown error' })
      }
    } catch (error: any) {
      failed.push({ productId, error: error.message || 'Unknown error' })
    }
  }

  return { success, failed }
}

export async function deleteProductVendor(productId: string, vendorId: string): Promise<void> {
  await connectDB()
  
  const product = await Uniform.findOne({ id: productId })
  const vendor = await Vendor.findOne({ id: vendorId })
  
  if (!product) {
    throw new Error(`Product not found: ${productId}`)
  }
  if (!vendor) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }

  // Use raw MongoDB collection for reliable ObjectId comparison
  const db = mongoose.connection.db
  if (!db) {
    throw new Error('Database connection not available')
  }

  const productIdStr = product._id.toString()
  const vendorIdStr = vendor._id.toString()

  // Use string IDs for deletion
  const result = await db.collection('productvendors').deleteOne({
    productId: productIdStr,
    vendorId: vendorIdStr
  })
  
  if (result.deletedCount === 0) {
    // Try with ObjectId matching as fallback for legacy data
    const fallbackResult = await db.collection('productvendors').deleteOne({
      productId: product._id,
      vendorId: vendor._id
    })
    
    if (fallbackResult.deletedCount === 0) {
      throw new Error(`No relationship found to delete between product ${productId} and vendor ${vendorId}`)
    } else {
      console.log(`Successfully deleted relationship between product ${productId} and vendor ${vendorId} (legacy format)`)
    }
  } else {
    console.log(`Successfully deleted relationship between product ${productId} and vendor ${vendorId}`)
  }
}

export async function createVendorCompany(vendorId: string, companyId: string): Promise<void> {
  // Vendor-company relationships are now automatically derived from ProductCompany + ProductVendor
  // This function is kept for backward compatibility but does nothing
  // To create a vendor-company relationship, create ProductCompany and ProductVendor links instead
  console.log(`createVendorCompany: Vendor-company relationships are now derived from ProductCompany + ProductVendor relationships.`)
  console.log(`  To link vendor ${vendorId} to company ${companyId}, ensure there's at least one product that:`)
  console.log(`  1. Is linked to company ${companyId} (via ProductCompany)`)
  console.log(`  2. Is supplied by vendor ${vendorId} (via ProductVendor)`)
}

export async function deleteVendorCompany(vendorId: string, companyId: string): Promise<void> {
  // Vendor-company relationships are now automatically derived from ProductCompany + ProductVendor
  // This function is kept for backward compatibility but does nothing
  // To remove a vendor-company relationship, delete the ProductCompany or ProductVendor links that create it
  console.log(`deleteVendorCompany: Vendor-company relationships are now derived from ProductCompany + ProductVendor relationships.`)
  console.log(`  To unlink vendor ${vendorId} from company ${companyId}, delete ProductCompany or ProductVendor links that connect them.`)
}

// ========== VENDOR INVENTORY FUNCTIONS ==========

/**
 * Get low stock items for a vendor (items where stock <= threshold)
 */
export async function getLowStockItems(vendorId: string): Promise<any[]> {
  await connectDB()
  
  console.log(`[getLowStockItems] ========================================`)
  console.log(`[getLowStockItems] 🚀 FETCHING LOW STOCK ITEMS FOR VENDOR: ${vendorId}`)
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) {
    console.log(`[getLowStockItems] ❌ Vendor not found: ${vendorId}`)
    return []
  }

  // CRITICAL FIX: Filter by ProductVendor relationships
  // A vendor should ONLY see low stock items for products assigned to them
  const db = mongoose.connection.db
  if (!db) {
    console.error('[getLowStockItems] Database connection not available')
    return []
  }
  
  const vendorIdStr = vendor.id || ''
  
  // Get ProductVendor relationships for this vendor using string ID
  console.log(`[getLowStockItems] 🔍 Querying ProductVendor relationships for vendor: ${vendorIdStr}...`)
  const productVendorLinks = await db.collection('productvendors').find({
    vendorId: vendorIdStr
  }).toArray()
  
  console.log(`[getLowStockItems] ✅ Found ${productVendorLinks.length} ProductVendor relationship(s)`)
  
  if (productVendorLinks.length === 0) {
    console.log(`[getLowStockItems] ⚠️ No ProductVendor relationships - vendor has no assigned products`)
    return []
  }
  
  // Extract assigned product IDs as strings
  const assignedProductIds = productVendorLinks
    .map((link: any) => {
      if (!link.productId) return null
      return String(link.productId)
    })
    .filter((id: any) => id !== null) as string[]
  
  console.log(`[getLowStockItems] ✅ Extracted ${assignedProductIds.length} assigned product ID(s)`)
  
  // CRITICAL: Only query inventory for assigned products using string IDs
  const inventoryRecords = await VendorInventory.find({ 
    vendorId: vendorIdStr,
    productId: { $in: assignedProductIds } // CRITICAL: Only inventory for assigned products
  })
    .populate('productId', 'id name category gender sizes price sku')
    .populate('vendorId', 'id name')
    .lean()
  
  console.log(`[getLowStockItems] ✅ Found ${inventoryRecords.length} inventory record(s) for assigned products`)

  const lowStockItems: any[] = []

  for (const inv of inventoryRecords) {
    const sizeInventory = inv.sizeInventory instanceof Map
      ? Object.fromEntries(inv.sizeInventory)
      : inv.sizeInventory || {}
    
    const lowInventoryThreshold = inv.lowInventoryThreshold instanceof Map
      ? Object.fromEntries(inv.lowInventoryThreshold)
      : inv.lowInventoryThreshold || {}

    // Check each size for low stock
    const lowStockSizes: { [size: string]: { stock: number, threshold: number } } = {}
    for (const [size, stock] of Object.entries(sizeInventory)) {
      const threshold = lowInventoryThreshold[size] || 0
      if (threshold > 0 && stock <= threshold) {
        lowStockSizes[size] = { stock, threshold }
      }
    }

    if (Object.keys(lowStockSizes).length > 0) {
      lowStockItems.push({
        id: inv.id,
        vendorId: inv.vendorId?.id || inv.vendorId?.toString(),
        vendorName: inv.vendorId?.name,
        productId: inv.productId?.id || inv.productId?.toString(),
        productName: inv.productId?.name,
        productCategory: inv.productId?.category,
        productGender: inv.productId?.gender,
        productSku: inv.productId?.sku,
        sizeInventory,
        lowInventoryThreshold,
        lowStockSizes,
        totalStock: inv.totalStock || 0,
      })
    }
  }

  return lowStockItems
}

/**
 * Get vendor inventory summary (total products, total stock, low stock count)
 */
export async function getVendorInventorySummary(vendorId: string): Promise<{
  totalProducts: number
  totalStock: number
  lowStockCount: number
}> {
  await connectDB()
  
  const vendor = await Vendor.findOne({ id: vendorId })
  if (!vendor) {
    return { totalProducts: 0, totalStock: 0, lowStockCount: 0 }
  }

  const inventoryRecords = await VendorInventory.find({ vendorId: vendor._id }).lean()
  
  let totalStock = 0
  let lowStockCount = 0

  for (const inv of inventoryRecords) {
    const sizeInventory = inv.sizeInventory instanceof Map
      ? Object.fromEntries(inv.sizeInventory)
      : inv.sizeInventory || {}
    
    const lowInventoryThreshold = inv.lowInventoryThreshold instanceof Map
      ? Object.fromEntries(inv.lowInventoryThreshold)
      : inv.lowInventoryThreshold || {}

    totalStock += inv.totalStock || 0

    // Check if any size is low stock
    let isLowStock = false
    for (const [size, stock] of Object.entries(sizeInventory)) {
      const threshold = lowInventoryThreshold[size] || 0
      if (threshold > 0 && stock <= threshold) {
        isLowStock = true
        break
      }
    }
    if (isLowStock) {
      lowStockCount++
    }
  }

  return {
    totalProducts: inventoryRecords.length,
    totalStock,
    lowStockCount,
  }
}

export async function getVendorInventory(vendorId: string, productId?: string): Promise<any[]> {
  await connectDB()
  
  console.log(`[getVendorInventory] ========================================`)
  console.log(`[getVendorInventory] 🚀 FETCHING INVENTORY FOR VENDOR: ${vendorId}`)
  
  // CRITICAL FIX: Use string vendorId directly (ProductVendor stores vendorId as string, not ObjectId)
  const vendorIdStr = typeof vendorId === 'string' ? vendorId : String(vendorId || '')
  if (!/^\d{6}$/.test(vendorIdStr)) {
    console.log(`[getVendorInventory] ❌ Invalid vendorId format: ${vendorIdStr}`)
    return []
  }
  
  const vendor = await Vendor.findOne({ id: vendorIdStr })
  if (!vendor) {
    console.log(`[getVendorInventory] ❌ Vendor not found for id: ${vendorIdStr}`)
    return []
  }
  
  console.log(`[getVendorInventory] ✅ Vendor found: ${vendor.name} (id: ${vendor.id})`)

  // CRITICAL FIX: Filter inventory by ProductVendor relationships
  // A vendor should ONLY see inventory for products assigned to them via ProductVendor relationships
  // This is the SINGLE SOURCE OF TRUTH for vendor-product access control
  // CRITICAL: ProductVendor stores vendorId and productId as STRING IDs (6-digit numeric), NOT ObjectId
  const db = mongoose.connection.db
  if (!db) {
    console.error('[getVendorInventory] Database connection not available')
    return []
  }
  
  // STEP 1: Get ProductVendor relationships for this vendor using STRING vendorId
  console.log(`[getVendorInventory] 🔍 Step 1: Querying ProductVendor relationships with string vendorId: ${vendorIdStr}`)
  const productVendorLinks = await db.collection('productvendors').find({
    vendorId: vendorIdStr // CRITICAL: Use string ID, not ObjectId
  }).toArray()
  
  console.log(`[getVendorInventory] ✅ Found ${productVendorLinks.length} ProductVendor relationship(s)`)
  
  if (productVendorLinks.length === 0) {
    console.log(`[getVendorInventory] ⚠️ No ProductVendor relationships found - vendor has no assigned products`)
    console.log(`[getVendorInventory] ⚠️ Returning empty inventory (vendor must have products assigned by Super Admin)`)
    return []
  }
  
  // Extract product IDs from ProductVendor relationships as STRING IDs
  const assignedProductIds = productVendorLinks
    .map((link: any) => {
      if (!link.productId) return null
      // CRITICAL: ProductVendor stores productId as STRING (6-digit numeric), not ObjectId
      const productIdStr = typeof link.productId === 'string' ? link.productId : String(link.productId || '')
      if (/^\d{6}$/.test(productIdStr)) {
        return productIdStr
      }
      return null
    })
    .filter((id: any) => id !== null) as string[]
  
  console.log(`[getVendorInventory] ✅ Extracted ${assignedProductIds.length} assigned product ID(s) as strings`)
  
  if (assignedProductIds.length === 0) {
    console.log(`[getVendorInventory] ⚠️ No valid product IDs extracted from ProductVendor relationships`)
    return []
  }
  
  // STEP 2: Build query - filter by vendorId AND productId in assigned products
  // CRITICAL: If specific productId requested, verify it's assigned to vendor
  if (productId) {
    const productIdStr = typeof productId === 'string' ? productId : String(productId || '')
    
    // CRITICAL: Verify product is assigned to vendor via ProductVendor relationship using string IDs
    const isAssigned = assignedProductIds.includes(productIdStr)
    if (!isAssigned) {
      console.log(`[getVendorInventory] ⚠️ Product ${productIdStr} is not assigned to vendor ${vendorIdStr} via ProductVendor relationship`)
      console.log(`[getVendorInventory] ⚠️ Returning empty result (access control enforcement)`)
      return []
    }
    
    console.log(`[getVendorInventory] ✅ Product ${productIdStr} is assigned to vendor - proceeding with query`)
  }
  
  // CRITICAL FIX: VendorInventory stores vendorId and productId as STRING IDs, not ObjectIds
  // Query using string IDs directly, matching how updateVendorInventory saves the data
  const vendorIdFinal = typeof vendor.id === 'string' ? vendor.id : String(vendor.id || vendorIdStr)
  
  // Build query with ProductVendor filter using STRING IDs
  const query: any = { 
    vendorId: vendorIdFinal, // CRITICAL: Use string ID, not ObjectId
    productId: { $in: assignedProductIds } // CRITICAL: Use string IDs, not ObjectIds
  }
  
  // If specific productId requested and verified, use exact match
  if (productId) {
    const productIdStr = typeof productId === 'string' ? productId : String(productId || '')
    query.productId = productIdStr // Use exact match for specific product (string ID)
    console.log(`[getVendorInventory] 🔍 Filtering by specific product: ${productIdStr}`)
  }

  // CRITICAL FIX: Get raw inventory records using STRING IDs
  // Note: db is already declared earlier in the function, so we reuse it here
  if (!db) {
    console.error('[getVendorInventory] Database connection not available')
    return []
  }
  
  // CRITICAL FIX: VendorInventory collection uses STRING IDs for vendorId and productId
  const rawQuery: any = {
    vendorId: vendorIdFinal, // Use string ID, not ObjectId
    productId: query.productId && typeof query.productId === 'object' && '$in' in query.productId
      ? query.productId // Already has $in operator from assignedProductIds
      : query.productId // Use exact match or $in with string IDs
  }
  
  console.log(`[getVendorInventory] 🔍 Raw MongoDB query:`, {
    vendorId: rawQuery.vendorId,
    vendorIdType: typeof rawQuery.vendorId,
    productId: rawQuery.productId
  })
  
  const rawInventoryRecords = await db.collection('vendorinventories').find(rawQuery).toArray()
  console.log(`[getVendorInventory] ✅ Found ${rawInventoryRecords.length} raw inventory records`)
  
  // CRITICAL FIX: Use STRING ID query for Mongoose model (matching raw query)
  // VendorInventory stores vendorId and productId as STRING IDs, not ObjectIds
  const mongooseQuery: any = {
    vendorId: vendorIdFinal, // Use string ID, not ObjectId
    productId: query.productId // Use string ID or $in with string IDs
  }
  
  console.log(`[getVendorInventory] 🔍 Mongoose query:`, {
    vendorId: mongooseQuery.vendorId,
    vendorIdType: typeof mongooseQuery.vendorId,
    productId: mongooseQuery.productId
  })
  
  // CRITICAL FIX: Cannot use populate() with string IDs - query directly and manually fetch related data
  const inventoryRecords = await VendorInventory.find(mongooseQuery).lean()

  console.log(`[getVendorInventory] ✅ Found ${inventoryRecords.length} inventory records via Mongoose`)
  console.log(`[getVendorInventory] ✅ Found ${rawInventoryRecords.length} raw inventory records from DB`)

  // CRITICAL FIX: If Mongoose query returned 0 but raw query found records, use raw records
  // This handles cases where Mongoose query fails but data exists in DB
  if (inventoryRecords.length === 0 && rawInventoryRecords.length > 0) {
    console.warn(`[getVendorInventory] ⚠️ Mongoose query returned 0 records but raw query found ${rawInventoryRecords.length} records`)
    console.warn(`[getVendorInventory] ⚠️ This indicates a query mismatch. Using raw records as fallback.`)
    
    // Build inventory records from raw data
    // We'll process rawInventoryRecords directly instead of inventoryRecords
    const rawBasedRecords: any[] = rawInventoryRecords.map((raw: any) => ({
      _id: raw._id,
      id: raw.id,
      vendorId: raw.vendorId,
      productId: raw.productId,
      sizeInventory: raw.sizeInventory,
      lowInventoryThreshold: raw.lowInventoryThreshold,
      totalStock: raw.totalStock,
      createdAt: raw.createdAt,
      updatedAt: raw.updatedAt
    }))
    
    // Replace inventoryRecords with raw-based records for processing
    // Clear and repopulate the array
    while (inventoryRecords.length > 0) {
      inventoryRecords.pop()
    }
    rawBasedRecords.forEach(record => inventoryRecords.push(record as any))
    console.log(`[getVendorInventory] ✅ Replaced inventoryRecords with ${inventoryRecords.length} raw-based records`)
  }

  // 🔍 LOG: Check populate results and raw data
  console.log(`[getVendorInventory] Processing ${inventoryRecords.length} inventory records`)
  
  // DIAGNOSTIC: Check raw productId values in database AND after lean()
  // Note: db is already declared earlier in the function, so we reuse it here
  if (inventoryRecords.length > 0) {
    if (db) {
      const rawInventory = await db.collection('vendorinventories').find(rawQuery).toArray()
      console.log(`[getVendorInventory] 🔍 DIAGNOSTIC: Raw inventory records from DB:`)
      rawInventory.slice(0, 3).forEach((raw: any, idx: number) => {
        console.log(`[getVendorInventory]   Raw[${idx}]:`, {
          id: raw.id,
          productId: raw.productId,
          productIdType: typeof raw.productId,
          productIdIsNull: raw.productId === null,
          productIdIsUndefined: raw.productId === undefined,
          productIdIsEmpty: raw.productId === '',
          productIdString: raw.productId?.toString ? raw.productId.toString() : String(raw.productId)
        })
      })
      
      // Also check what we got after lean() - this is CRITICAL for debugging
      console.log(`[getVendorInventory] 🔍 DIAGNOSTIC: Inventory records after lean():`)
      inventoryRecords.slice(0, 3).forEach((inv: any, idx: number) => {
        const pid = inv.productId
        console.log(`[getVendorInventory]   Lean[${idx}]:`, {
          id: inv.id,
          productId: pid,
          productIdType: typeof pid,
          productIdIsNull: pid === null,
          productIdIsUndefined: pid === undefined,
          productIdIsEmpty: pid === '',
          productIdConstructor: pid?.constructor?.name,
          productIdKeys: pid && typeof pid === 'object' ? Object.keys(pid) : null,
          productIdHasId: pid?.id !== undefined,
          productIdHas_id: pid?._id !== undefined,
          productIdIdValue: pid?.id,
          productId_idValue: pid?._id?.toString ? pid._id.toString() : pid?._id,
          productIdString: pid?.toString ? pid.toString() : (pid ? String(pid) : 'N/A'),
          productIdJSON: pid ? JSON.stringify(pid, (key, value) => {
            if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'ObjectId') {
              return value.toString()
            }
            return value
          }) : 'null'
        })
      })
    }
  }
  
  // CRITICAL FIX: VendorInventory stores productId as STRING ID, not ObjectId
  // Collect all product string IDs from inventory records and fetch product details manually
  const productIdMap = new Map<string, any>() // Map product string ID -> product data
  const productIdsToFetch = new Set<string>()
  
  // Extract product string IDs from inventory records
  for (const inv of inventoryRecords) {
    // CRITICAL: productId is now a STRING ID, not ObjectId
    const productIdStr = typeof inv.productId === 'string' ? inv.productId : String(inv.productId || '')
    if (productIdStr && productIdStr.trim() !== '') {
      productIdsToFetch.add(productIdStr)
    } else {
      console.warn(`[getVendorInventory] ⚠️ Inventory ${inv.id} has invalid productId: ${inv.productId}`)
    }
  }
  
  // Fetch all product details using string IDs
  if (productIdsToFetch.size > 0) {
    const productIdArray = Array.from(productIdsToFetch)
    console.log(`[getVendorInventory] 🔍 Fetching ${productIdArray.length} product(s) by string IDs:`, productIdArray.slice(0, 5))
    
    const products = await Uniform.find({
      id: { $in: productIdArray }
    })
      .select('id name category gender sizes price sku')
      .lean()
    
    console.log(`[getVendorInventory] ✅ Found ${products.length} product(s)`)
    
    // Add to map
    products.forEach((p: any) => {
      const productId = typeof p.id === 'string' ? p.id : String(p.id || '')
      productIdMap.set(productId, {
        id: productId,
        name: p.name,
        category: p.category,
        gender: p.gender,
        sizes: p.sizes || [],
        price: p.price,
        sku: p.sku
      })
    })
  }

  // CRITICAL: Filter inventory records - ensure productId is valid and product exists
  const assignedProductIdSet = new Set(assignedProductIds)
  let validInventoryRecords = inventoryRecords.filter((inv: any) => {
    // CRITICAL: productId is now a STRING ID, not ObjectId
    const productIdStr = typeof inv.productId === 'string' ? inv.productId : String(inv.productId || '')
    
    if (!productIdStr || productIdStr.trim() === '') {
      console.warn(`[getVendorInventory] ⚠️ Skipping inventory record ${inv.id} - productId is empty`)
      return false
    }
    
    // Verify product is assigned to vendor via ProductVendor relationship
    if (!assignedProductIdSet.has(productIdStr)) {
      console.error(`[getVendorInventory] ❌ SECURITY: Filtering out inventory ${inv.id} - product ${productIdStr} is NOT assigned to vendor via ProductVendor relationship`)
      return false
    }
    
    // Verify product exists
    if (!productIdMap.has(productIdStr)) {
      console.warn(`[getVendorInventory] ⚠️ Filtering out inventory ${inv.id} - product ${productIdStr} does not exist`)
      return false
    }
    
    return true
  })
  
  console.log(`[getVendorInventory] ✅ Final inventory count: ${validInventoryRecords.length} (filtered from ${inventoryRecords.length} total records)`)
  console.log(`[getVendorInventory] ✅ All inventory records validated against ProductVendor relationships`)
  console.log(`[getVendorInventory] ========================================`)
  
  // Fetch vendor details
  const vendorDetails = await Vendor.findOne({ id: vendorIdFinal }).select('id name').lean()
  
  return validInventoryRecords.map((inv: any) => {
    const sizeInventory = inv.sizeInventory instanceof Map
      ? Object.fromEntries(inv.sizeInventory)
      : inv.sizeInventory || {}
    
    const lowInventoryThreshold = inv.lowInventoryThreshold instanceof Map
      ? Object.fromEntries(inv.lowInventoryThreshold)
      : inv.lowInventoryThreshold || {}
    
    // CRITICAL: productId is now a STRING ID, not ObjectId
    const productIdStr = typeof inv.productId === 'string' ? inv.productId : String(inv.productId || '')
    const productData = productIdMap.get(productIdStr) || null
    
    if (!productData) {
      console.warn(`[getVendorInventory] ⚠️ Product data not found for inventory ${inv.id}, productId: ${productIdStr}`)
    }
    
    return {
      id: inv.id,
      vendorId: vendorDetails?.id || vendorIdFinal || '',
      vendorName: vendorDetails?.name || '',
      productId: productIdStr, // Use string ID directly
      productName: productData?.name || '',
      productCategory: productData?.category || '',
      productGender: productData?.gender || '',
      productSizes: productData?.sizes || [],
      productPrice: productData?.price || 0,
      productSku: productData?.sku || '',
      sizeInventory,
      lowInventoryThreshold,
      totalStock: inv.totalStock || 0,
      createdAt: inv.createdAt,
      updatedAt: inv.updatedAt,
    }
  })
}

/**
 * Get vendor-wise inventory for a company (read-only view for Company Admin)
 * Returns all inventory records for products linked to the company, grouped by vendor
 * @param companyId - Company ID (string or number)
 * @returns Array of inventory records with product and vendor details
 */
export async function getVendorWiseInventoryForCompany(companyId: string | number): Promise<any[]> {
  await connectDB()
  
  // Get company ObjectId
  const company = await Company.findOne({ id: String(companyId) })
  if (!company) {
    console.warn(`[getVendorWiseInventoryForCompany] Company not found: ${companyId}`)
    return []
  }
  
  // Get all products linked to this company via ProductCompany
  const db = mongoose.connection.db
  if (!db) {
    console.error('[getVendorWiseInventoryForCompany] Database connection not available')
    return []
  }
  
  const productCompanyLinks = await db.collection('productcompanies').find({
    companyId: company.id
  }).toArray()
  
  if (productCompanyLinks.length === 0) {
    console.log(`[getVendorWiseInventoryForCompany] No products linked to company ${companyId}`)
    return []
  }
  
  const productObjectIds = productCompanyLinks
    .map((link: any) => link.productId)
    .filter((id: any) => id)
  
  if (productObjectIds.length === 0) {
    return []
  }
  
  console.log(`[getVendorWiseInventoryForCompany] 🔍 Finding inventory for ${productObjectIds.length} products`)
  
  // First, get raw inventory records to inspect vendorId structure
  const rawInventoryRecords = await db.collection('vendorinventories').find({
    productId: { $in: productObjectIds }
  }).toArray()
  
  console.log(`[getVendorWiseInventoryForCompany] 📊 Raw inventory records from DB: ${rawInventoryRecords.length}`)
  if (rawInventoryRecords.length > 0) {
    const sampleRaw = rawInventoryRecords[0]
    console.log(`[getVendorWiseInventoryForCompany] 📋 Sample raw inventory record:`, {
      id: sampleRaw.id,
      vendorId: sampleRaw.vendorId,
      vendorIdType: sampleRaw.vendorId?.constructor?.name,
      vendorIdString: sampleRaw.vendorId?.toString(),
      productId: sampleRaw.productId,
      productIdType: sampleRaw.productId?.constructor?.name
    })
  }
  
  // Get all vendor inventories for these products
  const inventoryRecords = await VendorInventory.find({
    productId: { $in: productObjectIds }
  })
    .populate('productId', 'id name sku category gender')
    .populate('vendorId', 'id name')
    .lean()
  
  console.log(`[getVendorWiseInventoryForCompany] ✅ Found ${inventoryRecords.length} inventory records via Mongoose`)
  
  // Log sample of populated records
  if (inventoryRecords.length > 0) {
    const samplePopulated = inventoryRecords[0]
    console.log(`[getVendorWiseInventoryForCompany] 📋 Sample populated inventory record:`, {
      id: samplePopulated.id,
      vendorId: samplePopulated.vendorId,
      vendorIdType: typeof samplePopulated.vendorId,
      vendorIdIsObject: typeof samplePopulated.vendorId === 'object',
      vendorIdKeys: samplePopulated.vendorId && typeof samplePopulated.vendorId === 'object' ? Object.keys(samplePopulated.vendorId) : 'N/A',
      productId: samplePopulated.productId,
      productIdType: typeof samplePopulated.productId
    })
  }
  
  // Get all vendors for manual lookup (fallback if populate fails)
  const allVendors = await Vendor.find({}).lean()
  console.log(`[getVendorWiseInventoryForCompany] 📦 Loaded ${allVendors.length} vendors from database`)
  
  const vendorMap = new Map()
  allVendors.forEach((v: any) => {
    if (v._id) {
      const vendorIdStr = v._id.toString()
      vendorMap.set(vendorIdStr, { id: v.id, name: v.name })
      console.log(`[getVendorWiseInventoryForCompany] 📝 Mapped vendor: ${vendorIdStr} -> ${v.name} (id: ${v.id})`)
    }
  })
  
  console.log(`[getVendorWiseInventoryForCompany] 🗺️  Vendor map size: ${vendorMap.size}`)
  
  // Build a map of inventory ID -> vendorId from raw records for reliable lookup
  const inventoryVendorMap = new Map<string, any>()
  rawInventoryRecords.forEach((raw: any) => {
    if (raw.id && raw.vendorId) {
      let vendorIdStr: string | null = null
      if (typeof raw.vendorId === 'string') {
        vendorIdStr = raw.vendorId
      } else if (raw.vendorId.toString) {
        vendorIdStr = raw.vendorId.toString()
      } else if (raw.vendorId._id) {
        vendorIdStr = raw.vendorId._id.toString()
      }
      
      if (vendorIdStr) {
        inventoryVendorMap.set(raw.id, vendorIdStr)
        console.log(`[getVendorWiseInventoryForCompany] 📝 Mapped inventory ${raw.id} -> vendorId ${vendorIdStr}`)
      }
    }
  })
  
  console.log(`[getVendorWiseInventoryForCompany] 🗺️  Inventory-Vendor map size: ${inventoryVendorMap.size}`)
  
  // Format the data for display
  const formattedInventory = inventoryRecords.map((inv: any, index: number) => {
    console.log(`\n[getVendorWiseInventoryForCompany] 🔄 Processing inventory record ${index + 1}/${inventoryRecords.length}`)
    console.log(`[getVendorWiseInventoryForCompany]   Inventory ID: ${inv.id || 'N/A'}`)
    console.log(`[getVendorWiseInventoryForCompany]   Raw vendorId type: ${typeof inv.vendorId}`)
    console.log(`[getVendorWiseInventoryForCompany]   Raw vendorId value:`, inv.vendorId)
    console.log(`[getVendorWiseInventoryForCompany]   Raw vendorId constructor: ${inv.vendorId?.constructor?.name}`)
    
    // Also get the raw record for comparison
    const rawRecord = rawInventoryRecords.find((r: any) => r.id === inv.id)
    if (rawRecord) {
      console.log(`[getVendorWiseInventoryForCompany]   📦 Raw DB vendorId:`, rawRecord.vendorId)
      console.log(`[getVendorWiseInventoryForCompany]   📦 Raw DB vendorId type: ${rawRecord.vendorId?.constructor?.name}`)
      console.log(`[getVendorWiseInventoryForCompany]   📦 Raw DB vendorId string: ${rawRecord.vendorId?.toString()}`)
    }
    
    const product = inv.productId
    let vendor = inv.vendorId
    
    console.log(`[getVendorWiseInventoryForCompany]   Initial vendor from populate:`, vendor)
    console.log(`[getVendorWiseInventoryForCompany]   Has vendor.name? ${!!(vendor && vendor.name)}`)
    
    // Fallback: if populate didn't work, try manual lookup
    if (!vendor || !vendor.name) {
      console.log(`[getVendorWiseInventoryForCompany]   ⚠️  Populate failed, trying manual lookup...`)
      
      // Try multiple ways to extract vendorId
      let vendorIdStr: string | null = null
      
      if (inv.vendorId) {
        if (typeof inv.vendorId === 'string') {
          vendorIdStr = inv.vendorId
          console.log(`[getVendorWiseInventoryForCompany]   📌 vendorId is string: ${vendorIdStr}`)
        } else if (inv.vendorId._id) {
          vendorIdStr = inv.vendorId._id.toString()
          console.log(`[getVendorWiseInventoryForCompany]   📌 vendorId._id found: ${vendorIdStr}`)
        } else if (inv.vendorId.toString) {
          vendorIdStr = inv.vendorId.toString()
          console.log(`[getVendorWiseInventoryForCompany]   📌 vendorId.toString(): ${vendorIdStr}`)
        } else if (typeof inv.vendorId === 'object' && inv.vendorId.constructor?.name === 'ObjectId') {
          vendorIdStr = inv.vendorId.toString()
          console.log(`[getVendorWiseInventoryForCompany]   📌 vendorId is ObjectId: ${vendorIdStr}`)
        }
      }
      
      // Also check raw vendorId field from inventory record
      if (!vendorIdStr && inv.vendorId) {
        const rawVendorId = inv.vendorId
        if (rawVendorId && typeof rawVendorId === 'object' && rawVendorId._id) {
          vendorIdStr = rawVendorId._id.toString()
          console.log(`[getVendorWiseInventoryForCompany]   📌 Found vendorId from raw field: ${vendorIdStr}`)
        }
      }
      
      if (vendorIdStr) {
        console.log(`[getVendorWiseInventoryForCompany]   🔍 Looking up vendorId: ${vendorIdStr}`)
        console.log(`[getVendorWiseInventoryForCompany]   🗺️  Vendor map has key? ${vendorMap.has(vendorIdStr)}`)
        
        if (vendorMap.has(vendorIdStr)) {
          vendor = vendorMap.get(vendorIdStr)
          console.log(`[getVendorWiseInventoryForCompany]   ✅ Found vendor in map:`, vendor)
        } else {
          console.log(`[getVendorWiseInventoryForCompany]   ❌ Vendor not found in map for ID: ${vendorIdStr}`)
          console.log(`[getVendorWiseInventoryForCompany]   📋 Available vendor IDs in map:`, Array.from(vendorMap.keys()).slice(0, 5))
        }
      } else {
        console.log(`[getVendorWiseInventoryForCompany]   ❌ Could not extract vendorId string`)
      }
      
      // Try to extract from populated object structure
      if ((!vendor || !vendor.name) && inv.vendorId && typeof inv.vendorId === 'object') {
        console.log(`[getVendorWiseInventoryForCompany]   🔄 Trying to extract from populated object...`)
        console.log(`[getVendorWiseInventoryForCompany]   📦 Populated object keys:`, Object.keys(inv.vendorId))
        vendor = {
          id: inv.vendorId.id || inv.vendorId._id?.toString() || 'N/A',
          name: inv.vendorId.name || 'Unknown Vendor'
        }
        console.log(`[getVendorWiseInventoryForCompany]   📝 Extracted vendor:`, vendor)
      }
    }
    
    // Final fallback: use inventory-vendor map built from raw records
    if (!vendor || !vendor.name || vendor.name === 'Unknown Vendor') {
      console.log(`[getVendorWiseInventoryForCompany]   🔄 Final fallback: using inventory-vendor map...`)
      
      const mappedVendorId = inventoryVendorMap.get(inv.id)
      if (mappedVendorId) {
        console.log(`[getVendorWiseInventoryForCompany]   📝 Found vendorId from map: ${mappedVendorId}`)
        if (vendorMap.has(mappedVendorId)) {
          vendor = vendorMap.get(mappedVendorId)
          console.log(`[getVendorWiseInventoryForCompany]   ✅ Final lookup successful:`, vendor)
        } else {
          console.log(`[getVendorWiseInventoryForCompany]   ❌ VendorId ${mappedVendorId} not in vendor map`)
          console.log(`[getVendorWiseInventoryForCompany]   📋 Available vendor IDs:`, Array.from(vendorMap.keys()).slice(0, 10))
        }
      } else {
        console.log(`[getVendorWiseInventoryForCompany]   ❌ Inventory ${inv.id} not in inventory-vendor map`)
      }
    }
    
    // Log final vendor result
    console.log(`[getVendorWiseInventoryForCompany]   ✅ Final vendor for record:`, vendor)
    console.log(`[getVendorWiseInventoryForCompany]   📝 Vendor name: ${vendor?.name || 'MISSING'}`)
    
    // Ensure we always have a vendor object
    if (!vendor || !vendor.name) {
      console.log(`[getVendorWiseInventoryForCompany]   ⚠️  WARNING: No vendor found, using fallback`)
      vendor = { id: 'N/A', name: 'Unknown Vendor' }
    }
    
    // Convert sizeInventory Map to object
    const sizeInventoryObj = inv.sizeInventory instanceof Map
      ? Object.fromEntries(inv.sizeInventory)
      : (inv.sizeInventory || {})
    
    // Convert lowInventoryThreshold Map to object
    const thresholdObj = inv.lowInventoryThreshold instanceof Map
      ? Object.fromEntries(inv.lowInventoryThreshold)
      : (inv.lowInventoryThreshold || {})
    
    // Calculate overall threshold (minimum threshold across all sizes, or 0 if none set)
    const thresholdValues = Object.values(thresholdObj).filter((v: any) => typeof v === 'number' && v > 0)
    const overallThreshold = thresholdValues.length > 0 ? Math.min(...thresholdValues as number[]) : 0
    
    // Determine stock status
    const totalStock = inv.totalStock || 0
    let stockStatus = 'in_stock'
    if (totalStock === 0) {
      stockStatus = 'out_of_stock'
    } else if (overallThreshold > 0 && totalStock <= overallThreshold) {
      stockStatus = 'low_stock'
    }
    
    return {
      sku: product?.sku || 'N/A',
      productName: product?.name || 'Unknown Product',
      productId: product?.id || 'N/A',
      vendorName: vendor?.name || 'Unknown Vendor',
      vendorId: vendor?.id || 'N/A',
      availableStock: totalStock,
      threshold: overallThreshold,
      sizeInventory: sizeInventoryObj,
      lowInventoryThreshold: thresholdObj,
      stockStatus,
      lastUpdated: inv.updatedAt || inv.createdAt || null,
      category: product?.category || 'N/A',
      gender: product?.gender || 'N/A',
    }
  })
  
  // Summary log
  const vendorNameCounts = new Map<string, number>()
  formattedInventory.forEach((item: any) => {
    const vendorName = item.vendorName || 'Unknown Vendor'
    vendorNameCounts.set(vendorName, (vendorNameCounts.get(vendorName) || 0) + 1)
  })
  
  console.log(`\n[getVendorWiseInventoryForCompany] 📊 SUMMARY:`)
  console.log(`[getVendorWiseInventoryForCompany]   Total inventory records: ${formattedInventory.length}`)
  console.log(`[getVendorWiseInventoryForCompany]   Vendor distribution:`)
  vendorNameCounts.forEach((count, vendorName) => {
    console.log(`[getVendorWiseInventoryForCompany]     - ${vendorName}: ${count} record(s)`)
  })
  console.log(`[getVendorWiseInventoryForCompany] ✅ Returning ${formattedInventory.length} formatted inventory records\n`)
  
  return formattedInventory
}

/**
 * Initialize vendor inventory for a product-vendor combination
 * Creates inventory record with all product sizes initialized to 0 stock and 0 threshold
 * Idempotent: Safe to call multiple times, won't create duplicates
 * This is called automatically when products are linked to vendors
 * @param vendorId - Vendor ObjectId
 * @param productId - Product ObjectId
 * @param session - Optional MongoDB session for transactional operations
 */
async function ensureVendorInventoryExists(
  vendorId: mongoose.Types.ObjectId, 
  productId: mongoose.Types.ObjectId,
  session?: mongoose.ClientSession
): Promise<void> {
  try {
    // CRITICAL: Verify product exists before creating inventory
    const product = await Uniform.findById(productId)
    if (!product) {
      console.error(`[ensureVendorInventoryExists] ❌ Product not found: ObjectId ${productId}`)
      throw new Error(`Product not found: ${productId.toString()}`)
    }

    // Check if inventory already exists (idempotency check)
    const findQuery = VendorInventory.findOne({
      vendorId: vendorId,
      productId: productId,
    })
    const existingInventory = session ? await findQuery.session(session) : await findQuery

    if (existingInventory) {
      // Inventory already exists, no need to create (idempotent)
      console.log(`[ensureVendorInventoryExists] ✅ Inventory already exists for vendor ${vendorId.toString()} / product ${product.id || productId.toString()}`)
      return
    }

    // Get product sizes - initialize inventory for each size
    const productSizes = product.sizes || []
    if (!Array.isArray(productSizes) || productSizes.length === 0) {
      console.warn(`[ensureVendorInventoryExists] ⚠️  Product ${product.id || productId.toString()} has no sizes defined. Creating inventory with empty size map.`)
    }

    // Initialize sizeInventory Map with all product sizes set to 0
    const sizeInventoryMap = new Map<string, number>()
    for (const size of productSizes) {
      if (size && typeof size === 'string' && size.trim()) {
        sizeInventoryMap.set(size.trim(), 0)
      }
    }

    // Initialize lowInventoryThreshold Map with all product sizes set to 0
    const thresholdMap = new Map<string, number>()
    for (const size of productSizes) {
      if (size && typeof size === 'string' && size.trim()) {
        thresholdMap.set(size.trim(), 0)
      }
    }

    // Generate unique inventory ID
    let inventoryId = `VEND-INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
    let isUnique = false
    let attempts = 0
    while (!isUnique && attempts < 10) {
      const checkQuery = VendorInventory.findOne({ id: inventoryId })
      const existing = session ? await checkQuery.session(session) : await checkQuery
      if (!existing) {
        isUnique = true
      } else {
        inventoryId = `VEND-INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
        attempts++
      }
    }

    // Create inventory record with all sizes initialized to 0
    const inventoryDoc = new VendorInventory({
      id: inventoryId,
      vendorId: vendorId,
      productId: productId,
      sizeInventory: sizeInventoryMap,
      totalStock: 0, // Will be recalculated by pre-save hook (sum of all sizes = 0)
      lowInventoryThreshold: thresholdMap,
    })

    // Mark Map fields as modified to ensure Mongoose saves them
    inventoryDoc.markModified('sizeInventory')
    inventoryDoc.markModified('lowInventoryThreshold')

    // Save with session if provided (for transactional operations)
    if (session) {
      await inventoryDoc.save({ session })
    } else {
      await inventoryDoc.save()
    }

    console.log(`[ensureVendorInventoryExists] ✅ Created VendorInventory for vendor ${vendorId.toString()} / product ${product.id || productId.toString()}`)
    console.log(`[ensureVendorInventoryExists] 📊 Initialized ${sizeInventoryMap.size} sizes: ${Array.from(sizeInventoryMap.keys()).join(', ')}`)
  } catch (error: any) {
    // If error is due to duplicate (race condition), that's okay (idempotent)
    if (error.code === 11000 || error.message?.includes('duplicate')) {
      console.log(`[ensureVendorInventoryExists] ⚠️  VendorInventory already exists for vendor ${vendorId.toString()} / product ${productId.toString()} (race condition)`)
      return
    }
    // Re-throw other errors (including product not found)
    console.error(`[ensureVendorInventoryExists] ❌ Error creating VendorInventory:`, {
      vendorId: vendorId.toString(),
      productId: productId.toString(),
      error: error.message,
      code: error.code,
    })
    throw error
  }
}

export async function updateVendorInventory(
  vendorId: string,
  productId: string,
  sizeInventory: { [size: string]: number },
  lowInventoryThreshold?: { [size: string]: number }
): Promise<any> {
  await connectDB()
  
  // CRITICAL: Ensure input IDs are strings
  const vendorIdStr = typeof vendorId === 'string' ? vendorId : String(vendorId || '')
  const productIdStr = typeof productId === 'string' ? productId : String(productId || '')
  
  if (!vendorIdStr || !productIdStr) {
    throw new Error('Vendor ID and Product ID are required and must be strings')
  }
  
  const vendor = await Vendor.findOne({ id: vendorIdStr })
  const product = await Uniform.findOne({ id: productIdStr })
  
  if (!vendor || !product) {
    throw new Error('Vendor or Product not found')
  }

  // CRITICAL: Ensure vendor.id and product.id exist and are strings
  // Do NOT use _id - only use the string id field
  const vendorIdFinal = typeof vendor.id === 'string' ? vendor.id : String(vendor.id || vendorIdStr)
  const productIdFinal = typeof product.id === 'string' ? product.id : String(product.id || productIdStr)
  
  if (!vendorIdFinal || !productIdFinal) {
    throw new Error(`Vendor or Product missing string ID field. Vendor ID: ${vendorIdFinal}, Product ID: ${productIdFinal}`)
  }

  console.log('[updateVendorInventory] 🔍 Using string IDs:', {
    vendorId: vendorIdFinal,
    productId: productIdFinal,
    vendorIdType: typeof vendorIdFinal,
    productIdType: typeof productIdFinal
  })

  // Get existing inventory to preserve threshold if not provided
  // CRITICAL FIX: VendorInventory stores vendorId and productId as STRING IDs, not ObjectIds
  const existingInventory = await VendorInventory.findOne({
    vendorId: vendorIdFinal, // Use string ID, not ObjectId
    productId: productIdFinal, // Use string ID, not ObjectId
  })

  // Generate unique inventory ID if creating new
  let inventoryId = existingInventory?.id || `VEND-INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
  if (!existingInventory) {
  let isUnique = false
  while (!isUnique) {
    const existing = await VendorInventory.findOne({ id: inventoryId })
    if (!existing) {
      isUnique = true
    } else {
      inventoryId = `VEND-INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
      }
    }
  }

  // Convert sizeInventory object to Map for Mongoose schema
  // Mongoose Map type requires actual Map instances for proper serialization
  const sizeInventoryMap = new Map<string, number>()
  for (const [size, quantity] of Object.entries(sizeInventory)) {
    sizeInventoryMap.set(size, typeof quantity === 'number' ? quantity : 0)
  }

  // Handle lowInventoryThreshold - merge with existing if provided
  let thresholdMap: Map<string, number>
  if (lowInventoryThreshold !== undefined) {
    thresholdMap = new Map<string, number>()
    for (const [size, threshold] of Object.entries(lowInventoryThreshold)) {
      thresholdMap.set(size, typeof threshold === 'number' ? threshold : 0)
    }
  } else if (existingInventory?.lowInventoryThreshold) {
    // Preserve existing thresholds if not provided
    thresholdMap = existingInventory.lowInventoryThreshold instanceof Map
      ? new Map(existingInventory.lowInventoryThreshold)
      : new Map(Object.entries(existingInventory.lowInventoryThreshold || {}))
  } else {
    thresholdMap = new Map<string, number>()
  }

  // Calculate total stock
  let totalStock = 0
  for (const quantity of Object.values(sizeInventory)) {
    totalStock += typeof quantity === 'number' ? quantity : 0
  }

  console.log('[updateVendorInventory] 🔍 DIAGNOSTIC: Update payload:', {
    vendorId: vendorIdFinal,
    productId: productIdFinal,
    sizeInventory: Object.fromEntries(sizeInventoryMap),
    totalStock,
    lowInventoryThreshold: Object.fromEntries(thresholdMap),
    inventoryId
  })

  // CRITICAL FIX: Use document.save() instead of findOneAndUpdate
  // findOneAndUpdate with .lean() bypasses Mongoose pre-save hooks and Map serialization
  // document.save() ensures:
  // 1. Pre-save hook runs (recalculates totalStock from sizeInventory)
  // 2. Map serialization works correctly
  // 3. Data persists properly to database
  
  // CRITICAL FIX: VendorInventory stores vendorId and productId as STRING IDs, not ObjectIds
  let inventoryDoc = await VendorInventory.findOne({
    vendorId: vendorIdFinal, // Use string ID, not ObjectId
    productId: productIdFinal, // Use string ID, not ObjectId
  })

  if (!inventoryDoc) {
    // Create new inventory document if it doesn't exist
    inventoryDoc = new VendorInventory({
      id: inventoryId,
      vendorId: vendorIdFinal, // Use string ID, not ObjectId
      productId: productIdFinal, // Use string ID, not ObjectId
      sizeInventory: new Map(),
      lowInventoryThreshold: new Map(),
      totalStock: 0,
    })
    console.log('[updateVendorInventory] 🔍 DIAGNOSTIC: Created new inventory document with string IDs.')
  } else {
    console.log('[updateVendorInventory] 🔍 DIAGNOSTIC: Found existing inventory document.')
  }

  // CRITICAL: Ensure vendorId and productId are strings before saving
  // Explicitly set them to ensure they're strings, not ObjectIds
  inventoryDoc.vendorId = String(vendorIdFinal)
  inventoryDoc.productId = String(productIdFinal)
  
  // Update properties - use Map instances (schema expects Map type)
  inventoryDoc.sizeInventory = sizeInventoryMap
  inventoryDoc.lowInventoryThreshold = thresholdMap
  // Note: totalStock will be recalculated by pre-save hook, but we set it explicitly too
  inventoryDoc.totalStock = totalStock

  // CRITICAL: Mark Map fields as modified to ensure Mongoose saves them
  // Mongoose doesn't always detect changes to Map objects, so we must explicitly mark them
  inventoryDoc.markModified('sizeInventory')
  inventoryDoc.markModified('lowInventoryThreshold')
  
  // CRITICAL: Mark vendorId and productId as modified to ensure they're saved as strings
  inventoryDoc.markModified('vendorId')
  inventoryDoc.markModified('productId')
  
  console.log('[updateVendorInventory] 🔍 DIAGNOSTIC: Before save - inventoryDoc:', {
    id: inventoryDoc.id,
    vendorId: inventoryDoc.vendorId, // String ID, not ObjectId
    productId: inventoryDoc.productId, // String ID, not ObjectId
    vendorIdType: typeof inventoryDoc.vendorId,
    productIdType: typeof inventoryDoc.productId,
    sizeInventory: Object.fromEntries(inventoryDoc.sizeInventory),
    lowInventoryThreshold: Object.fromEntries(inventoryDoc.lowInventoryThreshold),
    totalStock: inventoryDoc.totalStock, // Will be recalculated by pre-save hook
  })

  // Save the document - this triggers pre-save hooks and proper Map serialization
  let savedInventory
  try {
    savedInventory = await inventoryDoc.save()
    console.log('[updateVendorInventory] ✅ Document.save() completed successfully')
  } catch (saveError: any) {
    console.error('[updateVendorInventory] ❌ CRITICAL: Document.save() failed:', saveError)
    console.error('[updateVendorInventory] ❌ Save error details:', {
      message: saveError.message,
      stack: saveError.stack,
      name: saveError.name,
      code: saveError.code,
    })
    throw new Error(`Failed to save inventory: ${saveError.message}`)
  }
  
  console.log('[updateVendorInventory] ✅ Inventory document saved successfully.')
  console.log('[updateVendorInventory] 🔍 DIAGNOSTIC: After save - savedInventory:', {
    id: savedInventory.id,
    totalStock: savedInventory.totalStock,
    sizeInventorySize: savedInventory.sizeInventory.size,
    lowInventoryThresholdSize: savedInventory.lowInventoryThreshold.size,
  })

  // CRITICAL FIX: VendorInventory stores vendorId and productId as STRING IDs, not ObjectIds
  // Cannot use populate() with string IDs - need to manually fetch related documents
  // Query by string IDs instead of using populate
  const inventory = await VendorInventory.findOne({
    vendorId: vendorIdFinal, // Use string ID, not ObjectId
    productId: productIdFinal, // Use string ID, not ObjectId
  }).lean()
  
  if (!inventory) {
    console.error('[updateVendorInventory] ❌ CRITICAL: Failed to retrieve inventory after save.')
    throw new Error('Failed to update inventory')
  }
  
  // Manually populate vendor and product details using string IDs
  const vendorDetails = await Vendor.findOne({ id: vendorIdFinal }).select('id name').lean()
  const productDetails = await Uniform.findOne({ id: productIdFinal }).select('id name category gender sizes price sku').lean()

  // Attach vendor and product details manually
  const inventoryAny = inventory as any
  inventoryAny.vendorId = vendorDetails
  inventoryAny.productId = productDetails

  // Verify the update persisted correctly
  console.log('[updateVendorInventory] ✅ Update result (after save):', {
    inventoryId: inventoryAny.id,
    persistedSizeInventory: inventoryAny.sizeInventory,
    persistedTotalStock: inventoryAny.totalStock,
    persistedThreshold: inventoryAny.lowInventoryThreshold,
    sizeInventoryType: typeof inventoryAny.sizeInventory,
    sizeInventoryIsMap: inventoryAny.sizeInventory instanceof Map,
    sizeInventoryConstructor: inventoryAny.sizeInventory?.constructor?.name
  })
  
  // CRITICAL: Verify data was actually persisted by querying database directly
  // CRITICAL FIX: VendorInventory stores vendorId and productId as STRING IDs, not ObjectIds
  const db = mongoose.connection.db
  if (db) {
    const rawInventory = await db.collection('vendorinventories').findOne({
      vendorId: vendorIdFinal, // Use string ID, not ObjectId
      productId: productIdFinal, // Use string ID, not ObjectId
    })
    if (rawInventory) {
      console.log('[updateVendorInventory] ✅ DATABASE VERIFICATION: Raw DB record:', {
        id: rawInventory.id,
        sizeInventory: rawInventory.sizeInventory,
        totalStock: rawInventory.totalStock,
        lowInventoryThreshold: rawInventory.lowInventoryThreshold,
        updatedAt: rawInventory.updatedAt,
      })
      
      // Verify the values match what we tried to save
      const expectedTotal = Object.values(sizeInventory).reduce((sum, qty) => sum + (typeof qty === 'number' ? qty : 0), 0)
      if (rawInventory.totalStock !== expectedTotal) {
        console.error(`[updateVendorInventory] ❌ DATABASE VERIFICATION FAILED: totalStock mismatch! Expected: ${expectedTotal}, Got: ${rawInventory.totalStock}`)
        throw new Error(`Inventory totalStock mismatch: expected ${expectedTotal}, got ${rawInventory.totalStock}`)
      }
      
      // Verify sizeInventory matches
      const rawSizeInv = rawInventory.sizeInventory || {}
      const sizeInventoryKeys = Object.keys(sizeInventory)
      for (const size of sizeInventoryKeys) {
        const expectedQty = sizeInventory[size]
        const actualQty = rawSizeInv[size]
        if (actualQty !== expectedQty) {
          console.error(`[updateVendorInventory] ❌ DATABASE VERIFICATION FAILED: sizeInventory mismatch for size ${size}! Expected: ${expectedQty}, Got: ${actualQty}`)
          throw new Error(`Inventory sizeInventory mismatch for size ${size}: expected ${expectedQty}, got ${actualQty}`)
        }
      }
      
      console.log('[updateVendorInventory] ✅ DATABASE VERIFICATION PASSED: All values match expected values')
    } else {
      console.error('[updateVendorInventory] ❌ DATABASE VERIFICATION FAILED: Record not found in DB after save!')
      throw new Error('Inventory update did not persist to database')
    }
  }

  // Convert retrieved Maps to plain objects for response
  // After .lean(), Maps are returned as plain objects
  const responseSizeInventory = inventoryAny.sizeInventory instanceof Map
    ? Object.fromEntries(inventoryAny.sizeInventory)
    : inventoryAny.sizeInventory || {}
  
  const responseThreshold = inventoryAny.lowInventoryThreshold instanceof Map
    ? Object.fromEntries(inventoryAny.lowInventoryThreshold)
    : inventoryAny.lowInventoryThreshold || {}

  return {
    id: inventoryAny.id,
    vendorId: vendorDetails?.id || inventoryAny.vendorId || '',
    vendorName: vendorDetails?.name || '',
    productId: productDetails?.id || inventoryAny.productId || '',
    productName: productDetails?.name || '',
    productCategory: productDetails?.category || '',
    productGender: productDetails?.gender || '',
    productSizes: productDetails?.sizes || [],
    productPrice: productDetails?.price || 0,
    productSku: productDetails?.sku || '',
    sizeInventory: responseSizeInventory,
    lowInventoryThreshold: responseThreshold,
    totalStock: inventoryAny.totalStock || 0,
    createdAt: inventoryAny.createdAt,
    updatedAt: inventoryAny.updatedAt,
  }
}

// ========== DESIGNATION PRODUCT ELIGIBILITY FUNCTIONS ==========

export async function getDesignationEligibilitiesByCompany(companyId: string): Promise<any[]> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    console.warn(`Company not found: ${companyId}`)
    return []
  }

  // First try with status filter
  let eligibilities = await DesignationProductEligibility.find({ 
    companyId: company._id,
    status: 'active'
  })
    .populate('companyId', 'id name')
    .sort({ designation: 1 })
    .lean()

  // If no active records found, also check for inactive records (for debugging)
  if (eligibilities.length === 0) {
    const inactiveCount = await DesignationProductEligibility.countDocuments({ 
      companyId: company._id,
      status: 'inactive'
    })
    if (inactiveCount > 0) {
      console.warn(`Found ${inactiveCount} inactive designation eligibilities for company ${companyId}. Only active records are returned.`)
    }
    
    // Also check if there are any records with this companyId but no status filter
    const allCount = await DesignationProductEligibility.countDocuments({ 
      companyId: company._id
    })
    if (allCount > 0 && allCount !== inactiveCount) {
      console.warn(`Found ${allCount} total designation eligibilities for company ${companyId}, but none are active.`)
    }
  }

  // Import decrypt function and crypto for alternative decryption
  const { decrypt } = require('../utils/encryption')
  const crypto = require('crypto')
  
  // Helper function to get encryption key
  const getKey = () => {
    const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'default-encryption-key-change-in-production-32-chars!!'
    const key = Buffer.from(ENCRYPTION_KEY, 'utf8')
    if (key.length !== 32) {
      return crypto.createHash('sha256').update(ENCRYPTION_KEY).digest()
    }
    return key
  }
  
  // Decrypt designations manually since .lean() bypasses Mongoose hooks
  const decryptedEligibilities = eligibilities.map((e: any) => {
    // Log raw data from DB before processing
    console.log('🔍 Raw eligibility from DB:', {
      id: e.id,
      hasItemEligibility: !!e.itemEligibility,
      itemEligibilityKeys: e.itemEligibility ? Object.keys(e.itemEligibility) : 'none',
      itemEligibilityRaw: e.itemEligibility ? JSON.stringify(e.itemEligibility, null, 2) : 'none',
      allowedProductCategories: e.allowedProductCategories,
    })
    
    // Convert to plain object first
    const plainObj = toPlainObject(e)
    
    // Ensure allowedProductCategories includes all categories from itemEligibility
    // This fixes existing data where categories might be missing
    if (plainObj.itemEligibility && typeof plainObj.itemEligibility === 'object') {
      const categoriesFromItemEligibility = Object.keys(plainObj.itemEligibility).filter(key => 
        key !== '_id' && plainObj.itemEligibility[key] && typeof plainObj.itemEligibility[key] === 'object'
      )
      const existingCategories = new Set(plainObj.allowedProductCategories || [])
      
      // Add missing categories from itemEligibility
      categoriesFromItemEligibility.forEach(cat => {
        // Handle aliases: pant -> trouser, jacket -> blazer
        if (cat === 'pant') {
          existingCategories.add('trouser')
          existingCategories.add('pant')
        } else if (cat === 'jacket') {
          existingCategories.add('blazer')
          existingCategories.add('jacket')
        } else {
          existingCategories.add(cat)
        }
      })
      
      // Update if categories were added
      if (existingCategories.size > (plainObj.allowedProductCategories?.length || 0)) {
        plainObj.allowedProductCategories = Array.from(existingCategories)
        console.log(`✅ Fixed missing categories for ${plainObj.id}:`, {
          original: e.allowedProductCategories,
          fixed: plainObj.allowedProductCategories,
          fromItemEligibility: categoriesFromItemEligibility,
        })
      }
    }
    
    // Log after toPlainObject
    console.log('🔍 After toPlainObject:', {
      id: plainObj.id,
      hasItemEligibility: !!plainObj.itemEligibility,
      itemEligibilityKeys: plainObj.itemEligibility ? Object.keys(plainObj.itemEligibility) : 'none',
      itemEligibilityPlain: plainObj.itemEligibility ? JSON.stringify(plainObj.itemEligibility, null, 2) : 'none',
    })
    
    // DesignationProductEligibility.designation is now stored as PLAINTEXT (encryption removed)
    // No decryption needed - designation is already in plaintext format
    
    return plainObj
  })

  console.log(`📊 Returning ${decryptedEligibilities.length} eligibilities`)
  return decryptedEligibilities
}

export async function getDesignationEligibilityById(eligibilityId: string): Promise<any | null> {
  await connectDB()
  
  const eligibility = await DesignationProductEligibility.findOne({ id: eligibilityId })
    .populate('companyId', 'id name')
    .lean()

  if (!eligibility) return null

  // Convert to plain object first
  const plainObj = toPlainObject(eligibility)
  
  // DesignationProductEligibility.designation is now stored as PLAINTEXT (encryption removed)
  // No decryption needed

  return plainObj
}

export async function getDesignationEligibilityByDesignation(
  companyId: string, 
  designation: string, 
  gender?: 'male' | 'female'
): Promise<any | null> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) return null

  // DesignationProductEligibility.designation is now PLAINTEXT (encryption removed)
  // Employee.designation is ENCRYPTED (employee PII)
  // Strategy: Decrypt employee.designation, then match with plaintext eligibility.designation
  
  const { decrypt } = require('../utils/encryption')
  
  // Decrypt the input designation (from employee) for matching
  // The input designation comes from Employee.designation which is encrypted
  let decryptedDesignation: string = designation.trim()
  if (decryptedDesignation && typeof decryptedDesignation === 'string' && decryptedDesignation.includes(':')) {
    try {
      decryptedDesignation = decrypt(decryptedDesignation)
  } catch (error) {
      console.warn('Failed to decrypt employee designation for eligibility lookup:', error)
      // If decryption fails, try using as-is (might already be plaintext)
    }
  }
  
  // Normalize designation to lowercase for case-insensitive matching
  const normalizedDesignation = decryptedDesignation.trim().toLowerCase()

  // Build query filter - prioritize gender-specific rules, then 'unisex' rules
  const queryFilter: any = {
    companyId: company._id,
    status: 'active'
  }

  // Query with plaintext designation (DesignationProductEligibility.designation is now plaintext)
  // Try exact match first, then case-insensitive match
  let eligibility = await DesignationProductEligibility.findOne({ 
    ...queryFilter,
    designation: { $regex: new RegExp(`^${normalizedDesignation.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }
  })
    .populate('companyId', 'id name')
    .lean()

  // If not found with exact match, fetch all and match case-insensitively
  if (!eligibility) {
    const allEligibilities = await DesignationProductEligibility.find(queryFilter)
      .populate('companyId', 'id name')
      .lean()

    // Find matching eligibility (eligibility.designation is now plaintext, no decryption needed)
    // Priority: gender-specific first, then 'unisex'
    const matchingEligibilities: any[] = []
    for (const elig of allEligibilities) {
      const eligDesignation = (elig.designation as string) || ''
      // Match designation (case-insensitive) - no decryption needed (already plaintext)
      const normalizedEligDesignation = eligDesignation.trim().toLowerCase()
      if (normalizedEligDesignation && normalizedEligDesignation === normalizedDesignation) {
        const eligGender = elig.gender || 'unisex'
        matchingEligibilities.push({ ...elig, gender: eligGender })
      }
    }

    // Prioritize gender-specific rules over 'unisex'
    if (gender) {
      const genderSpecific = matchingEligibilities.find(e => e.gender === gender)
      if (genderSpecific) {
        eligibility = genderSpecific
      } else {
        // Fall back to 'unisex' if no gender-specific rule found
        eligibility = matchingEligibilities.find(e => e.gender === 'unisex' || !e.gender)
      }
    } else {
      // If no gender specified, prefer 'unisex', otherwise take first match
      eligibility = matchingEligibilities.find(e => e.gender === 'unisex' || !e.gender) || matchingEligibilities[0]
    }
  } else {
    // Check if gender matches (if gender is specified)
    if (gender && eligibility.gender && eligibility.gender !== 'unisex' && eligibility.gender !== gender) {
      // Gender doesn't match, try to find 'unisex' or matching gender rule
      // CRITICAL FIX: Use company.id (string ID) instead of company._id (ObjectId)
      const allEligibilities = await DesignationProductEligibility.find({
        companyId: company.id,
        status: 'active'
      })
        .populate('companyId', 'id name')
        .lean()
      
      for (const elig of allEligibilities) {
        const eligDesignation = (elig.designation as string) || ''
        // No decryption needed - eligibility.designation is now plaintext
        const normalizedEligDesignation = eligDesignation.trim().toLowerCase()
        if (normalizedEligDesignation && normalizedEligDesignation === normalizedDesignation) {
          const eligGender = elig.gender || 'unisex'
          if (eligGender === gender || eligGender === 'unisex') {
            eligibility = elig
            break
          }
        }
      }
    }
  }

  return eligibility || null
}

export async function createDesignationEligibility(
  companyId: string,
  designation: string,
  allowedProductCategories: string[],
  itemEligibility?: {
    // Legacy categories (for backward compatibility)
    shirt?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    trouser?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    pant?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    shoe?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    blazer?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    jacket?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    // Dynamic categories (any category name can be used)
    [categoryName: string]: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' } | undefined
  },
  gender?: 'male' | 'female' | 'unisex'
): Promise<any> {
  await connectDB()
  
  const company = await Company.findOne({ id: companyId })
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }

  // Ensure system categories exist
  await ensureSystemCategories(companyId)
  
  // Get all categories for this company to validate and map category names
  const categories = await getCategoriesByCompany(companyId)
  const categoryMap = new Map<string, string>() // Maps normalized name to actual category name
  categories.forEach(cat => {
    categoryMap.set(cat.name.toLowerCase(), cat.name)
    categoryMap.set(normalizeCategoryName(cat.name), cat.name)
  })

  // Generate unique ID by finding the highest existing ID number
  let eligibilityId: string
  let attempts = 0
  const maxAttempts = 10
  
  while (attempts < maxAttempts) {
    // Find the highest existing ID
    const existingEligibilities = await DesignationProductEligibility.find({}, 'id')
      .sort({ id: -1 })
      .limit(1)
      .lean()
    
    let nextIdNumber = 1
    if (existingEligibilities.length > 0 && existingEligibilities[0].id) {
      const lastId = existingEligibilities[0].id as string
      const match = lastId.match(/^DESIG-ELIG-(\d+)$/)
      if (match) {
        nextIdNumber = parseInt(match[1], 10) + 1
      }
    }
    
    eligibilityId = `DESIG-ELIG-${String(nextIdNumber).padStart(6, '0')}`
    
    // Check if this ID already exists (race condition protection)
    const existing = await DesignationProductEligibility.findOne({ id: eligibilityId })
    if (!existing) {
      break // ID is available
    }
    
    // ID exists, try next number
    nextIdNumber++
    eligibilityId = `DESIG-ELIG-${String(nextIdNumber).padStart(6, '0')}`
    attempts++
  }
  
  if (attempts >= maxAttempts) {
    throw new Error('Failed to generate unique eligibility ID after multiple attempts')
  }

  // Structure itemEligibility to match schema exactly
  // Map category names to actual category names from DB (for dynamic categories)
  let structuredItemEligibility: any = undefined
  if (itemEligibility) {
    structuredItemEligibility = {}
    for (const [key, value] of Object.entries(itemEligibility)) {
      if (value && typeof value === 'object' && 'quantity' in value && 'renewalFrequency' in value) {
        // Preserve actual values - don't default to 0 if value is provided
        const qty = typeof value.quantity === 'number' ? value.quantity : (value.quantity ? Number(value.quantity) : 0)
        const freq = typeof value.renewalFrequency === 'number' ? value.renewalFrequency : (value.renewalFrequency ? Number(value.renewalFrequency) : 0)
        const unit = value.renewalUnit || 'months'
        
        // Map category key to actual category name from DB (for dynamic categories)
        // Try to find matching category in DB
        const normalizedKey = normalizeCategoryName(key)
        let categoryKey = key // Default to original key
        
        // Check if this key matches a category in DB
        if (categoryMap.has(key.toLowerCase())) {
          categoryKey = categoryMap.get(key.toLowerCase())!.toLowerCase()
        } else if (categoryMap.has(normalizedKey)) {
          categoryKey = categoryMap.get(normalizedKey)!.toLowerCase()
        } else {
          // For legacy categories or new categories not yet in DB, use normalized key
          categoryKey = normalizedKey
        }
        
        structuredItemEligibility[categoryKey] = {
          quantity: qty,
          renewalFrequency: freq,
          renewalUnit: unit,
        }
        console.log(`  ✅ Structured ${key} -> ${categoryKey}: quantity=${qty}, frequency=${freq}, unit=${unit}`)
      }
    }
  }

  // Normalize category names function (same as in UI)
  const normalizeCategory = (cat: string): string => {
    if (!cat) return ''
    const lower = cat.toLowerCase().trim()
    if (lower.includes('shirt')) return 'shirt'
    if (lower.includes('trouser') || lower.includes('pant')) return 'trouser'
    if (lower.includes('shoe')) return 'shoe'
    if (lower.includes('blazer') || lower.includes('jacket')) return 'blazer'
    if (lower.includes('accessory')) return 'accessory'
    return lower
  }

  // Ensure allowedProductCategories includes all categories from itemEligibility
  // This ensures consistency - if itemEligibility has entries, they should be in allowedProductCategories
  const categoriesFromItemEligibility = structuredItemEligibility ? Object.keys(structuredItemEligibility) : []
  const normalizedAllowedCategories = new Set<string>()
  
  // Normalize and add categories from allowedProductCategories
  ;(allowedProductCategories || []).forEach(cat => {
    const normalized = normalizeCategory(cat)
    // Try to find actual category name from DB
    if (categoryMap.has(cat.toLowerCase())) {
      normalizedAllowedCategories.add(categoryMap.get(cat.toLowerCase())!.toLowerCase())
    } else if (categoryMap.has(normalized)) {
      normalizedAllowedCategories.add(categoryMap.get(normalized)!.toLowerCase())
    } else {
      normalizedAllowedCategories.add(normalized)
    }
  })
  
  // Add normalized categories from itemEligibility that might be missing
  categoriesFromItemEligibility.forEach(cat => {
    // Category key is already normalized/mapped, just add it
    normalizedAllowedCategories.add(cat)
  })
  
  const finalAllowedCategories = Array.from(normalizedAllowedCategories)

  console.log('🔍 Creating new eligibility with itemEligibility:', {
    eligibilityId,
    designation,
    originalAllowedCategories: allowedProductCategories,
    categoriesFromItemEligibility,
    finalAllowedCategories,
    originalItemEligibility: itemEligibility ? JSON.stringify(itemEligibility, null, 2) : 'none',
    structuredItemEligibility: structuredItemEligibility ? JSON.stringify(structuredItemEligibility, null, 2) : 'none',
    gender: gender || 'unisex',
  })

  const eligibility = new DesignationProductEligibility({
    id: eligibilityId,
    companyId: company._id,
    companyName: company.name,
    designation: designation,
    gender: gender || 'unisex', // Use 'unisex' instead of 'all' to match model enum
    allowedProductCategories: finalAllowedCategories,
    itemEligibility: structuredItemEligibility,
    status: 'active',
  })
  
  console.log('🔍 Eligibility object created:', {
    itemEligibility: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
    itemEligibilityType: typeof eligibility.itemEligibility,
  })

  try {
    // Log before save
    console.log('🔍 Document state BEFORE save (create):', {
      itemEligibility: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
      isNew: eligibility.isNew,
    })
    
    await eligibility.save()
    console.log('✅ Eligibility document created successfully')
    
    // Log after save
    console.log('🔍 Document state AFTER save (create):', {
      itemEligibility: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
    })
    
    // Verify by fetching from DB
    const verifyCreated = await DesignationProductEligibility.findOne({ id: eligibilityId }).lean()
    if (verifyCreated) {
      console.log('✅ Verification - Created document from DB:', {
        id: verifyCreated.id,
        itemEligibility: verifyCreated.itemEligibility ? JSON.stringify(verifyCreated.itemEligibility, null, 2) : 'none',
      })
    }
  } catch (saveError: any) {
    console.error('❌ Error saving eligibility:', saveError)
    // If still a duplicate key error, try one more time with a higher ID
    if (saveError.code === 11000 && saveError.keyPattern?.id) {
      const existingEligibilities = await DesignationProductEligibility.find({}, 'id')
        .sort({ id: -1 })
        .limit(1)
        .lean()
      
      let nextIdNumber = 1
      if (existingEligibilities.length > 0 && existingEligibilities[0].id) {
        const lastId = existingEligibilities[0].id as string
        const match = lastId.match(/^DESIG-ELIG-(\d+)$/)
        if (match) {
          nextIdNumber = parseInt(match[1], 10) + 1
        }
      }
      
      eligibilityId = `DESIG-ELIG-${String(nextIdNumber).padStart(6, '0')}`
      eligibility.id = eligibilityId
      await eligibility.save()
      console.log('✅ Eligibility document created successfully after retry')
    } else {
      throw saveError
    }
  }
  
  // Fetch the created eligibility with proper decryption
  const createdEligibility = await getDesignationEligibilityById(eligibilityId)
  if (createdEligibility) {
    return createdEligibility
  }
  
  // Fallback: manually decrypt if fetch fails
  const plainObj = toPlainObject(eligibility)
  const { decrypt } = require('../utils/encryption')
  if (plainObj.designation && typeof plainObj.designation === 'string' && plainObj.designation.includes(':')) {
    try {
      plainObj.designation = decrypt(plainObj.designation)
    } catch (error: any) {
      console.error('Failed to decrypt designation after create:', error.message)
    }
  }
  return plainObj
}

export async function updateDesignationEligibility(
  eligibilityId: string,
  designation?: string,
  allowedProductCategories?: string[],
  itemEligibility?: {
    // Legacy categories (for backward compatibility)
    shirt?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    trouser?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    pant?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    shoe?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    blazer?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    jacket?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    // Dynamic categories (any category name can be used)
    [categoryName: string]: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' } | undefined
  },
  gender?: 'male' | 'female' | 'unisex',
  status?: 'active' | 'inactive',
  refreshEligibility?: boolean
): Promise<any> {
  await connectDB()
  
  // Get existing eligibility to find companyId
  const existingEligibility = await DesignationProductEligibility.findOne({ id: eligibilityId })
  if (!existingEligibility) {
    throw new Error(`Eligibility not found: ${eligibilityId}`)
  }
  
  // CRITICAL FIX: existingEligibility.companyId is a STRING ID, not ObjectId
  const companyIdStr = String(existingEligibility.companyId)
  const company = /^\d{6}$/.test(companyIdStr) 
    ? await Company.findOne({ id: companyIdStr })
    : await Company.findById(existingEligibility.companyId)
  if (!company) {
    throw new Error(`Company not found for eligibility: ${eligibilityId}`)
  }
  
  // Ensure system categories exist
  await ensureSystemCategories(company.id)
  
  // Get all categories for this company to validate and map category names
  const categories = await getCategoriesByCompany(company.id)
  const categoryMap = new Map<string, string>() // Maps normalized name to actual category name
  categories.forEach(cat => {
    categoryMap.set(cat.name.toLowerCase(), cat.name)
    categoryMap.set(normalizeCategoryName(cat.name), cat.name)
  })
  
  // Try using findOne + save approach to ensure pre-save hooks run and changes are detected
  const eligibility = await DesignationProductEligibility.findOne({ id: eligibilityId })
  if (!eligibility) {
    throw new Error(`Designation eligibility not found: ${eligibilityId}`)
  }

  // Structure itemEligibility first if provided (map category names to actual DB category names)
  let structuredItemEligibility: any = undefined
  if (itemEligibility !== undefined) {
    structuredItemEligibility = {}
    for (const [key, value] of Object.entries(itemEligibility)) {
      if (value && typeof value === 'object' && 'quantity' in value && 'renewalFrequency' in value) {
        // Preserve actual values - don't default to 0 if value is provided
        const qty = typeof value.quantity === 'number' ? value.quantity : (value.quantity ? Number(value.quantity) : 0)
        const freq = typeof value.renewalFrequency === 'number' ? value.renewalFrequency : (value.renewalFrequency ? Number(value.renewalFrequency) : 0)
        const unit = value.renewalUnit || 'months'
        
        // Map category key to actual category name from DB (for dynamic categories)
        const normalizedKey = normalizeCategoryName(key)
        let categoryKey = key // Default to original key
        
        // Check if this key matches a category in DB
        if (categoryMap.has(key.toLowerCase())) {
          categoryKey = categoryMap.get(key.toLowerCase())!.toLowerCase()
        } else if (categoryMap.has(normalizedKey)) {
          categoryKey = categoryMap.get(normalizedKey)!.toLowerCase()
        } else {
          // For legacy categories or new categories not yet in DB, use normalized key
          categoryKey = normalizedKey
        }
        
        structuredItemEligibility[categoryKey] = {
          quantity: qty,
          renewalFrequency: freq,
          renewalUnit: unit,
        }
        console.log(`  ✅ Structured ${key} -> ${categoryKey}: quantity=${qty}, frequency=${freq}, unit=${unit}`)
      }
    }
  }

  // Ensure allowedProductCategories includes all categories from itemEligibility
  // This ensures consistency - if itemEligibility has entries, they should be in allowedProductCategories
  let finalAllowedCategories = allowedProductCategories
  if (allowedProductCategories !== undefined || structuredItemEligibility !== undefined) {
    const categoriesFromItemEligibility = structuredItemEligibility ? Object.keys(structuredItemEligibility) : []
    // Normalize category names function (same as in create)
    const normalizeCategory = (cat: string): string => {
      if (!cat) return ''
      const lower = cat.toLowerCase().trim()
      if (lower.includes('shirt')) return 'shirt'
      if (lower.includes('trouser') || lower.includes('pant')) return 'trouser'
      if (lower.includes('shoe')) return 'shoe'
      if (lower.includes('blazer') || lower.includes('jacket')) return 'blazer'
      if (lower.includes('accessory')) return 'accessory'
      return lower
    }

    const normalizedAllowedCategories = new Set<string>()
    
    // Normalize and add categories from allowedProductCategories or existing eligibility
    const categoriesToNormalize = allowedProductCategories || eligibility.allowedProductCategories || []
    categoriesToNormalize.forEach(cat => {
      const normalized = normalizeCategory(cat)
      // Try to find actual category name from DB
      if (categoryMap.has(cat.toLowerCase())) {
        normalizedAllowedCategories.add(categoryMap.get(cat.toLowerCase())!.toLowerCase())
      } else if (categoryMap.has(normalized)) {
        normalizedAllowedCategories.add(categoryMap.get(normalized)!.toLowerCase())
      } else {
        normalizedAllowedCategories.add(normalized)
      }
    })
    
    // Add normalized categories from itemEligibility that might be missing
    categoriesFromItemEligibility.forEach(cat => {
      // Category key is already normalized/mapped, just add it
      normalizedAllowedCategories.add(cat)
    })
    
    finalAllowedCategories = Array.from(normalizedAllowedCategories)
  }

  // Update fields
  if (designation !== undefined) {
    eligibility.designation = designation // Stored as plaintext (encryption removed from DesignationProductEligibility)
  }
  if (finalAllowedCategories !== undefined) {
    eligibility.allowedProductCategories = finalAllowedCategories
    console.log('🔍 Updated allowedProductCategories:', finalAllowedCategories)
  }
  if (structuredItemEligibility !== undefined) {
    // MERGE with existing itemEligibility instead of replacing
    // This preserves categories that exist in DB but aren't in the current form
    const existingItemEligibility = eligibility.itemEligibility || {}
    const mergedItemEligibility = {
      ...existingItemEligibility, // Preserve existing categories
      ...structuredItemEligibility, // Override with new/updated categories
    }
    
    // Log what we're about to save
    console.log('🔍 Merging itemEligibility on eligibility document:', {
      before: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
      newValue: JSON.stringify(structuredItemEligibility, null, 2),
      merged: JSON.stringify(mergedItemEligibility, null, 2),
      existingKeys: Object.keys(existingItemEligibility),
      newKeys: Object.keys(structuredItemEligibility),
      mergedKeys: Object.keys(mergedItemEligibility),
    })
    
    // Use set() method to explicitly set the merged nested object
    eligibility.set('itemEligibility', mergedItemEligibility)
    // Mark as modified to ensure Mongoose saves it
    eligibility.markModified('itemEligibility')
    
    // Verify it was set
    console.log('🔍 After setting itemEligibility:', {
      eligibilityItemEligibility: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
      isModified: eligibility.isModified('itemEligibility'),
      type: typeof eligibility.itemEligibility,
      directAccess: eligibility.get('itemEligibility') ? JSON.stringify(eligibility.get('itemEligibility'), null, 2) : 'none',
    })
  }
  if (gender !== undefined) {
    eligibility.gender = gender
  }
  if (status !== undefined) {
    eligibility.status = status
  }

  // Save the document (designation is stored as plaintext - encryption removed)
  try {
    // Log the document state before save
    console.log('🔍 Document state BEFORE save:', {
      itemEligibility: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
      itemEligibilityType: typeof eligibility.itemEligibility,
      itemEligibilityKeys: eligibility.itemEligibility ? Object.keys(eligibility.itemEligibility) : [],
      isModified: eligibility.isModified('itemEligibility'),
      isNew: eligibility.isNew,
      documentId: eligibility._id,
    })
    
    await eligibility.save()
    console.log('✅ Eligibility document saved successfully using save() method')
    
    // Log the document state after save
    console.log('🔍 Document state AFTER save:', {
      itemEligibility: eligibility.itemEligibility ? JSON.stringify(eligibility.itemEligibility, null, 2) : 'none',
    })
  } catch (saveError: any) {
    console.error('❌ Error saving eligibility:', saveError)
    console.error('❌ Save error details:', {
      message: saveError.message,
      code: saveError.code,
      errors: saveError.errors,
      stack: saveError.stack,
    })
    throw new Error(`Failed to save eligibility: ${saveError.message}`)
  }

  const updated = eligibility
  
  // Verify the update was successful by fetching the document directly (without lean to get Mongoose document)
  const verifyUpdatedDoc = await DesignationProductEligibility.findOne({ id: eligibilityId })
  if (verifyUpdatedDoc) {
    console.log('✅ Verification - Updated document from DB (Mongoose doc):', {
      id: verifyUpdatedDoc.id,
      hasItemEligibility: !!verifyUpdatedDoc.itemEligibility,
      itemEligibilityKeys: verifyUpdatedDoc.itemEligibility ? Object.keys(verifyUpdatedDoc.itemEligibility) : 'none',
      itemEligibilityFull: verifyUpdatedDoc.itemEligibility ? JSON.stringify(verifyUpdatedDoc.itemEligibility, null, 2) : 'none',
    })
    
    // Log specific values to verify they were saved
    if (verifyUpdatedDoc.itemEligibility) {
      for (const [key, value] of Object.entries(verifyUpdatedDoc.itemEligibility)) {
        console.log(`  📊 ${key}:`, JSON.stringify(value, null, 2))
      }
    }
  }
  
  // Also verify with lean() to see what's actually in the database
  const verifyUpdated = await DesignationProductEligibility.findOne({ id: eligibilityId }).lean()
  if (verifyUpdated) {
    console.log('✅ Verification - Updated document from DB (lean):', {
      id: verifyUpdated.id,
      hasItemEligibility: !!verifyUpdated.itemEligibility,
      itemEligibilityKeys: verifyUpdated.itemEligibility ? Object.keys(verifyUpdated.itemEligibility) : 'none',
      itemEligibilityFull: verifyUpdated.itemEligibility ? JSON.stringify(verifyUpdated.itemEligibility, null, 2) : 'none',
      allowedCategories: verifyUpdated.allowedProductCategories,
      gender: verifyUpdated.gender,
    })
    
    // Log specific values to verify they were saved
    if (verifyUpdated.itemEligibility) {
      for (const [key, value] of Object.entries(verifyUpdated.itemEligibility)) {
        console.log(`  📊 ${key} (lean):`, JSON.stringify(value, null, 2))
      }
    }
  }

  // Fetch the updated eligibility with proper decryption
  // Use getDesignationEligibilityById to ensure proper decryption
  const updatedEligibility = await getDesignationEligibilityById(eligibilityId)
  if (!updatedEligibility) {
    // Fallback: manually decrypt if fetch fails
    const plainObj = toPlainObject(updated || verifyUpdated)
    const { decrypt } = require('../utils/encryption')
    if (plainObj && plainObj.designation && typeof plainObj.designation === 'string' && plainObj.designation.includes(':')) {
      try {
        plainObj.designation = decrypt(plainObj.designation)
      } catch (error: any) {
        console.error('Failed to decrypt designation after update:', error.message)
      }
    }
    return plainObj
  }
  
  console.log('✅ Returning updated eligibility with decrypted designation')
  
  // If refreshEligibility is true, update all employees with this designation
  if (refreshEligibility && updatedEligibility) {
    try {
      // Get company ID - handle both string ID and ObjectId
      let companyIdForRefresh: string | undefined
      if (updatedEligibility.companyId) {
        // If it's already a string ID, use it
        if (typeof updatedEligibility.companyId === 'string') {
          companyIdForRefresh = updatedEligibility.companyId
        } else if (typeof updatedEligibility.companyId === 'object' && updatedEligibility.companyId.id) {
          companyIdForRefresh = updatedEligibility.companyId.id
        }
      }
      
      // If still not found, get from eligibility document
      if (!companyIdForRefresh && eligibility && eligibility.companyId) {
        if (typeof eligibility.companyId === 'object') {
          // CRITICAL FIX: eligibility.companyId could be populated object or string ID
          // If it's an object with id property, use that; otherwise try findById
          const companyIdValue = eligibility.companyId.id || eligibility.companyId._id || eligibility.companyId
          const companyIdStr = String(companyIdValue)
          const company = /^\d{6}$/.test(companyIdStr)
            ? await Company.findOne({ id: companyIdStr })
            : await Company.findById(companyIdValue)
          if (company) {
            companyIdForRefresh = company.id
          }
        } else {
          companyIdForRefresh = eligibility.companyId.toString()
        }
      }
      
      if (companyIdForRefresh) {
        // Check if company allows eligibility consumption reset
        const company = await Company.findOne({ id: companyIdForRefresh })
        const allowReset = company?.allowEligibilityConsumptionReset === true
        
        // Refresh employee eligibility
        await refreshEmployeeEligibilityForDesignation(
          companyIdForRefresh,
          updatedEligibility.designation || designation || '',
          updatedEligibility.gender || gender || 'unisex',
          updatedEligibility.itemEligibility || itemEligibility
        )
        console.log('✅ Successfully refreshed employee entitlements for designation')
        
        // If company allows reset, reset consumed eligibility for affected employees
        if (allowReset) {
          await resetConsumedEligibilityForDesignation(
            companyIdForRefresh,
            updatedEligibility.designation || designation || '',
            updatedEligibility.gender || gender || 'unisex',
            updatedEligibility.itemEligibility || itemEligibility
          )
          console.log('✅ Successfully reset consumed eligibility for designation')
        }
      } else {
        console.warn('⚠️ Could not determine company ID for refresh, skipping employee entitlement update')
      }
    } catch (error: any) {
      console.error('⚠️ Error refreshing employee entitlements:', error)
      // Don't fail the update if refresh fails, just log it
    }
  }
  
  return updatedEligibility
}

/**
 * Reset consumed eligibility for employees with a specific designation
 * This sets eligibilityResetDates for affected categories, effectively resetting consumed eligibility to 0
 */
async function resetConsumedEligibilityForDesignation(
  companyId: string,
  designation: string,
  gender: 'male' | 'female' | 'unisex',
  itemEligibility?: {
    // Legacy categories (for backward compatibility)
    shirt?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    trouser?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    pant?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    shoe?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    blazer?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    jacket?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    // Dynamic categories (any category name can be used)
    [categoryName: string]: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' } | undefined
  }
): Promise<void> {
  await connectDB()
  
  if (!itemEligibility) {
    console.warn('No itemEligibility provided, skipping consumed eligibility reset')
    return
  }
  
  // Find company
  let company = await Company.findOne({ id: companyId })
  if (!company && mongoose.Types.ObjectId.isValid(companyId)) {
    company = await Company.findOne({ id: String(companyId) })
  }
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }

  // Ensure system categories exist
  await ensureSystemCategories(companyId)
  
  // Get all categories for this company
  const categories = await getCategoriesByCompany(companyId)
  
  // DesignationProductEligibility.designation is now plaintext, but Employee.designation is encrypted
  // Strategy: Decrypt employee designations, then match with plaintext eligibility designations
  const { decrypt } = require('../utils/encryption')
  
  // Find all employees with this company
  // CRITICAL FIX: Employee.companyId is stored as STRING ID, not ObjectId
  const allEmployees = await Employee.find({ companyId: company.id })
    .lean()
  
  const matchingEmployees: any[] = []
  for (const emp of allEmployees) {
    let empDesignation = emp.designation
    if (empDesignation && typeof empDesignation === 'string' && empDesignation.includes(':')) {
      try {
        empDesignation = decrypt(empDesignation)
      } catch (error) {
        continue
      }
    }
    
    // Check if designation matches (case-insensitive)
    if (empDesignation && empDesignation.trim().toLowerCase() === designation.trim().toLowerCase()) {
      // Check gender filter
      if (gender === 'unisex' || !gender || emp.gender === gender) {
        matchingEmployees.push(emp)
      }
    }
  }
  
  if (matchingEmployees.length === 0) {
    console.log(`No employees found with designation "${designation}" and gender "${gender || 'all'}" for reset`)
    return
  }
  
  // Determine which categories need reset based on itemEligibility (dynamic)
  const resetCategories: string[] = []
  
  // Process all categories from itemEligibility (including dynamic ones)
  for (const [categoryKey, itemElig] of Object.entries(itemEligibility)) {
    if (itemElig) {
      const normalizedKey = normalizeCategoryName(categoryKey)
      
      // Try to find matching category in DB
      const category = categories.find(cat => 
        cat.name.toLowerCase() === categoryKey.toLowerCase() ||
        cat.name.toLowerCase() === normalizedKey ||
        normalizeCategoryName(cat.name) === normalizedKey
      )
      
      if (category) {
        resetCategories.push(category.name.toLowerCase())
      } else {
        // For legacy categories or categories not yet in DB, use normalized key
        resetCategories.push(normalizedKey)
      }
    }
  }
  
  // Also add legacy categories for backward compatibility
  if (itemEligibility.shirt && !resetCategories.includes('shirt')) resetCategories.push('shirt')
  if ((itemEligibility.trouser || itemEligibility.pant) && !resetCategories.includes('pant') && !resetCategories.includes('trouser')) {
    resetCategories.push('pant')
  }
  if (itemEligibility.shoe && !resetCategories.includes('shoe')) resetCategories.push('shoe')
  if ((itemEligibility.blazer || itemEligibility.jacket) && !resetCategories.includes('jacket') && !resetCategories.includes('blazer')) {
    resetCategories.push('jacket')
  }
  
  if (resetCategories.length === 0) {
    console.log('No categories to reset')
    return
  }
  
  // Current timestamp for reset dates
  const resetDate = new Date()
  
  // Update each matching employee's eligibilityResetDates - use string id field instead of _id
  for (const emp of matchingEmployees) {
    try {
      const employeeId = emp.id || String(emp._id || '')
      const employee = await Employee.findOne({ id: employeeId })
      if (!employee) continue
      
      // Initialize eligibilityResetDates if it doesn't exist
      if (!employee.eligibilityResetDates) {
        employee.eligibilityResetDates = {}
      }
      
      // Set reset date for each affected category
      for (const category of resetCategories) {
        (employee.eligibilityResetDates as any)[category] = resetDate
      }
      
      await employee.save()
      console.log(`✅ Reset consumed eligibility for employee ${employee.employeeId || employee.id} (categories: ${resetCategories.join(', ')})`)
    } catch (error: any) {
      console.error(`⚠️ Error resetting consumed eligibility for employee ${emp.employeeId || emp.id}:`, error.message)
      // Continue with other employees even if one fails
    }
  }
  
  console.log(`✅ Successfully reset consumed eligibility for ${matchingEmployees.length} employees with designation "${designation}"`)
}

/**
 * Refresh employee entitlements based on updated designation eligibility
 */
async function refreshEmployeeEligibilityForDesignation(
  companyId: string,
  designation: string,
  gender: 'male' | 'female' | 'unisex',
  itemEligibility?: {
    // Legacy categories (for backward compatibility)
    shirt?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    trouser?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    pant?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    shoe?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    blazer?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    jacket?: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' }
    // Dynamic categories (any category name can be used)
    [categoryName: string]: { quantity: number; renewalFrequency: number; renewalUnit: 'months' | 'years' } | undefined
  }
): Promise<void> {
  await connectDB()
  
  if (!itemEligibility) {
    console.warn('No itemEligibility provided, skipping employee entitlement refresh')
    return
  }
  
  // Find company
  let company = await Company.findOne({ id: companyId })
  if (!company && mongoose.Types.ObjectId.isValid(companyId)) {
    company = await Company.findOne({ id: String(companyId) })
  }
  if (!company) {
    throw new Error(`Company not found: ${companyId}`)
  }

  // Ensure system categories exist
  await ensureSystemCategories(companyId)
  
  // Get all categories for this company
  const categories = await getCategoriesByCompany(companyId)
  
  // DesignationProductEligibility.designation is now plaintext, but Employee.designation is encrypted
  // Strategy: Decrypt employee designations, then match with plaintext eligibility designations
  const { encrypt, decrypt } = require('../utils/encryption')
  
  // Find all employees with this company
  // CRITICAL FIX: Employee.companyId is stored as STRING ID, not ObjectId
  const allEmployees = await Employee.find({ companyId: company.id })
    .lean()
  
  // Filter employees by designation (case-insensitive, handling encryption)
  const matchingEmployees: any[] = []
  for (const emp of allEmployees) {
    let empDesignation = emp.designation
    if (empDesignation && typeof empDesignation === 'string' && empDesignation.includes(':')) {
      try {
        empDesignation = decrypt(empDesignation)
      } catch (error) {
        continue
      }
    }
    
    // Check if designation matches (case-insensitive)
    if (empDesignation && empDesignation.trim().toLowerCase() === designation.trim().toLowerCase()) {
      // Check gender filter
      if (gender === 'unisex' || !gender || emp.gender === gender) {
        matchingEmployees.push(emp)
      }
    }
  }
  
  if (matchingEmployees.length === 0) {
    console.log(`No employees found with designation "${designation}" and gender "${gender || 'all'}"`)
    return
  }
  
  // Calculate eligibility and cycle duration from itemEligibility
  // IMPORTANT: Start with a clean slate - reset all values to 0 first, then apply new values
  // This ensures that categories removed from designation eligibility are properly cleared
  // Note: Employee records still use legacy format (shirt, pant, shoe, jacket)
  const eligibility = {
    shirt: 0,
    pant: 0,
    shoe: 0,
    jacket: 0,
  }
  
  // Convert renewal frequency to months for cycle duration
  const convertToMonths = (itemElig: any): number => {
    if (!itemElig) return 6 // Default
    if (itemElig.renewalUnit === 'years') {
      return itemElig.renewalFrequency * 12
    }
    return itemElig.renewalFrequency || 6
  }
  
  // Initialize with default cycle durations
  const cycleDuration = {
    shirt: 6, // Default
    pant: 6,  // Default
    shoe: 6,  // Default
    jacket: 12, // Default
  }
  
  // Process all categories from itemEligibility (including dynamic ones)
  // Map dynamic categories to legacy format for employee records
  for (const [categoryKey, itemElig] of Object.entries(itemEligibility)) {
    if (itemElig) {
      const normalizedKey = normalizeCategoryName(categoryKey)
      
      // Map to legacy categories for employee records
      if (categoryKey === 'shirt' || normalizedKey === 'shirt') {
        eligibility.shirt = itemElig.quantity || 0
        cycleDuration.shirt = convertToMonths(itemElig)
      } else if (categoryKey === 'pant' || categoryKey === 'trouser' || normalizedKey === 'pant' || normalizedKey === 'trouser') {
        eligibility.pant = itemElig.quantity || 0
        cycleDuration.pant = convertToMonths(itemElig)
      } else if (categoryKey === 'shoe' || normalizedKey === 'shoe') {
        eligibility.shoe = itemElig.quantity || 0
        cycleDuration.shoe = convertToMonths(itemElig)
      } else if (categoryKey === 'jacket' || categoryKey === 'blazer' || normalizedKey === 'jacket' || normalizedKey === 'blazer') {
        eligibility.jacket = itemElig.quantity || 0
        cycleDuration.jacket = convertToMonths(itemElig)
      }
      // Note: Custom categories beyond legacy ones are stored in designation eligibility
      // but employee records only support legacy format for now
    }
  }
  
  console.log(`🔄 Refreshing entitlements for ${matchingEmployees.length} employees:`, {
    designation,
    gender: gender || 'all',
    eligibility,
    cycleDuration,
    note: 'All eligibility values reset to 0 first, then new values applied'
  })
  
  // Update all matching employees
  // IMPORTANT: Use a transaction-like approach - reset first, then apply new values
  let updatedCount = 0
  for (const emp of matchingEmployees) {
    try {
      // Use string id field instead of _id
      const employeeId = emp.id || String(emp._id || '')
      const employee = await Employee.findOne({ id: employeeId })
      if (employee) {
        // STEP 1: Reset all eligibility fields to 0 (clear existing values)
        employee.eligibility = {
          shirt: 0,
          pant: 0,
          shoe: 0,
          jacket: 0,
        }
        
        // STEP 2: Reset cycle durations to defaults
        employee.cycleDuration = {
          shirt: 6,
          pant: 6,
          shoe: 6,
          jacket: 12,
        }
        
        // STEP 3: Apply new eligibility values (from current designation configuration)
        employee.eligibility = eligibility
        employee.cycleDuration = cycleDuration
        
        await employee.save()
        updatedCount++
        
        console.log(`✅ Updated employee ${emp.id || emp.employeeId}:`, {
          eligibility: employee.eligibility,
          cycleDuration: employee.cycleDuration,
        })
      }
    } catch (error: any) {
      console.error(`Error updating employee ${emp.id}:`, error)
    }
  }
  
  console.log(`✅ Successfully updated entitlements for ${updatedCount} out of ${matchingEmployees.length} employees`)
}

export async function deleteDesignationEligibility(eligibilityId: string): Promise<void> {
  await connectDB()
  
  await DesignationProductEligibility.deleteOne({ id: eligibilityId })
}

/**
 * CORE LOGIC REWRITE — CATALOGUE VISIBILITY BASED ON SUBCATEGORY ELIGIBILITY
 * 
 * This function returns products visible to an employee based STRICTLY on:
 * 1. DesignationSubcategoryEligibility (subcategory-level, company-scoped)
 * 2. ProductSubcategoryMapping (product-to-subcategory mapping, company-scoped)
 * 
 * NO category-level fallbacks.
 * NO implicit "show all products" behavior.
 * 
 * Business Rule: NO eligibility = NO products (enforced strictly)
 */
export async function getProductsForDesignation(
  companyId: string, 
  designation: string, 
  gender?: 'male' | 'female'
): Promise<any[]> {
  await connectDB()
  
  console.log(`[getProductsForDesignation] ========================================`)
  console.log(`[getProductsForDesignation] Input: companyId=${companyId}, designation="${designation}", gender="${gender || 'all'}"`)
  
  // ============================================================
  // STEP 1: VALIDATE INPUTS (STRICT ENFORCEMENT)
  // ============================================================
  if (!designation || designation.trim().length === 0) {
    console.log(`[getProductsForDesignation] ⚠️ STRICT ENFORCEMENT - No designation provided, returning empty array`)
    return []
  }
  
  if (!companyId) {
    console.log(`[getProductsForDesignation] ⚠️ STRICT ENFORCEMENT - No companyId provided, returning empty array`)
    return []
  }
  
  // Get company using safe helper
  const company = await getCompanyByIdSafe(companyId)
  if (!company) {
    console.log(`[getProductsForDesignation] ⚠️ Company not found for companyId=${companyId}, returning empty array`)
    return []
  }
  
  console.log(`[getProductsForDesignation] ✅ Company found: ${company.name} (ID: ${company.id})`)
  
  // ============================================================
  // STEP 2: CHECK FOR SUBCATEGORY-BASED ELIGIBILITY (SINGLE SOURCE OF TRUTH)
  // ============================================================
  const normalizedDesignation = designation.trim()
  const genderFilter = gender === 'unisex' || !gender ? { $in: ['male', 'female', 'unisex'] } : gender
  
  console.log(`[getProductsForDesignation] Checking DesignationSubcategoryEligibility for:`)
  console.log(`  - companyId: ${company.id}`)
  console.log(`  - designationId: "${normalizedDesignation}"`)
  console.log(`  - gender: ${JSON.stringify(genderFilter)}`)
  console.log(`  - status: 'active'`)
  
  const subcategoryEligibilities = await DesignationSubcategoryEligibility.find({
    companyId: company.id,
    designationId: normalizedDesignation,
    gender: genderFilter,
    status: 'active'
  }).lean()
  
  console.log(`[getProductsForDesignation] Found ${subcategoryEligibilities.length} active eligibility rules`)
  
  // ============================================================
  // STEP 3: STRICT ENFORCEMENT — NO ELIGIBILITY = NO PRODUCTS
  // ============================================================
  if (subcategoryEligibilities.length === 0) {
    console.log(`[getProductsForDesignation] ⚠️ STRICT ENFORCEMENT - No eligibility rules found`)
    console.log(`[getProductsForDesignation] Returning EMPTY array (no products visible)`)
    console.log(`[getProductsForDesignation] ========================================`)
    return []
  }
  
  // ============================================================
  // STEP 4: GET ELIGIBLE SUBCATEGORY IDs
  // ============================================================
  // CRITICAL FIX: subCategoryId is stored as STRING ID (6-digit), not ObjectId
  const subcategoryIds = subcategoryEligibilities
    .map(e => e.subCategoryId)
    .filter(Boolean)
    .map((s: any) => String(s)) // Ensure all are strings
  
  if (subcategoryIds.length === 0) {
    console.log(`[getProductsForDesignation] ⚠️ No valid subcategory IDs found in eligibility rules, returning empty array`)
    return []
  }
  
  console.log(`[getProductsForDesignation] Eligible subcategory IDs: ${subcategoryIds.length}`)
  
  // ============================================================
  // STEP 5: VERIFY SUBCATEGORIES EXIST AND BELONG TO COMPANY
  // ============================================================
  // CRITICAL FIX: Subcategory uses STRING ID field (id), not _id ObjectId
  // subcategoryIds contains strings from e.subCategoryId, so query by id field
  const subcategoryIdStrings = subcategoryIds
    .map((s: any) => {
      // Convert ObjectId to string if needed, otherwise use as-is
      if (mongoose.Types.ObjectId.isValid(s)) {
        // If it's an ObjectId, we can't use it - subcategories use string IDs
        return null
      }
      return String(s)
    })
    .filter((s: any): s is string => s !== null && /^\d{6}$/.test(s))
  
  const subcategories = await Subcategory.find({
    id: { $in: subcategoryIdStrings },
    companyId: company.id,
    status: 'active'
  }).lean()
  
  if (subcategories.length === 0) {
    console.log(`[getProductsForDesignation] ⚠️ No active subcategories found for company, returning empty array`)
    return []
  }
  
  // Filter to only valid subcategory IDs (those that exist and are active) - use string id field
  const validSubcategoryIds = subcategories.map((s: any) => s.id).filter(Boolean)
  console.log(`[getProductsForDesignation] Valid subcategories: ${validSubcategoryIds.length}`)
  
  // ============================================================
  // STEP 6: GET PRODUCT-SUBCATEGORY MAPPINGS (COMPANY-SCOPED)
  // ============================================================
  // CRITICAL FIX: ProductSubcategoryMapping.companyId and subCategoryId are STRING IDs, not ObjectIds
  const productMappings = await ProductSubcategoryMapping.find({
    subCategoryId: { $in: validSubcategoryIds },
    companyId: company.id
  })
    .lean()
  
  console.log(`[getProductsForDesignation] Found ${productMappings.length} product-subcategory mappings`)
  
  if (productMappings.length === 0) {
    console.log(`[getProductsForDesignation] ⚠️ No products mapped to eligible subcategories, returning empty array`)
    return []
  }
  
  // ============================================================
  // STEP 7: EXTRACT PRODUCT IDs FROM MAPPINGS
  // ============================================================
  // CRITICAL FIX: ProductSubcategoryMapping.productId is a STRING ID, not ObjectId
  const eligibleProductIds = new Set<string>()
  const productMappingDetails: Array<{ productId: string; subcategoryId: string; subcategoryName: string }> = []
  
  // Get subcategory names for mapping details
  const subcategoryMap = new Map(subcategories.map((s: any) => [s.id, s.name]))
  
  productMappings.forEach((mapping: any) => {
    // productId is a string ID (6-digit), not ObjectId
    const productId = String(mapping.productId || '')
    const subcategoryId = String(mapping.subCategoryId || '')
    const subcategoryName = subcategoryMap.get(subcategoryId) || 'Unknown'
    
    if (productId && /^\d{6}$/.test(productId)) {
      eligibleProductIds.add(productId)
      productMappingDetails.push({ productId, subcategoryId, subcategoryName })
    }
  })
  
  console.log(`[getProductsForDesignation] Unique eligible product IDs: ${eligibleProductIds.size}`)
  
  // ============================================================
  // STEP 8: FETCH PRODUCTS BY ID (EFFICIENT QUERY)
  // ============================================================
  // CRITICAL FIX: Uniform uses STRING ID field (id), not _id ObjectId
  const productIdStrings = Array.from(eligibleProductIds).filter(id => /^\d{6}$/.test(id))
  
  if (productIdStrings.length === 0) {
    console.log(`[getProductsForDesignation] ⚠️ No valid product IDs, returning empty array`)
    return []
  }
  
  // Fetch products using string id field
  const products = await Uniform.find({
    id: { $in: productIdStrings }
  })
    .populate('vendorId', 'id name')
    .lean()
  
  console.log(`[getProductsForDesignation] Fetched ${products.length} products from database`)
  
  // ============================================================
  // STEP 9: APPLY GENDER FILTER (IF SPECIFIED)
  // ============================================================
  let filteredProducts = products
  
  if (gender) {
    filteredProducts = products.filter((product: any) => {
      const productGender = product.gender || 'unisex'
      return productGender === gender || productGender === 'unisex'
    })
    console.log(`[getProductsForDesignation] After gender filter (${gender}): ${filteredProducts.length} products`)
  }
  
  // ============================================================
  // STEP 10: ENHANCE PRODUCTS WITH MAPPING INFORMATION
  // ============================================================
  // Create a map of productId -> subcategory info for reference
  const productSubcategoryMap = new Map<string, string[]>()
  productMappingDetails.forEach(({ productId, subcategoryName }) => {
    if (!productSubcategoryMap.has(productId)) {
      productSubcategoryMap.set(productId, [])
    }
    productSubcategoryMap.get(productId)!.push(subcategoryName)
  })
  
  // Add subcategory information to products (optional, for debugging/reference)
  const enhancedProducts = filteredProducts.map((product: any) => {
    // CRITICAL FIX: Use string id field, not _id ObjectId
    const productId = product.id || product._id?.toString()
    const subcategories = productSubcategoryMap.get(productId) || []
    return {
      ...product,
      _eligibleSubcategories: subcategories // For debugging/reference only
    }
  })
  
  console.log(`[getProductsForDesignation] ✅ Returning ${enhancedProducts.length} products`)
  console.log(`[getProductsForDesignation] Products:`, enhancedProducts.map((p: any) => ({
    id: p.id,
    name: p.name,
    subcategories: p._eligibleSubcategories
  })))
  console.log(`[getProductsForDesignation] ========================================`)
  
  return enhancedProducts
}

// ========== PRODUCT FEEDBACK FUNCTIONS ==========

/**
 * Create product feedback
 * @param feedbackData Feedback data
 * @returns Created feedback
 */
export async function createProductFeedback(feedbackData: {
  orderId: string
  productId: string
  employeeId: string
  companyId: string
  vendorId?: string
  rating: number
  comment?: string
}): Promise<any> {
  await connectDB()
  
  // Get employee
  const employee = await Employee.findOne({
    $or: [
      { employeeId: feedbackData.employeeId },
      { id: feedbackData.employeeId }
    ]
  }).lean()
  
  if (!employee) {
    throw new Error(`Employee not found: ${feedbackData.employeeId}`)
  }
  
  // Get company
  const company = await Company.findOne({
    id: feedbackData.companyId
  }).lean()
  
  if (!company) {
    throw new Error(`Company not found: ${feedbackData.companyId}`)
  }
  
  // Get order to verify it belongs to employee and is delivered
  // Handle both parent order IDs and split order IDs
  let order = await Order.findOne({ id: feedbackData.orderId }).lean()
  let isParentOrder = false
  
  // If found order has a parentOrderId, it's a child order (split order)
  // If found order doesn't have parentOrderId but has split orders, it's a parent
  if (order && !order.parentOrderId) {
    // Check if this is a parent order with split children
    const splitOrders = await Order.find({ parentOrderId: feedbackData.orderId }).lean()
    if (splitOrders.length > 0) {
      // This is a parent order, find the specific split order that contains the product
      isParentOrder = true
      for (const splitOrder of splitOrders) {
        const hasProduct = splitOrder.items?.some((item: any) => {
          const itemProductId = item.productId || (item.uniformId?.toString()) || (item.uniformId?.id)
          return itemProductId === feedbackData.productId
        })
        if (hasProduct) {
          order = splitOrder
          console.log(`[createProductFeedback] Found split child order for product:`, {
            parentOrderId: feedbackData.orderId,
            childOrderId: splitOrder.id,
            childOrderStatus: splitOrder.status,
            productId: feedbackData.productId
          })
          break
        }
      }
    }
  }
  
  // If not found, check if it's a parent order ID and find the specific split order
  if (!order && feedbackData.orderId.startsWith('ORD-')) {
    // Check if this looks like a split order ID (has format: ORD-timestamp-vendorId)
    // If it contains a dash after the timestamp, it might be a split order
    const parts = feedbackData.orderId.split('-')
    if (parts.length >= 3) {
      // This is likely a split order ID, try exact match again with trimmed ID
      const trimmedId = feedbackData.orderId.trim()
      order = await Order.findOne({ id: trimmedId }).lean()
    }
    
    // If still not found, try to find split orders with this as parentOrderId
    if (!order) {
      const splitOrders = await Order.find({ parentOrderId: feedbackData.orderId }).lean()
      
      if (splitOrders.length > 0) {
        // Find the specific split order that contains the product
        for (const splitOrder of splitOrders) {
          const hasProduct = splitOrder.items?.some((item: any) => {
            const itemProductId = item.productId || (item.uniformId?.toString()) || (item.uniformId?.id)
            return itemProductId === feedbackData.productId
          })
          if (hasProduct) {
            order = splitOrder
            console.log(`[createProductFeedback] Found split child order (fallback):`, {
              parentOrderId: feedbackData.orderId,
              childOrderId: splitOrder.id,
              childOrderStatus: splitOrder.status,
              productId: feedbackData.productId
            })
            break
          }
        }
      }
    }
  }
  
  if (!order) {
    console.error(`[createProductFeedback] Order not found:`, {
      orderId: feedbackData.orderId,
      productId: feedbackData.productId,
      employeeId: feedbackData.employeeId,
      employeeIdStr: employee._id?.toString()
    })
    throw new Error(`Order not found: ${feedbackData.orderId}. Please ensure the order is delivered and belongs to you.`)
  }
  
  console.log(`[createProductFeedback] Order found:`, {
    orderId: order.id,
    status: order.status,
    statusType: typeof order.status,
    parentOrderId: order.parentOrderId,
    isSplitOrder: !!order.parentOrderId,
    itemCount: order.items?.length
  })
  
  // Verify order belongs to employee using string ID comparison
  const employeeIdStr = employee.id || employee.employeeId || ''
  const orderEmployeeIdStr = order.employeeId ? String(order.employeeId) : ''
  
  const employeeMatches = 
    employeeIdStr === orderEmployeeIdStr ||
    (order.employeeIdNum && (order.employeeIdNum === employee.employeeId || order.employeeIdNum === employee.id))
  
  if (!employeeMatches) {
    console.error(`[createProductFeedback] Order employee mismatch:`, {
      orderId: order.id,
      orderEmployeeId: orderEmployeeIdStr,
      orderEmployeeIdNum: order.employeeIdNum,
      employeeId: employeeIdStr,
      employeeIdNum: employee.employeeId || employee.id
    })
    throw new Error('Order does not belong to employee')
  }
  
  // Verify order is delivered
  // Normalize status: trim whitespace and handle case variations
  const normalizedStatus = order.status?.toString().trim()
  const isDelivered = normalizedStatus === 'Delivered' || normalizedStatus?.toLowerCase() === 'delivered'
  
  console.log(`[createProductFeedback] Order status check:`, {
    orderId: order.id,
    rawStatus: order.status,
    normalizedStatus: normalizedStatus,
    isDelivered: isDelivered,
    statusType: typeof order.status
  })
  
  if (!isDelivered) {
    console.error(`[createProductFeedback] Order status validation failed:`, {
      orderId: order.id,
      status: order.status,
      normalizedStatus: normalizedStatus,
      expected: 'Delivered',
      allOrderFields: Object.keys(order)
    })
    throw new Error(`Feedback can only be submitted for delivered orders. Current order status: "${order.status || 'Unknown'}"`)
  }
  
  // Verify product is in order
  const orderItem = order.items?.find((item: any) => {
    const itemProductId = item.productId || (item.uniformId?.toString()) || (item.uniformId?.id) || (typeof item.uniformId === 'object' && item.uniformId?.id)
    return itemProductId === feedbackData.productId
  })
  
  if (!orderItem) {
    console.error(`[createProductFeedback] Product not found in order:`, {
      orderId: order.id,
      productId: feedbackData.productId,
      orderItems: order.items?.map((item: any) => ({
        productId: item.productId,
        uniformId: item.uniformId?.toString(),
        uniformName: item.uniformName
      }))
    })
    throw new Error(`Product not found in order. Please ensure you're submitting feedback for a product in this order.`)
  }
  
  // Get uniform/product
  const uniform = await Uniform.findOne({
    id: feedbackData.productId
  }).lean()
  
  // Use the actual order ID (might be a split order child ID)
  const actualOrderId = order.id
  
  // Check if feedback already exists for this order+product+employee combination
  // This ensures one feedback per product per order per employee
  const existingFeedback = await ProductFeedback.findOne({
    orderId: actualOrderId,
    productId: feedbackData.productId,
    employeeId: employee._id
  }).lean()
  
  if (existingFeedback) {
    throw new Error('Feedback already submitted for this product')
  }
  
  // Get vendorId - try from order first, then from ProductVendor relationship
  let vendorId: mongoose.Types.ObjectId | undefined = undefined
  
  if (order.vendorId) {
    // VendorId exists in order - use as string
    vendorId = String(order.vendorId)
    console.log(`[createProductFeedback] Using vendorId from order: ${vendorId}`)
  } else if (uniform?.id) {
    // Try to get vendorId from ProductVendor relationship using string ID
    const db = mongoose.connection.db
    if (db) {
      const productVendorLink = await db.collection('productvendors').findOne({ 
        productId: uniform.id 
      })
      
      if (productVendorLink && productVendorLink.vendorId) {
        vendorId = String(productVendorLink.vendorId)
        console.log(`[createProductFeedback] Using vendorId from ProductVendor relationship: ${vendorId}`)
      } else {
        console.warn(`[createProductFeedback] No vendorId found in order or ProductVendor relationship for product: ${feedbackData.productId}`)
      }
    }
  }
  
  // Create feedback using string IDs
  const feedback = new ProductFeedback({
    orderId: actualOrderId,
    productId: feedbackData.productId,
    uniformId: uniform?.id,
    employeeId: employee.id || employee.employeeId,
    employeeIdNum: employee.employeeId || employee.id,
    companyId: company.id,
    companyIdNum: typeof company.id === 'string' ? parseInt(company.id) : company.id,
    vendorId: vendorId,
    rating: feedbackData.rating,
    comment: feedbackData.comment || undefined,
  })
  
  await feedback.save()
  return toPlainObject(feedback)
}

/**
 * Get feedback with role-based access control
 * @param userEmail User email
 * @param filters Optional filters (orderId, productId, employeeId, companyId, vendorId)
 * @returns Array of feedback
 */
export async function getProductFeedback(
  userEmail: string,
  filters?: {
    orderId?: string
    productId?: string
    employeeId?: string
    companyId?: string
    vendorId?: string
  }
): Promise<any[]> {
  try {
    await connectDB()
  } catch (error: any) {
    console.error('[getProductFeedback] Database connection error:', error.message)
    throw new Error(`Database connection failed: ${error.message}`)
  }
  
  // Find user by email
  const { encrypt, decrypt } = require('../utils/encryption')
  const trimmedEmail = userEmail.trim()
  let encryptedEmail: string
  
  try {
    encryptedEmail = encrypt(trimmedEmail)
  } catch (error) {
    encryptedEmail = ''
  }
  
  // FIRST: Check if user is a Company Admin (most privileged role)
  // This must be checked BEFORE employee lookup to handle edge cases
  console.log(`[getProductFeedback] Checking Company Admin status first for: ${trimmedEmail}`)
  const db = mongoose.connection.db
  let companyId: string | null = null
  let isCompanyAdminUser = false
  let employee: any = null
  
  // Get all companies and check if user is admin of any
  const allCompanies = await Company.find({}).lean()
  for (const company of allCompanies) {
    const adminCheck = await isCompanyAdmin(trimmedEmail, company.id)
    if (adminCheck) {
      companyId = company.id
      isCompanyAdminUser = true
      console.log(`[getProductFeedback] ✅ Found Company Admin - email: ${trimmedEmail}, companyId: ${companyId}, companyName: ${company.name}`)
      
      // Get employee record from CompanyAdmin
      const adminRecords = await db.collection('companyadmins').find({ 
        companyId: company._id 
      }).toArray()
      
      // Find the admin record that matches this email
      for (const adminRecord of adminRecords) {
        if (adminRecord.employeeId) {
          const emp = await Employee.findById(adminRecord.employeeId).lean()
          if (emp) {
            // Verify this employee's email matches
            let empEmailMatches = false
            if (emp.email === encryptedEmail) {
              empEmailMatches = true
            } else if (emp.email) {
              try {
                const decryptedEmpEmail = decrypt(emp.email)
                if (decryptedEmpEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
                  empEmailMatches = true
                }
              } catch (error) {
                // Continue checking
              }
            }
            
            if (empEmailMatches) {
              employee = emp
              console.log(`[getProductFeedback] Found employee record for Company Admin - employeeId: ${employee._id}`)
              break
            }
          }
        }
      }
      break
    }
  }
  
  // If not Company Admin, check if user is a vendor
  if (!isCompanyAdminUser) {
    // Try case-insensitive email search for vendor
    let vendor = await Vendor.findOne({ 
      email: { $regex: new RegExp(`^${trimmedEmail.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }
    }).lean()
    
    // Fallback: if not found by regex, try manual comparison
    if (!vendor) {
      const allVendors = await Vendor.find({}).lean()
      for (const v of allVendors) {
        if (v.email && v.email.trim().toLowerCase() === trimmedEmail.toLowerCase()) {
          vendor = v
          break
        }
      }
    }
    
    if (vendor) {
      // Vendor can see feedback for their products
      // CRITICAL FIX: ProductFeedback stores ALL IDs as STRINGS (6-digit numeric), NOT ObjectIds
      const query: any = {}
      if (filters?.vendorId) {
        query.vendorId = filters.vendorId
      } else {
        query.vendorId = vendor.id
      }
      if (filters?.productId) {
        query.productId = filters.productId
      }
      
      // No .populate() since all IDs are strings, not ObjectId refs
      const feedback = await ProductFeedback.find(query)
        .sort({ createdAt: -1 })
        .lean()
      
      return feedback.map((f: any) => toPlainObject(f))
    }
  }
  
  // If not Company Admin and not Vendor, try to find as employee
  if (!employee && !isCompanyAdminUser) {
    // Try finding with encrypted email first
    employee = await Employee.findOne({ email: encryptedEmail }).lean()
    
    // If not found, try decryption matching
    if (!employee && encryptedEmail) {
      const allEmployees = await Employee.find({}).lean()
      for (const emp of allEmployees) {
        if (emp.email && typeof emp.email === 'string') {
          try {
            const decryptedEmail = decrypt(emp.email)
            if (decryptedEmail.toLowerCase() === trimmedEmail.toLowerCase()) {
              employee = emp
              break
            }
          } catch (error) {
            continue
          }
        }
      }
    }
    
    if (!employee) {
      throw new Error('User not found')
    }
    
    // Employee found - get companyId and check if Company Admin
    const employeeIdStr = (employee._id || employee.id).toString()
    companyId = employee.companyId ? (typeof employee.companyId === 'object' ? employee.companyId.id : employee.companyId) : null
    
    // If companyId is an ObjectId string, try to find the company by _id and get its id
    if (companyId && typeof companyId === 'string' && mongoose.Types.ObjectId.isValid(companyId) && companyId.length === 24) {
      const companyForIdConversion = await Company.findById(companyId).select('id').lean()
      if (companyForIdConversion) {
        companyId = companyForIdConversion.id
        console.log(`[getProductFeedback] Converted ObjectId companyId to string ID: ${companyId}`)
      }
    }
    
    // Check if Company Admin
    if (companyId) {
      isCompanyAdminUser = await isCompanyAdmin(trimmedEmail, companyId)
      console.log(`[getProductFeedback] Company Admin check - email: ${trimmedEmail}, companyId: ${companyId}, isAdmin: ${isCompanyAdminUser}`)
    } else {
      console.warn(`[getProductFeedback] No companyId found for employee: ${employeeIdStr}`)
    }
  }
  
  // Check if Location Admin
  const location = await getLocationByAdminEmail(trimmedEmail)
  const isLocationAdminUser = !!location
  let locationEmployees: any[] = [] // Store for debugging later
  
  // Build query based on role
  const query: any = {}
  
  if (isCompanyAdminUser && companyId) {
    // Company Admin can see all feedback for their company
    // CRITICAL FIX: ProductFeedback stores companyId as STRING (6-digit numeric), NOT ObjectId
    console.log(`[getProductFeedback] Processing Company Admin request - companyId: ${companyId}, email: ${trimmedEmail}`)
    
    // Verify company exists
    const companyForAdmin = await Company.findOne({ id: companyId }).lean()
    if (!companyForAdmin) {
      console.error(`[getProductFeedback] Company not found for Company Admin - companyId: ${companyId}`)
      return []
    }
    
    // Use the company's string ID for the query (NOT ObjectId)
    query.companyId = companyId
    console.log(`[getProductFeedback] Company Admin query - using companyId string: ${companyId}, company.name: ${companyForAdmin.name}`)
    
    if (filters?.orderId) {
      query.orderId = filters.orderId
    }
    if (filters?.productId) {
      query.productId = filters.productId
    }
    if (filters?.employeeId) {
      // CRITICAL FIX: Use string employeeId, not ObjectId
      query.employeeId = filters.employeeId
    }
  } else if (isLocationAdminUser && location) {
    // Location Admin can see feedback only if setting is enabled
    console.log(`[getProductFeedback] 🔍 Location Admin detected - location:`, {
      locationId: location.id,
      locationName: location.name,
      locationCompanyId: location.companyId,
      locationCompanyIdType: typeof location.companyId,
      locationCompanyIdId: location.companyId?.id,
      locationCompanyId_id: location.companyId?._id?.toString()
    })
    
    // Get company ID from location - handle both populated and non-populated cases
    let locationCompanyIdStr: string | null = null
    if (location.companyId) {
      if (typeof location.companyId === 'object' && location.companyId !== null) {
        // Populated company object
        locationCompanyIdStr = location.companyId.id || null
      } else if (typeof location.companyId === 'string') {
        // Check if it's a company ID string (6-digit) or ObjectId string (24 hex)
        if (/^\d{6}$/.test(location.companyId)) {
          locationCompanyIdStr = location.companyId
        } else if (mongoose.Types.ObjectId.isValid(location.companyId)) {
          // It's an ObjectId - need to find company
          const companyByObjectId = await Company.findById(location.companyId).select('id').lean()
          locationCompanyIdStr = companyByObjectId?.id || null
        }
      }
    }
    
    if (!locationCompanyIdStr) {
      console.error(`[getProductFeedback] ❌ Could not determine company ID from location`)
      return []
    }
    
    console.log(`[getProductFeedback] 🔍 Location company ID: ${locationCompanyIdStr}`)
    
    // Get company and check setting
    const companyForLocationAdmin = await Company.findOne({ id: locationCompanyIdStr }).lean()
    if (!companyForLocationAdmin) {
      console.error(`[getProductFeedback] ❌ Company not found for Location Admin - companyId: ${locationCompanyIdStr}`)
      return []
    }
    
    console.log(`[getProductFeedback] 🔍 Company found: ${companyForLocationAdmin.name} (${companyForLocationAdmin.id})`)
    console.log(`[getProductFeedback] 🔍 allowLocationAdminViewFeedback setting:`, companyForLocationAdmin.allowLocationAdminViewFeedback)
    
    if (!companyForLocationAdmin.allowLocationAdminViewFeedback) {
      // Setting is OFF - return empty array
      console.log(`[getProductFeedback] ❌ Location Admin access denied - setting is OFF`)
      return []
    }
    
    // Setting is ON - Location Admin can see feedback ONLY for employees in their location
    console.log(`[getProductFeedback] ✅ Location Admin access granted - filtering by location: ${location.id} (${location.name})`)
    
    // Get location ObjectId - location from getLocationByAdminEmail should have _id
    let locationObjectId = null
    // ARCHITECTURAL DECISION: Use ONLY string ID, NO ObjectId fallbacks
    // Employees have locationId stored as string ID (location.id), not ObjectId
    if (!location.id) {
      console.error(`[getProductFeedback] ❌ Location has no valid string ID - cannot filter employees. Location:`, location)
      return []
    }
    
    const locationIdString = location.id
    console.log(`[getProductFeedback] 🔍 Location string ID: ${locationIdString}`)
    
    // Find all employees in this location using string ID
    locationEmployees = await Employee.find({ locationId: locationIdString })
      .select('_id employeeId id firstName lastName')
      .lean()
    
    console.log(`[getProductFeedback] 🔍 Found ${locationEmployees.length} employees in location ${locationIdString} (${location.name})`)
    
    if (locationEmployees.length === 0) {
      // No employees in this location - return empty array
      console.log(`[getProductFeedback] ⚠️ No employees found in location - returning empty array`)
      return []
    }
    
    // Log employee details for debugging
    const { decrypt } = require('../utils/encryption')
    console.log(`[getProductFeedback] 🔍 Employees in location:`)
    locationEmployees.slice(0, 5).forEach((emp: any) => {
      let firstName = emp.firstName
      let lastName = emp.lastName
      try {
        firstName = decrypt(firstName)
        lastName = decrypt(lastName)
      } catch (e) {
        // Not encrypted
      }
      console.log(`  - ${firstName} ${lastName} (${emp.employeeId || emp.id}) - locationId: ${emp.locationId?.toString() || 'none'}`)
    })
    
    // CRITICAL FIX: ProductFeedback stores employeeId as STRING (6-digit numeric), NOT ObjectId
    // Get employee string IDs (employeeId or id field), NOT ObjectIds
    const employeeStringIds = locationEmployees.map((e: any) => e.employeeId || e.id).filter((id: any) => id)
    
    if (employeeStringIds.length === 0) {
      console.error(`[getProductFeedback] ❌ No employees with string IDs found in location`)
      return []
    }
    
    // Filter feedback to only include feedback from employees in this location
    // IMPORTANT: Use $in for employeeId to match multiple employees (STRING IDs)
    query.employeeId = { $in: employeeStringIds }
    // Also filter by company to ensure we only get feedback for this company
    // CRITICAL FIX: companyId is stored as STRING in ProductFeedback, not ObjectId
    query.companyId = companyForLocationAdmin.id
    
    // Remove any $or that might have been set earlier (for Company Admin)
    if (query.$or) {
      delete query.$or
    }
    
    if (filters?.orderId) {
      query.orderId = filters.orderId
    }
    if (filters?.productId) {
      query.productId = filters.productId
    }
    
    console.log(`[getProductFeedback] ✅ Location Admin query built:`, {
      location: location.id,
      locationName: location.name,
      employeeCount: employeeStringIds.length,
      companyId: companyForLocationAdmin.id,
      companyName: companyForLocationAdmin.name,
      employeeStringIds: employeeStringIds.slice(0, 3),
      queryStructure: {
        employeeId: '$in with ' + employeeStringIds.length + ' employees',
        companyId: companyForLocationAdmin.id
      }
    })
  } else {
    // Regular employee can only see their own feedback
    // CRITICAL FIX: ProductFeedback stores employeeId as STRING (6-digit numeric), NOT ObjectId
    // Use the employee's string ID (employeeId or id field), not the MongoDB _id
    const employeeIdString = employee.employeeId || employee.id
    if (!employeeIdString) {
      console.error(`[getProductFeedback] ❌ Employee has no employeeId or id field - cannot query feedback`)
      return []
    }
    query.employeeId = employeeIdString
    console.log(`[getProductFeedback] Regular employee query - using employeeId string: ${employeeIdString}`)
    if (filters?.orderId) {
      query.orderId = filters.orderId
    }
    if (filters?.productId) {
      query.productId = filters.productId
    }
  }
  
  // Convert ObjectId in query to ensure proper matching
  // Ensure companyId is a string for consistent querying
  if (query.companyId) {
    query.companyId = String(query.companyId)
  }
  
  // Ensure query is not empty
  const hasQueryParams = Object.keys(query).length > 0
  if (!hasQueryParams) {
    console.warn(`[getProductFeedback] Empty query - returning empty array`)
    return []
  }
  
  try {
    console.log(`[getProductFeedback] Query:`, {
      companyId: query.companyId?.toString(),
      employeeId: query.employeeId?.toString(),
      orderId: query.orderId,
      productId: query.productId,
      vendorId: query.vendorId?.toString()
    })
  } catch (logError) {
    console.log(`[getProductFeedback] Query built (logging failed)`)
  }
  
  let feedback: any[] = []
  try {
    console.log(`[getProductFeedback] Executing query with:`, {
      companyId: query.companyId?.toString(),
      employeeId: query.employeeId?.toString(),
      orderId: query.orderId,
      productId: query.productId,
      vendorId: query.vendorId?.toString(),
      isCompanyAdmin: isCompanyAdminUser,
      isLocationAdmin: isLocationAdminUser
    })
    
    // Fetch feedback with population
    // Note: populate('vendorId') will return null if vendorId is null in DB, not an empty object
    // Log the full query including $or
    const queryForLog = {
      ...query,
      companyId: query.companyId?.toString(),
      employeeId: query.employeeId?.toString(),
      $or: query.$or ? query.$or.map((or: any) => ({
        companyId: or.companyId?.toString(),
        companyIdNum: or.companyIdNum
      })) : undefined
    }
    console.log(`[getProductFeedback] 🔍 Executing query:`, JSON.stringify(queryForLog, null, 2))
    
    // For Location Admin: Log detailed query structure
    if (isLocationAdminUser) {
      console.log(`[getProductFeedback] 🔍 Location Admin query details:`, {
        hasEmployeeIdFilter: !!query.employeeId,
        employeeIdType: typeof query.employeeId,
        employeeIdIsIn: query.employeeId && typeof query.employeeId === 'object' && '$in' in query.employeeId,
        employeeIdInCount: query.employeeId && typeof query.employeeId === 'object' && '$in' in query.employeeId 
          ? (query.employeeId.$in?.length || 0) 
          : 0,
        hasOr: !!query.$or,
        orConditions: query.$or ? query.$or.map((or: any) => ({
          companyId: or.companyId?.toString(),
          companyIdNum: or.companyIdNum
        })) : null,
        fullQueryKeys: Object.keys(query)
      })
    }
    
    // BEFORE query: Check if the specific feedback exists and what its companyId is
    const specificFeedbackCheck = await ProductFeedback.findOne({ 
      orderId: 'ORD-1765652961649-4ZMRWCRMB-100001' 
    })
      .populate('companyId', 'id name')
      .lean()
    
    if (specificFeedbackCheck) {
      console.log(`[getProductFeedback] 🔍 SPECIFIC FEEDBACK CHECK - Found feedback ORD-1765652961649-4ZMRWCRMB-100001:`, {
        _id: specificFeedbackCheck._id?.toString(),
        orderId: specificFeedbackCheck.orderId,
        companyId: specificFeedbackCheck.companyId?._id?.toString() || specificFeedbackCheck.companyId?.toString(),
        companyIdNum: specificFeedbackCheck.companyIdNum,
        companyName: specificFeedbackCheck.companyId?.name,
        companyIdFromQuery: query.companyId?.toString(),
        queryHasOr: !!query.$or,
        orConditions: query.$or ? query.$or.map((or: any) => ({
          companyId: or.companyId?.toString(),
          companyIdNum: or.companyIdNum
        })) : null
      })
      
      // Test if this feedback would match the query
      const testQuery = { ...query }
      const wouldMatch = await ProductFeedback.findOne({
        _id: specificFeedbackCheck._id,
        ...testQuery
      }).lean()
      
      console.log(`[getProductFeedback] 🔍 Would this feedback match the query?`, {
        wouldMatch: !!wouldMatch,
        testQuery: JSON.stringify({
          ...testQuery,
          companyId: testQuery.companyId?.toString(),
          employeeId: testQuery.employeeId?.toString(),
          $or: testQuery.$or ? testQuery.$or.map((or: any) => ({
            companyId: or.companyId?.toString(),
            companyIdNum: or.companyIdNum
          })) : undefined
        }, null, 2)
      })
    } else {
      console.warn(`[getProductFeedback] 🔍 SPECIFIC FEEDBACK CHECK - Feedback ORD-1765652961649-4ZMRWCRMB-100001 NOT FOUND in database`)
    }
    
    // CRITICAL FIX: ProductFeedback stores ALL IDs as STRINGS (6-digit numeric), NOT ObjectIds
    // Therefore we cannot use .populate() - instead we fetch the raw feedback and manually enrich if needed
    feedback = await ProductFeedback.find(query)
      .sort({ createdAt: -1 })
      .lean()
    
    console.log(`[getProductFeedback] Initial query returned ${feedback.length} records`)
    
    // Location Admin specific debugging
    if (isLocationAdminUser && location) {
      console.log(`[getProductFeedback] 🔍 Location Admin query results:`, {
        locationId: location.id,
        locationName: location.name,
        feedbackCount: feedback.length,
        feedbackOrderIds: feedback.map((f: any) => f.orderId).slice(0, 5),
        feedbackEmployees: feedback.slice(0, 3).map((f: any) => ({
          orderId: f.orderId,
          employeeId: f.employeeId?.employeeId || f.employeeId?.id || f.employeeId,
          employeeName: f.employeeId?.firstName && f.employeeId?.lastName 
            ? `${f.employeeId.firstName} ${f.employeeId.lastName}` 
            : 'N/A'
        }))
      })
      
      // Verify all feedback belongs to location employees
      if (feedback.length > 0) {
        const feedbackEmployeeIds = feedback
          .map((f: any) => f.employeeId?._id?.toString() || f.employeeId?.toString())
          .filter((id: any) => id)
        
        const locationEmployeeIds = locationEmployees.map((e: any) => e._id.toString())
        const allInLocation = feedbackEmployeeIds.every((id: string) => locationEmployeeIds.includes(id))
        
        console.log(`[getProductFeedback] 🔍 Location Admin feedback validation:`, {
          feedbackEmployeeIds: feedbackEmployeeIds.slice(0, 3),
          locationEmployeeIds: locationEmployeeIds.slice(0, 3),
          allInLocation: allInLocation,
          feedbackCount: feedback.length,
          locationEmployeeCount: locationEmployees.length
        })
        
        if (!allInLocation && feedback.length > 0) {
          console.warn(`[getProductFeedback] ⚠️ WARNING: Some feedback employees are not in location!`)
        }
      }
    }
    
    // Check if the specific feedback is in the results
    const specificOrderId = 'ORD-1765652961649-4ZMRWCRMB-100001'
    const foundInResults = feedback.find((f: any) => f.orderId === specificOrderId)
    console.log(`[getProductFeedback] 🔍 Is ORD-1765652961649-4ZMRWCRMB-100001 in results?`, {
      found: !!foundInResults,
      totalResults: feedback.length,
      orderIds: feedback.map((f: any) => f.orderId)
    })
    
    // Debug: Check if the missing feedback would match the query
    if (isCompanyAdminUser && !foundInResults) {
      const missingFeedbackOrderId = 'ORD-1765652961649-4ZMRWCRMB-100001'
      const missingFeedbackCheck = await ProductFeedback.findOne({ 
        orderId: missingFeedbackOrderId 
      })
        .populate('companyId', 'id name')
        .lean()
      
      if (missingFeedbackCheck) {
        const queryCompanyId = query.companyId?.toString() || (query.$or && query.$or[0]?.companyId?.toString())
        const queryCompanyIdNum = query.$or && query.$or[1]?.companyIdNum
        
        console.log(`[getProductFeedback] 🔍 DEBUG: Missing feedback analysis for ${missingFeedbackOrderId}:`, {
          feedbackCompanyId: missingFeedbackCheck.companyId?._id?.toString() || missingFeedbackCheck.companyId?.toString(),
          feedbackCompanyIdNum: missingFeedbackCheck.companyIdNum,
          feedbackCompanyName: missingFeedbackCheck.companyId?.name,
          queryCompanyId: queryCompanyId,
          queryCompanyIdNum: queryCompanyIdNum,
          queryHasOr: !!query.$or,
          matchesById: missingFeedbackCheck.companyId?._id?.toString() === queryCompanyId || missingFeedbackCheck.companyId?.toString() === queryCompanyId,
          matchesByNum: missingFeedbackCheck.companyIdNum === queryCompanyIdNum,
          queryStructure: JSON.stringify({
            ...query,
            companyId: query.companyId?.toString(),
            $or: query.$or ? query.$or.map((or: any) => ({
              companyId: or.companyId?.toString(),
              companyIdNum: or.companyIdNum
            })) : undefined
          }, null, 2)
        })
        
        // Test direct query match with $or
        if (query.$or) {
          const directMatchTest = await ProductFeedback.findOne({
            orderId: missingFeedbackOrderId,
            $or: query.$or
          }).lean()
          console.log(`[getProductFeedback] 🔍 Direct $or query test:`, {
            matches: !!directMatchTest,
            orConditions: query.$or.map((or: any) => ({
              companyId: or.companyId?.toString(),
              companyIdNum: or.companyIdNum
            }))
          })
        }
        
        // Test if it matches by companyId ObjectId
        if (query.companyId) {
          const directMatchById = await ProductFeedback.findOne({
            orderId: missingFeedbackOrderId,
            companyId: query.companyId
          }).lean()
          console.log(`[getProductFeedback] 🔍 Direct companyId ObjectId test:`, {
            matches: !!directMatchById,
            queryCompanyId: query.companyId.toString()
          })
        }
        
        // Also check by companyIdNum
        if (missingFeedbackCheck.companyIdNum) {
          const companyForNumCheck = await Company.findOne({ id: companyId }).lean()
          if (companyForNumCheck) {
            const companyIdNumMatch = typeof companyForNumCheck.id === 'string' 
              ? parseInt(companyForNumCheck.id) === missingFeedbackCheck.companyIdNum
              : companyForNumCheck.id === missingFeedbackCheck.companyIdNum
            console.log(`[getProductFeedback] 🔍 DEBUG: companyIdNum check:`, {
              feedbackCompanyIdNum: missingFeedbackCheck.companyIdNum,
              companyIdNum: companyForNumCheck.id,
              matches: companyIdNumMatch
            })
          }
        }
      } else {
        console.warn(`[getProductFeedback] 🔍 DEBUG: Missing feedback ${missingFeedbackOrderId} not found in database`)
      }
    }
    if (feedback.length > 0) {
      const vendorStats = {
        hasVendorId: feedback.filter(f => f.vendorId && f.vendorId.name).length,
        nullVendorId: feedback.filter(f => f.vendorId === null || f.vendorId === undefined).length,
        emptyVendorId: feedback.filter(f => f.vendorId && !f.vendorId.name).length
      }
      console.log(`[getProductFeedback] VendorId population stats:`, vendorStats)
    }
    
    console.log(`[getProductFeedback] Found ${feedback.length} feedback records`)
    
    // Debug: Log sample feedback structure
    if (feedback.length > 0) {
      const sample = feedback[0]
      console.log(`[getProductFeedback] Sample feedback structure:`, {
        hasVendorId: !!sample.vendorId,
        vendorIdType: typeof sample.vendorId,
        vendorIdValue: sample.vendorId,
        hasUniformId: !!sample.uniformId,
        uniformIdType: typeof sample.uniformId,
        uniformIdValue: sample.uniformId,
        hasEmployeeId: !!sample.employeeId,
        employeeIdType: typeof sample.employeeId,
        employeeIdValue: sample.employeeId,
        employeeIdIsObject: typeof sample.employeeId === 'object' && sample.employeeId !== null,
        employeeFirstName: sample.employeeId?.firstName,
        employeeLastName: sample.employeeId?.lastName,
        employeeIdKeys: sample.employeeId && typeof sample.employeeId === 'object' ? Object.keys(sample.employeeId) : []
      })
      
      // Check all feedback records for employee data
      const employeeStats = {
        hasEmployeeId: feedback.filter(f => f.employeeId).length,
        hasFirstName: feedback.filter(f => f.employeeId?.firstName).length,
        hasLastName: feedback.filter(f => f.employeeId?.lastName).length,
        hasFullName: feedback.filter(f => f.employeeId?.firstName && f.employeeId?.lastName).length,
        nullEmployeeId: feedback.filter(f => !f.employeeId || f.employeeId === null).length
      }
      console.log(`[getProductFeedback] Employee data stats:`, employeeStats)
    }
    
    // Post-process: Fill in missing vendorIds from ProductVendor relationships
    // CRITICAL: This ensures Company Admin always sees vendor information
    // OPTIMIZED: Batch process to avoid blocking
    const db = mongoose.connection.db
    if (db && feedback.length > 0) {
      console.log(`[getProductFeedback] Post-processing ${feedback.length} feedback records for vendorId population`)
      
      // Batch process: Only process feedback missing vendorId, limit to prevent blocking
      const feedbackNeedingVendor = feedback.filter(fb => {
        const hasValidVendorId = fb.vendorId && 
          typeof fb.vendorId === 'object' && 
          fb.vendorId !== null &&
          !Array.isArray(fb.vendorId) &&
          fb.vendorId.name && 
          typeof fb.vendorId.name === 'string' &&
          fb.vendorId.name.trim() !== '' &&
          fb.vendorId.name !== 'null' &&
          fb.vendorId.name !== 'undefined'
        return !hasValidVendorId
      })
      
      console.log(`[getProductFeedback] ${feedbackNeedingVendor.length} feedback records need vendorId population`)
      
      // Process in parallel batches to avoid blocking
      // PRIORITY 1: Try to get vendorId from Order (most reliable)
      // PRIORITY 2: Fall back to ProductVendor relationship
      if (feedbackNeedingVendor.length > 0) {
        // STEP 1: Try to get vendorId from orders (batch lookup)
        console.log(`[getProductFeedback] 🔍 DEBUG: Sample feedback orderIds:`, 
          feedbackNeedingVendor.slice(0, 3).map(fb => ({
            feedbackId: fb._id?.toString(),
            orderId: fb.orderId,
            orderIdType: typeof fb.orderId,
            orderIdLength: fb.orderId?.length
          })))
        
        const orderIds = feedbackNeedingVendor
          .map(fb => fb.orderId)
          .filter((id): id is string => !!id && typeof id === 'string')
        
        if (orderIds.length > 0) {
          console.log(`[getProductFeedback] 🔍 DEBUG: Looking up vendorId from ${orderIds.length} orders`)
          console.log(`[getProductFeedback] 🔍 DEBUG: Order IDs to search:`, orderIds.slice(0, 3), orderIds.length > 3 ? `... (${orderIds.length - 3} more)` : '')
          
          // Try multiple query strategies
          let orders: any[] = []
          
          // Strategy 1: Direct id match
          orders = await Order.find({ id: { $in: orderIds } })
            .select('id vendorId')
            .lean()
          console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 1 (id: $in) found ${orders.length} orders`)
          
          // Strategy 2: If no matches, try exact string match (case sensitive)
          if (orders.length === 0) {
            console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 1 failed, trying individual queries...`)
            for (const orderId of orderIds.slice(0, 2)) { // Test first 2
              const testOrder = await Order.findOne({ id: orderId }).select('id vendorId').lean()
              if (testOrder) {
                console.log(`[getProductFeedback] 🔍 DEBUG: Found order with direct findOne:`, {
                  searchedId: orderId,
                  foundId: testOrder.id,
                  hasVendorId: !!testOrder.vendorId,
                  vendorIdType: typeof testOrder.vendorId,
                  vendorIdValue: testOrder.vendorId
                })
              } else {
                console.log(`[getProductFeedback] 🔍 DEBUG: Order NOT found with id:`, orderId)
                // Try to find any order with similar pattern
                const similarOrders = await Order.find({ id: { $regex: orderId.substring(0, 20) } })
                  .select('id vendorId')
                  .limit(3)
                  .lean()
                console.log(`[getProductFeedback] 🔍 DEBUG: Found ${similarOrders.length} orders with similar pattern:`, 
                  similarOrders.map((o: any) => ({ id: o.id, hasVendorId: !!o.vendorId })))
              }
            }
          }
          
          // Strategy 3: Try using the raw MongoDB collection
          if (orders.length === 0) {
            console.log(`[getProductFeedback] 🔍 DEBUG: Trying raw MongoDB collection query...`)
            const db = mongoose.connection.db
            if (db) {
              const rawOrders = await db.collection('orders').find({ id: { $in: orderIds } })
                .project({ id: 1, vendorId: 1 })
                .toArray()
              console.log(`[getProductFeedback] 🔍 DEBUG: Raw collection query found ${rawOrders.length} orders`)
              if (rawOrders.length > 0) {
                console.log(`[getProductFeedback] 🔍 DEBUG: Sample raw order:`, {
                  id: rawOrders[0].id,
                  vendorId: rawOrders[0].vendorId,
                  vendorIdType: typeof rawOrders[0].vendorId,
                  _id: rawOrders[0]._id
                })
                orders = rawOrders
              }
            }
          }
          
          console.log(`[getProductFeedback] 🔍 DEBUG: Total orders found: ${orders.length}`)
          if (orders.length > 0) {
            console.log(`[getProductFeedback] 🔍 DEBUG: Sample order structure:`, {
              id: orders[0].id,
              vendorId: orders[0].vendorId,
              vendorIdType: typeof orders[0].vendorId,
              vendorIdIsObject: typeof orders[0].vendorId === 'object',
              vendorIdIsObjectId: orders[0].vendorId instanceof mongoose.Types.ObjectId
            })
          }
          
          const orderVendorMap = new Map<string, any>()
          const vendorIdsFromOrders = new Set<string>()
          
          for (const order of orders) {
            if (order.vendorId) {
              let vendorIdStr: string
              if (typeof order.vendorId === 'object') {
                if (order.vendorId._id) {
                  vendorIdStr = order.vendorId._id.toString()
                } else if (order.vendorId.toString) {
                  vendorIdStr = order.vendorId.toString()
                } else {
                  console.warn(`[getProductFeedback] 🔍 DEBUG: Order ${order.id} has vendorId object but can't extract string:`, order.vendorId)
                  continue
                }
              } else {
                vendorIdStr = order.vendorId.toString()
              }
              
              orderVendorMap.set(order.id, vendorIdStr)
              vendorIdsFromOrders.add(vendorIdStr)
              console.log(`[getProductFeedback] 🔍 DEBUG: Mapped order ${order.id} -> vendorId ${vendorIdStr}`)
            } else {
              console.warn(`[getProductFeedback] 🔍 DEBUG: Order ${order.id} has no vendorId`)
            }
          }
          
          console.log(`[getProductFeedback] 🔍 DEBUG: Order-vendor mapping: ${orderVendorMap.size} mappings, ${vendorIdsFromOrders.size} unique vendors`)
          
          // Get all vendors in database for fallback (do this once, outside the loop)
          const allVendors = await Vendor.find({}).select('_id id name').lean()
          console.log(`[getProductFeedback] 🔍 DEBUG: Total vendors in database: ${allVendors.length}`)
          if (allVendors.length > 0) {
            console.log(`[getProductFeedback] 🔍 DEBUG: Sample of existing vendors:`, 
              allVendors.slice(0, 5).map((v: any) => ({ id: v.id, name: v.name })))
          } else {
            console.warn(`[getProductFeedback] 🔍 DEBUG: ⚠️ NO VENDORS EXIST IN DATABASE!`)
          }
          
          // Batch lookup vendors from orders using string IDs
          if (vendorIdsFromOrders.size > 0) {
            const vendorIdArray = Array.from(vendorIdsFromOrders)
            console.log(`[getProductFeedback] 🔍 DEBUG: Vendor IDs to lookup:`, vendorIdArray)
            
            // Use string ID lookup - filter to valid string IDs
            const validVendorIds = vendorIdArray.filter(id => id && typeof id === 'string' && id.length > 0)
            
            console.log(`[getProductFeedback] 🔍 DEBUG: Looking up ${validVendorIds.length} vendors`)
            
            // Strategy 1: Try string ID query
            let vendorsFromOrders = await Vendor.find({ id: { $in: validVendorIds } })
              .select('id name')
              .lean()
            
            console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 1 (string ID) found ${vendorsFromOrders.length} vendors`)
            
            // Strategy 2: If no results, try individual findOne queries
            if (vendorsFromOrders.length === 0 && validVendorIds.length > 0) {
              console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 1 failed, trying individual queries...`)
              const individualVendors: any[] = []
              
              for (const vendorIdStr of validVendorIds) {
                try {
                  const vendor = await Vendor.findOne({ id: vendorIdStr }).select('id name').lean()
                  if (vendor) {
                    individualVendors.push(vendor)
                    console.log(`[getProductFeedback] 🔍 DEBUG: ✅ Found vendor ${vendorIdStr}: ${vendor.name || 'no name'}`)
                  } else {
                    console.warn(`[getProductFeedback] 🔍 DEBUG: ❌ Vendor ${vendorIdStr} not found`)
                  }
                } catch (error: any) {
                  console.error(`[getProductFeedback] 🔍 DEBUG: Error finding vendor ${vendorIdStr}:`, error.message)
                }
              }
              
              if (individualVendors.length > 0) {
                vendorsFromOrders = individualVendors
                console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 2 found ${vendorsFromOrders.length} vendors`)
              }
            }
            
            // Strategy 3: If still no results, try raw MongoDB collection
            if (vendorsFromOrders.length === 0) {
              console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 2 failed, trying raw MongoDB collection...`)
              const db = mongoose.connection.db
              if (db) {
                // Try the standard 'vendors' collection with string ID
                let rawVendors = await db.collection('vendors').find({ 
                  id: { $in: validVendorIds } 
                })
                  .project({ id: 1, name: 1 })
                  .toArray()
                
                console.log(`[getProductFeedback] 🔍 DEBUG: Raw 'vendors' collection query found ${rawVendors.length} vendors`)
                
                // If no results, try individual lookups with detailed debugging
                if (rawVendors.length === 0) {
                  console.log(`[getProductFeedback] 🔍 DEBUG: Trying individual raw collection lookups with detailed debugging...`)
                  const individualRawVendors: any[] = []
                  
                  for (const vendorObjectId of vendorObjectIds) {
                    try {
                      // Try using string id field instead of _id
                      const vendorIdStr = typeof vendorObjectId === 'string' ? vendorObjectId : String(vendorObjectId || '')
                      let rawVendor = await db.collection('vendors').findOne({ id: vendorIdStr })
                      
                      if (rawVendor) {
                        individualRawVendors.push(rawVendor)
                        console.log(`[getProductFeedback] 🔍 DEBUG: ✅ Found vendor in raw collection with string id:`, {
                          id: rawVendor.id,
                          name: rawVendor.name
                        })
                      } else {
                        // Fallback: if vendorObjectId looks like an ObjectId string, try to find by converting
                        // But prefer using the id field directly
                        rawVendor = await db.collection('vendors').findOne({ id: vendorIdStr })
                        
                        if (rawVendor) {
                          individualRawVendors.push(rawVendor)
                          console.log(`[getProductFeedback] 🔍 DEBUG: ✅ Found vendor with _id as string:`, {
                            _id: rawVendor._id,
                            _idType: typeof rawVendor._id,
                            id: rawVendor.id,
                            name: rawVendor.name
                          })
                        } else {
                          // Try finding by id field
                          rawVendor = await db.collection('vendors').findOne({ id: vendorIdStr })
                          
                          if (rawVendor) {
                            individualRawVendors.push(rawVendor)
                            console.log(`[getProductFeedback] 🔍 DEBUG: ✅ Found vendor with id field:`, {
                              _id: rawVendor._id,
                              id: rawVendor.id,
                              name: rawVendor.name
                            })
                          } else {
                            // Debug: Check what _id values actually exist in the collection
                            const sampleVendors = await db.collection('vendors').find({}).limit(5).toArray()
                            console.log(`[getProductFeedback] 🔍 DEBUG: Sample vendor _id types in collection:`, 
                              sampleVendors.map((v: any) => ({
                                _id: v._id,
                                _idType: typeof v._id,
                                _idIsObjectId: v._id instanceof mongoose.Types.ObjectId,
                                id: v.id,
                                name: v.name
                              })))
                            
                            console.warn(`[getProductFeedback] 🔍 DEBUG: ❌ Vendor ${vendorObjectId} (${vendorIdStr}) not found with any query method`)
                          }
                        }
                      }
                    } catch (error: any) {
                      console.error(`[getProductFeedback] 🔍 DEBUG: Error in raw lookup ${vendorObjectId}:`, error.message, error.stack)
                    }
                  }
                  
                  if (individualRawVendors.length > 0) {
                    vendorsFromOrders = individualRawVendors
                    console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 3 (individual raw) found ${vendorsFromOrders.length} vendors`)
                  }
                } else {
                  vendorsFromOrders = rawVendors
                  console.log(`[getProductFeedback] 🔍 DEBUG: Strategy 3 (raw $in) found ${vendorsFromOrders.length} vendors`)
                }
              }
            }
            
            console.log(`[getProductFeedback] 🔍 DEBUG: Found ${vendorsFromOrders.length} vendors`)
            
            const vendorMap = new Map<string, any>()
            for (const vendor of vendorsFromOrders) {
              if (vendor) {
                const vendorIdStr = vendor.id || String(vendor._id || '')
                if (vendor.name) {
                  vendorMap.set(vendorIdStr, {
                    id: vendor.id || vendorIdStr,
                    name: vendor.name
                  })
                  console.log(`[getProductFeedback] 🔍 DEBUG: Mapped vendor ${vendorIdStr} -> ${vendor.name}`)
                } else {
                  console.warn(`[getProductFeedback] 🔍 DEBUG: Vendor ${vendorIdStr} found but has no name`)
                }
              }
            }
            
            // Apply vendorId from orders to feedback
            // FALLBACK: If vendor lookup fails, still use the vendorId ObjectId from order
            let ordersMatched = 0
            for (const fb of feedbackNeedingVendor) {
              if (fb.orderId) {
                const hasMapping = orderVendorMap.has(fb.orderId)
                console.log(`[getProductFeedback] 🔍 DEBUG: Feedback ${fb._id} orderId ${fb.orderId} has mapping: ${hasMapping}`)
                
                if (hasMapping) {
                  const vendorIdStr = orderVendorMap.get(fb.orderId)!
                  const vendor = vendorMap.get(vendorIdStr)
                  
                  console.log(`[getProductFeedback] 🔍 DEBUG: Feedback ${fb._id} vendorIdStr ${vendorIdStr} -> vendor:`, !!vendor, vendor ? vendor.name : 'NOT FOUND')
                  
                  if (vendor) {
                    // Full vendor object with name
                    fb.vendorId = vendor
                    ordersMatched++
                    console.log(`[getProductFeedback] 🔍 DEBUG: ✅ Applied vendor ${vendor.name} to feedback ${fb.id || fb._id}`)
                    // Update database asynchronously using string IDs only
                    const fbIdForUpdate = fb.id || String(fb._id || '')
                    if (fbIdForUpdate) {
                      ProductFeedback.updateOne(
                        { id: fbIdForUpdate },
                        { $set: { vendorId: vendor.id } }
                      ).catch(err => console.error(`[getProductFeedback] Error updating feedback ${fbIdForUpdate} from order:`, err))
                    }
                  } else {
                    // FALLBACK: Vendor not found in lookup, but we have vendorId from order
                    // The vendor might not exist, but we should still try ProductVendor as fallback
                    console.warn(`[getProductFeedback] 🔍 DEBUG: ⚠️ Vendor ${vendorIdStr} not found in batch lookup`)
                    
                    // FALLBACK: Try to find vendor through ProductVendor relationship
                    // This is more reliable since ProductVendor should have valid vendorIds
                    let foundViaProductVendor = false
                    if (fb.uniformId) {
                      try {
                        const db = mongoose.connection.db
                        if (db) {
                          // Extract uniformId as string - use string id field instead of ObjectId
                          let uniformIdStr: string | null = null
                          
                          if (fb.uniformId) {
                            if (typeof fb.uniformId === 'object' && fb.uniformId.id) {
                              uniformIdStr = String(fb.uniformId.id || '')
                            } else if (typeof fb.uniformId === 'object' && fb.uniformId._id) {
                              // Fallback: if only _id exists, try to get id from Uniform collection
                              uniformIdStr = String(fb.uniformId._id || '')
                            } else if (typeof fb.uniformId === 'string') {
                              uniformIdStr = fb.uniformId
                            } else if (fb.uniformId instanceof mongoose.Types.ObjectId) {
                              uniformIdStr = fb.uniformId.toString()
                            }
                          }
                          
                          if (uniformIdStr) {
                            console.log(`[getProductFeedback] 🔍 DEBUG: Trying ProductVendor lookup for uniform ${uniformIdStr}`)
                            // ProductVendor stores productId as string, so use string ID directly
                            const productVendorLink = await db.collection('productvendors').findOne({ 
                              productId: uniformIdStr 
                            })
                            
                            if (productVendorLink && productVendorLink.vendorId) {
                              const productVendorIdStr = String(productVendorLink.vendorId || '')
                              console.log(`[getProductFeedback] 🔍 DEBUG: Found ProductVendor link with vendorId: ${productVendorIdStr}`)
                              
                              // Try to find this vendor using string id field
                              const productVendor = await Vendor.findOne({ id: productVendorIdStr }).select('id name').lean()
                              if (productVendor && productVendor.name) {
                                fb.vendorId = {
                                  _id: productVendor._id,
                                  id: productVendor.id,
                                  name: productVendor.name
                                }
                                ordersMatched++
                                foundViaProductVendor = true
                                console.log(`[getProductFeedback] 🔍 DEBUG: ✅ Found vendor via ProductVendor: ${productVendor.name}`)
                                // Update database using string IDs only
                                const fbIdForPvUpdate = fb.id || String(fb._id || '')
                                if (fbIdForPvUpdate) {
                                  ProductFeedback.updateOne(
                                    { id: fbIdForPvUpdate },
                                    { $set: { vendorId: productVendor.id } }
                                  ).catch(err => console.error(`[getProductFeedback] Error updating feedback ${fbIdForPvUpdate} from ProductVendor:`, err))
                                }
                              } else {
                                console.warn(`[getProductFeedback] 🔍 DEBUG: ProductVendor vendorId ${productVendorIdStr} also doesn't exist`)
                              }
                            } else {
                              console.warn(`[getProductFeedback] 🔍 DEBUG: No ProductVendor link found for uniform ${uniformObjectId}`)
                            }
                          } else {
                            console.warn(`[getProductFeedback] 🔍 DEBUG: Could not extract uniformId ObjectId from:`, fb.uniformId)
                          }
                        }
                      } catch (productVendorError: any) {
                        console.error(`[getProductFeedback] 🔍 DEBUG: Error in ProductVendor fallback:`, productVendorError.message)
                      }
                    }
                    
                    // Only set placeholder if ProductVendor also failed
                    if (!foundViaProductVendor) {
                      // Do NOT use fallback vendor - show "Unknown" if vendor cannot be found
                      // This allows proper troubleshooting to identify the correct vendor
                      fb.vendorId = {
                        id: 'unknown',
                        name: 'Unknown'
                      }
                      // Do NOT update database - keep the original vendorId for troubleshooting
                      const fbIdForLog = fb.id || fb._id
                      console.warn(`[getProductFeedback] 🔍 DEBUG: ⚠️ Vendor ${vendorIdStr} not found - showing "Unknown" for feedback ${fbIdForLog}`)
                      console.warn(`[getProductFeedback] 🔍 DEBUG: OrderId: ${fb.orderId}, ProductId: ${fb.productId}, UniformId: ${fb.uniformId?.name || fb.uniformId?.id}`)
                    }
                  }
                } else {
                  console.warn(`[getProductFeedback] 🔍 DEBUG: ⚠️ No order mapping found for orderId ${fb.orderId} (feedback ${fb.id || fb._id})`)
                }
              } else {
                console.warn(`[getProductFeedback] 🔍 DEBUG: ⚠️ Feedback ${fb.id || fb._id} has no orderId`)
              }
            }
            console.log(`[getProductFeedback] ✅ Populated vendorId from orders for ${ordersMatched} feedback records`)
          } else {
            console.warn(`[getProductFeedback] 🔍 DEBUG: ⚠️ No vendorIds extracted from ${orders.length} orders`)
          }
        }
        
        // STEP 2: For feedback still missing vendorId, try ProductVendor relationship
        const stillNeedingVendor = feedbackNeedingVendor.filter(fb => {
          const hasValidVendorId = fb.vendorId && 
            typeof fb.vendorId === 'object' && 
            fb.vendorId !== null &&
            !Array.isArray(fb.vendorId) &&
            fb.vendorId.name && 
            typeof fb.vendorId.name === 'string' &&
            fb.vendorId.name.trim() !== '' &&
            fb.vendorId.name !== 'null' &&
            fb.vendorId.name !== 'undefined'
          return !hasValidVendorId
        })
        
        if (stillNeedingVendor.length > 0) {
          console.log(`[getProductFeedback] ${stillNeedingVendor.length} feedback records still need vendorId, trying ProductVendor lookup`)
          
          // Get all uniformIds that need vendor lookup
          const uniformIdsToLookup = new Map<string, any>()
          
          for (const fb of stillNeedingVendor) {
            let uniformObjectId = null
            if (fb.uniformId) {
              if (typeof fb.uniformId === 'object' && fb.uniformId._id) {
                uniformObjectId = fb.uniformId._id.toString()
              } else if (fb.uniformId instanceof mongoose.Types.ObjectId) {
                uniformObjectId = fb.uniformId.toString()
              } else if (typeof fb.uniformId === 'string' && mongoose.Types.ObjectId.isValid(fb.uniformId)) {
                uniformObjectId = fb.uniformId
              }
            }
            if (uniformObjectId) {
              if (!uniformIdsToLookup.has(uniformObjectId)) {
                uniformIdsToLookup.set(uniformObjectId, [])
              }
              uniformIdsToLookup.get(uniformObjectId)!.push(fb)
            }
          }
          
          // Batch lookup all ProductVendor relationships at once - use string IDs
          if (uniformIdsToLookup.size > 0) {
            // ProductVendor stores productId as string, so use string IDs directly
            const uniformStringIds = Array.from(uniformIdsToLookup.keys())
            const productVendorLinks = await db.collection('productvendors')
              .find({ productId: { $in: uniformStringIds } })
              .toArray()
            
            // Batch lookup all vendors at once - use string id field
            const uniqueVendorIds = [...new Set(productVendorLinks
              .filter(link => link.vendorId)
              .map(link => String(link.vendorId || '')))]
              .filter(id => id && id.length > 0)
            
            const vendors = await Vendor.find({ id: { $in: uniqueVendorIds } })
              .select('id name')
              .lean()
            
            const vendorIdMap = new Map<string, any>()
            for (const vendor of vendors) {
              if (vendor && vendor.name) {
                const vendorIdStr = vendor.id || String(vendor._id || '')
                vendorIdMap.set(vendorIdStr, {
                  id: vendor.id || vendorIdStr,
                  name: vendor.name
                })
              }
            }
            
            // Apply vendorId to all feedback records from ProductVendor - use string IDs
            let productVendorMatched = 0
            for (const [uniformIdStr, feedbackList] of uniformIdsToLookup.entries()) {
              // ProductVendor stores productId as string, so use string directly
              const link = productVendorLinks.find(l => String(l.productId || '') === uniformIdStr)
              
              if (link && link.vendorId) {
                const vendorIdStr = link.vendorId.toString()
                const vendor = vendorIdMap.get(vendorIdStr)
                
                if (vendor) {
                  for (const fb of feedbackList) {
                    // Only update if still missing vendorId
                    const stillMissing = !fb.vendorId || 
                      !fb.vendorId.name || 
                      fb.vendorId.name.trim() === ''
                    if (stillMissing) {
                      fb.vendorId = vendor
                      productVendorMatched++
                      // Update database asynchronously using string id field
                      const fbIdForUpdate = fb.id || String(fb._id || '')
                      if (fbIdForUpdate && vendor.id) {
                        ProductFeedback.updateOne(
                          { id: fbIdForUpdate },
                          { $set: { vendorId: vendor.id } }
                        ).catch(err => console.error(`[getProductFeedback] Error updating feedback ${fbIdForUpdate} from ProductVendor:`, err))
                      }
                    }
                  }
                }
              }
            }
            console.log(`[getProductFeedback] ✅ Populated vendorId from ProductVendor for ${productVendorMatched} feedback records`)
          }
        }
      }
    }
    
    // Decrypt employee fields (firstName, lastName are encrypted)
    const { decrypt } = require('../utils/encryption')
    for (const fb of feedback) {
      if (fb.employeeId) {
        const sensitiveFields = ['firstName', 'lastName']
        for (const field of sensitiveFields) {
          if (fb.employeeId[field] && typeof fb.employeeId[field] === 'string' && fb.employeeId[field].includes(':')) {
            try {
              fb.employeeId[field] = decrypt(fb.employeeId[field])
              console.log(`[getProductFeedback] Decrypted employee ${field} for feedback ${fb._id}`)
            } catch (error) {
              console.warn(`[getProductFeedback] Failed to decrypt employee ${field} for feedback ${fb._id}:`, error)
            }
          }
        }
      }
    }
    
    // Final verification: Ensure all feedback has vendorId populated (especially for Company Admin)
    if (isCompanyAdminUser && feedback.length > 0) {
      const feedbackWithoutVendor = feedback.filter(fb => !fb.vendorId || !fb.vendorId.name)
      if (feedbackWithoutVendor.length > 0) {
        console.warn(`[getProductFeedback] ⚠️ WARNING: ${feedbackWithoutVendor.length} feedback records still missing vendorId for Company Admin`)
        for (const fb of feedbackWithoutVendor) {
          console.warn(`[getProductFeedback] Missing vendorId for feedback:`, {
            feedbackId: fb._id,
            orderId: fb.orderId,
            productId: fb.productId,
            uniformId: fb.uniformId?.name || fb.uniformId?._id
          })
        }
      } else {
        console.log(`[getProductFeedback] ✅ All ${feedback.length} feedback records have vendorId populated for Company Admin`)
      }
    }
    
    // Additional debug: Check populated fields
    if (feedback.length > 0) {
      const sampleFeedback = feedback[0]
      console.log(`[getProductFeedback] Final sample feedback:`, {
        feedbackId: sampleFeedback._id?.toString(),
        orderId: sampleFeedback.orderId,
        productId: sampleFeedback.productId,
        vendorId: sampleFeedback.vendorId ? {
          name: sampleFeedback.vendorId.name,
          id: sampleFeedback.vendorId.id,
          _id: sampleFeedback.vendorId._id?.toString(),
          isValid: !!(sampleFeedback.vendorId.name && sampleFeedback.vendorId.name.trim() !== '')
        } : null,
        employeeId: sampleFeedback.employeeId ? {
          firstName: sampleFeedback.employeeId.firstName,
          lastName: sampleFeedback.employeeId.lastName,
          id: sampleFeedback.employeeId.id
        } : null,
        uniformId: sampleFeedback.uniformId ? {
          name: sampleFeedback.uniformId.name,
          id: sampleFeedback.uniformId.id,
          _id: sampleFeedback.uniformId._id?.toString()
        } : null
      })
    }
  } catch (queryError: any) {
    console.error(`[getProductFeedback] Error executing query:`, queryError.message)
    console.error(`[getProductFeedback] Error stack:`, queryError.stack)
    console.error(`[getProductFeedback] Query that failed:`, JSON.stringify({
      companyId: query.companyId?.toString(),
      employeeId: query.employeeId?.toString(),
      orderId: query.orderId,
      productId: query.productId,
      vendorId: query.vendorId?.toString()
    }, null, 2))
    throw new Error(`Failed to fetch product feedback: ${queryError.message}`)
  }
  
  // If no feedback found and we're querying by companyId, try a more flexible query
  if (feedback.length === 0 && query.companyId) {
    console.log(`[getProductFeedback] No feedback found with strict query, trying alternative query...`)
    // Get company using string ID
    const companyForFallback = await Company.findOne({ id: query.companyId }).lean()
    
    if (companyForFallback && companyForFallback.id) {
      // Try querying with companyIdNum as well (fallback)
      const companyIdNum = typeof companyForFallback.id === 'string' ? parseInt(companyForFallback.id) : companyForFallback.id
      const altQuery: any = {}
      if (query.employeeId) altQuery.employeeId = query.employeeId
      if (query.orderId) altQuery.orderId = query.orderId
      if (query.productId) altQuery.productId = query.productId
      if (query.vendorId) altQuery.vendorId = query.vendorId
      altQuery.companyIdNum = companyIdNum
      
      const altFeedback = await ProductFeedback.find(altQuery)
        .populate('employeeId', 'id employeeId firstName lastName')
        .populate('companyId', 'id name')
        .populate('uniformId', 'id name')
        .populate('vendorId', 'id name')
        .sort({ createdAt: -1 })
        .lean()
      console.log(`[getProductFeedback] Alternative query (by companyIdNum) found ${altFeedback.length} feedback records`)
      
      // Post-process: Fill in missing vendorIds
      // PRIORITY 1: Try to get vendorId from Order (most reliable)
      // PRIORITY 2: Fall back to ProductVendor relationship
      const dbForAlt = mongoose.connection.db
      if (altFeedback.length > 0 && dbForAlt) {
        // STEP 1: Try to get vendorId from orders (batch lookup)
        const altFeedbackNeedingVendor = altFeedback.filter(fb => {
          const hasVendorId = fb.vendorId && 
            typeof fb.vendorId === 'object' && 
            fb.vendorId !== null &&
            !Array.isArray(fb.vendorId) &&
            fb.vendorId.name && 
            typeof fb.vendorId.name === 'string' &&
            fb.vendorId.name.trim() !== '' &&
            fb.vendorId.name !== 'null' &&
            fb.vendorId.name !== 'undefined'
          return !hasVendorId
        })
        
        if (altFeedbackNeedingVendor.length > 0) {
          const altOrderIds = altFeedbackNeedingVendor
            .map(fb => fb.orderId)
            .filter((id): id is string => !!id && typeof id === 'string')
          
          if (altOrderIds.length > 0) {
            console.log(`[getProductFeedback] [Alt Query] Looking up vendorId from ${altOrderIds.length} orders`)
            const altOrders = await Order.find({ id: { $in: altOrderIds } })
              .select('id vendorId')
              .lean()
            
            const altOrderVendorMap = new Map<string, any>()
            const altVendorIdsFromOrders = new Set<string>()
            
            for (const order of altOrders) {
              if (order.vendorId) {
                const vendorIdStr = typeof order.vendorId === 'object' && order.vendorId._id 
                  ? order.vendorId._id.toString() 
                  : order.vendorId.toString()
                altOrderVendorMap.set(order.id, vendorIdStr)
                altVendorIdsFromOrders.add(vendorIdStr)
              }
            }
            
            // Batch lookup vendors from orders using string IDs
            if (altVendorIdsFromOrders.size > 0) {
              const altVendorStringIds = Array.from(altVendorIdsFromOrders).filter(id => id && typeof id === 'string')
              const altVendorsFromOrders = await Vendor.find({ id: { $in: altVendorStringIds } })
                .select('id name')
                .lean()
              
              const altVendorMap = new Map<string, any>()
              for (const vendor of altVendorsFromOrders) {
                if (vendor && vendor.name) {
                  const vendorIdStr = vendor.id || String(vendor._id || '')
                  altVendorMap.set(vendorIdStr, {
                    id: vendor.id || vendorIdStr,
                    name: vendor.name
                  })
                }
              }
              
              // Apply vendorId from orders to feedback
              let altOrdersMatched = 0
              for (const fb of altFeedbackNeedingVendor) {
                if (fb.orderId && altOrderVendorMap.has(fb.orderId)) {
                  const vendorIdStr = altOrderVendorMap.get(fb.orderId)!
                  const vendor = altVendorMap.get(vendorIdStr)
                  
                  if (vendor) {
                    fb.vendorId = vendor
                    altOrdersMatched++
                    // Update database asynchronously using string IDs only
                    const altFbIdForUpdate = fb.id || String(fb._id || '')
                    if (altFbIdForUpdate) {
                      ProductFeedback.updateOne(
                        { id: altFbIdForUpdate },
                        { $set: { vendorId: vendor.id } }
                      ).catch(err => console.error(`[getProductFeedback] [Alt Query] Error updating feedback ${altFbIdForUpdate} from order:`, err))
                    }
                  }
                }
              }
              console.log(`[getProductFeedback] [Alt Query] ✅ Populated vendorId from orders for ${altOrdersMatched} feedback records`)
            }
          }
          
          // STEP 2: For feedback still missing vendorId, try ProductVendor relationship
          const altStillNeedingVendor = altFeedbackNeedingVendor.filter(fb => {
            const hasValidVendorId = fb.vendorId && 
              typeof fb.vendorId === 'object' && 
              fb.vendorId !== null &&
              !Array.isArray(fb.vendorId) &&
              fb.vendorId.name && 
              typeof fb.vendorId.name === 'string' &&
              fb.vendorId.name.trim() !== '' &&
              fb.vendorId.name !== 'null' &&
              fb.vendorId.name !== 'undefined'
            return !hasValidVendorId
          })
          
          if (altStillNeedingVendor.length > 0) {
            console.log(`[getProductFeedback] [Alt Query] ${altStillNeedingVendor.length} feedback records still need vendorId, trying ProductVendor lookup`)
            
            for (const fb of altStillNeedingVendor) {
              // Get uniformId as string ID - when using .lean(), populated fields are plain objects
              let uniformIdStr = ''
              
              if (fb.uniformId) {
                if (typeof fb.uniformId === 'object' && fb.uniformId.id) {
                  uniformIdStr = fb.uniformId.id
                } else if (typeof fb.uniformId === 'object' && fb.uniformId._id) {
                  uniformIdStr = String(fb.uniformId._id)
                } else if (typeof fb.uniformId === 'string') {
                  uniformIdStr = fb.uniformId
                }
              }
              
              if (!uniformIdStr && fb.uniformId) {
                const fbIdStr = fb.id || String(fb._id || '')
                const rawFeedback = fbIdStr ? await ProductFeedback.findOne({ id: fbIdStr }).select('uniformId').lean() : null
                if (rawFeedback && rawFeedback.uniformId) {
                  uniformIdStr = typeof rawFeedback.uniformId === 'object' ? (rawFeedback.uniformId.id || String(rawFeedback.uniformId._id || '')) : String(rawFeedback.uniformId)
                }
              }
              
              if (uniformIdStr) {
                const productVendorLink = await dbForAlt.collection('productvendors').findOne({ 
                  productId: uniformIdStr 
                })
                
                if (productVendorLink && productVendorLink.vendorId) {
                  const vendorIdFromLink = String(productVendorLink.vendorId)
                  const vendor = await Vendor.findOne({ id: vendorIdFromLink })
                    .select('id name')
                    .lean()
                  
                  if (vendor) {
                    const vendorIdStr = vendor.id || ''
                    const feedbackId = fb.id || String(fb._id || '')
                    if (feedbackId) {
                      await ProductFeedback.updateOne(
                        { id: feedbackId },
                        { $set: { vendorId: vendorIdStr } }
                      )
                    }
                    
                    fb.vendorId = {
                      id: vendor.id || vendorIdStr,
                      name: vendor.name
                    }
                    console.log(`[getProductFeedback] [Alt Query] ✅ Populated vendorId for alt feedback ${feedbackId}: ${vendor.name}`)
                  }
                }
              }
            }
          }
        }
      }
      
      // Decrypt employee fields for alternative query results
      if (altFeedback.length > 0) {
        const { decrypt: decryptAlt } = require('../utils/encryption')
        for (const fb of altFeedback) {
          if (fb.employeeId) {
            const sensitiveFields = ['firstName', 'lastName']
            for (const field of sensitiveFields) {
              if (fb.employeeId[field] && typeof fb.employeeId[field] === 'string' && fb.employeeId[field].includes(':')) {
                try {
                  fb.employeeId[field] = decryptAlt(fb.employeeId[field])
                } catch (error) {
                  console.warn(`[getProductFeedback] Failed to decrypt employee ${field} for alt feedback ${fb.id || fb._id}:`, error)
                }
              }
            }
          }
        }
      }
      
      if (altFeedback.length > 0) {
        return altFeedback.map((f: any) => toPlainObject(f))
      }
      
      // Last resort: try to find all feedback and filter by company manually
      console.log(`[getProductFeedback] Trying manual company matching...`)
      const allFeedback = await ProductFeedback.find({
        ...(query.employeeId ? { employeeId: query.employeeId } : {}),
        ...(query.orderId ? { orderId: query.orderId } : {}),
        ...(query.productId ? { productId: query.productId } : {}),
        ...(query.vendorId ? { vendorId: query.vendorId } : {})
      })
        .populate('companyId', 'id name')
        .lean()
      
      const filteredFeedback = allFeedback.filter((fb: any) => {
        const fbCompanyId = fb.companyId?.id || String(fb.companyId?._id || '') || String(fb.companyId || '')
        const targetCompanyId = companyForFallback.id || String(companyForFallback._id || '')
        return fbCompanyId === targetCompanyId
      })
      
      // Populate other fields using string IDs only
      const feedbackIds = filteredFeedback.map((f: any) => f.id || String(f._id || '')).filter(Boolean)
      const populatedFeedback = feedbackIds.length > 0 
        ? await ProductFeedback.find({ id: { $in: feedbackIds } })
        : []
        .populate('employeeId', 'id employeeId firstName lastName')
        .populate('companyId', 'id name')
        .populate('uniformId', 'id name')
        .populate('vendorId', 'id name')
        .sort({ createdAt: -1 })
        .lean()
      
      console.log(`[getProductFeedback] Manual matching found ${populatedFeedback.length} feedback records`)
      
      // Apply vendorId population to manually matched feedback as well
      // PRIORITY 1: Try to get vendorId from Order (most reliable)
      // PRIORITY 2: Fall back to ProductVendor relationship
      if (db && populatedFeedback.length > 0) {
        const manualFeedbackNeedingVendor = populatedFeedback.filter(fb => {
          const hasValidVendorId = fb.vendorId && 
            typeof fb.vendorId === 'object' && 
            fb.vendorId !== null &&
            !Array.isArray(fb.vendorId) &&
            fb.vendorId.name && 
            typeof fb.vendorId.name === 'string' &&
            fb.vendorId.name.trim() !== '' &&
            fb.vendorId.name !== 'null' &&
            fb.vendorId.name !== 'undefined'
          return !hasValidVendorId
        })
        
        if (manualFeedbackNeedingVendor.length > 0) {
          // STEP 1: Try to get vendorId from orders (batch lookup)
          const manualOrderIds = manualFeedbackNeedingVendor
            .map(fb => fb.orderId)
            .filter((id): id is string => !!id && typeof id === 'string')
          
          if (manualOrderIds.length > 0) {
            console.log(`[getProductFeedback] [Manual Match] Looking up vendorId from ${manualOrderIds.length} orders`)
            const manualOrders = await Order.find({ id: { $in: manualOrderIds } })
              .select('id vendorId')
              .lean()
            
            const manualOrderVendorMap = new Map<string, any>()
            const manualVendorIdsFromOrders = new Set<string>()
            
            for (const order of manualOrders) {
              if (order.vendorId) {
                const vendorIdStr = typeof order.vendorId === 'object' 
                  ? (order.vendorId.id || String(order.vendorId._id || ''))
                  : String(order.vendorId)
                manualOrderVendorMap.set(order.id, vendorIdStr)
                manualVendorIdsFromOrders.add(vendorIdStr)
              }
            }
            
            // Batch lookup vendors from orders using string IDs
            if (manualVendorIdsFromOrders.size > 0) {
              const manualVendorStringIds = Array.from(manualVendorIdsFromOrders).filter(id => id && typeof id === 'string')
              const manualVendorsFromOrders = await Vendor.find({ id: { $in: manualVendorStringIds } })
                .select('id name')
                .lean()
              
              const manualVendorMap = new Map<string, any>()
              for (const vendor of manualVendorsFromOrders) {
                if (vendor && vendor.name) {
                  const vendorIdStr = vendor.id || ''
                  if (vendorIdStr) {
                    manualVendorMap.set(vendorIdStr, {
                      id: vendorIdStr,
                      name: vendor.name
                    })
                  }
                }
              }
              
              // Apply vendorId from orders to feedback
              let manualOrdersMatched = 0
              for (const fb of manualFeedbackNeedingVendor) {
                if (fb.orderId && manualOrderVendorMap.has(fb.orderId)) {
                  const vendorIdStr = manualOrderVendorMap.get(fb.orderId)!
                  const vendor = manualVendorMap.get(vendorIdStr)
                  
                  if (vendor) {
                    fb.vendorId = vendor
                    manualOrdersMatched++
                  }
                }
              }
              console.log(`[getProductFeedback] [Manual Match] ✅ Populated vendorId from orders for ${manualOrdersMatched} feedback records`)
            }
          }
          
          // STEP 2: For feedback still missing vendorId, try ProductVendor relationship
          const manualStillNeedingVendor = manualFeedbackNeedingVendor.filter(fb => {
            const hasValidVendorId = fb.vendorId && 
              typeof fb.vendorId === 'object' && 
              fb.vendorId !== null &&
              !Array.isArray(fb.vendorId) &&
              fb.vendorId.name && 
              typeof fb.vendorId.name === 'string' &&
              fb.vendorId.name.trim() !== '' &&
              fb.vendorId.name !== 'null' &&
              fb.vendorId.name !== 'undefined'
            return !hasValidVendorId
          })
          
          if (manualStillNeedingVendor.length > 0 && db) {
            console.log(`[getProductFeedback] [Manual Match] ${manualStillNeedingVendor.length} feedback records still need vendorId, trying ProductVendor lookup`)
            for (const fb of manualStillNeedingVendor) {
              // Get uniformId as string
              const uniformIdStr = fb.uniformId?.id || String(fb.uniformId?._id || fb.uniformId || '')
              if (uniformIdStr) {
                const productVendorLink = await db.collection('productvendors').findOne({ 
                  productId: uniformIdStr 
                })
                
                if (productVendorLink && productVendorLink.vendorId) {
                  const vendorIdFromLink = String(productVendorLink.vendorId)
                  const vendor = await Vendor.findOne({ id: vendorIdFromLink }).select('id name').lean()
                  if (vendor && vendor.name) {
                    fb.vendorId = {
                      id: vendor.id,
                      name: vendor.name
                    }
                  }
                }
              }
            }
          }
        }
      }
      
      // Apply same vendorId population and transformation to alternative query results
      const transformedAltFeedback = populatedFeedback.map((f: any) => {
        // Preserve employee data before toPlainObject converts it
        const employeeData = f.employeeId && typeof f.employeeId === 'object' && f.employeeId !== null
          ? {
              id: f.employeeId.id || f.employeeId.employeeId || '',
              employeeId: f.employeeId.employeeId,
              firstName: f.employeeId.firstName,
              lastName: f.employeeId.lastName
            }
          : null
        
        const plain = toPlainObject(f)
        
        // Restore employee data if it was populated
        if (employeeData) {
          plain.employeeId = employeeData
        }
        
        // Ensure vendorId structure is correct
        if (plain.vendorId && typeof plain.vendorId === 'object' && !plain.vendorId.name) {
          console.warn(`[getProductFeedback] ⚠️ vendorId object missing name in alt query transform:`, plain.vendorId)
        }
        return plain
      })
      
      console.log(`[getProductFeedback] Returning ${transformedAltFeedback.length} feedback records from alternative query`)
      if (transformedAltFeedback.length > 0 && isCompanyAdminUser) {
        const vendorsInAltResponse = new Set(transformedAltFeedback
          .filter(f => f.vendorId && f.vendorId.name && f.vendorId.name.trim() !== '')
          .map(f => f.vendorId.name))
        console.log(`[getProductFeedback] ✅ Alternative query includes ${vendorsInAltResponse.size} unique vendors:`, Array.from(vendorsInAltResponse))
      }
      
      return transformedAltFeedback
    }
  }
  
  // Final transformation: Ensure vendorId and employeeId are properly formatted in response
  const transformedFeedback = feedback.map((f: any, index: number) => {
    // Preserve employee data before toPlainObject converts it
    let employeeData = null
    
    if (f.employeeId && typeof f.employeeId === 'object' && f.employeeId !== null && !Array.isArray(f.employeeId)) {
      // Employee is populated - extract the data
      employeeData = {
        _id: f.employeeId._id?.toString() || f.employeeId._id,
        id: f.employeeId.id,
        employeeId: f.employeeId.employeeId,
        firstName: f.employeeId.firstName,
        lastName: f.employeeId.lastName
      }
      
      // Debug first few records
      if (index < 3) {
        console.log(`[getProductFeedback] 🔍 Employee data BEFORE toPlainObject for feedback ${f.orderId}:`, {
          employeeIdType: typeof f.employeeId,
          employeeIdIsObject: typeof f.employeeId === 'object',
          employeeIdKeys: Object.keys(f.employeeId),
          firstName: f.employeeId.firstName,
          lastName: f.employeeId.lastName,
          extractedData: employeeData
        })
      }
    } else if (f.employeeId) {
      // EmployeeId exists but is not an object (might be ObjectId string)
      if (index < 3) {
        console.warn(`[getProductFeedback] ⚠️ EmployeeId is not populated for feedback ${f.orderId}:`, {
          employeeIdType: typeof f.employeeId,
          employeeIdValue: f.employeeId,
          employeeIdString: f.employeeId?.toString()
        })
      }
    } else {
      // No employeeId at all
      if (index < 3) {
        console.warn(`[getProductFeedback] ⚠️ No employeeId for feedback ${f.orderId || f._id}`)
      }
    }
    
    const plain = toPlainObject(f)
    
    // Restore employee data if it was populated
    if (employeeData) {
      plain.employeeId = employeeData
      if (index < 3) {
        console.log(`[getProductFeedback] ✅ Preserved employee data for feedback ${plain.orderId}:`, {
          firstName: employeeData.firstName,
          lastName: employeeData.lastName,
          employeeId: employeeData.employeeId
        })
      }
    }
    
    // Ensure vendorId structure is correct for frontend
    if (plain.vendorId && typeof plain.vendorId === 'object') {
      // Ensure name is present and not empty
      if (!plain.vendorId.name || plain.vendorId.name.trim() === '') {
        console.warn(`[getProductFeedback] ⚠️ vendorId object missing valid name in final transform for feedback ${plain._id}`)
      }
    }
    
    return plain
  })
  
  // Batch lookup employees that weren't populated
  const feedbackNeedingEmployee = transformedFeedback.filter(f => 
    !f.employeeId || 
    typeof f.employeeId === 'string' || 
    (typeof f.employeeId === 'object' && (!f.employeeId.firstName || !f.employeeId.lastName))
  )
  
  if (feedbackNeedingEmployee.length > 0) {
    console.log(`[getProductFeedback] 🔍 ${feedbackNeedingEmployee.length} feedback records need employee data, attempting batch lookup...`)
    
    const employeeIdsToLookup: string[] = []
    const feedbackEmployeeMap = new Map<string, any[]>() // Map employeeId to feedback records
    
    feedbackNeedingEmployee.forEach(f => {
      let employeeIdStr = ''
      
      if (typeof f.employeeId === 'string') {
        employeeIdStr = f.employeeId
      } else if (f.employeeId?.id) {
        employeeIdStr = f.employeeId.id
      } else if (f.employeeIdNum) {
        employeeIdStr = String(f.employeeIdNum)
      }
      
      if (employeeIdStr && !employeeIdsToLookup.includes(employeeIdStr)) {
        employeeIdsToLookup.push(employeeIdStr)
      }
      if (employeeIdStr) {
        if (!feedbackEmployeeMap.has(employeeIdStr)) {
          feedbackEmployeeMap.set(employeeIdStr, [])
        }
        feedbackEmployeeMap.get(employeeIdStr)!.push(f)
      }
    })
    
    if (employeeIdsToLookup.length > 0) {
      console.log(`[getProductFeedback] 🔍 Looking up ${employeeIdsToLookup.length} unique employees...`)
      const employees = await Employee.find({ 
        $or: [
          { id: { $in: employeeIdsToLookup } },
          { employeeId: { $in: employeeIdsToLookup } }
        ]
      })
        .select('id employeeId firstName lastName')
        .lean()
      
      console.log(`[getProductFeedback] 🔍 Found ${employees.length} employees in batch lookup`)
      
      // Create a map for quick lookup
      const employeeMap = new Map()
      employees.forEach((emp: any) => {
        const empId = emp.id || emp.employeeId || String(emp._id || '')
        const empData = {
          id: emp.id || empId,
          employeeId: emp.employeeId || empId,
          firstName: emp.firstName,
          lastName: emp.lastName
        }
        employeeMap.set(empId, empData)
      })
      
      // Update feedback records with employee data
      let updatedCount = 0
      feedbackEmployeeMap.forEach((feedbackRecords, employeeIdStr) => {
        if (employeeMap.has(employeeIdStr)) {
          const empData = employeeMap.get(employeeIdStr)
          feedbackRecords.forEach(f => {
            f.employeeId = empData
            updatedCount++
            console.log(`[getProductFeedback] ✅ Manually populated employee for feedback ${f.orderId}: ${empData.firstName} ${empData.lastName}`)
          })
        } else {
          console.warn(`[getProductFeedback] ⚠️ Employee ${employeeIdStr} not found in database`)
        }
      })
      
      console.log(`[getProductFeedback] ✅ Updated ${updatedCount} feedback records with employee data`)
    }
  }
  
  console.log(`[getProductFeedback] Returning ${transformedFeedback.length} feedback records`)
  
  // Debug: Log ALL feedback records with their vendor assignments
  console.log(`[getProductFeedback] 📊 COMPLETE FEEDBACK LIST (${transformedFeedback.length} records):`)
  transformedFeedback.forEach((fb: any, index: number) => {
    console.log(`[getProductFeedback]   [${index + 1}] OrderId: ${fb.orderId}, ProductId: ${fb.productId}, Uniform: ${fb.uniformId?.name || 'N/A'}, Vendor: ${fb.vendorId?.name || 'Unknown'}, VendorId: ${fb.vendorId?._id || 'null'}`)
  })
  
  if (transformedFeedback.length > 0 && isCompanyAdminUser) {
    const vendorsInResponse = new Set(transformedFeedback
      .filter(f => f.vendorId && f.vendorId.name && f.vendorId.name.trim() !== '')
      .map(f => f.vendorId.name))
    console.log(`[getProductFeedback] ✅ Company Admin response includes ${vendorsInResponse.size} unique vendors:`, Array.from(vendorsInResponse))
    
    // Group by vendor for debugging
    const vendorGroups = transformedFeedback.reduce((acc: any, fb: any) => {
      const vendorName = fb.vendorId?.name || 'Unknown'
      if (!acc[vendorName]) {
        acc[vendorName] = []
      }
      acc[vendorName].push({
        orderId: fb.orderId,
        productId: fb.productId,
        uniformName: fb.uniformId?.name
      })
      return acc
    }, {})
    
    console.log(`[getProductFeedback] 📊 Feedback grouped by vendor:`, 
      Object.entries(vendorGroups).map(([vendor, items]: [string, any]) => ({
        vendor,
        count: items.length,
        items: items
      }))
    )
    
    // Final check: Log any feedback still missing vendor
    const missingVendor = transformedFeedback.filter(f => !f.vendorId || !f.vendorId.name || f.vendorId.name.trim() === '')
    if (missingVendor.length > 0) {
      console.error(`[getProductFeedback] ❌ CRITICAL: ${missingVendor.length} feedback records still missing vendorId for Company Admin:`, 
        missingVendor.map(f => ({ id: f._id, orderId: f.orderId, productId: f.productId })))
    }
  }
  
  return transformedFeedback
}

// ============================================================================
// RETURN & REPLACEMENT REQUEST FUNCTIONS
// ============================================================================

/**
 * Generate unique return request ID (6-digit, starting from 600001)
 */
async function generateReturnRequestId(): Promise<string> {
  await connectDB()
  
  // Find the highest existing return request ID
  const lastRequest = await ReturnRequest.findOne()
    .sort({ returnRequestId: -1 })
    .select('returnRequestId')
    .lean()
  
  if (!lastRequest || !lastRequest.returnRequestId) {
    return '600001'
  }
  
  const lastId = parseInt(lastRequest.returnRequestId)
  const nextId = lastId + 1
  
  // Ensure we stay within 6-digit range (600001-699999)
  if (nextId >= 700000) {
    throw new Error('Return request ID limit reached (699999). Please contact system administrator.')
  }
  
  return nextId.toString().padStart(6, '0')
}

/**
 * Validate if a product in a delivered order is eligible for return
 * 
 * Rules:
 * 1. Order status must be DELIVERED
 * 2. Product must not already have an active/completed replacement
 * 3. Return request must be within return window (default: 14 days)
 * 4. Quantity requested ≤ quantity delivered
 */
export async function validateReturnEligibility(
  orderId: string,
  itemIndex: number,
  requestedQty: number,
  returnWindowDays: number = 14
): Promise<{
  eligible: boolean
  errors: string[]
  orderItem?: any
  deliveredDate?: Date
}> {
  await connectDB()
  
  const errors: string[] = []
  
  // Find the order - try multiple formats for robustness
  let order = await Order.findOne({ id: orderId }).lean()
  let isSplitOrder = false
  let actualChildOrder: any = null
  
  if (!order) {
    // Try with _id if orderId looks like ObjectId
    if (orderId && orderId.length === 24 && /^[0-9a-fA-F]{24}$/.test(orderId)) {
      order = await Order.findById(orderId).lean()
    }
    // Try with parentOrderId (for split orders)
    if (!order) {
      // This might be a parent order ID - find all child orders
      const childOrders = await Order.find({ parentOrderId: orderId })
        .populate('items.uniformId', 'id name')
        .lean()
        .sort({ vendorName: 1 }) // Sort by vendor name for consistency
      
      if (childOrders.length > 0) {
        isSplitOrder = true
        console.log(`[validateReturnEligibility] Found split order with ${childOrders.length} child orders`)
        
        // Reconstruct the grouped order items (same logic as getOrdersByEmployee)
        let currentItemIndex = 0
        for (const childOrder of childOrders) {
          const childItems = childOrder.items || []
          // Check if the requested itemIndex falls within this child order's items
          if (itemIndex >= currentItemIndex && itemIndex < currentItemIndex + childItems.length) {
            // Found the child order containing this item
            actualChildOrder = childOrder
            const localItemIndex = itemIndex - currentItemIndex
            order = {
              ...childOrder,
              items: childItems,
            }
            console.log(`[validateReturnEligibility] Item at index ${itemIndex} is in child order ${childOrder.id} at local index ${localItemIndex}`)
            break
          }
          currentItemIndex += childItems.length
        }
        
        // If we didn't find the item, create a grouped order for error checking
        if (!order) {
          const allItems = childOrders.flatMap(o => o.items || [])
          order = {
            ...childOrders[0],
            id: orderId,
            items: allItems,
            isSplitOrder: true,
          }
        }
      } else {
        // Try finding by parentOrderId as a direct lookup (single child order)
        order = await Order.findOne({ parentOrderId: orderId }).lean()
      }
    }
  }
  
  if (!order) {
    return {
      eligible: false,
      errors: ['Order not found'],
    }
  }
  
  // For split orders, check the status of the specific child order containing the item
  const orderToCheck = actualChildOrder || order
  const statusToCheck = orderToCheck.status
  
  // Check order status
  if (statusToCheck !== 'Delivered') {
    errors.push(`Order status must be "Delivered". Current status: "${statusToCheck}"`)
    if (isSplitOrder && actualChildOrder) {
      errors.push(`Note: This is a split order. The item you're returning is in order ${actualChildOrder.id} which has status "${statusToCheck}"`)
    }
  }
  
  // For split orders, we need to find the correct item in the correct child order
  let orderItem: any = null
  if (isSplitOrder && actualChildOrder) {
    // Recalculate the local item index within the child order
    let currentItemIndex = 0
    const childOrders = await Order.find({ parentOrderId: orderId })
      .populate('items.uniformId', 'id name')
      .lean()
      .sort({ vendorName: 1 })
    
    for (const childOrder of childOrders) {
      const childItems = childOrder.items || []
      if (itemIndex >= currentItemIndex && itemIndex < currentItemIndex + childItems.length) {
        const localItemIndex = itemIndex - currentItemIndex
        orderItem = childItems[localItemIndex]
        break
      }
      currentItemIndex += childItems.length
    }
  } else {
    // Regular order - use itemIndex directly
    orderItem = order.items?.[itemIndex]
  }
  
  // Check item index
  if (!orderItem) {
    errors.push('Invalid item index')
    return { eligible: false, errors }
  }
  
  // Check if there's already an active/completed return request for this product in this order
  const existingReturn = await ReturnRequest.findOne({
    originalOrderId: orderId,
    originalOrderItemIndex: itemIndex,
    status: { $in: ['REQUESTED', 'APPROVED', 'COMPLETED'] },
  }).lean()
  
  if (existingReturn) {
    errors.push('A return request already exists for this product in this order')
  }
  
  // Check quantity
  if (requestedQty <= 0) {
    errors.push('Requested quantity must be greater than 0')
  } else if (requestedQty > orderItem.quantity) {
    errors.push(`Requested quantity (${requestedQty}) cannot exceed delivered quantity (${orderItem.quantity})`)
  }
  
  // Check return window (if order has updatedAt, use that; otherwise use orderDate)
  // For split orders, use the actual child order's date
  const orderForDate = actualChildOrder || order
  const deliveredDate = orderForDate.updatedAt || orderForDate.orderDate || new Date()
  const daysSinceDelivery = Math.floor((Date.now() - new Date(deliveredDate).getTime()) / (1000 * 60 * 60 * 24))
  
  if (daysSinceDelivery > returnWindowDays) {
    errors.push(`Return request must be submitted within ${returnWindowDays} days of delivery. ${daysSinceDelivery} days have passed.`)
  }
  
  return {
    eligible: errors.length === 0,
    errors,
    orderItem: toPlainObject(orderItem),
    deliveredDate: deliveredDate ? new Date(deliveredDate) : undefined,
  }
}

/**
 * Create a return request
 */
export async function createReturnRequest(requestData: {
  originalOrderId: string
  originalOrderItemIndex: number
  requestedQty: number
  requestedSize: string
  reason?: string
  comments?: string
  requestedBy: string // Employee email/ID
  returnWindowDays?: number
}): Promise<any> {
  await connectDB()
  
  // Validate eligibility
  const validation = await validateReturnEligibility(
    requestData.originalOrderId,
    requestData.originalOrderItemIndex,
    requestData.requestedQty,
    requestData.returnWindowDays || 14
  )
  
  if (!validation.eligible) {
    throw new Error(`Return request not eligible: ${validation.errors.join(', ')}`)
  }
  
  // Get order and item details - try multiple formats for robustness
  // Handle split orders correctly (same logic as validateReturnEligibility)
  let order = await Order.findOne({ id: requestData.originalOrderId })
    .populate('employeeId', 'id employeeId firstName lastName email')
    .populate('companyId', 'id name')
    .populate('items.uniformId', 'id name')
    .lean()
  
  let isSplitOrder = false
  let actualChildOrder: any = null
  
  if (!order) {
    // Try with _id if originalOrderId looks like ObjectId
    if (requestData.originalOrderId && requestData.originalOrderId.length === 24 && /^[0-9a-fA-F]{24}$/.test(requestData.originalOrderId)) {
      order = await Order.findById(requestData.originalOrderId)
        .populate('employeeId', 'id employeeId firstName lastName email')
        .populate('companyId', 'id name')
        .populate('items.uniformId', 'id name')
        .lean()
    }
    // Try with parentOrderId (for split orders)
    if (!order) {
      // This might be a parent order ID - find all child orders
      const childOrders = await Order.find({ parentOrderId: requestData.originalOrderId })
        .populate('employeeId', 'id employeeId firstName lastName email')
        .populate('companyId', 'id name')
        .populate('items.uniformId', 'id name')
        .lean()
        .sort({ vendorName: 1 }) // Sort by vendor name for consistency
      
      if (childOrders.length > 0) {
        isSplitOrder = true
        console.log(`[createReturnRequest] Found split order with ${childOrders.length} child orders`)
        
        // Reconstruct the grouped order items (same logic as validateReturnEligibility)
        let currentItemIndex = 0
        for (const childOrder of childOrders) {
          const childItems = childOrder.items || []
          // Check if the requested itemIndex falls within this child order's items
          if (requestData.originalOrderItemIndex >= currentItemIndex && requestData.originalOrderItemIndex < currentItemIndex + childItems.length) {
            // Found the child order containing this item
            actualChildOrder = childOrder
            const localItemIndex = requestData.originalOrderItemIndex - currentItemIndex
            order = {
              ...childOrder,
              items: childItems,
            }
            console.log(`[createReturnRequest] Item at index ${requestData.originalOrderItemIndex} is in child order ${childOrder.id} at local index ${localItemIndex}`)
            break
          }
          currentItemIndex += childItems.length
        }
        
        // If we didn't find the item, create a grouped order for error checking
        if (!order) {
          const allItems = childOrders.flatMap(o => o.items || [])
          order = {
            ...childOrders[0],
            id: requestData.originalOrderId,
            items: allItems,
            isSplitOrder: true,
          }
        }
      } else {
        // Try finding by parentOrderId as a direct lookup (single child order)
        order = await Order.findOne({ parentOrderId: requestData.originalOrderId })
          .populate('employeeId', 'id employeeId firstName lastName email')
          .populate('companyId', 'id name')
          .populate('items.uniformId', 'id name')
          .lean()
      }
    }
  }
  
  if (!order) {
    throw new Error('Order not found')
  }
  
  // For split orders, we need to find the correct item in the correct child order
  let orderItem: any = null
  if (isSplitOrder && actualChildOrder) {
    // Recalculate the local item index within the child order
    let currentItemIndex = 0
    const childOrders = await Order.find({ parentOrderId: requestData.originalOrderId })
      .populate('items.uniformId', 'id name')
      .lean()
      .sort({ vendorName: 1 })
    
    for (const childOrder of childOrders) {
      const childItems = childOrder.items || []
      if (requestData.originalOrderItemIndex >= currentItemIndex && requestData.originalOrderItemIndex < currentItemIndex + childItems.length) {
        const localItemIndex = requestData.originalOrderItemIndex - currentItemIndex
        orderItem = childItems[localItemIndex]
        break
      }
      currentItemIndex += childItems.length
    }
  } else {
    // Regular order - use itemIndex directly
    orderItem = order.items?.[requestData.originalOrderItemIndex]
  }
  
  // Validate that orderItem exists
  if (!orderItem) {
    throw new Error(`Order item not found at index ${requestData.originalOrderItemIndex}. Order has ${order.items?.length || 0} items.`)
  }
  
  // Validate that orderItem has uniformId
  if (!orderItem.uniformId) {
    throw new Error(`Order item at index ${requestData.originalOrderItemIndex} is missing uniformId. Item data: ${JSON.stringify(orderItem)}`)
  }
  
  // Get employee - prefer using the employee from the order (already populated)
  // This is more reliable than looking up by email again
  let employee: any = null
  
  // First, try to use the employee from the order (most reliable)
  if (order.employeeId) {
    if (typeof order.employeeId === 'object' && order.employeeId._id) {
      // It's a populated object, use it directly
      employee = order.employeeId
      // Ensure it's a plain object
      if (employee.toObject) {
        employee = employee.toObject()
      }
      employee = toPlainObject(employee)
    } else if (typeof order.employeeId === 'object' && order.employeeId.id) {
      // It's a populated object with id field
      employee = order.employeeId
      employee = toPlainObject(employee)
    } else {
      // It's an ObjectId, fetch the employee
      employee = await Employee.findById(order.employeeId)
        .populate('companyId', 'id name')
        .populate('locationId', 'id name address city state pincode')
        .lean()
      if (employee) {
        employee = toPlainObject(employee)
      }
    }
  }
  
  // If order employee lookup failed, try by email (handles encrypted emails)
  if (!employee) {
    console.log(`[createReturnRequest] Order employee not found, trying email lookup: ${requestData.requestedBy}`)
    employee = await getEmployeeByEmail(requestData.requestedBy)
  }
  
  // If still not found by email, try by employeeId or id
  if (!employee) {
    console.log(`[createReturnRequest] Email lookup failed, trying ID lookup: ${requestData.requestedBy}`)
    const employeeDoc = await Employee.findOne({
      $or: [
        { employeeId: requestData.requestedBy },
        { id: requestData.requestedBy },
      ],
    })
      .populate('companyId', 'id name')
      .populate('locationId', 'id name address city state pincode')
      .lean()
    
    if (employeeDoc) {
      employee = toPlainObject(employeeDoc)
    }
  }
  
  // Final fallback: if requestedBy looks like an ObjectId, try that
  if (!employee && requestData.requestedBy && requestData.requestedBy.length === 24 && /^[0-9a-fA-F]{24}$/.test(requestData.requestedBy)) {
    console.log(`[createReturnRequest] Trying ObjectId lookup: ${requestData.requestedBy}`)
    const employeeDoc = await Employee.findById(requestData.requestedBy)
      .populate('companyId', 'id name')
      .populate('locationId', 'id name address city state pincode')
      .lean()
    
    if (employeeDoc) {
      employee = toPlainObject(employeeDoc)
    }
  }
  
  if (!employee) {
    console.error(`[createReturnRequest] Employee lookup failed for: ${requestData.requestedBy}`)
    console.error(`[createReturnRequest] Order employeeId:`, order.employeeId)
    throw new Error(`Employee not found: ${requestData.requestedBy}`)
  }
  
  // Validate that the requestedBy email matches the order's employee (security check)
  // Get the employee's email for comparison (decrypt if needed)
  let employeeEmail = employee.email
  if (employeeEmail) {
    try {
      const { decrypt } = require('../utils/encryption')
      employeeEmail = decrypt(employeeEmail)
    } catch (error) {
      // Email might already be decrypted or decryption failed, use as-is
      console.log(`[createReturnRequest] Email decryption not needed or failed, using as-is`)
    }
  }
  
  // Compare requestedBy with employee email (case-insensitive)
  if (requestData.requestedBy && employeeEmail && 
      requestData.requestedBy.toLowerCase().trim() !== employeeEmail.toLowerCase().trim() &&
      requestData.requestedBy !== employee.id &&
      requestData.requestedBy !== employee.employeeId) {
    console.warn(`[createReturnRequest] Email mismatch: requestedBy=${requestData.requestedBy}, employeeEmail=${employeeEmail}`)
    // Don't throw error, just log warning - the order's employee is the authoritative source
  }
  
  // Get uniform using string ID
  const uniformIdStr = typeof orderItem.uniformId === 'object' 
    ? (orderItem.uniformId.id || String(orderItem.uniformId._id || orderItem.uniformId)) 
    : String(orderItem.uniformId)
  const uniform = await Uniform.findOne({ id: uniformIdStr }).lean()
  if (!uniform) {
    throw new Error('Uniform product not found')
  }
  
  // Generate return request ID
  const returnRequestId = await generateReturnRequestId()
  
  // Get company ID as string
  let companyIdStr = ''
  if (typeof order.companyId === 'object' && order.companyId !== null) {
    companyIdStr = order.companyId.id || String(order.companyId)
  } else if (order.companyId) {
    companyIdStr = String(order.companyId)
  }
  
  if (!companyIdStr) {
    throw new Error('Invalid companyId format')
  }
  
  // Get employee ID as string
  const employeeIdStr = employee?.id || employee?.employeeId || ''
  if (!employeeIdStr) {
    throw new Error('Employee ID not found in employee object')
  }
  
  const employeeIdNum = employee.employeeId || employee.id || ''
  
  // Create return request
  const returnRequest = await ReturnRequest.create({
    returnRequestId,
    originalOrderId: requestData.originalOrderId,
    originalOrderItemIndex: requestData.originalOrderItemIndex,
    productId: orderItem.productId,
    uniformId: orderItem.uniformId,
    uniformName: orderItem.uniformName,
    employeeId: employeeIdStr,
    employeeIdNum,
    companyId: companyIdStr,
    requestedQty: requestData.requestedQty,
    originalSize: orderItem.size,
    requestedSize: requestData.requestedSize,
    reason: requestData.reason,
    comments: requestData.comments,
    status: 'REQUESTED',
    requestedBy: requestData.requestedBy,
    returnWindowDays: requestData.returnWindowDays || 14,
  })
  
  return toPlainObject(returnRequest)
}

/**
 * Get return requests for an employee
 */
export async function getReturnRequestsByEmployee(employeeId: string): Promise<any[]> {
  await connectDB()
  
  // Find employee using string IDs only
  const employee = await Employee.findOne({
    $or: [
      { employeeId: employeeId },
      { id: employeeId },
    ],
  }).select('employeeId id').lean()
  
  if (!employee) {
    return []
  }
  
  const employeeIdNum = employee.employeeId || employee.id
  
  // Find return requests using string ID
  const returnRequests = await ReturnRequest.find({
    $or: [
      { employeeId: employee.id || employee.employeeId },
      { employeeIdNum: employeeIdNum },
    ],
  })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('uniformId', 'id name')
    .sort({ createdAt: -1 })
    .lean()
  
  return returnRequests.map((rr) => toPlainObject(rr))
}

/**
 * Get return requests for a company (for admin approval)
 */
export async function getReturnRequestsByCompany(companyId: string, status?: string): Promise<any[]> {
  await connectDB()
  
  // Find company - try multiple formats for robustness
  let company = await Company.findOne({ id: companyId }).select('_id id').lean()
  
  if (!company) {
    // Try with _id if companyId looks like ObjectId
    if (companyId && companyId.length === 24 && /^[0-9a-fA-F]{24}$/.test(companyId)) {
      company = await Company.findOne({ id: String(companyId) }).select('_id id').lean()
    }
    // Try as numeric ID (if companyId is a number string)
    if (!company && !isNaN(Number(companyId))) {
      company = await Company.findOne({ id: Number(companyId) }).select('_id id').lean()
    }
  }
  
  if (!company) {
    console.error(`[getReturnRequestsByCompany] Company not found for companyId: ${companyId}`)
    return []
  }
  
  const query: any = {
    companyId: company._id,
  }
  
  if (status) {
    query.status = status
  }
  
  // Find return requests
  const returnRequests = await ReturnRequest.find(query)
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('uniformId', 'id name')
    .sort({ createdAt: -1 })
    .lean()
  
  // Enrich return requests with vendor information from original order
  const enrichedReturnRequests = await Promise.all(
    returnRequests.map(async (rr) => {
      const plainRR = toPlainObject(rr)
      
      // Fetch the original order to get vendor information
      // Use the same robust logic as validateReturnEligibility and createReturnRequest
      let vendorName = null
      try {
        const itemIndex = rr.originalOrderItemIndex || 0
        
        // First, try to find order by id
        let originalOrder = await Order.findOne({ id: rr.originalOrderId })
          .populate('vendorId', 'id name')
          .lean()
        
        // If not found, try with _id (if originalOrderId is an ObjectId)
        if (!originalOrder && rr.originalOrderId && rr.originalOrderId.length === 24 && /^[0-9a-fA-F]{24}$/.test(rr.originalOrderId)) {
          originalOrder = await Order.findById(rr.originalOrderId)
            .populate('vendorId', 'id name')
            .lean()
        }
        
        // Check if this might be a parent order (has child orders) - same logic as validateReturnEligibility
        if (!originalOrder || !originalOrder.parentOrderId) {
          // Try finding child orders with parentOrderId (this might be a parent order ID)
          const childOrders = await Order.find({ parentOrderId: rr.originalOrderId })
            .populate('vendorId', 'id name')
            .sort({ vendorName: 1 }) // Sort by vendor name for consistency (same as validateReturnEligibility)
            .lean()
          
          if (childOrders.length > 0) {
            // This is a parent order with child orders - find which child contains the item
            let currentIndex = 0
            for (const childOrder of childOrders) {
              const childItems = childOrder.items || []
              if (itemIndex >= currentIndex && itemIndex < currentIndex + childItems.length) {
                // This child order contains the item - use its vendor
                if (childOrder.vendorName) {
                  vendorName = childOrder.vendorName
                } else if (childOrder.vendorId && typeof childOrder.vendorId === 'object' && childOrder.vendorId.name) {
                  vendorName = childOrder.vendorId.name
                } else if (childOrder.vendorId) {
                  // vendorId is an ObjectId, fetch vendor name
                  const vendor = await Vendor.findById(childOrder.vendorId).select('name').lean()
                  if (vendor) {
                    vendorName = vendor.name
                  }
                }
                console.log(`[getReturnRequestsByCompany] Found vendor ${vendorName} from child order ${childOrder.id} for item index ${itemIndex}`)
                break
              }
              currentIndex += childItems.length
            }
          } else if (originalOrder) {
            // Single order (not split) - use its vendor
            if (originalOrder.vendorName) {
              vendorName = originalOrder.vendorName
            } else if (originalOrder.vendorId && typeof originalOrder.vendorId === 'object' && originalOrder.vendorId.name) {
              vendorName = originalOrder.vendorId.name
            } else if (originalOrder.vendorId) {
              // vendorId is an ObjectId, fetch vendor name
              const vendor = await Vendor.findById(originalOrder.vendorId).select('name').lean()
              if (vendor) {
                vendorName = vendor.name
              }
            }
            console.log(`[getReturnRequestsByCompany] Found vendor ${vendorName} from single order ${originalOrder.id}`)
          }
        } else {
          // This is a child order - check if it contains the item
          if (originalOrder.items && originalOrder.items.length > itemIndex) {
            // This child order contains the item
            if (originalOrder.vendorName) {
              vendorName = originalOrder.vendorName
            } else if (originalOrder.vendorId && typeof originalOrder.vendorId === 'object' && originalOrder.vendorId.name) {
              vendorName = originalOrder.vendorId.name
            } else if (originalOrder.vendorId) {
              // vendorId is an ObjectId, fetch vendor name
              const vendor = await Vendor.findById(originalOrder.vendorId).select('name').lean()
              if (vendor) {
                vendorName = vendor.name
              }
            }
            console.log(`[getReturnRequestsByCompany] Found vendor ${vendorName} from child order ${originalOrder.id} for item index ${itemIndex}`)
          }
        }
      } catch (error) {
        console.error(`[getReturnRequestsByCompany] Error fetching vendor for return request ${rr.returnRequestId}:`, error)
      }
      
      return {
        ...plainRR,
        vendorName: vendorName || 'N/A'
      }
    })
  )
  
  return enrichedReturnRequests
}

/**
 * Get a single return request by ID
 */
export async function getReturnRequestById(returnRequestId: string): Promise<any> {
  await connectDB()
  
  const returnRequest = await ReturnRequest.findOne({ returnRequestId })
    .populate('employeeId', 'id firstName lastName email')
    .populate('companyId', 'id name')
    .populate('uniformId', 'id name')
    .lean()
  
  if (!returnRequest) {
    return null
  }
  
  return toPlainObject(returnRequest)
}

/**
 * Approve a return request and create replacement order
 */
export async function approveReturnRequest(
  returnRequestId: string,
  approvedBy: string
): Promise<any> {
  await connectDB()
  
  // Get return request
  const returnRequest = await ReturnRequest.findOne({ returnRequestId })
    .populate('employeeId', 'id employeeId firstName lastName email')
    .populate('companyId', 'id name')
    .populate('uniformId', 'id name')
    .lean()
  
  if (!returnRequest) {
    throw new Error('Return request not found')
  }
  
  if (returnRequest.status !== 'REQUESTED') {
    throw new Error(`Return request cannot be approved. Current status: ${returnRequest.status}`)
  }
  
  // Get original order - try multiple formats for robustness
  // CRITICAL: First query without populate to see raw vendorId, then populate for full details
  let originalOrderRaw = await Order.findOne({ id: returnRequest.originalOrderId }).lean()
  
  if (!originalOrderRaw) {
    // Try with _id if originalOrderId looks like ObjectId
    if (returnRequest.originalOrderId && returnRequest.originalOrderId.length === 24 && /^[0-9a-fA-F]{24}$/.test(returnRequest.originalOrderId)) {
      originalOrderRaw = await Order.findById(returnRequest.originalOrderId).lean()
    }
    // Try with parentOrderId (for split orders - the stored ID might be a parent order ID)
    if (!originalOrderRaw) {
      originalOrderRaw = await Order.findOne({ parentOrderId: returnRequest.originalOrderId }).lean()
    }
  }
  
  if (!originalOrderRaw) {
    throw new Error(`Original order not found: ${returnRequest.originalOrderId}`)
  }
  
  // DEBUG: Log raw order to see actual vendorId in database
  console.log(`[approveReturnRequest] 🔍 DEBUG: Raw order from database:`, {
    orderId: originalOrderRaw.id,
    vendorId: originalOrderRaw.vendorId,
    vendorIdType: typeof originalOrderRaw.vendorId,
    vendorIdIsObjectId: originalOrderRaw.vendorId instanceof mongoose.Types.ObjectId,
    vendorName: originalOrderRaw.vendorName,
    parentOrderId: originalOrderRaw.parentOrderId,
    hasItems: !!originalOrderRaw.items,
    itemCount: originalOrderRaw.items?.length
  })
  
  // Now populate for full details
  let originalOrder = await Order.findOne({ id: originalOrderRaw.id })
        .populate('employeeId', 'id employeeId firstName lastName email')
        .populate('companyId', 'id name')
    .populate('vendorId', 'id name')
        .lean()
  
  if (!originalOrder) {
    // Fallback to raw order if populate fails
    originalOrder = originalOrderRaw
  }
  
  if (!originalOrder) {
    throw new Error(`Original order not found: ${returnRequest.originalOrderId}`)
  }
  
  // DEBUG: Log order details to understand the structure
  console.log(`[approveReturnRequest] 🔍 DEBUG: Original order found:`, {
    orderId: originalOrder.id,
    orderIdType: typeof originalOrder.id,
    hasParentOrderId: !!originalOrder.parentOrderId,
    parentOrderId: originalOrder.parentOrderId,
    vendorId: originalOrder.vendorId,
    vendorIdType: typeof originalOrder.vendorId,
    vendorIdIsObject: typeof originalOrder.vendorId === 'object',
    vendorIdIsObjectId: originalOrder.vendorId instanceof mongoose.Types.ObjectId,
    vendorName: originalOrder.vendorName,
    vendorIdKeys: originalOrder.vendorId && typeof originalOrder.vendorId === 'object' ? Object.keys(originalOrder.vendorId) : 'N/A',
    itemCount: originalOrder.items?.length,
    originalOrderItemIndex: returnRequest.originalOrderItemIndex
  })
  
  // Get uniform to get price and product ID
  const uniform = await Uniform.findById(returnRequest.uniformId).lean()
  if (!uniform) {
    throw new Error('Uniform product not found')
  }
  
  // Get product ID (string) - createOrder expects the product ID, not ObjectId
  const productId = uniform.id || uniform._id?.toString()
  if (!productId) {
    throw new Error('Product ID not found for uniform')
  }
  
  // Get employee
  const employee = typeof originalOrder.employeeId === 'object' && originalOrder.employeeId?._id
    ? originalOrder.employeeId
    : await Employee.findById(originalOrder.employeeId)
  
  if (!employee) {
    throw new Error('Employee not found')
  }
  
  const employeeId = employee.employeeId || employee.id
  
  // CRITICAL: For replacement orders, we must use the SAME vendor as the original order
  // Find the vendor from the original order (handle split orders)
  // NOTE: vendorId in orders is stored as a string (6-digit numeric), not ObjectId
  let originalVendorId: string | null = null
  let originalVendorName: string | null = null
  
  // Helper function to extract vendorId from various formats
  // CRITICAL: vendorId in orders is a string (6-digit numeric), not ObjectId
  const extractVendorId = async (order: any, orderLabel: string = 'order'): Promise<{ vendorId: string | null; vendorName: string | null }> => {
    let vendorId: string | null = null
    let vendorName: string | null = null
    
    console.log(`[approveReturnRequest] 🔍 DEBUG: Extracting vendorId from ${orderLabel}:`, {
      hasVendorId: !!order.vendorId,
      vendorIdType: typeof order.vendorId,
      vendorIdIsObjectId: order.vendorId instanceof mongoose.Types.ObjectId,
      vendorIdIsObject: typeof order.vendorId === 'object' && order.vendorId !== null,
      vendorIdValue: order.vendorId,
      vendorName: order.vendorName
    })
    
    // CRITICAL: vendorId in orders is stored as a string (6-digit numeric), not ObjectId
    if (order.vendorId) {
      if (typeof order.vendorId === 'string') {
        // String vendorId (6-digit numeric) - use directly
        vendorId = order.vendorId
        vendorName = order.vendorName || null
        console.log(`[approveReturnRequest] ✅ Extracted vendorId as string: ${vendorId}`)
      } else if (typeof order.vendorId === 'object' && order.vendorId !== null) {
        // Populated vendor object - extract the 'id' field (string), not _id
        if (order.vendorId.id) {
          vendorId = order.vendorId.id.toString()
          vendorName = order.vendorId.name || order.vendorName || null
          console.log(`[approveReturnRequest] ✅ Extracted vendorId from populated object id field: ${vendorId}, name: ${vendorName}`)
        } else if (order.vendorId._id) {
          // Fallback: if only _id exists, convert to string id and query vendor
          try {
            // Convert _id to string id format and query by id field
            const vendorIdFromId = String(order.vendorId._id || '')
            const vendorByObjectId = await Vendor.findOne({ id: vendorIdFromId }).lean()
            if (vendorByObjectId && (vendorByObjectId as any).id) {
              vendorId = (vendorByObjectId as any).id.toString()
              vendorName = order.vendorId.name || order.vendorName || null
              console.log(`[approveReturnRequest] ✅ Queried vendor by converted id to get string id: ${vendorId}`)
            }
          } catch (e) {
            console.warn(`[approveReturnRequest] ⚠️ Error querying vendor by _id:`, e)
          }
        }
      } else if (order.vendorId instanceof mongoose.Types.ObjectId) {
        // Legacy: ObjectId format - query vendor to get the string 'id'
        try {
          const vendorByObjectId = await Vendor.findById(order.vendorId).lean()
          if (vendorByObjectId && (vendorByObjectId as any).id) {
            vendorId = (vendorByObjectId as any).id.toString()
            vendorName = order.vendorName || null
            console.log(`[approveReturnRequest] ✅ Queried vendor by ObjectId to get string id: ${vendorId}`)
          }
        } catch (e) {
          console.warn(`[approveReturnRequest] ⚠️ Error querying vendor by ObjectId:`, e)
        }
      }
    } else {
      console.warn(`[approveReturnRequest] ⚠️ Order ${orderLabel} does not have vendorId field`)
    }
    
    return { vendorId, vendorName }
  }
  
  // Check if this is a split order (has child orders)
  // First, check if the order itself has a parentOrderId (it's a child)
  // Or if it has child orders (it's a parent)
  const hasParentOrderId = !!originalOrder.parentOrderId
    const childOrders = await Order.find({ 
    parentOrderId: originalOrder.id 
    }).lean()
  
  const isParentOrder = childOrders.length > 0
  const isChildOrder = hasParentOrderId
  
  console.log(`[approveReturnRequest] 🔍 DEBUG: Order structure:`, {
    isParentOrder,
    isChildOrder,
    hasParentOrderId,
    childOrdersCount: childOrders.length,
    orderId: originalOrder.id
  })
  
  // For split orders, find the specific child order that contains the returned item
  if (isParentOrder) {
    // This is a parent order - find the child order containing the item
    // CRITICAL: Populate vendorId on child orders too
    const childOrdersWithVendor = await Order.find({ 
      parentOrderId: originalOrder.id
    })
    .populate('vendorId', 'id name')
    .lean()
    
    console.log(`[approveReturnRequest] Found ${childOrdersWithVendor.length} child orders for split order`)
    
    // Find which child order contains the item at originalOrderItemIndex
    let currentItemIndex = 0
    for (const childOrder of childOrdersWithVendor) {
      const childItems = childOrder.items || []
      const itemIndexRange = {
        start: currentItemIndex,
        end: currentItemIndex + childItems.length - 1,
        requested: returnRequest.originalOrderItemIndex
      }
      console.log(`[approveReturnRequest] 🔍 DEBUG: Checking child order ${childOrder.id}, item range:`, itemIndexRange)
      
      if (returnRequest.originalOrderItemIndex >= currentItemIndex && 
          returnRequest.originalOrderItemIndex < currentItemIndex + childItems.length) {
        // Found the child order containing this item
        const vendorInfo = await extractVendorId(childOrder, `child order ${childOrder.id}`)
        originalVendorId = vendorInfo.vendorId
        originalVendorName = vendorInfo.vendorName
        console.log(`[approveReturnRequest] ✅ Found vendor from child order: ${originalVendorName || 'N/A'} (${originalVendorId})`)
        break
      }
      currentItemIndex += childItems.length
    }
    
    if (!originalVendorId) {
      console.error(`[approveReturnRequest] ❌ Could not find child order containing item at index ${returnRequest.originalOrderItemIndex}`)
      console.error(`[approveReturnRequest] ❌ Total child orders: ${childOrdersWithVendor.length}`)
      for (let i = 0; i < childOrdersWithVendor.length; i++) {
        const co = childOrdersWithVendor[i]
        console.error(`[approveReturnRequest] ❌ Child order ${i}: id=${co.id}, items=${co.items?.length || 0}, vendorId=${co.vendorId}`)
      }
    }
  } else {
    // Regular order (not a parent, might be a child or standalone) - use vendor directly
    const vendorInfo = await extractVendorId(originalOrder, 'original order')
    originalVendorId = vendorInfo.vendorId
    originalVendorName = vendorInfo.vendorName
    
    // FALLBACK: If populated order doesn't have vendorId, try raw order
    if (!originalVendorId && originalOrderRaw.vendorId) {
      console.log(`[approveReturnRequest] ⚠️ Populated order missing vendorId, using raw order vendorId`)
      if (typeof originalOrderRaw.vendorId === 'string') {
        // String vendorId (6-digit numeric) - use directly
        originalVendorId = originalOrderRaw.vendorId
        originalVendorName = originalOrderRaw.vendorName || null
        console.log(`[approveReturnRequest] ✅ Extracted vendorId from raw order: ${originalVendorId}`)
      } else if (originalOrderRaw.vendorId instanceof mongoose.Types.ObjectId) {
        // Legacy ObjectId format - query vendor to get string 'id'
        try {
          const vendorByObjectId = await Vendor.findById(originalOrderRaw.vendorId).lean()
          if (vendorByObjectId && (vendorByObjectId as any).id) {
            originalVendorId = (vendorByObjectId as any).id.toString()
            originalVendorName = originalOrderRaw.vendorName || (vendorByObjectId as any).name || null
            console.log(`[approveReturnRequest] ✅ Queried vendor by ObjectId to get string id: ${originalVendorId}`)
          }
        } catch (e) {
          console.warn(`[approveReturnRequest] ⚠️ Error querying vendor by ObjectId from raw order:`, e)
        }
      }
    }
    
    console.log(`[approveReturnRequest] Using vendor from original order: ${originalVendorName || 'N/A'} (${originalVendorId})`)
  }
  
  // CRITICAL: Validate that vendorId exists and is valid
  if (!originalVendorId) {
    const errorDetails = {
      returnRequestId,
      originalOrderId: returnRequest.originalOrderId,
      orderVendorId: originalOrder.vendorId,
      orderVendorIdType: typeof originalOrder.vendorId,
      rawOrderVendorId: originalOrderRaw.vendorId,
      rawOrderVendorIdType: typeof originalOrderRaw.vendorId,
      isSplitOrder: !!(originalOrder.parentOrderId || (originalOrder as any).isSplitOrder),
      productId: returnRequest.productId,
      uniformId: returnRequest.uniformId
    }
    console.error(`[approveReturnRequest] ❌ CRITICAL: Original order does not have a valid vendorId:`, errorDetails)
    throw new Error(`Original order does not have a vendor assigned. Order ID: ${returnRequest.originalOrderId}. Cannot create replacement order.`)
  }
  
  // CRITICAL: Validate that vendorId is a string (6-digit numeric)
  if (typeof originalVendorId !== 'string') {
    console.error(`[approveReturnRequest] ❌ CRITICAL: vendorId is not a string:`, {
      vendorId: originalVendorId,
      type: typeof originalVendorId,
      constructor: originalVendorId?.constructor?.name
    })
    throw new Error(`Invalid vendorId format: ${originalVendorId}. Expected string (6-digit numeric). Order ID: ${returnRequest.originalOrderId}. Cannot create replacement order.`)
  }
  
  // CRITICAL: Validate that vendor exists in database
  // Query vendor by 'id' field (string), not _id (ObjectId)
  console.log(`[approveReturnRequest] 🔍 DEBUG: Querying vendor with string id:`, {
    vendorId: originalVendorId,
    vendorIdType: typeof originalVendorId
  })
  
  // Query vendor by 'id' field (string)
  let vendorExists = await Vendor.findOne({ id: originalVendorId }).lean()
  
  // If not found, try legacy ObjectId lookup (for backward compatibility)
  if (!vendorExists) {
    console.warn(`[approveReturnRequest] ⚠️ Vendor not found by string id, trying legacy ObjectId lookup...`)
    // Check if vendorId could be an ObjectId string
    if (mongoose.Types.ObjectId.isValid(originalVendorId)) {
      try {
        const vendorByObjectId = await Vendor.findById(originalVendorId).lean()
        if (vendorByObjectId) {
          // Found by ObjectId, but we need the string 'id' field
          originalVendorId = (vendorByObjectId as any).id || originalVendorId
          vendorExists = vendorByObjectId
          console.log(`[approveReturnRequest] ✅ Found vendor by ObjectId, using string id: ${originalVendorId}`)
        }
      } catch (e) {
        console.warn(`[approveReturnRequest] ⚠️ Error querying vendor by ObjectId:`, e)
      }
    }
  }
  
  if (!vendorExists) {
    const errorDetails = {
      returnRequestId,
      originalOrderId: returnRequest.originalOrderId,
      vendorId: originalVendorId,
      vendorIdType: typeof originalVendorId,
      rawOrderVendorId: originalOrderRaw.vendorId?.toString(),
      populatedOrderVendorId: originalOrder.vendorId?.toString()
    }
    console.error(`[approveReturnRequest] ❌ CRITICAL: Vendor not found in database:`, errorDetails)
    throw new Error(`Vendor not found: ${originalVendorId}. The vendor may have been deleted or the vendorId in the order is invalid. Order ID: ${returnRequest.originalOrderId}. Cannot create replacement order.`)
  }
  
  console.log(`[approveReturnRequest] ✅ Vendor found:`, {
    _id: vendorExists._id?.toString(),
    id: (vendorExists as any).id,
    name: (vendorExists as any).name
  })
  
  // Update vendorName from vendor document if not already set
  if (!originalVendorName && (vendorExists as any).name) {
    originalVendorName = (vendorExists as any).name
    console.log(`[approveReturnRequest] ✅ Updated vendorName from vendor document: ${originalVendorName}`)
  }
  
  console.log(`[approveReturnRequest] ✅ Vendor validated: ${originalVendorName || 'N/A'} (${originalVendorId})`)
  
  // Create replacement order using existing createOrder function
  // Replacement order uses same SKU, new size, requested quantity
  const replacementOrder = await createOrder({
    employeeId: employeeId,
    items: [
      {
        uniformId: productId, // Use product ID (string), not ObjectId
        uniformName: returnRequest.uniformName,
        size: returnRequest.requestedSize,
        quantity: returnRequest.requestedQty,
        price: uniform.price || 0, // Use current price from uniform
      },
    ],
    deliveryAddress: originalOrder.deliveryAddress,
    estimatedDeliveryTime: originalOrder.estimatedDeliveryTime,
    dispatchLocation: originalOrder.dispatchLocation,
  })
  
  // Get the replacement order ID (could be parentOrderId if split)
  const replacementOrderId = replacementOrder.parentOrderId || replacementOrder.id
  
  // Update replacement orders to mark them as REPLACEMENT type, use original vendor, and auto-approve
  // If it's a split order, update all child orders
  const ordersToUpdate = replacementOrder.parentOrderId
    ? await Order.find({ parentOrderId: replacementOrder.parentOrderId })
    : [await Order.findOne({ id: replacementOrderId })]
  
  for (const order of ordersToUpdate) {
    if (order) {
      order.orderType = 'REPLACEMENT'
      order.returnRequestId = returnRequestId
      // CRITICAL: Use the same vendor as the original order
      order.vendorId = originalVendorId
      if (originalVendorName) {
        order.vendorName = originalVendorName
      }
      // Auto-approve replacement orders since return request is already approved by company admin
      if (order.status === 'Awaiting approval' || order.status === 'Awaiting fulfilment') {
        order.status = 'Awaiting fulfilment'
      }
      await order.save()
      console.log(`[approveReturnRequest] Updated replacement order ${order.id} with vendor ${originalVendorName} (${originalVendorId})`)
    }
  }
  
  // Update return request
  await ReturnRequest.updateOne(
    { returnRequestId },
    {
      status: 'APPROVED',
      replacementOrderId,
      approvedBy,
      approvedAt: new Date(),
    }
  )
  
  // Get updated return request
  const updatedRequest = await getReturnRequestById(returnRequestId)
  
  return {
    returnRequest: updatedRequest,
    replacementOrder,
  }
}

/**
 * Reject a return request
 */
export async function rejectReturnRequest(
  returnRequestId: string,
  rejectedBy: string,
  rejectionReason?: string
): Promise<any> {
  await connectDB()
  
  // Get return request
  const returnRequest = await ReturnRequest.findOne({ returnRequestId }).lean()
  
  if (!returnRequest) {
    throw new Error('Return request not found')
  }
  
  if (returnRequest.status !== 'REQUESTED') {
    throw new Error(`Return request cannot be rejected. Current status: ${returnRequest.status}`)
  }
  
  // Update return request
  await ReturnRequest.updateOne(
    { returnRequestId },
    {
      status: 'REJECTED',
      approvedBy: rejectedBy,
      approvedAt: new Date(),
      comments: rejectionReason
        ? `${returnRequest.comments || ''}\n\nRejection reason: ${rejectionReason}`.trim()
        : returnRequest.comments,
    }
  )
  
  // Get updated return request
  const updatedRequest = await getReturnRequestById(returnRequestId)
  
  return updatedRequest
}

/**
 * Mark return request as completed when replacement is delivered
 * This should be called when replacement order status changes to "Delivered"
 */
export async function completeReturnRequest(returnRequestId: string): Promise<any> {
  await connectDB()
  
  // Get return request
  const returnRequest = await ReturnRequest.findOne({ returnRequestId }).lean()
  
  if (!returnRequest) {
    throw new Error('Return request not found')
  }
  
  if (returnRequest.status !== 'APPROVED') {
    throw new Error(`Return request cannot be completed. Current status: ${returnRequest.status}`)
  }
  
  // Update return request
  await ReturnRequest.updateOne(
    { returnRequestId },
    {
      status: 'COMPLETED',
    }
  )
  
  // Get updated return request
  const updatedRequest = await getReturnRequestById(returnRequestId)
  
  return updatedRequest
}

// ============================================================================
// PRODUCT SIZE CHART FUNCTIONS
// ============================================================================

/**
 * Get size chart for a product
 */
export async function getProductSizeChart(productId: string): Promise<any | null> {
  await connectDB()
  
  const sizeChart = await ProductSizeChart.findOne({ productId }).lean()
  
  if (!sizeChart) {
    return null
  }
  
  return toPlainObject(sizeChart)
}

/**
 * Get size charts for multiple products (bulk fetch)
 */
export async function getProductSizeCharts(productIds: string[]): Promise<Record<string, any>> {
  await connectDB()
  
  const sizeCharts = await ProductSizeChart.find({ productId: { $in: productIds } }).lean()
  
  const result: Record<string, any> = {}
  sizeCharts.forEach((chart) => {
    result[chart.productId] = toPlainObject(chart)
  })
  
  return result
}

/**
 * Create or update size chart for a product
 */
export async function upsertProductSizeChart(
  productId: string,
  imageUrl: string,
  imageType: 'jpg' | 'jpeg' | 'png' | 'webp',
  fileName: string,
  fileSize: number
): Promise<any> {
  await connectDB()
  
  // Validate product exists
  const product = await Uniform.findOne({ id: productId }).lean()
  if (!product) {
    throw new Error(`Product with ID ${productId} not found`)
  }
  
  // Check if size chart already exists
  const existing = await ProductSizeChart.findOne({ productId })
  
  if (existing) {
    // Update existing
    existing.imageUrl = imageUrl
    existing.imageType = imageType
    existing.fileName = fileName
    existing.fileSize = fileSize
    await existing.save()
    return toPlainObject(existing)
  } else {
    // Create new
    const sizeChart = new ProductSizeChart({
      productId,
      imageUrl,
      imageType,
      fileName,
      fileSize,
    })
    await sizeChart.save()
    return toPlainObject(sizeChart)
  }
}

/**
 * Delete size chart for a product
 */
export async function deleteProductSizeChart(productId: string): Promise<boolean> {
  await connectDB()
  
  const result = await ProductSizeChart.deleteOne({ productId })
  return result.deletedCount > 0
}

// ============================================================================
// VENDOR-LED GRN WORKFLOW FUNCTIONS (INCREMENTAL EXTENSION)
// ============================================================================

/**
 * Get POs eligible for GRN creation by vendor
 * Returns POs where:
 * - PO.shippingStatus = FULLY_DELIVERED (derived from PRs)
 * - No GRN exists for the PO
 * - PO vendorId matches the requesting vendor
 * @param vendorId Vendor ID (6-digit numeric)
 * @returns Array of eligible POs with delivery details
 */
export async function getPOsEligibleForGRN(vendorId: string): Promise<any[]> {
  await connectDB()
  
  // Get vendor
  const vendor = await Vendor.findOne({ id: vendorId }).select('_id id name').lean()
  if (!vendor) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }
  
  // Get all POs for this vendor
  const pos = await PurchaseOrder.find({ vendorId: vendorId })
    .populate('companyId', 'id name')
    .sort({ po_date: -1 })
    .lean()
  
  if (pos.length === 0) {
    return []
  }
  
  // Get all existing GRNs to filter out POs that already have GRN
  const existingGRNs = await GRN.find({ vendorId: vendorId })
    .select('poNumber')
    .lean()
  
  const poNumbersWithGRN = new Set(existingGRNs.map((g: any) => g.poNumber))
  
  // For each PO, check if it's fully delivered and doesn't have GRN
  const eligiblePOs: any[] = []
  
  console.log(`[getPOsEligibleForGRN] Processing ${pos.length} PO(s) for vendor ${vendorId}`)
  
  for (const po of pos) {
    // Skip if GRN already exists
    if (poNumbersWithGRN.has(po.client_po_number)) {
      console.log(`[getPOsEligibleForGRN] PO ${po.client_po_number} already has GRN, skipping`)
      continue
    }
    
    console.log(`[getPOsEligibleForGRN] Checking PO ${po.client_po_number} (PO ID: ${po.id})`)
    
    // Derive shipping status from PRs
    try {
      const shippingStatus = await derivePOShippingStatus(po.id)
      console.log(`[getPOsEligibleForGRN] PO ${po.client_po_number} shipping status: ${shippingStatus}`)
      
      if (shippingStatus === 'FULLY_DELIVERED') {
        console.log(`[getPOsEligibleForGRN] ✅ PO ${po.client_po_number} is FULLY_DELIVERED, adding to eligible list`)
        // Get PRs linked to this PO to get delivery details (use string ID)
        const poOrderMappings = await POOrder.find({ purchase_order_id: po.id }).lean()
        if (poOrderMappings.length === 0) {
          continue
        }
        
        const orderIds = poOrderMappings.map(m => m.order_id)
        const prs = await Order.find({ id: { $in: orderIds } })
          .select('id pr_number deliveredDate items')
          .lean()
        
        // Calculate total items and delivery date
        let totalItems = 0
        let latestDeliveryDate: Date | null = null
        
        for (const pr of prs) {
          const items = pr.items || []
          totalItems += items.length
          
          if (pr.deliveredDate) {
            const deliveryDate = new Date(pr.deliveredDate)
            if (!latestDeliveryDate || deliveryDate > latestDeliveryDate) {
              latestDeliveryDate = deliveryDate
            }
          }
        }
        
        eligiblePOs.push({
          poId: po.id,
          poNumber: po.client_po_number,
          poDate: po.po_date,
          vendorId: po.vendorId,
          vendorName: vendor.name,
          companyId: (po.companyId as any)?.id || po.companyId,
          companyName: (po.companyId as any)?.name || '',
          deliveryDate: latestDeliveryDate,
          itemCount: totalItems,
          shippingStatus: shippingStatus
        })
      } else {
        console.log(`[getPOsEligibleForGRN] ⚠️ PO ${po.client_po_number} is not FULLY_DELIVERED (status: ${shippingStatus}), skipping`)
      }
    } catch (error: any) {
      console.error(`[getPOsEligibleForGRN] ❌ Error deriving shipping status for PO ${po.id} (${po.client_po_number}):`, error.message)
      console.error(`[getPOsEligibleForGRN] Error stack:`, error.stack)
      continue
    }
  }
  
  console.log(`[getPOsEligibleForGRN] ✅ Found ${eligiblePOs.length} eligible PO(s) for GRN creation`)
  
  return eligiblePOs.sort((a, b) => {
    const dateA = new Date(a.deliveryDate || 0).getTime()
    const dateB = new Date(b.deliveryDate || 0).getTime()
    return dateB - dateA
  })
}

/**
 * Create GRN by vendor (vendor-led workflow)
 * @param poNumber PO number
 * @param grnNumber GRN number (vendor provided)
 * @param grnDate GRN date
 * @param vendorId Vendor ID
 * @param remarks Optional remarks
 * @returns Created GRN
 */
export async function createGRNByVendor(
  poNumber: string,
  grnNumber: string,
  grnDate: Date,
  vendorId: string,
  remarks?: string
): Promise<any> {
  await connectDB()
  
  // Get vendor
  const vendor = await Vendor.findOne({ id: vendorId }).select('_id id name').lean()
  if (!vendor) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }
  
  // Get PO
  const Company = (await import('../models/Company')).default
  // NOTE: PurchaseOrder.companyId is a STRING field (6-digit numeric), NOT an ObjectId reference
  // Therefore .populate() won't work - we need to manually fetch company info
  const pos = await PurchaseOrder.find({ vendorId: vendorId, client_po_number: poNumber })
    .lean()
  
  if (pos.length === 0) {
    throw new Error(`PO not found: ${poNumber} for vendor ${vendorId}`)
  }
  
  const po = pos[0]
  // CRITICAL FIX: po.companyId is already a string ID (e.g., "123456"), not a populated object
  const companyIdString = typeof po.companyId === 'string' ? po.companyId : (po.companyId as any)?.id || String(po.companyId)
  
  // Manually fetch company for name (needed for response)
  const company = await Company.findOne({ id: companyIdString }).select('id name').lean()
  
  // Check if GRN already exists
  const existingGRN = await GRN.findOne({ poNumber: poNumber })
  if (existingGRN) {
    throw new Error(`GRN already exists for PO ${poNumber}. Only one GRN per PO is allowed.`)
  }
  
  // Validate PO is fully delivered
  const shippingStatus = await derivePOShippingStatus(po.id)
  if (shippingStatus !== 'FULLY_DELIVERED') {
    throw new Error(`PO ${poNumber} is not fully delivered (current status: ${shippingStatus}). All items must be fully delivered before creating GRN.`)
  }
  
  // Get all PRs (Orders) linked to this PO (use string ID)
  const poOrderMappings = await POOrder.find({ purchase_order_id: po.id }).lean()
  if (poOrderMappings.length === 0) {
    throw new Error(`No PRs found for PO ${poNumber}`)
  }
  
  const orderIds = poOrderMappings.map(m => m.order_id)
  const prs = await Order.find({ id: { $in: orderIds } })
    .select('id pr_number items deliveryStatus')
    .lean()
  
  if (prs.length === 0) {
    throw new Error(`No PRs found for PO ${poNumber}`)
  }
  
  // Validate all PRs are fully delivered
  for (const pr of prs) {
    if (pr.deliveryStatus !== 'DELIVERED') {
      throw new Error(`PR ${pr.pr_number || pr.id} is not fully delivered (current status: ${pr.deliveryStatus || 'NOT_DELIVERED'}). All PRs must be fully delivered before creating GRN.`)
    }
    
    const items = pr.items || []
    for (const item of items) {
      const orderedQty = item.quantity || 0
      const deliveredQty = item.deliveredQuantity || 0
      
      if (deliveredQty < orderedQty) {
        throw new Error(`PR ${pr.pr_number || pr.id} item has delivered quantity (${deliveredQty}) less than ordered quantity (${orderedQty}). All items must be fully delivered before creating GRN.`)
      }
    }
  }
  
  // Collect all items from all PRs for GRN
  const grnItems: Array<{
    productCode: string
    size: string
    orderedQuantity: number
    deliveredQuantity: number
    rejectedQuantity: number
    condition: 'ACCEPTED' | 'PARTIAL' | 'REJECTED'
    remarks?: string
  }> = []
  
  const prNumbers: string[] = []
  
  for (const pr of prs) {
    if (pr.pr_number) {
      prNumbers.push(pr.pr_number)
    }
    
    const items = pr.items || []
    for (const item of items) {
      const orderedQty = item.quantity || 0
      const deliveredQty = item.deliveredQuantity || 0
      
      grnItems.push({
        productCode: item.productId || '',
        size: item.size || '',
        orderedQuantity: orderedQty,
        deliveredQuantity: deliveredQty,
        rejectedQuantity: 0, // Default: no rejections
        condition: 'ACCEPTED', // Default: all accepted
        remarks: undefined
      })
    }
  }
  
  // Generate GRN ID (6-10 digit numeric)
  const grnId = String(Date.now()).slice(-10).padStart(6, '0')
  
  // Create GRN with vendor-led workflow flags
  const grn = await GRN.create({
    id: grnId,
    grnId: grnId,
    grnNumber: grnNumber.trim(),
    companyId: companyIdString, // Use string ID directly (not company.id which could be undefined)
    vendorId: vendorId,
    poNumber: poNumber,
    prNumbers: prNumbers,
    items: grnItems,
    status: 'CREATED',
    createdBy: vendorId, // Vendor ID as creator
    grnRaisedByVendor: true,
    grnAcknowledgedByCompany: false,
    grnStatus: 'RAISED', // Simple approval workflow: start as RAISED
    remarks: remarks?.trim()
  })
  
  console.log(`[createGRNByVendor] ✅ Created GRN: ${grnId} for PO: ${poNumber} by vendor: ${vendorId}`)
  
  // Return created GRN - use string id field instead of _id
  const createdGRN = await GRN.findOne({ id: grnId }).lean()
  
  const result = toPlainObject(createdGRN)
  if (vendor) {
    (result as any).vendorName = vendor.name
  }
  if (company && company.name) {
    (result as any).companyName = company.name
  }
  
  return result
}

/**
 * Get GRNs raised by vendor
 * @param vendorId Vendor ID
 * @returns Array of GRNs
 */
export async function getGRNsByVendor(vendorId: string): Promise<any[]> {
  await connectDB()
  
  // CRITICAL: Use .lean() to get all fields (no .select() to ensure all fields are returned)
  // This ensures grnStatus, approvedBy, approvedAt, and all other fields are included
  const grns = await GRN.find({ vendorId: vendorId, grnRaisedByVendor: true })
    .sort({ createdAt: -1 })
    .lean()
  
  console.log(`[getGRNsByVendor] Found ${grns.length} GRN(s) for vendor ${vendorId}`)
  
  // Get company names
  const companyIds = [...new Set(grns.map((g: any) => g.companyId).filter(Boolean))]
  const companies = await Company.find({ id: { $in: companyIds } })
    .select('id name')
    .lean()
  
  const companyMap = new Map(companies.map((c: any) => [c.id, c.name]))
  
  // Get PO dates for all GRNs
  const poNumbers = [...new Set(grns.map((g: any) => g.poNumber).filter(Boolean))]
  const pos = await PurchaseOrder.find({ client_po_number: { $in: poNumbers } })
    .select('client_po_number po_date')
    .lean()
  
  const poDateMap = new Map(pos.map((po: any) => [po.client_po_number, po.po_date]))
  
  return grns.map((grn: any) => {
    const plain = toPlainObject(grn)
    
    // CRITICAL: Explicitly ensure grnStatus and related fields are preserved
    if (grn.grnStatus !== undefined) {
      (plain as any).grnStatus = grn.grnStatus
    }
    if (grn.approvedBy !== undefined) {
      (plain as any).approvedBy = grn.approvedBy
    }
    if (grn.approvedAt !== undefined) {
      (plain as any).approvedAt = grn.approvedAt
    }
    if (grn.grnAcknowledgedByCompany !== undefined) {
      (plain as any).grnAcknowledgedByCompany = grn.grnAcknowledgedByCompany
    }
    if (grn.invoiceId !== undefined) {
      (plain as any).invoiceId = grn.invoiceId
    }
    
    if (plain.companyId && companyMap.has(plain.companyId)) {
      (plain as any).companyName = companyMap.get(plain.companyId)
    }
    if (plain.poNumber && poDateMap.has(plain.poNumber)) {
      (plain as any).poDate = poDateMap.get(plain.poNumber)
    }
    
    // Debug log for approved GRNs
    if (grn.grnStatus === 'APPROVED' || grn.status === 'ACKNOWLEDGED' || grn.grnAcknowledgedByCompany === true) {
      console.log(`[getGRNsByVendor] ✅ Approved GRN found: ${grn.id || grn.grnNumber}`, {
        grnStatus: grn.grnStatus,
        status: grn.status,
        grnAcknowledgedByCompany: grn.grnAcknowledgedByCompany,
        approvedBy: grn.approvedBy,
        invoiceId: grn.invoiceId
      })
    }
    
    return plain
  })
}

/**
 * Get all GRNs raised by vendors (for Company Admin)
 * Returns all GRNs where grnRaisedByVendor = true
 * @param companyId Company ID (optional filter)
 * @returns Array of GRNs raised by vendors
 */
export async function getGRNsRaisedByVendors(companyId?: string): Promise<any[]> {
  await connectDB()
  
  const query: any = {
    grnRaisedByVendor: true
  }
  
  if (companyId) {
    query.companyId = companyId
  }
  
  const grns = await GRN.find(query)
    .sort({ createdAt: -1 })
    .lean()
  
  // Get vendor and company names
  const vendorIds = [...new Set(grns.map((g: any) => g.vendorId).filter(Boolean))]
  const companyIds = [...new Set(grns.map((g: any) => g.companyId).filter(Boolean))]
  
  const vendors = await Vendor.find({ id: { $in: vendorIds } })
    .select('id name')
    .lean()
  
  const companies = await Company.find({ id: { $in: companyIds } })
    .select('id name')
    .lean()
  
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  const companyMap = new Map(companies.map((c: any) => [c.id, c.name]))
  
  // Get PO dates for all GRNs
  const poNumbers = [...new Set(grns.map((g: any) => g.poNumber).filter(Boolean))]
  const pos = await PurchaseOrder.find({ client_po_number: { $in: poNumbers } })
    .select('client_po_number po_date')
    .lean()
  
  const poDateMap = new Map(pos.map((po: any) => [po.client_po_number, po.po_date]))
  
  return grns.map((grn: any) => {
    const plain = toPlainObject(grn)
    if (plain.vendorId && vendorMap.has(plain.vendorId)) {
      (plain as any).vendorName = vendorMap.get(plain.vendorId)
    }
    if (plain.companyId && companyMap.has(plain.companyId)) {
      (plain as any).companyName = companyMap.get(plain.companyId)
    }
    if (plain.poNumber && poDateMap.has(plain.poNumber)) {
      (plain as any).poDate = poDateMap.get(plain.poNumber)
    }
    return plain
  })
}

/**
 * Get GRNs pending acknowledgment by Company Admin
 * Returns GRNs where:
 * - grnStatus = RAISED (or undefined/null, for backward compatibility)
 * - grnRaisedByVendor = true
 * @param companyId Company ID (optional filter)
 * @returns Array of GRNs pending acknowledgment
 */
export async function getGRNsPendingAcknowledgment(companyId?: string): Promise<any[]> {
  await connectDB()
  
  const query: any = {
    grnRaisedByVendor: true,
    $or: [
      { grnStatus: 'RAISED' },
      { grnStatus: { $exists: false } }, // Backward compatibility: treat missing grnStatus as RAISED
      { grnStatus: null }
    ]
  }
  
  if (companyId) {
    query.companyId = companyId
  }
  
  const grns = await GRN.find(query)
    .sort({ createdAt: -1 })
    .lean()
  
  // Get vendor and company names
  const vendorIds = [...new Set(grns.map((g: any) => g.vendorId).filter(Boolean))]
  const companyIds = [...new Set(grns.map((g: any) => g.companyId).filter(Boolean))]
  
  const vendors = await Vendor.find({ id: { $in: vendorIds } })
    .select('id name')
    .lean()
  
  const companies = await Company.find({ id: { $in: companyIds } })
    .select('id name')
    .lean()
  
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  const companyMap = new Map(companies.map((c: any) => [c.id, c.name]))
  
  return grns.map((grn: any) => {
    const plain = toPlainObject(grn)
    if (plain.vendorId && vendorMap.has(plain.vendorId)) {
      (plain as any).vendorName = vendorMap.get(plain.vendorId)
    }
    if (plain.companyId && companyMap.has(plain.companyId)) {
      (plain as any).companyName = companyMap.get(plain.companyId)
    }
    return plain
  })
}

/**
 * Acknowledge GRN by Company Admin
 * @param grnId GRN ID
 * @param acknowledgedBy Company Admin ID/name
 * @returns Updated GRN
 */
export async function acknowledgeGRN(
  grnId: string,
  acknowledgedBy: string
): Promise<any> {
  await connectDB()
  
  const grn = await GRN.findOne({ id: grnId })
  if (!grn) {
    throw new Error(`GRN not found: ${grnId}`)
  }
  
  // Validate GRN is in CREATED status and raised by vendor
  if (grn.status !== 'CREATED') {
    throw new Error(`GRN ${grnId} is not in CREATED status (current: ${grn.status})`)
  }
  
  if (!grn.grnRaisedByVendor) {
    throw new Error(`GRN ${grnId} was not raised by vendor and cannot be acknowledged`)
  }
  
  // Update GRN
  grn.status = 'ACKNOWLEDGED'
  grn.grnAcknowledgedByCompany = true
  grn.grnAcknowledgedDate = new Date()
  grn.grnAcknowledgedBy = acknowledgedBy.trim()
  
  await grn.save()
  
  console.log(`[acknowledgeGRN] ✅ Acknowledged GRN: ${grnId} by: ${acknowledgedBy}`)
  
  // Return updated GRN - use string id field instead of _id
  const updatedGRN = await GRN.findOne({ id: grnId }).lean()
  
  // Add vendor and company names
  let vendorName = null
  let companyName = null
  if (updatedGRN && updatedGRN.vendorId) {
    const vendor = await Vendor.findOne({ id: updatedGRN.vendorId }).select('id name').lean()
    if (vendor) {
      vendorName = (vendor as any).name
    }
  }
  if (updatedGRN && updatedGRN.companyId) {
    const company = await Company.findOne({ id: updatedGRN.companyId }).select('id name').lean()
    if (company) {
      companyName = (company as any).name
    }
  }
  
  const result = toPlainObject(updatedGRN)
  if (vendorName) {
    (result as any).vendorName = vendorName
  }
  if (companyName) {
    (result as any).companyName = companyName
  }
  
  return result
}

/**
 * Approve GRN by Company Admin (Simple Approval Workflow)
 * Updates grnStatus from RAISED to APPROVED
 * @param grnId GRN ID
 * @param approvedBy Company Admin identifier
 * @returns Updated GRN
 */
export async function approveGRN(
  grnId: string,
  approvedBy: string
): Promise<any> {
  await connectDB()
  
  const grn = await GRN.findOne({ id: grnId })
  if (!grn) {
    throw new Error(`GRN not found: ${grnId}`)
  }
  
  // Validate GRN is in RAISED status
  if (grn.grnStatus && grn.grnStatus !== 'RAISED') {
    throw new Error(`GRN ${grnId} is not in RAISED status (current: ${grn.grnStatus})`)
  }
  
  // Update GRN
  grn.grnStatus = 'APPROVED'
  grn.approvedBy = approvedBy.trim()
  grn.approvedAt = new Date()
  
  await grn.save()
  
  console.log(`[approveGRN] ✅ Approved GRN: ${grnId} by: ${approvedBy}`)
  
  // Return updated GRN - use string id field instead of _id
  const updatedGRN = await GRN.findOne({ id: grnId }).lean()
  
  // Add vendor and company names
  let vendorName = null
  let companyName = null
  if (updatedGRN && updatedGRN.vendorId) {
    const vendor = await Vendor.findOne({ id: updatedGRN.vendorId }).select('id name').lean()
    if (vendor) {
      vendorName = (vendor as any).name
    }
  }
  if (updatedGRN && updatedGRN.companyId) {
    const company = await Company.findOne({ id: updatedGRN.companyId }).select('id name').lean()
    if (company) {
      companyName = (company as any).name
    }
  }
  
  const result = toPlainObject(updatedGRN)
  if (vendorName) {
    (result as any).vendorName = vendorName
  }
  if (companyName) {
    (result as any).companyName = companyName
  }
  
  return result
}

/**
 * Create Invoice by vendor
 * Invoice can be created ONLY if GRN status is APPROVED
 * @param grnId GRN ID
 * @param invoiceNumber System-generated invoice number (internal to UDS)
 * @param invoiceDate System-generated invoice date (internal to UDS)
 * @param vendorInvoiceNumber Vendor-provided invoice number (required)
 * @param vendorInvoiceDate Vendor-provided invoice date (required)
 * @param invoiceAmount Invoice amount (calculated from items + optional tax)
 * @param vendorId Vendor ID (for authorization)
 * @param remarks Optional invoice remarks
 * @param taxAmount Optional tax or additional charges
 * @returns Created Invoice with pre-populated data
 */
export async function createInvoiceByVendor(
  grnId: string,
  invoiceNumber: string,
  invoiceDate: Date,
  vendorInvoiceNumber: string,
  vendorInvoiceDate: Date,
  invoiceAmount: number,
  vendorId: string,
  remarks?: string,
  taxAmount?: number
): Promise<any> {
  await connectDB()
  
  // Get GRN with full details
  const grn = await GRN.findOne({ id: grnId }).lean()
  if (!grn) {
    throw new Error(`GRN not found: ${grnId}`)
  }
  
  // Validate vendor authorization
  if (grn.vendorId !== vendorId) {
    throw new Error(`Vendor ${vendorId} is not authorized to create invoice for GRN ${grnId}`)
  }
  
  // Validate GRN is approved (supports both new and old approval workflows)
  const isApproved = grn.grnStatus === 'APPROVED' || 
                     grn.grnAcknowledgedByCompany === true || 
                     grn.status === 'ACKNOWLEDGED'
  
  if (!isApproved) {
    throw new Error(`GRN ${grnId} must be APPROVED before creating invoice (current status: ${grn.grnStatus || grn.status || 'RAISED'})`)
  }
  
  // Retrofit: If GRN was approved via old workflow but doesn't have grnStatus set, update it
  if (grn.grnStatus !== 'APPROVED' && (grn.grnAcknowledgedByCompany === true || grn.status === 'ACKNOWLEDGED')) {
    grn.grnStatus = 'APPROVED'
    if (!grn.approvedBy && grn.grnAcknowledgedBy) {
      grn.approvedBy = grn.grnAcknowledgedBy
    }
    if (!grn.approvedAt && grn.grnAcknowledgedDate) {
      grn.approvedAt = grn.grnAcknowledgedDate
    }
    await grn.save()
    console.log(`[createInvoiceByVendor] ✅ Retrofit: Updated GRN ${grnId} to have grnStatus = APPROVED`)
  }
  
  // Check if invoice already exists for this GRN
  const existingInvoice = await Invoice.findOne({ grnId: grnId })
  if (existingInvoice) {
    throw new Error(`Invoice already exists for GRN ${grnId}. Only one invoice per GRN is allowed.`)
  }
  
  // Get product details for invoice items
  const ProductVendor = (await import('../models/Relationship')).ProductVendor
  
  const productCodes = [...new Set(grn.items.map((item: any) => item.productCode).filter(Boolean))]
  
  // Get products from Uniform model (using product codes which are stored in 'id' field)
  const products = await Uniform.find({ id: { $in: productCodes } })
    .select('id name _id')
    .lean()
  
  const productMap = new Map(products.map((p: any) => [p.id, p]))
  
  // Extract product ObjectIds for ProductVendor query
  // ProductVendor.productId is an ObjectId, not a string product code
  const productObjectIds = products.map((p: any) => p._id).filter(Boolean)
  
  // Convert vendorId (6-digit string) to ObjectId for query (ProductVendor uses ObjectId for vendorId)
  // Also fetch vendor name for later use in response
  // Note: Vendor is already imported at the top of the file
  const vendorForQuery = await Vendor.findOne({ id: vendorId }).select('_id id name').lean()
  if (!vendorForQuery) {
    throw new Error(`Vendor not found: ${vendorId}`)
  }
  const vendorObjectId = vendorForQuery._id
  
  // Get vendor prices for products using ObjectIds
  const productVendors = await ProductVendor.find({
    vendorId: vendorObjectId,
    productId: { $in: productObjectIds }
  }).lean()
  
  // Create a map: product ObjectId -> price
  const priceMapByObjectId = new Map(productVendors.map((pv: any) => {
    const productIdStr = pv.productId?.toString() || ''
    return [productIdStr, pv.price || 0]
  }))
  
  // Create a map: product code (id) -> price (for easy lookup by product code)
  const priceMap = new Map<string, number>()
  products.forEach((p: any) => {
    const productObjectIdStr = p._id?.toString() || ''
    const price = priceMapByObjectId.get(productObjectIdStr) || 0
    priceMap.set(p.id, price)
  })
  
  // Build invoice items from GRN items
  const invoiceItems: Array<{
    productCode: string
    productName?: string
    size?: string
    quantity: number
    unitPrice: number
    lineTotal: number
  }> = []
  
  let calculatedTotal = 0
  
  for (const grnItem of grn.items) {
    const product = productMap.get(grnItem.productCode)
    const unitPrice = priceMap.get(grnItem.productCode) || 0
    const quantity = grnItem.deliveredQuantity || grnItem.orderedQuantity || 0
    const lineTotal = unitPrice * quantity
    
    invoiceItems.push({
      productCode: grnItem.productCode,
      productName: product?.name,
      size: grnItem.size,
      quantity: quantity,
      unitPrice: unitPrice,
      lineTotal: lineTotal
    })
    
    calculatedTotal += lineTotal
  }
  
  // Add tax if provided
  if (taxAmount && taxAmount > 0) {
    calculatedTotal += taxAmount
  }
  
  // Use provided invoiceAmount or calculated total
  const finalAmount = invoiceAmount > 0 ? invoiceAmount : calculatedTotal
  
  // Generate Invoice ID (6-10 digit numeric)
  const invoiceId = String(Date.now()).slice(-10).padStart(6, '0')
  
  // Create Invoice with all required fields
  const invoice = await Invoice.create({
    id: invoiceId,
    invoiceId: invoiceId,
    invoiceNumber: invoiceNumber.trim(), // System-generated (internal)
    invoiceDate: invoiceDate, // System-generated (internal)
    vendorInvoiceNumber: vendorInvoiceNumber.trim(), // Vendor-provided (required)
    vendorInvoiceDate: vendorInvoiceDate, // Vendor-provided (required)
    vendorId: vendorId,
    companyId: grn.companyId,
    grnId: grnId,
    grnNumber: grn.grnNumber,
    grnApprovedDate: grn.approvedAt || null,
    poNumber: grn.poNumber,
    prNumbers: grn.prNumbers || [],
    invoiceItems: invoiceItems,
    invoiceAmount: finalAmount,
    invoiceStatus: 'RAISED',
    raisedBy: vendorId,
    remarks: remarks?.trim(),
    taxAmount: taxAmount || 0
  })
  
  // Update GRN to link invoice (but don't change GRN status - keep it APPROVED)
  await GRN.updateOne({ id: grnId }, { invoiceId: invoiceId })
  
  console.log(`[createInvoiceByVendor] ✅ Created Invoice: ${invoiceId} for GRN: ${grnId}`)
  
  // Return created invoice with vendor and company names - use string id field instead of _id
  const createdInvoice = await Invoice.findOne({ id: invoiceId }).lean()
  
  // Reuse vendor data already fetched above (vendorForQuery)
  const company = await Company.findOne({ id: grn.companyId }).select('id name').lean()
  
  const result = toPlainObject(createdInvoice)
  if (vendorForQuery) {
    (result as any).vendorName = vendorForQuery.name
  }
  if (company) {
    (result as any).companyName = company.name
  }
  
  return result
}

/**
 * Get Invoices by vendor
 * @param vendorId Vendor ID
 * @returns Array of invoices
 */
export async function getInvoicesByVendor(vendorId: string): Promise<any[]> {
  await connectDB()
  
  const invoices = await Invoice.find({ vendorId: vendorId })
    .sort({ invoiceDate: -1, createdAt: -1 })
    .lean()
  
  // Get company names
  const companyIds = [...new Set(invoices.map((i: any) => i.companyId).filter(Boolean))]
  const companies = await Company.find({ id: { $in: companyIds } })
    .select('id name')
    .lean()
  
  const companyMap = new Map(companies.map((c: any) => [c.id, c.name]))
  
  return invoices.map((invoice: any) => {
    const plain = toPlainObject(invoice)
    if (plain.companyId && companyMap.has(plain.companyId)) {
      (plain as any).companyName = companyMap.get(plain.companyId)
    }
    return plain
  })
}

/**
 * Get Invoices for Company Admin
 * @param companyId Company ID (optional filter)
 * @returns Array of invoices
 */
export async function getInvoicesForCompany(companyId?: string): Promise<any[]> {
  await connectDB()
  
  const query: any = {}
  if (companyId) {
    query.companyId = companyId
  }
  
  const invoices = await Invoice.find(query)
    .sort({ invoiceDate: -1, createdAt: -1 })
    .lean()
  
  // Get vendor names
  const vendorIds = [...new Set(invoices.map((i: any) => i.vendorId).filter(Boolean))]
  const vendors = await Vendor.find({ id: { $in: vendorIds } })
    .select('id name')
    .lean()
  
  const vendorMap = new Map(vendors.map((v: any) => [v.id, v.name]))
  
  return invoices.map((invoice: any) => {
    const plain = toPlainObject(invoice)
    if (plain.vendorId && vendorMap.has(plain.vendorId)) {
      (plain as any).vendorName = vendorMap.get(plain.vendorId)
    }
    return plain
  })
}

/**
 * Approve Invoice by Company Admin
 * @param invoiceId Invoice ID
 * @param approvedBy Company Admin identifier
 * @returns Updated Invoice
 */
export async function approveInvoice(
  invoiceId: string,
  approvedBy: string
): Promise<any> {
  await connectDB()
  
  const invoice = await Invoice.findOne({ id: invoiceId })
  if (!invoice) {
    throw new Error(`Invoice not found: ${invoiceId}`)
  }
  
  // Validate invoice is in RAISED status
  if (invoice.invoiceStatus !== 'RAISED') {
    throw new Error(`Invoice ${invoiceId} is not in RAISED status (current: ${invoice.invoiceStatus})`)
  }
  
  // Update invoice
  invoice.invoiceStatus = 'APPROVED'
  invoice.approvedBy = approvedBy.trim()
  invoice.approvedAt = new Date()
  
  await invoice.save()
  
  console.log(`[approveInvoice] ✅ Approved Invoice: ${invoiceId} by: ${approvedBy}`)
  
  // Return updated invoice with vendor and company names
  const invoiceIdStr = invoice.id || String(invoice._id || '')
  const updatedInvoice = await Invoice.findOne({ id: invoiceIdStr }).lean()
  
  const vendor = await Vendor.findOne({ id: invoice.vendorId }).select('id name').lean()
  const company = await Company.findOne({ id: invoice.companyId }).select('id name').lean()
  
  const result = toPlainObject(updatedInvoice)
  if (vendor) {
    (result as any).vendorName = vendor.name
  }
  if (company) {
    (result as any).companyName = company.name
  }
  
  return result
}

// ============================================================================
// SHIPPING / LOGISTICS PROVIDER CONFIGURATION FUNCTIONS
// ============================================================================

/**
 * Generate alphanumeric ID for shipping entities (≤15 chars)
 */
function generateShippingId(prefix: string): string {
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = Math.random().toString(36).substring(2, 6).toUpperCase()
  const id = `${prefix}_${timestamp}${random}`.substring(0, 15)
  return id
}

// Explicit export to ensure module is recognized by Turbopack
export {}