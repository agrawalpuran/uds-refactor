import { NextResponse } from 'next/server'
import {
  createPayment,
  completePayment,
} from '@/lib/db/indent-workflow'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { invoice_id, vendor_id, payment_reference, payment_date, amount_paid, action } = body

    if (action === 'create') {
      if (!invoice_id || !vendor_id || !payment_reference || !payment_date || !amount_paid) {
        return NextResponse.json(
          { error: 'Missing required fields' },
          { status: 400 }
        )
      }

      const payment = await createPayment({
        invoice_id,
        vendor_id,
        payment_reference,
        payment_date: new Date(payment_date),
        amount_paid,
      })

      return NextResponse.json({ success: true, payment }, { status: 201 })
    }

    if (action === 'complete') {
      if (!invoice_id) {
        return NextResponse.json(
          { error: 'invoice_id is required' },
          { status: 400 }
        )
      }

      // Find payment by invoice_id
      const { Payment } = await import('@/lib/models/Payment')
      const payment = await Payment.findOne({ invoice_id }).lean()
      
      if (!payment) {
        return NextResponse.json(
          { error: 'Payment not found' },
          { status: 404 }
        )
      }

      const completedPayment = await completePayment(payment._id)
      
      return NextResponse.json({ success: true, payment: completedPayment })
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error: any) {
    console.error('Error processing payment:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to process payment' },
      { status: 500 }
    )
  }
}

