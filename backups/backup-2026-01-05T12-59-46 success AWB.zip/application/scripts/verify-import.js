// Quick verification that connectDB import works
import connectDB from '@/lib/db/mongodb'
console.log('✅ connectDB import successful:', typeof connectDB)
