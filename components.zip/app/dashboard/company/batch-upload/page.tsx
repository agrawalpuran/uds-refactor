'use client'

import { useState } from 'react'
import DashboardLayout from '@/components/DashboardLayout'
import { Upload, Download, FileText, CheckCircle } from 'lucide-react'

export default function BatchUploadPage() {
  const [file, setFile] = useState<File | null>(null)
  const [uploaded, setUploaded] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
      setUploaded(false)
    }
  }

  const handleUpload = () => {
    if (file) {
      // Simulate upload
      setTimeout(() => {
        setUploaded(true)
        alert('Batch upload successful! Employees have been added to the system.')
      }, 1500)
    }
  }

  const downloadTemplate = () => {
    const csvContent = `First Name,Last Name,Designation,Gender,Location,Email,Mobile,Shirt Size,Pant Size,Shoe Size,Address,Dispatch Preference,Status
John,Doe,Software Engineer,Male,New York Office,john.doe@company.com,+1234567890,L,32,10,123 Main St New York NY 10001,direct,active
Jane,Smith,Product Manager,Female,San Francisco Office,jane.smith@company.com,+1234567891,M,28,7,456 Market St San Francisco CA 94102,regional,active`
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'employee_template.csv'
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <DashboardLayout actorType="company">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Batch Employee Upload</h1>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Upload Employee Data</h2>
            
            <div className="mb-6">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                {file ? (
                  <div>
                    <FileText className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <p className="text-gray-900 font-semibold">{file.name}</p>
                    <p className="text-gray-600 text-sm">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                ) : (
                  <div>
                    <p className="text-gray-600 mb-2">Drag and drop your CSV file here</p>
                    <p className="text-gray-500 text-sm mb-4">or</p>
                    <label className="inline-block bg-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-purple-700 transition-colors cursor-pointer">
                      Browse Files
                      <input
                        type="file"
                        accept=".csv"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>
                )}
              </div>
            </div>

            {file && !uploaded && (
              <button
                onClick={handleUpload}
                className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors"
              >
                Upload and Process
              </button>
            )}

            {uploaded && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <div>
                  <p className="font-semibold text-green-900">Upload Successful!</p>
                  <p className="text-sm text-green-700">Employees have been added to the system.</p>
                </div>
              </div>
            )}
          </div>

          {/* Instructions Section */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Instructions</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Required Columns:</h3>
                <ul className="list-disc list-inside text-gray-600 space-y-1 text-sm">
                  <li>First Name</li>
                  <li>Last Name</li>
                  <li>Designation</li>
                  <li>Gender (Male/Female)</li>
                  <li>Location</li>
                  <li>Email</li>
                  <li>Mobile</li>
                  <li>Shirt Size</li>
                  <li>Pant Size</li>
                  <li>Shoe Size</li>
                  <li>Address</li>
                  <li>Dispatch Preference (direct/central/regional)</li>
                  <li>Status (active/inactive)</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Eligibility Configuration:</h3>
                <p className="text-gray-600 text-sm">
                  After upload, you can configure eligibility (number of items allowed per time period) for each employee in the Employee Management section.
                </p>
              </div>
            </div>

            <button
              onClick={downloadTemplate}
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Download className="h-5 w-5" />
              <span>Download Template</span>
            </button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}









