'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import DashboardLayout from '@/components/DashboardLayout'
import { Users, ShoppingCart, DollarSign, TrendingUp, FileText, CheckCircle, IndianRupee } from 'lucide-react'
import { getEmployeesByCompany, getOrdersByCompany, getProductsByCompany, getCompanyByAdminEmail, isCompanyAdmin, getPendingApprovalCount } from '@/lib/data-mongodb'

export default function CompanyDashboard() {
  const [companyId, setCompanyId] = useState<string>('')
  const [companyEmployees, setCompanyEmployees] = useState<any[]>([])
  const [companyOrders, setCompanyOrders] = useState<any[]>([])
  const [pendingApprovalCount, setPendingApprovalCount] = useState<number>(0)
  const [loading, setLoading] = useState(true)
  const [accessDenied, setAccessDenied] = useState(false)
  const router = useRouter()
  
  // Verify admin access and get company ID
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const verifyAccess = async () => {
        try {
          setLoading(true)
          const userEmail = localStorage.getItem('userEmail')
          if (!userEmail) {
            setAccessDenied(true)
            setLoading(false)
            return
          }

          // Get company by admin email
          const company = await getCompanyByAdminEmail(userEmail)
          if (!company) {
            setAccessDenied(true)
            setLoading(false)
            alert('Access denied: You are not authorized as a company admin. Please contact your super admin.')
            router.push('/login/company')
            return
          }

          // Verify admin status
          const adminStatus = await isCompanyAdmin(userEmail, company.id)
          if (!adminStatus) {
            setAccessDenied(true)
            setLoading(false)
            alert('Access denied: You are not authorized as a company admin.')
            router.push('/login/company')
            return
          }

          // Set company ID and load data
          setCompanyId(company.id)
          localStorage.setItem('companyId', company.id)
          
          // Filter employees by company - only show employees linked to this company
          const filtered = await getEmployeesByCompany(company.id)
          setCompanyEmployees(filtered)
          // Filter orders by company
          const orders = await getOrdersByCompany(company.id)
          console.log('Company Dashboard - Orders loaded:', orders.length, orders)
          if (orders.length > 0) {
            console.log('First order sample:', orders[0])
            console.log('First order total:', orders[0].total)
            console.log('First order items:', orders[0].items)
          }
          setCompanyOrders(orders)
          // Get pending approval count
          const pendingCount = await getPendingApprovalCount(company.id)
          setPendingApprovalCount(pendingCount)
        } catch (error) {
          console.error('Error loading company data:', error)
          setAccessDenied(true)
          alert('Error verifying access. Please try logging in again.')
          router.push('/login/company')
        } finally {
          setLoading(false)
        }
      }
      
      verifyAccess()
    }
  }, [router])
  
  const activeEmployees = companyEmployees.filter(e => e.status === 'active').length
  const totalOrders = companyOrders.length
  // Calculate total spent - always calculate from items to ensure accuracy
  const totalSpent = companyOrders.reduce((sum, order) => {
    // Always calculate from items if available (more reliable)
    if (order.items && Array.isArray(order.items) && order.items.length > 0) {
      const calculatedTotal = order.items.reduce((itemSum: number, item: any) => {
        const price = typeof item.price === 'number' ? item.price : parseFloat(item.price) || 0
        const quantity = typeof item.quantity === 'number' ? item.quantity : parseInt(item.quantity) || 0
        const itemTotal = price * quantity
        return itemSum + itemTotal
      }, 0)
      if (calculatedTotal > 0) {
        return sum + calculatedTotal
      }
    }
    // Fallback to order.total if items calculation fails
    if (order.total !== undefined && order.total !== null && typeof order.total === 'number' && !isNaN(order.total) && order.total > 0) {
      return sum + order.total
    }
    console.warn(`Order ${order.id}: Could not calculate total - total=${order.total}, items=${order.items?.length || 0}`)
    return sum
  }, 0)
  
  console.log('Total spent calculated:', totalSpent, 'from', companyOrders.length, 'orders')
  const pendingOrders = companyOrders.filter(o => o.status === 'pending' || o.status === 'confirmed').length

  const stats = [
    { name: 'Active Employees', value: activeEmployees, icon: Users, color: 'blue' },
    { name: 'Total Orders', value: totalOrders, icon: ShoppingCart, color: 'purple' },
    { name: 'Total Spent', value: `₹${totalSpent.toFixed(2)}`, icon: IndianRupee, color: 'green' },
    { name: 'Pending Approvals', value: pendingApprovalCount, icon: CheckCircle, color: 'orange' },
  ]

  if (loading) {
    return (
      <DashboardLayout actorType="company">
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <p className="text-gray-600">Verifying access...</p>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  if (accessDenied) {
    return (
      <DashboardLayout actorType="company">
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center bg-red-50 border border-red-200 rounded-lg p-8 max-w-md">
            <h2 className="text-2xl font-bold text-red-900 mb-4">Access Denied</h2>
            <p className="text-red-700 mb-4">
              You are not authorized to access the company portal. Only assigned company administrators can log in.
            </p>
            <button
              onClick={() => router.push('/login/company')}
              className="bg-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-purple-700 transition-colors"
            >
              Back to Login
            </button>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout actorType="company">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Company Dashboard</h1>
        
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => {
            const Icon = stat.icon
            const getColorClasses = (color: string) => {
              const colors: Record<string, { bg: string; text: string }> = {
                blue: { bg: 'bg-blue-100', text: 'text-blue-600' },
                purple: { bg: 'bg-purple-100', text: 'text-purple-600' },
                green: { bg: 'bg-green-100', text: 'text-green-600' },
                orange: { bg: 'bg-orange-100', text: 'text-orange-600' },
              }
              return colors[color] || colors.blue
            }
            const colorClasses = getColorClasses(stat.color)
            return (
              <div key={stat.name} className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-1">{stat.name}</p>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`${colorClasses.bg} p-3 rounded-lg`}>
                    <Icon className={`h-6 w-6 ${colorClasses.text}`} />
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <button className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">
                Upload Employee Data
              </button>
              <Link
                href="/dashboard/company/employees"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors text-center block"
              >
                Place Bulk Order
              </Link>
              <button className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                Generate Report
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
            <div className="space-y-3">
              {companyOrders.slice(0, 3).map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold text-gray-900">{order.employeeName}</p>
                    <p className="text-sm text-gray-600">Order #{order.id}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    order.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {order.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Employee Overview */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Employee Overview</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Employee ID</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Name</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Designation</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Location</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Email</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {companyEmployees.slice(0, 10).map((employee) => (
                  <tr key={employee.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <span className="font-mono text-sm font-semibold text-blue-600">
                        {employee.employeeId || 'N/A'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-900 font-medium">{employee.firstName} {employee.lastName}</td>
                    <td className="py-3 px-4 text-gray-600">{employee.designation}</td>
                    <td className="py-3 px-4 text-gray-600">{employee.location}</td>
                    <td className="py-3 px-4 text-gray-600">{employee.email}</td>
                    <td className="py-3 px-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        employee.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                      }`}>
                        {employee.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}

